import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import { AppProvider } from './context/AppContext.tsx';
import { ToastProvider } from './components/ui/Toast.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import './index.css';

// ---------------------------------------------------------------------------
// PWA & Service Worker Safety Guard:
// Prevent unexpected automatic page reloads caused by stale service workers,
// controllerchange events, unhandled promise rejections, or error listeners.
// ---------------------------------------------------------------------------
if (typeof window !== 'undefined') {
  // Anti-loop breaker: detect rapid successive reloads (< 7s apart) and recover safely
  try {
    const LOOP_COUNT_KEY = 'pwa_rapid_reload_count';
    const LOOP_TIME_KEY = 'pwa_rapid_reload_ts';
    const now = Date.now();
    const lastTime = parseInt(sessionStorage.getItem(LOOP_TIME_KEY) || '0', 10);
    let count = parseInt(sessionStorage.getItem(LOOP_COUNT_KEY) || '0', 10);

    if (now - lastTime < 7000) {
      count += 1;
    } else {
      count = 1;
    }
    sessionStorage.setItem(LOOP_TIME_KEY, String(now));
    sessionStorage.setItem(LOOP_COUNT_KEY, String(count));

    if (count >= 3) {
      console.warn('[PWA Guard] Rapid reload loop detected! Unregistering all Service Workers to restore stability.');
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.getRegistrations().then((regs) => {
          for (const reg of regs) {
            reg.unregister();
          }
        }).catch(() => {});
      }
      sessionStorage.removeItem(LOOP_COUNT_KEY);
      sessionStorage.removeItem('pwa_update_in_progress');
    }
  } catch {
    // Non-blocking
  }

  // Prevent aggressive SW auto-reloads on controllerchange
  if ('serviceWorker' in navigator) {
    try {
      navigator.serviceWorker.addEventListener('controllerchange', (e) => {
        // Log gracefully instead of calling location.reload()
        console.info('[PWA Guard] Service worker controller updated silently without forcing page reload.', e);
      });
    } catch {
      // Ignore
    }
  }

  // Global unhandled promise rejection guard
  window.addEventListener('unhandledrejection', (event) => {
    console.warn('[Global Guard] Handled unhandled promise rejection without reloading:', event.reason);
    event.preventDefault();
  });

  // Global error listener to log without refreshing
  window.addEventListener('error', (event) => {
    console.warn('[Global Guard] Handled window error gracefully without reloading:', event.error || event.message);
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <AppProvider>
        <ToastProvider>
          <App />
        </ToastProvider>
      </AppProvider>
    </ErrorBoundary>
  </StrictMode>,
);
