import React, { useState, useEffect, useMemo, useRef, useCallback, memo } from 'react';
import { gsap } from 'gsap';
import {
  LayoutDashboard,
  LayoutGrid,
  Wallet,
  FileText,
  Settings,
  Lock,
  Bell,
  BadgeAlert,
  Layers,
  Users,
  Calendar,
  FileSpreadsheet,
  Bot,
  Search,
  Phone,
  ShieldAlert,
  MoreHorizontal,
  User,
  Eye,
  EyeOff,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useApp } from '../context/AppContext';
import { getCNHStatus, getDaysUntil, isInstallmentOverdue } from '../utils/formatters';
import { Logo } from './Logo';
import { MotoIcon, KitnetIcon } from './CategoryIcons';
import { MoreMenuDrawer } from './MoreMenuDrawer';
import { ThemeToggle } from './ui/theme-toggle';
import { useRenderTracker } from '../utils/perfLogger';
import { COLORS } from '../styles/colors';
import { gsapButtonPress } from '../utils/gsapAnimations';

export type TabType =
  | 'dashboard'
  | 'cobrancas'
  | 'motos'
  | 'kitnets'
  | 'clientes'
  | 'calendario'
  | 'financeiro'
  | 'relatorios'
  | 'documentos'
  | 'configuracoes';

interface NavigationProps {
  activeTab?: TabType;
  currentTab?: TabType;
  onTabChange?: (tab: TabType) => void;
  onSelectTab?: (tab: TabType) => void;
  onOpenSettings?: () => void;
  onOpenNotifications: () => void;
  onOpenSearch?: () => void;
  onOpenContacts?: () => void;
  onOpenSimulator?: () => void;
  onOpenPwaGuide?: () => void;
}

export const NavigationComponent: React.FC<NavigationProps> = ({
  activeTab,
  currentTab,
  onTabChange,
  onSelectTab,
  onOpenSettings,
  onOpenNotifications,
  onOpenSearch,
  onOpenContacts,
  onOpenSimulator,
  onOpenPwaGuide,
}) => {
  useRenderTracker('Navigation');
  const current = activeTab || currentTab || 'dashboard';
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);

  // Dynamic Scroll Overlay & Header Glow
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    let ticking = false;

    const updateScroll = () => {
      const scrollY =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop ||
        window.scrollY ||
        (document.getElementById('root')?.scrollTop || 0);
      const nextScrolled = scrollY > 10;
      setIsScrolled((prev) => (prev !== nextScrolled ? nextScrolled : prev));
      ticking = false;
    };

    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(updateScroll);
        ticking = true;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true, capture: true });
    document.addEventListener('scroll', handleScroll, { passive: true, capture: true });
    updateScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll, true);
      document.removeEventListener('scroll', handleScroll, true);
    };
  }, []);

  const {
    lockApp,
    motos,
    kitnets,
    motoTenants,
    motoContracts,
    kitnetContracts,
    expenses,
    isReadOnlyMode,
    toggleReadOnlyMode,
    isDemoMode,
    toggleDemoMode,
  } = useApp();

  const [showExitReadOnlyModal, setShowExitReadOnlyModal] = useState(false);

  const handleSelect = (tab: TabType) => {
    if (isReadOnlyMode && tab !== 'dashboard') {
      return;
    }
    if (onTabChange) onTabChange(tab);
    else if (onSelectTab) onSelectTab(tab);
  };

  const handleSettings = () => {
    if (isReadOnlyMode) {
      setShowExitReadOnlyModal(true);
      return;
    }
    if (onOpenSettings) onOpenSettings();
    else handleSelect('configuracoes');
  };

  const handleLogoClick = () => {
    handleSelect('dashboard');
  };

  // Automatically close more menu drawer if read-only mode becomes active
  useEffect(() => {
    if (isReadOnlyMode && isMoreMenuOpen) {
      setIsMoreMenuOpen(false);
    }
  }, [isReadOnlyMode, isMoreMenuOpen]);

  // Overdue and active alerts count for badge (memoized)
  const { overdueCount, alertCount } = useMemo(() => {
    let overdue = 0;
    let upcomingRentals = 0;

    motoContracts.forEach((c) => {
      c.installments.forEach((i) => {
        if (i.status === 'pago') return;
        if (isInstallmentOverdue(i)) {
          overdue++;
        } else {
          const days = getDaysUntil(i.dueDate);
          if (days <= 3) upcomingRentals++;
        }
      });
    });

    kitnetContracts.forEach((c) => {
      c.installments.forEach((i) => {
        if (i.status === 'pago') return;
        if (isInstallmentOverdue(i)) {
          overdue++;
        } else {
          const days = getDaysUntil(i.dueDate);
          if (days <= 3) upcomingRentals++;
        }
      });
    });

    let alerts = overdue + upcomingRentals;
    const activeMotoTenantIds = new Set(
      motoContracts.filter((c) => c.status === 'ativo').map((c) => c.tenantId)
    );

    motoTenants.forEach((t) => {
      if (activeMotoTenantIds.has(t.id) && t.cnh?.expirationDate) {
        const cnh = getCNHStatus(t.cnh.expirationDate);
        if (cnh.status === 'vencendo' || cnh.status === 'vencida') alerts++;
      }
    });

    motos.forEach((m) => {
      if (m.ipvaDueDate) {
        const days = getDaysUntil(m.ipvaDueDate);
        if (days >= 0 && days <= 15) alerts++;
      }
    });

    expenses.forEach((e) => {
      if (e.status === 'pendente') {
        const days = getDaysUntil(e.dueDate);
        if (days <= 3) alerts++;
      }
    });

    return { overdueCount: overdue, alertCount: alerts };
  }, [motoContracts, kitnetContracts, motoTenants, motos, expenses]);

  // Centralized theme colors for tabs and indicators
  const TAB_THEMES: Record<string, {
    activeText: string;
    activeGlow: string;
    activeBg: string;
    activeBorder: string;
    activeColor: string;
  }> = {
    dashboard: {
      activeText: 'text-action-primary',
      activeGlow: 'bg-action-primary',
      activeBg: 'bg-action-primary/15',
      activeBorder: 'border-action-primary/30',
      activeColor: COLORS.action.primary,
    },
    motos: {
      activeText: 'text-category-motos',
      activeGlow: 'bg-category-motos',
      activeBg: 'bg-category-motos/15',
      activeBorder: 'border-category-motos/30',
      activeColor: COLORS.category.motos,
    },
    kitnets: {
      activeText: 'text-category-kitnets-sky',
      activeGlow: 'bg-category-kitnets-sky',
      activeBg: 'bg-category-kitnets-sky/15',
      activeBorder: 'border-category-kitnets-sky/30',
      activeColor: COLORS.category.kitnetsSky,
    },
    financeiro: {
      activeText: 'text-money-positive',
      activeGlow: 'bg-money-positive',
      activeBg: 'bg-money-positive/15',
      activeBorder: 'border-money-positive/30',
      activeColor: COLORS.money.positive,
    },
    cobrancas: {
      activeText: 'text-money-negative',
      activeGlow: 'bg-money-negative',
      activeBg: 'bg-money-negative/15',
      activeBorder: 'border-money-negative/30',
      activeColor: COLORS.money.negative,
    },
    clientes: {
      activeText: 'text-action-primary',
      activeGlow: 'bg-action-primary',
      activeBg: 'bg-action-primary/15',
      activeBorder: 'border-action-primary/30',
      activeColor: COLORS.action.primary,
    },
    calendario: {
      activeText: 'text-category-motos-alt',
      activeGlow: 'bg-category-motos-alt',
      activeBg: 'bg-category-motos-alt/15',
      activeBorder: 'border-category-motos-alt/30',
      activeColor: COLORS.money.warning,
    },
    relatorios: {
      activeText: 'text-money-positive',
      activeGlow: 'bg-money-positive',
      activeBg: 'bg-money-positive/15',
      activeBorder: 'border-money-positive/30',
      activeColor: COLORS.money.positive,
    },
    ia: {
      activeText: 'text-action-light',
      activeGlow: 'bg-action-primary',
      activeBg: 'bg-action-primary/15',
      activeBorder: 'border-action-primary/30',
      activeColor: COLORS.action.primary,
    },
    documentos: {
      activeText: 'text-category-kitnets-cyan',
      activeGlow: 'bg-category-kitnets-cyan',
      activeBg: 'bg-category-kitnets-cyan/15',
      activeBorder: 'border-category-kitnets-cyan/30',
      activeColor: COLORS.category.kitnetsCyan,
    },
    configuracoes: {
      activeText: 'text-text-primary',
      activeGlow: 'bg-white',
      activeBg: 'bg-white/10',
      activeBorder: 'border-white/20',
      activeColor: COLORS.text.white,
    },
    mais: {
      activeText: 'text-action-primary',
      activeGlow: 'bg-action-primary',
      activeBg: 'bg-action-primary/15',
      activeBorder: 'border-action-primary/30',
      activeColor: COLORS.action.primary,
    },
  };

  // Desktop Navigation Items
  const desktopNavItems: Array<{
    id: TabType;
    label: string;
    icon: React.ComponentType<{ className?: string; size?: number; color?: string }>;
    badge?: number;
    badgeColor?: string;
  }> = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    {
      id: 'cobrancas',
      label: 'Cobranças',
      icon: BadgeAlert,
      badge: overdueCount > 0 ? overdueCount : undefined,
      badgeColor: 'bg-money-negative text-white',
    },
    {
      id: 'motos',
      label: 'Motos',
      icon: (props) => <MotoIcon {...props} size={15} color={COLORS.category.motos} />,
      badge: motos.filter((m) => m.status === 'alugada').length,
      badgeColor: 'bg-category-motos/20 text-category-motos border border-category-motos/30',
    },
    {
      id: 'kitnets',
      label: 'Kitnets',
      icon: (props) => <KitnetIcon {...props} size={15} color={COLORS.category.kitnetsSky} />,
      badge: kitnets.filter((k) => k.status === 'alugada').length,
      badgeColor: 'bg-category-kitnets-sky/20 text-category-kitnets-sky border border-category-kitnets-sky/30',
    },
    { id: 'clientes', label: 'Clientes & Score', icon: Users },
    { id: 'calendario', label: 'Calendário', icon: Calendar },
    { id: 'financeiro', label: 'Financeiro', icon: Wallet },
    { id: 'relatorios', label: 'Relatórios', icon: FileSpreadsheet },
    { id: 'documentos', label: 'Documentos', icon: FileText },
  ];

  // Mobile bottom items matching exact 5 icons from IMG_1024
  const mobileBottomItems = [
    { id: 'dashboard' as TabType, label: 'Dashboard', icon: LayoutGrid },
    {
      id: 'motos' as TabType,
      label: 'Motos',
      icon: MotoIcon,
      badge: motos.filter((m) => m.status === 'alugada').length,
    },
    {
      id: 'kitnets' as TabType,
      label: 'Kitnets',
      icon: KitnetIcon,
      badge: kitnets.filter((k) => k.status === 'alugada').length,
    },
    { id: 'financeiro' as TabType, label: 'Financeiro', icon: Wallet },
    { id: 'mais' as any, label: 'Mais', icon: Settings },
  ];

  // Clean active index for mobile bottom dock
  const activeMobileIndex = useMemo(() => {
    if (isMoreMenuOpen) return 4;
    if (current === 'dashboard') return 0;
    if (current === 'motos') return 1;
    if (current === 'kitnets') return 2;
    if (current === 'financeiro') return 3;
    return 4;
  }, [current, isMoreMenuOpen]);

  const currentTheme = TAB_THEMES[current] || TAB_THEMES.dashboard;
  const currentActiveColor = currentTheme.activeColor || COLORS.action.primary;

  return (
    <>
      {/* Top Navbar: Permanently fixed at top-0 with floating card and safe-area support */}
      <header className="fixed top-0 left-0 right-0 z-40 w-full px-2 sm:px-4 lg:px-6 pt-safe-header pb-2 sm:py-2.5 pointer-events-none">
        {/* Elegant Clean Card Container wrapping around the header */}
        <div
          className={`relative max-w-7xl mx-auto rounded-2xl pointer-events-auto transition-all duration-300 ease-in-out ${
            isScrolled
              ? 'header-box-scrolled'
              : 'header-box'
          }`}
        >
          <div className="relative z-20 px-2.5 sm:px-5 lg:px-7 flex items-center justify-between gap-1.5 sm:gap-3 h-14 sm:h-16">
            {/* Main Logo & Brand */}
            <div
              className="cursor-pointer shrink min-w-0 transition-transform active:scale-95 flex items-center gap-2 group relative"
              onClick={handleLogoClick}
              title="Ir para o Dashboard"
            >
              <Logo
                variant="main"
                size="md"
                showSubtitle={true}
                animated={true}
              />
            </div>

            {/* Desktop Nav Links - Hidden completely during Read-Only Mode */}
            {!isReadOnlyMode && (
              <nav className="relative hidden xl:flex items-center gap-1 overflow-x-auto py-1">
                {desktopNavItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = current === item.id;
                  const theme = TAB_THEMES[item.id] || TAB_THEMES.dashboard;

                  const activeClass = `${theme.activeBg} ${theme.activeText} border ${theme.activeBorder} shadow-xs`;
                  const iconActiveClass = theme.activeText;

                  return (
                    <button
                      type="button"
                      key={item.id}
                      id={`nav-link-${item.id}`}
                      onClick={() => handleSelect(item.id)}
                      className={`relative px-3 py-1.5 rounded-xl text-xs font-semibold transition-all duration-150 flex items-center gap-1.5 whitespace-nowrap cursor-pointer active:scale-95 ${
                        isActive
                          ? activeClass
                          : 'text-text-secondary hover:text-text-primary hover:bg-white/[0.05]'
                      }`}
                    >
                      <Icon
                        className={`w-3.5 h-3.5 ${isActive ? iconActiveClass : ''}`}
                        color={
                          item.id === 'motos'
                            ? COLORS.category.motos
                            : item.id === 'kitnets'
                            ? COLORS.category.kitnetsSky
                            : isActive
                            ? theme.activeColor
                            : undefined
                        }
                      />
                      <span className="shrink-0">{item.label}</span>
                      {item.badge !== undefined && (
                        <span
                          className={`min-w-[16px] h-4 px-1 rounded-full text-[9px] font-bold inline-flex items-center justify-center shrink-0 leading-none ${
                            item.badgeColor || 'bg-white/10 text-text-secondary'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </nav>
            )}

            {/* Right Action Buttons */}
            <div className="relative flex items-center gap-1 sm:gap-2 shrink-0">
              {/* Sair do Modo Leitura Button (when read only mode is active) */}
              {isReadOnlyMode && (
                <button
                  type="button"
                  id="header-btn-exit-readonly"
                  onClick={(e) => {
                    gsapButtonPress(e.currentTarget);
                    toggleReadOnlyMode();
                  }}
                  className="px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95 cursor-pointer shrink-0 animate-pulse"
                  title="Clique para desativar o Modo Leitura"
                >
                  <EyeOff className="w-3.5 h-3.5" />
                  <span className="hidden xs:inline sm:inline">Sair Leitura</span>
                  <span className="xs:hidden sm:hidden">Sair</span>
                </button>
              )}

              {/* Dark / Light Mode Switcher with requested styling */}
              <ThemeToggle className="scale-85 sm:scale-100 origin-center shrink-0" />

              {/* Search Squircle Button */}
              {onOpenSearch && (
                <button
                  type="button"
                  id="header-btn-search"
                  onClick={(e) => {
                    gsapButtonPress(e.currentTarget);
                    onOpenSearch();
                  }}
                  className="w-9 h-9 sm:w-10 sm:h-10 min-w-[36px] min-h-[36px] sm:min-w-[40px] sm:min-h-[40px] rounded-xl sm:rounded-2xl bg-slate-100/90 dark:bg-surface-elevated/90 hover:bg-slate-200 dark:hover:bg-surface-hover border border-slate-200/90 dark:border-border-subtle text-slate-700 dark:text-text-primary flex items-center justify-center transition-colors duration-150 cursor-pointer shadow-xs touch-manipulation active:scale-95 shrink-0"
                  title="Busca Unificada (Ctrl+K)"
                  aria-label="Buscar"
                >
                  <Search className="w-4 sm:w-4.5 h-4 sm:h-4.5" />
                </button>
              )}

              {/* Notifications Squircle Button with Badge */}
              <button
                type="button"
                id="header-btn-notifications"
                onClick={(e) => {
                  gsapButtonPress(e.currentTarget);
                  onOpenNotifications();
                }}
                className="w-9 h-9 sm:w-10 sm:h-10 min-w-[36px] min-h-[36px] sm:min-w-[40px] sm:min-h-[40px] relative rounded-xl sm:rounded-2xl bg-slate-100/90 dark:bg-surface-elevated/90 hover:bg-slate-200 dark:hover:bg-surface-hover border border-slate-200/90 dark:border-border-subtle text-slate-700 dark:text-text-primary flex items-center justify-center transition-colors duration-150 cursor-pointer shadow-xs touch-manipulation active:scale-95 shrink-0"
                title="Alertas e Notificações"
                aria-label="Alertas e Notificações"
              >
                <Bell className="w-4 sm:w-4.5 h-4 sm:h-4.5" />
                {alertCount > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[17px] h-[17px] px-1 rounded-full bg-rose-500 text-white text-[9.5px] font-bold flex items-center justify-center ring-2 ring-surface-sidebar shadow-sm animate-pulse">
                    {alertCount}
                  </span>
                )}
              </button>

              {/* User Profile / Settings Squircle Button */}
              <button
                type="button"
                id="header-btn-user"
                onClick={(e) => {
                  gsapButtonPress(e.currentTarget);
                  handleSettings();
                }}
                className={`w-9 h-9 sm:w-10 sm:h-10 min-w-[36px] min-h-[36px] sm:min-w-[40px] sm:min-h-[40px] rounded-xl sm:rounded-2xl border flex items-center justify-center transition-colors duration-150 cursor-pointer shadow-xs touch-manipulation active:scale-95 shrink-0 ${
                  current === 'configuracoes'
                    ? 'bg-purple-100 dark:bg-purple-600/25 border-purple-300 dark:border-purple-500/50 text-purple-700 dark:text-purple-300 shadow-purple-600/20'
                    : 'bg-slate-100/90 dark:bg-surface-elevated/90 hover:bg-slate-200 dark:hover:bg-surface-hover border-slate-200/90 dark:border-border-subtle text-slate-700 dark:text-text-primary'
                }`}
                title="Perfil & Configurações"
                aria-label="Perfil & Configurações"
              >
                <User className="w-4 sm:w-4.5 h-4 sm:h-4.5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Structural layout spacer ensuring page content starts cleanly below the fixed header */}
      <div
        className="w-full shrink-0 pointer-events-none spacer-safe-header"
        aria-hidden="true"
      />

      {/* Mobile Sticky Bottom Floating Dock - Exact Spotlight/Limelight matching IMG_1025 */}
      {isReadOnlyMode ? null : (
        <div className="lg:hidden fixed bottom-2 sm:bottom-3 left-2.5 sm:left-4 right-2.5 sm:right-4 max-w-[365px] sm:max-w-md mx-auto z-40 pointer-events-none pb-safe">
          <nav
            aria-label="Menu Principal"
            className="pointer-events-auto relative flex items-center justify-between h-14 sm:h-15 rounded-[24px] sm:rounded-3xl bg-white/95 dark:bg-slate-900/95 border border-slate-200/90 dark:border-white/[0.12] backdrop-blur-xl px-1.5 sm:px-2 shadow-[0_6px_24px_rgba(0,0,0,0.08)] dark:shadow-[0_8px_32px_rgba(0,0,0,0.6)]"
          >
            {mobileBottomItems.map((item) => {
              const Icon = item.icon;
              const isMais = item.id === 'mais';
              const isTabActive = isMais
                ? isMoreMenuOpen || !['dashboard', 'motos', 'kitnets', 'financeiro'].includes(current)
                : !isMoreMenuOpen && current === item.id;

              return (
                <button
                  type="button"
                  key={item.id}
                  id={`mobile-tab-${item.id}`}
                  aria-label={item.label}
                  title={item.label}
                  onClick={() => {
                    if (isMais) {
                      setIsMoreMenuOpen((prev) => !prev);
                    } else {
                      handleSelect(item.id);
                    }
                  }}
                  className="relative z-20 flex-1 min-w-0 h-full flex items-center justify-center cursor-pointer touch-manipulation select-none active:scale-95 transition-transform duration-150 py-0.5"
                >
                  {/* Spotlight (Holofote) for Active Tab - Exactly matching IMG_1025 */}
                  {isTabActive && (
                    <motion.div
                      layoutId="mobileBottomSpotlight"
                      className="absolute inset-0 pointer-events-none flex items-center justify-center overflow-visible"
                      transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                    >
                      {/* Top Horizontal Glowing Light Bar */}
                      <div
                        className="absolute top-0 left-1/2 -translate-x-1/2 w-10 sm:w-11 h-[3.5px] rounded-full bg-violet-600 dark:bg-violet-500 shadow-[0_0_10px_rgba(139,92,246,0.9),0_1px_4px_rgba(139,92,246,0.6)]"
                      />

                      {/* Downward Spotlight Cone */}
                      <div
                        className="absolute left-[-16%] top-[3.5px] w-[132%] h-12 [clip-path:polygon(14%_100%,26%_0,74%_0,86%_100%)] pointer-events-none"
                        style={{
                          background:
                            'linear-gradient(to bottom, rgba(139, 92, 246, 0.32) 0%, rgba(139, 92, 246, 0.09) 65%, transparent 100%)',
                        }}
                      />

                      {/* Ambient light pool at bottom of icon */}
                      <div
                        className="absolute bottom-1 left-1/2 -translate-x-1/2 w-10 h-2.5 rounded-full blur-[5px] pointer-events-none bg-violet-500/20"
                      />
                    </motion.div>
                  )}

                  <div className="relative flex items-center justify-center z-10">
                    <Icon
                      className={`w-5.5 h-5.5 sm:w-6 sm:h-6 transition-all duration-200 ${
                        isTabActive
                          ? 'text-violet-700 dark:text-white drop-shadow-[0_0_7px_rgba(139,92,246,0.5)] scale-105'
                          : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                      }`}
                    />

                    {item.badge !== undefined && item.badge > 0 && (
                      <span
                        className={`absolute -top-1.5 -right-2 min-w-[14px] h-[14px] px-0.5 rounded-full text-[8.5px] font-bold inline-flex items-center justify-center leading-none select-none tabular-nums shadow-xs ${
                          item.id === 'motos'
                            ? 'bg-amber-500 text-slate-950'
                            : item.id === 'kitnets'
                            ? 'bg-sky-400 text-slate-950'
                            : 'bg-rose-500 text-white'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </nav>
        </div>
      )}

      {/* Drawer Menu for "Mais" */}
      <MoreMenuDrawer
        isOpen={isMoreMenuOpen}
        onClose={() => setIsMoreMenuOpen(false)}
        onSelectTab={handleSelect}
        onOpenSimulator={() => {
          if (onOpenSimulator) onOpenSimulator();
        }}
        onOpenContacts={() => {
          if (onOpenContacts) onOpenContacts();
        }}
        onOpenPwaGuide={() => {
          if (onOpenPwaGuide) onOpenPwaGuide();
        }}
        overdueCount={overdueCount}
      />

      {/* Discreet Floating Capsule for Read-Only Mode (Single clean exit control) */}
      {isReadOnlyMode && (
        <aside
          aria-label="Controle de Modo Leitura"
          className="fixed bottom-4 sm:bottom-6 left-1/2 -translate-x-1/2 z-[95] flex items-center justify-center pointer-events-none pb-safe"
        >
          <div className="pointer-events-auto flex items-center gap-3 px-4 py-2 rounded-full bg-white/95 dark:bg-surface-elevated/95 border border-amber-500/50 text-slate-900 dark:text-slate-100 shadow-2xl backdrop-blur-md text-xs font-medium">
            <span className="flex items-center gap-1.5 text-amber-600 dark:text-amber-400 font-semibold">
              <Eye className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              Modo Leitura
            </span>
            <span className="w-px h-4 bg-slate-700 dark:bg-slate-600" />
            <button
              type="button"
              id="floating-btn-exit-readonly"
              onClick={(e) => {
                gsapButtonPress(e.currentTarget);
                toggleReadOnlyMode();
              }}
              className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-full cursor-pointer active:scale-95 transition-all shadow-xs"
            >
              Desativar
            </button>
          </div>
        </aside>
      )}

      {/* Exit Read-Only Modal Dialog when clicking profile or blocked sections */}
      {showExitReadOnlyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="relative w-full max-w-sm rounded-2xl bg-surface-base border border-border-subtle p-5 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-violet-500/15 text-violet-600 dark:text-violet-400 border border-violet-500/30 flex items-center justify-center shrink-0">
                <Eye className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h3 className="text-base font-bold text-text-primary">Modo Leitura Ativo</h3>
                <p className="text-xs text-text-secondary">Visualização restrita ao Dashboard</p>
              </div>
            </div>

            <p className="text-xs text-text-secondary leading-relaxed">
              O aplicativo está operando em Modo Somente Leitura. Deseja desativar o modo leitura para acessar o Perfil, Configurações e todos os módulos operacionais?
            </p>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setShowExitReadOnlyModal(false)}
                className="px-3.5 py-2 rounded-xl text-xs font-medium text-text-secondary hover:text-text-primary hover:bg-surface-subtle transition-colors cursor-pointer"
              >
                Permanecer em Leitura
              </button>
              <button
                type="button"
                id="modal-btn-confirm-exit-readonly"
                onClick={() => {
                  toggleReadOnlyMode();
                  setShowExitReadOnlyModal(false);
                  if (onOpenSettings) onOpenSettings();
                  else handleSelect('configuracoes');
                }}
                className="px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-violet-600/25 transition-all cursor-pointer active:scale-95"
              >
                <EyeOff className="w-3.5 h-3.5" />
                <span>Desativar e Abrir</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export const Navigation = memo(NavigationComponent);


