/**
 * src/constants/appVersion.ts
 * 
 * Fonte Única da Verdade para a versão e build da aplicação no cliente.
 * Atualizado automaticamente pelo sistema de build (scripts/generate-source-zip.js e scripts/project-version.js).
 * NUNCA utilize números fixos mágicos como fallback no código.
 */

export const CURRENT_APP_VERSION_NUMBER = 86;
export const CURRENT_APP_VERSION_STRING = 'Versão 86';
export const CURRENT_APP_BUILD_ID = 'BUILD-V86-MU5JYH6I';
export const CURRENT_APP_ZIP_FILENAME = 'projeto-versao-86.zip';
export const CURRENT_APP_ZIP_URL = '/versions/projeto-versao-86.zip';
export const CURRENT_APP_GENERIC_ZIP_URL = '/projeto-completo.zip';

export const CURRENT_APP_BUILD_DATE = '17/09/2026';
export const CURRENT_APP_BUILD_DATETIME = '17/09/2026 às 10:15:32';
