#!/usr/bin/env node

/**
 * scripts/pipeline.js
 * Master Automated Build, Validation, Audit & Version Packaging Pipeline.
 * 
 * Implements the 4-step workflow:
 * 
 * PASSO 1: Dependencies Check & Install (npm install)
 * PASSO 2: Automated Validation Suite (lint, typecheck, test)
 *          - Dynamically discovers all validation scripts in package.json
 *          - Aborts immediately on any failure (no zip, no publish)
 * PASSO 3: Deep Project Audit (scripts/audit-project.js)
 *          - Broken imports, missing deps, orphan files, TS errors
 *          - Detailed status report
 * PASSO 4: Full Production Build (npm run build)
 *          - Version incrementation
 *          - Vite bundle generation
 *          - Fresh source ZIP generation with real SHA-256 and size
 *          - Audit of all historical versions (keeps previous version intact)
 *          - Synchronization to distribution mirror
 *          - Post-build integrity verification
 */

import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

const BRAZIL_TIMEZONE = 'America/Sao_Paulo';

function getBrazilFormattedTime() {
  return new Intl.DateTimeFormat('pt-BR', {
    timeZone: BRAZIL_TIMEZONE,
    dateStyle: 'short',
    timeStyle: 'medium',
  }).format(new Date());
}

function runStep(stepNum, stepTitle, actionFn) {
  console.log('\n=======================================================');
  console.log(`▶️ [PASSO ${stepNum}] ${stepTitle}`);
  console.log(`⏰ ${getBrazilFormattedTime()}`);
  console.log('=======================================================');

  const startTime = Date.now();
  try {
    actionFn();
    const duration = ((Date.now() - startTime) / 1000).toFixed(2);
    console.log(`✅ [PASSO ${stepNum}] Concluído com sucesso em ${duration}s.`);
    return true;
  } catch (err) {
    const duration = ((Date.now() - startTime) / 1000).toFixed(2);
    console.error(`\n🚨 [ERRO CRÍTICO NO PASSO ${stepNum}] ${stepTitle}`);
    console.error(`   Tempo decorrido: ${duration}s`);
    console.error(`   Mensagem de erro: ${err.message}`);
    if (err.stdout) console.error(`   Output:\n${err.stdout.toString()}`);
    if (err.stderr) console.error(`   Stderr:\n${err.stderr.toString()}`);
    console.error('\n🛑 PROCESSO INTERROMPIDO: Não será gerado ZIP nem publicada nova versão.\n');
    process.exit(1);
  }
}

function getPackageScripts() {
  const pkgPath = path.join(rootDir, 'package.json');
  if (!fs.existsSync(pkgPath)) {
    throw new Error('package.json não encontrado.');
  }
  const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
  return pkg.scripts || {};
}

function main() {
  console.log('\n╔═══════════════════════════════════════════════════════╗');
  console.log('║   🚀 INICIANDO PIPELINE AUTOMÁTICA DE ATUALIZAÇÃO     ║');
  console.log(`║   Data/Hora: ${getBrazilFormattedTime().padEnd(39)}║`);
  console.log('╚═══════════════════════════════════════════════════════╝');

  // ----------------------------------------------------
  // PASSO 1: npm install
  // ----------------------------------------------------
  runStep(1, 'Verificação e Instalação de Dependências (npm install)', () => {
    console.log('📦 Verificando consistência das dependências...');
    // In our container environment, dependencies are pre-installed.
    // Run npm install to ensure tree integrity.
    execSync('npm install --prefer-offline --no-audit --no-fund', {
      cwd: rootDir,
      stdio: 'inherit',
      timeout: 120000,
    });
  });

  // ----------------------------------------------------
  // PASSO 2: Scripts de validação disponíveis no package.json
  // ----------------------------------------------------
  runStep(2, 'Execução dos Scripts de Validação (lint, typecheck, test)', () => {
    const scripts = getPackageScripts();
    const validationCandidates = ['lint', 'typecheck', 'test'];
    const availableScripts = validationCandidates.filter(s => !!scripts[s]);

    console.log(`📋 Scripts de validação detectados no package.json: ${availableScripts.join(', ')}`);

    const executedCommands = new Set();
    for (const scriptName of availableScripts) {
      const command = scripts[scriptName];
      if (executedCommands.has(command)) {
        console.log(`ℹ️ Pulando '${scriptName}' pois o comando ('${command}') já foi executado.`);
        continue;
      }
      executedCommands.add(command);

      console.log(`\n⏳ Executando 'npm run ${scriptName}'...`);
      execSync(`npm run ${scriptName}`, {
        cwd: rootDir,
        stdio: 'inherit',
        timeout: 90000,
      });
      console.log(`   ✓ 'npm run ${scriptName}' passou com sucesso.`);
    }
  });

  // ----------------------------------------------------
  // PASSO 3: Auditoria profunda automática
  // ----------------------------------------------------
  runStep(3, 'Auditoria Automática de Código, Imports, Dependências e Rotas', () => {
    const auditScript = path.join(rootDir, 'scripts', 'audit-project.js');
    if (!fs.existsSync(auditScript)) {
      throw new Error(`Script de auditoria não encontrado em: ${auditScript}`);
    }

    execSync(`node "${auditScript}" --fast`, {
      cwd: rootDir,
      stdio: 'inherit',
      timeout: 90000,
    });
  });

  // ----------------------------------------------------
  // PASSO 4: Build Completa e Empacotamento de Versão
  // ----------------------------------------------------
  runStep(4, 'Build Completa do Projeto e Empacotamento do ZIP (npm run build)', () => {
    console.log('🏗️ Executando build de produção e geração de pacote...');
    execSync('npm run build', {
      cwd: rootDir,
      stdio: 'inherit',
      env: {
        ...process.env,
        NODE_ENV: 'production',
        FORCE_GENERATE_ZIP: 'true',
      },
      timeout: 120000,
    });
  });

  console.log('\n╔═══════════════════════════════════════════════════════╗');
  console.log('║   🎉 PIPELINE AUTOMÁTICA CONCLUÍDA COM SUCESSO!       ║');
  console.log('║   ✓ Dependências verificadas                          ║');
  console.log('║   ✓ Lint, Typecheck e Testes aprovados                ║');
  console.log('║   ✓ Auditoria profunda: 0 falhas                      ║');
  console.log('║   ✓ Build e ZIP de código-fonte atualizados           ║');
  console.log('║   ✓ Histórico de versões sincronizado                 ║');
  console.log('╚═══════════════════════════════════════════════════════╝\n');
}

main();
