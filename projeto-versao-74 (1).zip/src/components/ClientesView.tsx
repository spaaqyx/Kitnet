import React, { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import {
  Users,
  Search,
  Motorbike,
  Home,
  ShieldCheck,
  Phone,
  ChevronRight,
  MessageCircle,
  ArrowLeft,
  UserCheck,
  Award,
  Sparkles,
  AlertTriangle,
  X,
  SlidersHorizontal,
  ExternalLink,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { calculateClientScore } from '../utils/scoreCalculator';
import { formatCPF, formatPhone } from '../utils/formatters';
import { useScrollActiveIntoView } from '../hooks/useScrollActiveIntoView';

interface ClientesViewProps {
  onOpenClientProfile: (tenantId: string, type: 'moto' | 'kitnet') => void;
  onOpenWhatsApp: (contractId: string, installmentId?: string) => void;
  onNavigateTab?: (tab: any) => void;
}

export const ClientesView: React.FC<ClientesViewProps> = ({
  onOpenClientProfile,
  onOpenWhatsApp,
  onNavigateTab,
}) => {
  const { motoTenants, kitnetTenants, motoContracts, kitnetContracts, isDemoMode, toggleDemoMode } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'todos' | 'moto' | 'kitnet'>('todos');
  const [filterScore, setFilterScore] = useState<'todos' | 'excelente' | 'medio' | 'alto_risco'>('todos');

  const { containerRef, registerItem, scrollItemIntoView } = useScrollActiveIntoView(filterType);

  // Unified Client List with Calculated Scores
  const clientList = useMemo(() => {
    const list: {
      id: string;
      fullName: string;
      cpf: string;
      phone: string;
      whatsapp: string;
      photoUrl?: string;
      type: 'moto' | 'kitnet';
      profession: string;
      scoreData: ReturnType<typeof calculateClientScore>;
      activeContractsCount: number;
      primaryContractId?: string;
    }[] = [];

    motoTenants.forEach((t) => {
      const contracts = motoContracts.filter((c) => c.tenantId === t.id && c.status === 'ativo');
      const score = calculateClientScore(t, motoContracts);
      list.push({
        id: t.id,
        fullName: t.fullName,
        cpf: t.cpf,
        phone: t.phone,
        whatsapp: t.whatsapp || t.phone,
        photoUrl: t.photoUrl,
        type: 'moto',
        profession: t.profession || 'Locatário',
        scoreData: score,
        activeContractsCount: contracts.length,
        primaryContractId: contracts[0]?.id,
      });
    });

    kitnetTenants.forEach((t) => {
      const contracts = kitnetContracts.filter((c) => c.tenantId === t.id && c.status === 'ativo');
      const score = calculateClientScore(t, kitnetContracts);
      list.push({
        id: t.id,
        fullName: t.fullName,
        cpf: t.cpf,
        phone: t.phone,
        whatsapp: t.whatsapp || t.phone,
        photoUrl: t.photoUrl,
        type: 'kitnet',
        profession: t.incomeType?.toUpperCase() || 'Inquilino',
        scoreData: score,
        activeContractsCount: contracts.length,
        primaryContractId: contracts[0]?.id,
      });
    });

    return list;
  }, [motoTenants, kitnetTenants, motoContracts, kitnetContracts]);

  // Quick statistics
  const stats = useMemo(() => {
    const total = clientList.length;
    const motos = clientList.filter((c) => c.type === 'moto').length;
    const kitnets = clientList.filter((c) => c.type === 'kitnet').length;
    const avgScore =
      total > 0
        ? Math.round(clientList.reduce((acc, c) => acc + c.scoreData.score, 0) / total)
        : 100;
    const excelenteCount = clientList.filter((c) => c.scoreData.classification === 'excelente').length;
    return { total, motos, kitnets, avgScore, excelenteCount };
  }, [clientList]);

  // Filtered List
  const filteredClients = useMemo(() => {
    return clientList.filter((c) => {
      if (filterType !== 'todos' && c.type !== filterType) return false;
      if (filterScore !== 'todos' && c.scoreData.classification !== filterScore) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          c.fullName.toLowerCase().includes(q) ||
          c.cpf.replace(/\D/g, '').includes(q.replace(/\D/g, '')) ||
          c.phone.includes(q) ||
          c.whatsapp.includes(q)
        );
      }
      return true;
    });
  }, [clientList, filterType, filterScore, searchQuery]);

  return (
    <div className="space-y-4 font-sans text-slate-900 dark:text-slate-100 max-w-7xl mx-auto">
      {/* Top Header Card - Clean & Sophisticated */}
      <div className="p-4 sm:p-5 bg-surface-sidebar border border-border-subtle rounded-2xl shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5 min-w-0">
          {onNavigateTab && (
            <button
              onClick={() => onNavigateTab('dashboard')}
              className="p-2 sm:p-2.5 rounded-xl bg-surface-card hover:bg-surface-elevated border border-border-subtle hover:border-violet-500/30 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-all cursor-pointer flex items-center gap-1.5 text-xs font-semibold shrink-0 active:scale-95 shadow-xs"
              title="Voltar ao Dashboard"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Voltar</span>
            </button>
          )}

          <div className="p-2.5 sm:p-3 rounded-xl bg-violet-500/10 text-violet-600 dark:text-violet-400 border border-violet-500/20 shrink-0">
            <Users className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <div className="min-w-0">
            <h1 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white tracking-tight truncate">
              Gestão de Clientes & Score
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 truncate">
              Perfis cadastrais, pontuação de crédito, contratos e cobranças
            </p>
          </div>
        </div>

        {/* Quick KPI Stat Chips & Clientes Demo Button - Standardized h-9 and no text truncation */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0 pb-0.5">
          <button
            type="button"
            id="clientes-view-toggle-demo"
            onClick={() => toggleDemoMode()}
            className={`h-9 px-3 rounded-xl border inline-flex items-center justify-center gap-2 transition-all duration-150 cursor-pointer active:scale-95 text-xs font-semibold select-none whitespace-nowrap shrink-0 ${
              isDemoMode
                ? 'bg-purple-500/20 border-purple-500/50 text-purple-700 dark:text-purple-200 hover:bg-purple-500/30'
                : 'bg-surface-card border-border-subtle text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-surface-elevated'
            }`}
            title={
              isDemoMode
                ? 'Clientes Demo Ativos: clique para desligar'
                : 'Clientes Demo Desligados: clique para ligar'
            }
          >
            <Users className={`w-3.5 h-3.5 shrink-0 ${isDemoMode ? 'text-purple-600 dark:text-purple-400' : 'text-slate-400'}`} />
            <span className="shrink-0">Demo</span>
            <span
              className={`text-[10px] px-1.5 py-0.5 rounded font-bold uppercase shrink-0 tabular-nums ${
                isDemoMode ? 'bg-purple-500/30 text-purple-700 dark:text-purple-200 ring-1 ring-purple-400/40' : 'bg-black/5 dark:bg-white/5 text-slate-500 dark:text-slate-400'
              }`}
            >
              {isDemoMode ? 'LIG' : 'OFF'}
            </span>
          </button>

          <div className="h-9 px-3 rounded-xl bg-surface-card border border-border-subtle inline-flex items-center justify-center gap-2 shrink-0 whitespace-nowrap">
            <div className="w-2 h-2 rounded-full bg-violet-500 dark:bg-violet-400 shrink-0" />
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium shrink-0">Total:</span>
            <span className="text-xs font-bold text-slate-900 dark:text-white font-mono tabular-nums shrink-0">{stats.total}</span>
          </div>

          <div className="h-9 px-3 rounded-xl bg-surface-card border border-border-subtle inline-flex items-center justify-center gap-2 shrink-0 whitespace-nowrap">
            <Award className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium shrink-0">Score Médio:</span>
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 font-mono tabular-nums shrink-0">{stats.avgScore} pts</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar - Mobile Ergonomic & Standardized h-9 Buttons */}
      <div className="bg-surface-sidebar border border-border-subtle p-3 sm:p-4 rounded-2xl shadow-sm space-y-3">
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
            <input
              type="text"
              placeholder="Buscar por nome, CPF ou WhatsApp..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-10 bg-surface-card border border-border-subtle hover:border-border-highlight rounded-xl pl-9 pr-9 text-xs sm:text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500/40 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 dark:hover:text-white p-1 rounded-md transition-colors cursor-pointer active:scale-95"
                title="Limpar busca"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Segment & Score Filter Controls - Standardized h-9, auto-scroll and Centered */}
          <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap overflow-x-auto no-scrollbar">
            {/* Segment Filter Buttons - Matching icon-specific palettes */}
            <div
              ref={containerRef}
              className="flex items-center gap-1.5 shrink-0 overflow-x-auto no-scrollbar scroll-smooth touch-pan-x"
            >
              <motion.button
                ref={registerItem('todos')}
                type="button"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.96 }}
                onClick={() => {
                  setFilterType('todos');
                  scrollItemIntoView('todos');
                }}
                className={`h-9 px-3.5 rounded-xl text-xs font-semibold inline-flex items-center justify-center gap-2 whitespace-nowrap transition-all cursor-pointer shrink-0 border select-none ${
                  filterType === 'todos'
                    ? 'bg-purple-500/20 text-purple-700 dark:text-purple-200 border-purple-500 ring-1 ring-purple-400/40 font-bold'
                    : 'bg-surface-card text-slate-600 dark:text-slate-400 border-border-subtle hover:border-purple-500/50 hover:bg-purple-500/[0.08] hover:text-purple-700 dark:hover:text-purple-300'
                }`}
              >
                <Users className={`w-3.5 h-3.5 shrink-0 ${filterType === 'todos' ? 'text-purple-700 dark:text-purple-300' : 'text-slate-400'}`} />
                <span className="shrink-0">Todos</span>
                <span
                  className={`text-[10px] min-w-[20px] h-5 px-1.5 rounded-full font-bold inline-flex items-center justify-center shrink-0 leading-none tabular-nums transition-all ${
                    filterType === 'todos'
                      ? 'bg-purple-600 text-white font-black'
                      : 'bg-surface-subtle text-slate-600 dark:text-slate-400 border border-border-subtle'
                  }`}
                >
                  {clientList.length}
                </span>
              </motion.button>

              <motion.button
                ref={registerItem('moto')}
                type="button"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.96 }}
                onClick={() => {
                  setFilterType('moto');
                  scrollItemIntoView('moto');
                }}
                className={`h-9 px-3.5 rounded-xl text-xs font-semibold inline-flex items-center justify-center gap-2 whitespace-nowrap transition-all cursor-pointer shrink-0 border select-none ${
                  filterType === 'moto'
                    ? 'bg-amber-500/20 text-amber-700 dark:text-amber-200 border-amber-500 ring-1 ring-amber-400/40 font-bold'
                    : 'bg-surface-card text-slate-600 dark:text-slate-400 border-border-subtle hover:border-amber-500/50 hover:bg-amber-500/[0.08] hover:text-amber-700 dark:hover:text-amber-300'
                }`}
              >
                <Motorbike className={`w-3.5 h-3.5 shrink-0 ${filterType === 'moto' ? 'text-amber-700 dark:text-amber-300' : 'text-slate-400'}`} />
                <span className="shrink-0">Motos</span>
                <span
                  className={`text-[10px] min-w-[20px] h-5 px-1.5 rounded-full font-bold inline-flex items-center justify-center shrink-0 leading-none tabular-nums transition-all ${
                    filterType === 'moto'
                      ? 'bg-amber-600 text-white font-black'
                      : 'bg-surface-subtle text-slate-600 dark:text-slate-400 border border-border-subtle'
                  }`}
                >
                  {stats.motos}
                </span>
              </motion.button>

              <motion.button
                ref={registerItem('kitnet')}
                type="button"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.96 }}
                onClick={() => {
                  setFilterType('kitnet');
                  scrollItemIntoView('kitnet');
                }}
                className={`h-9 px-3.5 rounded-xl text-xs font-semibold inline-flex items-center justify-center gap-2 whitespace-nowrap transition-all cursor-pointer shrink-0 border select-none ${
                  filterType === 'kitnet'
                    ? 'bg-sky-500/20 text-sky-700 dark:text-sky-200 border-sky-500 ring-1 ring-sky-400/40 font-bold'
                    : 'bg-surface-card text-slate-600 dark:text-slate-400 border-border-subtle hover:border-sky-500/50 hover:bg-sky-500/[0.08] hover:text-sky-700 dark:hover:text-sky-300'
                }`}
              >
                <Home className={`w-3.5 h-3.5 shrink-0 ${filterType === 'kitnet' ? 'text-sky-700 dark:text-sky-300' : 'text-slate-400'}`} />
                <span className="shrink-0">Kitnets</span>
                <span
                  className={`text-[10px] min-w-[20px] h-5 px-1.5 rounded-full font-bold inline-flex items-center justify-center shrink-0 leading-none tabular-nums transition-all ${
                    filterType === 'kitnet'
                      ? 'bg-sky-600 text-white font-black'
                      : 'bg-surface-subtle text-slate-600 dark:text-slate-400 border border-border-subtle'
                  }`}
                >
                  {stats.kitnets}
                </span>
              </motion.button>
            </div>

            {/* Score Selector Dropdown - Standardized h-9 and rounded-xl */}
            <div className="relative shrink-0">
              <select
                value={filterScore}
                onChange={(e) => setFilterScore(e.target.value as any)}
                aria-label="Filtrar por Score"
                className="h-9 bg-surface-card hover:bg-surface-card border border-border-subtle hover:border-border-highlight text-slate-800 dark:text-slate-200 text-xs font-semibold rounded-xl pl-3 pr-8 focus:outline-none focus:border-violet-500 cursor-pointer transition-all appearance-none"
              >
                <option value="todos">Todos os Scores</option>
                <option value="excelente">Excelente (80+)</option>
                <option value="medio">Médio (50-79)</option>
                <option value="alto_risco">Alto Risco (&lt;50)</option>
              </select>
              <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>
        </div>
      </div>

      {/* Client Cards Grid - Clean & Uncluttered (No box inside box) */}
      {filteredClients.length === 0 ? (
        <div className="bg-surface-subtle border border-border-subtle rounded-2xl p-10 text-center shadow-sm animate-fadeIn">
          <div className="w-14 h-14 rounded-2xl bg-violet-500/10 border border-violet-500/20 text-violet-600 dark:text-violet-400 flex items-center justify-center mx-auto mb-3">
            <UserCheck className="w-7 h-7 opacity-80" />
          </div>
          <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">Nenhum cliente encontrado</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto mt-1 mb-5">
            Não foram encontrados clientes cadastrados correspondentes aos filtros ou termo de busca informado.
          </p>

          <div className="flex items-center justify-center gap-2.5 flex-wrap">
            <button
              type="button"
              onClick={() => toggleDemoMode(true)}
              className="group h-9 px-4 rounded-xl text-xs font-semibold flex items-center gap-1.5 bg-surface-subtle hover:bg-surface-card text-slate-900 dark:text-white border border-action-primary/40 hover:border-action-primary shadow-xs cursor-pointer transition-colors shrink-0 active:scale-95"
            >
              <Users className="w-3.5 h-3.5 text-action-light shrink-0" />
              <span>{isDemoMode ? 'Recarregar Clientes Demo' : 'Ligar Clientes Demo para Testes'}</span>
            </button>
            {onNavigateTab && (
              <>
                <button
                  type="button"
                  onClick={() => onNavigateTab('motos')}
                  className="group h-9 px-4 rounded-xl text-xs font-semibold flex items-center gap-1.5 bg-surface-subtle hover:bg-surface-card text-slate-900 dark:text-white border border-category-motos/40 hover:border-category-motos shadow-xs cursor-pointer transition-colors shrink-0 active:scale-95"
                >
                  <Motorbike className="w-3.5 h-3.5 text-category-motos shrink-0" />
                  <span>Cadastrar Moto</span>
                </button>
                <button
                  type="button"
                  onClick={() => onNavigateTab('kitnets')}
                  className="group h-9 px-4 rounded-xl text-xs font-semibold flex items-center gap-1.5 bg-surface-subtle hover:bg-surface-card text-slate-900 dark:text-white border border-category-kitnets-sky/40 hover:border-category-kitnets-sky shadow-xs cursor-pointer transition-colors shrink-0 active:scale-95"
                >
                  <Home className="w-3.5 h-3.5 text-category-kitnets-sky shrink-0" />
                  <span>Cadastrar Kitnet</span>
                </button>
              </>
            )}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {filteredClients.map((client) => {
            const score = client.scoreData;
            const isExcelente = score.classification === 'excelente';
            const isMedio = score.classification === 'medio';

            const scoreBadgeStyle = isExcelente
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-700 dark:text-emerald-400'
              : isMedio
              ? 'bg-amber-500/10 border-amber-500/30 text-amber-700 dark:text-amber-400'
              : 'bg-rose-500/10 border-rose-500/30 text-rose-700 dark:text-rose-400';

            const isMoto = client.type === 'moto';

            return (
              <div
                key={client.id}
                id={`client-card-${client.id}`}
                onClick={() => onOpenClientProfile(client.id, client.type)}
                className="bg-surface-subtle hover:bg-surface-card border border-border-subtle hover:border-violet-500/40 p-4 sm:p-4.5 rounded-2xl transition-all duration-200 cursor-pointer flex flex-col justify-between space-y-3.5 group shadow-xs hover:shadow-md active:scale-[0.99]"
              >
                {/* Top Profile & Score Header */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    {/* Photo or Monogram */}
                    {client.photoUrl ? (
                      <img
                        src={client.photoUrl}
                        alt={client.fullName}
                        referrerPolicy="no-referrer"
                        className="w-11 h-11 rounded-xl object-cover border border-border-subtle shadow-xs shrink-0"
                      />
                    ) : (
                      <div className="w-11 h-11 rounded-xl bg-violet-500/10 border border-violet-500/30 flex items-center justify-center font-bold text-sm text-violet-700 dark:text-violet-200 group-hover:bg-violet-600 group-hover:text-white transition-all shrink-0 shadow-xs">
                        {client.fullName.charAt(0).toUpperCase()}
                      </div>
                    )}

                    <div className="min-w-0">
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-violet-600 dark:group-hover:text-violet-300 transition-colors truncate">
                        {client.fullName}
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums mt-0.5">
                        CPF: {formatCPF(client.cpf)}
                      </p>
                    </div>
                  </div>

                  {/* Clean Score Pill */}
                  <div
                    className={`px-2.5 py-1 rounded-xl text-xs font-bold border tabular-nums shrink-0 flex items-center gap-1 ${scoreBadgeStyle}`}
                  >
                    {isExcelente ? (
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    ) : (
                      <Award className="w-3.5 h-3.5 shrink-0" />
                    )}
                    <span>{score.score} pts</span>
                  </div>
                </div>

                {/* Clean Key Details (NO nested box, elegant divider list) */}
                <div className="pt-2 border-t border-border-subtle space-y-2 text-xs">
                  {/* Segment & Active Contracts */}
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-500 dark:text-slate-400">Segmento:</span>
                    {isMoto ? (
                      <span className="px-2 py-0.5 rounded-lg bg-orange-500/10 border border-orange-500/20 text-orange-600 dark:text-orange-400 font-medium text-[11px] flex items-center gap-1">
                        <Motorbike className="w-3 h-3" />
                        <span>Locação Moto</span>
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-lg bg-sky-500/10 border border-sky-500/20 text-sky-600 dark:text-sky-400 font-medium text-[11px] flex items-center gap-1">
                        <Home className="w-3 h-3" />
                        <span>Locação Kitnet</span>
                      </span>
                    )}
                  </div>

                  {/* WhatsApp / Contato */}
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-500 dark:text-slate-400">Contato:</span>
                    <span className="text-slate-800 dark:text-slate-200 font-medium font-mono tabular-nums flex items-center gap-1">
                      <Phone className="w-3 h-3 text-slate-400 dark:text-slate-500" />
                      <span>{formatPhone(client.whatsapp || client.phone)}</span>
                    </span>
                  </div>

                  {/* Classificação & Contratos */}
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-500 dark:text-slate-400">Classificação:</span>
                    <span
                      className={`font-semibold ${
                        isExcelente
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : isMedio
                          ? 'text-amber-600 dark:text-amber-400'
                          : 'text-rose-600 dark:text-rose-400'
                      }`}
                    >
                      {isExcelente ? 'Excelente' : isMedio ? 'Médio Risco' : 'Alto Risco'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-500 dark:text-slate-400">Contratos Ativos:</span>
                    <span className="font-semibold text-slate-900 dark:text-white font-mono">
                      {client.activeContractsCount}{' '}
                      {client.activeContractsCount === 1 ? 'ativo' : 'ativos'}
                    </span>
                  </div>
                </div>

                {/* Bottom Action Footer */}
                <div className="flex items-center justify-between pt-2.5 border-t border-border-subtle text-xs">
                  <span className="text-violet-600 dark:text-violet-400 font-semibold flex items-center gap-1 group-hover:text-violet-700 dark:group-hover:text-violet-300 group-hover:translate-x-0.5 transition-all">
                    <span>Ver Perfil</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </span>

                  {client.primaryContractId && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenWhatsApp(client.primaryContractId!);
                      }}
                      className="p-1.5 sm:p-2 bg-emerald-500/15 hover:bg-emerald-500 text-emerald-600 dark:text-emerald-400 hover:text-white rounded-xl border border-emerald-500/30 hover:border-emerald-500 transition-all cursor-pointer active:scale-90 shadow-xs flex items-center justify-center"
                      title="Cobrança via WhatsApp"
                    >
                      <MessageCircle className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};


