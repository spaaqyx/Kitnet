import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import { useBodyScrollLock } from '../../../hooks/useBodyScrollLock';
import {
  Send,
  X,
  Copy,
  Check,
  ChevronDown,
  ChevronRight,
  CheckCheck,
  MessageCircle,
} from 'lucide-react';
import { BillingItem } from '../types';
import { SystemSettings, MotoContract, KitnetContract, MotoTenant, KitnetTenant } from '../../../types';
import { formatCurrency, formatDate } from '../../../utils/formatters';
import {
  openWhatsAppLink,
  generateMotoWhatsAppMessage,
  generateKitnetWhatsAppMessage,
  getDaysRemainingText,
} from '../../../utils/whatsappGenerator';

interface BatchWhatsAppModalProps {
  batchQueueItems: BillingItem[];
  motoContracts: MotoContract[];
  kitnetContracts: KitnetContract[];
  motoTenants: MotoTenant[];
  kitnetTenants: KitnetTenant[];
  settings: SystemSettings;
  isOpen?: boolean;
  onClose: () => void;
  onPaySingle: (item: BillingItem) => void;
  showToast: (msg: string) => void;
}

export const BatchWhatsAppModal: React.FC<BatchWhatsAppModalProps> = ({
  batchQueueItems,
  motoContracts,
  kitnetContracts,
  motoTenants,
  kitnetTenants,
  settings,
  isOpen: propIsOpen,
  onClose,
  onPaySingle,
  showToast,
}) => {
  const isOpen = propIsOpen !== undefined ? propIsOpen : true;
  const prefersReducedMotion = useReducedMotion();
  const lastQueueItemsRef = useRef<BillingItem[]>([]);

  if (batchQueueItems && batchQueueItems.length > 0) {
    lastQueueItemsRef.current = batchQueueItems;
  }
  const currentItems = (batchQueueItems && batchQueueItems.length > 0) ? batchQueueItems : lastQueueItemsRef.current;

  const [batchMode, setBatchMode] = useState<'completa' | 'simples' | 'urgente'>('completa');
  const [sentItemIds, setSentItemIds] = useState<string[]>([]);
  const [copiedItemId, setCopiedItemId] = useState<string | null>(null);
  const [expandedPreviewId, setExpandedPreviewId] = useState<string | null>(null);

  useBodyScrollLock(isOpen);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (typeof document === 'undefined') return null;

  // Helper to generate personalized message for any billing item
  const getItemWhatsAppMessage = (item: BillingItem, mode: 'completa' | 'simples' | 'urgente'): string => {
    const pixKey = settings.adminPixKey || 'wleal0131@gmail.com';
    const pixType = settings.adminPixType ? ` (${settings.adminPixType.toUpperCase()})` : '';
    const adminName = settings.adminName || 'Wigne Leal Xavier Macedo';
    const daysRemaining = getDaysRemainingText(item.dueDate);

    if (mode === 'urgente') {
      return `⚠️ *NOTIFICAÇÃO DE COBRANÇA URGENTE*

Olá, *${item.clientName}*!
Consta em nosso sistema uma pendência no contrato referente a *${item.assetName}* (${item.assetDetails}).

📄 *Parcela:* ${item.installmentNumber}/${item.totalInstallments}
💰 *Valor:* ${formatCurrency(item.amount)}
📅 *Vencimento:* ${formatDate(item.dueDate)} (${daysRemaining})

Favor realizar o pagamento para regularizar sua situação cadastral:
• Chave PIX${pixType}: *${pixKey}*
• Titular: *${adminName}*

Caso o pagamento já tenha sido efetuado, por favor nos envie o comprovante por aqui. Obrigado!`;
    }

    if (item.assetType === 'moto') {
      const contract = item.rawContract as MotoContract;
      const tenant = motoTenants.find((t) => t.id === item.tenantId);
      if (contract && tenant) {
        return generateMotoWhatsAppMessage(
          contract,
          tenant,
          item.rawInstallment,
          settings,
          `${item.assetName} (${item.assetDetails})`,
          mode === 'simples' ? 'simples' : 'completa'
        );
      }
    } else {
      const contract = item.rawContract as KitnetContract;
      const tenant = kitnetTenants.find((t) => t.id === item.tenantId);
      if (contract && tenant) {
        return generateKitnetWhatsAppMessage(
          contract,
          tenant,
          item.rawInstallment,
          settings,
          item.assetName,
          mode === 'simples' ? 'simples' : 'completa'
        );
      }
    }

    // Fallback message
    return `🔔 *LEMBRETE DE PAGAMENTO*

Olá, *${item.clientName}*!
Lembramos do vencimento da sua parcela de *${item.assetName}*.

📄 *Parcela:* ${item.installmentNumber}/${item.totalInstallments}
💰 *Valor:* ${formatCurrency(item.amount)}
📅 *Vencimento:* ${formatDate(item.dueDate)} (${daysRemaining})

💳 *Dados para Pagamento via PIX:*
• Chave PIX${pixType}: *${pixKey}*
• Titular: *${adminName}*

Obrigado pela preferência!`;
  };

  // Dispatch message to WhatsApp and record sent status
  const handleSendItemMessage = (item: BillingItem) => {
    const message = getItemWhatsAppMessage(item, batchMode);
    openWhatsAppLink(item.clientPhone, message);
    if (!sentItemIds.includes(item.id)) {
      setSentItemIds((prev) => [...prev, item.id]);
    }
  };

  // Copy single message to clipboard
  const handleCopyItemMessage = (item: BillingItem) => {
    const message = getItemWhatsAppMessage(item, batchMode);
    navigator.clipboard.writeText(message);
    setCopiedItemId(item.id);
    setTimeout(() => {
      setCopiedItemId(null);
    }, 2000);
    showToast(`Mensagem de ${item.clientName} copiada para a área de transferência!`);
  };

  // Send next pending in queue
  const handleSendNextInQueue = () => {
    const nextPending = batchQueueItems.find((item) => !sentItemIds.includes(item.id));
    if (nextPending) {
      handleSendItemMessage(nextPending);
    } else {
      showToast('Todas as mensagens da fila já foram encaminhadas!');
    }
  };

  // Copy all messages
  const handleCopyAllMessages = () => {
    const allText = batchQueueItems
      .map((item, index) => {
        const msg = getItemWhatsAppMessage(item, batchMode);
        return `========================================\n[${index + 1}/${batchQueueItems.length}] CLIENTE: ${item.clientName} (${item.clientPhone})\n========================================\n${msg}\n\n`;
      })
      .join('\n');

    navigator.clipboard.writeText(allText);
    showToast(`Todas as ${batchQueueItems.length} mensagens foram copiadas!`);
  };

  return createPortal(
    <AnimatePresence>
      {isOpen && currentItems.length > 0 && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Encaminhar Mensagens no WhatsApp"
          className="fixed inset-0 z-[100] flex items-center justify-center p-2.5 sm:p-4 overflow-y-auto overflow-x-hidden font-sans touch-pan-y w-full max-w-full"
          style={{ overflowX: 'hidden', touchAction: 'pan-y' }}
        >
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: prefersReducedMotion ? 0.05 : 0.2 }}
            className="fixed inset-0 bg-black/85 backdrop-blur-md"
            onClick={onClose}
          />

          {/* Modal Container */}
          <motion.div
            initial={prefersReducedMotion ? { opacity: 0 } : { opacity: 0, scale: 0.95, y: 10 }}
            animate={prefersReducedMotion ? { opacity: 1 } : { opacity: 1, scale: 1, y: 0 }}
            exit={prefersReducedMotion ? { opacity: 0 } : { opacity: 0, scale: 0.95, y: 10 }}
            transition={{
              duration: prefersReducedMotion ? 0.05 : 0.22,
              ease: [0.16, 1, 0.3, 1],
            }}
            className="relative bg-surface-card border border-border-subtle rounded-2xl sm:rounded-3xl w-full max-w-2xl min-w-0 overflow-hidden flex flex-col my-auto shadow-2xl max-h-[92vh] z-10"
          >
            {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-border-subtle flex items-center justify-between bg-surface-header shrink-0 gap-2">
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-action-primary/10 text-action-primary border border-action-primary/25 flex items-center justify-center shrink-0">
              <Send className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm sm:text-base font-bold text-text-primary truncate">
                Encaminhar Mensagens no WhatsApp
              </h3>
              <p className="text-[11px] sm:text-xs text-text-secondary truncate">
                Fila de envio individual e disparo em lote para clientes selecionados
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl text-text-muted hover:text-text-primary hover:bg-surface-hover border border-transparent hover:border-border-subtle transition-colors flex items-center justify-center cursor-pointer shrink-0 active:scale-90"
          >
            <X className="w-4.5 h-4.5" />
          </button>
        </div>

        {/* Modal Body */}
        <div
          className="p-4 sm:p-6 space-y-4 overflow-y-auto overflow-x-hidden overscroll-contain modal-scroll-container flex-1 w-full max-w-full"
          style={{ WebkitOverflowScrolling: 'touch', touchAction: 'pan-y', overflowX: 'hidden' }}
        >
          {/* Queue Status Progress Banner */}
          <div className="bg-surface-subtle p-4 rounded-xl border border-border-subtle space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <span className="text-xs text-text-secondary font-semibold block">Progresso do Envio:</span>
                <span className="text-sm font-bold text-text-primary">
                  {sentItemIds.filter((id) => batchQueueItems.some((i) => i.id === id)).length} de{' '}
                  {batchQueueItems.length} mensagens encaminhadas
                </span>
              </div>
              <div className="text-right">
                <span className="text-xs text-text-secondary block">Total na Fila:</span>
                <span className="text-sm font-bold text-action-primary tabular-nums">
                  {formatCurrency(batchQueueItems.reduce((acc, i) => acc + i.amount, 0))}
                </span>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-surface-card rounded-full h-2 overflow-hidden border border-border-dark">
              <div
                className="h-full bg-gradient-to-r from-action-primary to-money-positive rounded-full transition-all duration-300"
                style={{
                  width: `${
                    batchQueueItems.length > 0
                      ? Math.round(
                          (sentItemIds.filter((id) => batchQueueItems.some((i) => i.id === id)).length /
                            batchQueueItems.length) *
                            100
                        )
                      : 0
                  }%`,
                }}
              />
            </div>

            {/* Batch Top Quick Actions */}
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <button
                onClick={handleSendNextInQueue}
                className="px-3.5 py-1.5 bg-action-primary hover:bg-action-hover text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-sm"
              >
                <Send className="w-3.5 h-3.5 stroke-[2.5]" />
                Encaminhar Próximo da Fila
              </button>

              <button
                onClick={handleCopyAllMessages}
                className="px-3 py-1.5 bg-surface-card hover:bg-border-dark text-text-primary border border-border-dark text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5 text-text-secondary" />
                Copiar Todas
              </button>
            </div>
          </div>

          {/* Message Template Selector */}
          <div>
            <label className="block text-xs font-semibold text-text-secondary mb-2 uppercase tracking-wider">
              Modelo da Mensagem
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setBatchMode('completa')}
                className={`p-2.5 rounded-xl border text-xs text-left transition-all active:scale-95 cursor-pointer ${
                  batchMode === 'completa'
                    ? 'bg-action-primary/10 border-action-primary text-text-primary'
                    : 'bg-surface-base border-border-dark text-text-secondary hover:border-border-dark-hover'
                }`}
              >
                <div className="font-bold flex items-center gap-1.5 text-text-primary">
                  {batchMode === 'completa' && <Check className="w-3.5 h-3.5 text-action-primary" />}
                  Completa
                </div>
                <p className="text-[11px] text-text-secondary mt-0.5">Extrato, PIX e barra de progresso</p>
              </button>

              <button
                type="button"
                onClick={() => setBatchMode('simples')}
                className={`p-2.5 rounded-xl border text-xs text-left transition-all active:scale-95 cursor-pointer ${
                  batchMode === 'simples'
                    ? 'bg-action-primary/10 border-action-primary text-text-primary'
                    : 'bg-surface-base border-border-dark text-text-secondary hover:border-border-dark-hover'
                }`}
              >
                <div className="font-bold flex items-center gap-1.5 text-text-primary">
                  {batchMode === 'simples' && <Check className="w-3.5 h-3.5 text-action-primary" />}
                  Simples
                </div>
                <p className="text-[11px] text-text-secondary mt-0.5">Lembrete rápido de vencimento</p>
              </button>

              <button
                type="button"
                onClick={() => setBatchMode('urgente')}
                className={`p-2.5 rounded-xl border text-xs text-left transition-all active:scale-95 cursor-pointer ${
                  batchMode === 'urgente'
                    ? 'bg-money-negative/10 border-money-negative text-text-primary'
                    : 'bg-surface-base border-border-dark text-text-secondary hover:border-border-dark-hover'
                }`}
              >
                <div className="font-bold flex items-center gap-1.5 text-money-negative">
                  {batchMode === 'urgente' && <Check className="w-3.5 h-3.5 text-money-negative" />}
                  Cobrança Urgente
                </div>
                <p className="text-[11px] text-text-secondary mt-0.5">Para contratos em atraso</p>
              </button>
            </div>
          </div>

          {/* List of Clients in Queue */}
          <div className="space-y-2.5">
            <span className="text-xs font-semibold text-text-secondary uppercase tracking-wider flex items-center justify-between">
              <span>Clientes na Fila ({batchQueueItems.length}):</span>
              <span className="text-[11px] text-text-muted lowercase">Clique em "Enviar" para abrir o WhatsApp</span>
            </span>

            {batchQueueItems.map((item, index) => {
              const isSent = sentItemIds.includes(item.id);
              const isExpanded = expandedPreviewId === item.id;
              const itemMessage = getItemWhatsAppMessage(item, batchMode);

              return (
                <div
                  key={item.id}
                  className={`p-3.5 rounded-xl border transition-all ${
                    isSent
                      ? 'bg-surface-base/60 border-money-positive/30'
                      : 'bg-surface-base border-border-dark hover:border-border-dark-hover'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-start gap-2.5 min-w-0">
                      <span className="w-5 h-5 rounded-full bg-surface-card text-text-secondary text-[10px] font-bold flex items-center justify-center shrink-0 border border-border-dark mt-0.5">
                        {index + 1}
                      </span>

                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-sm text-text-primary truncate">{item.clientName}</span>
                          {isSent ? (
                            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-money-positive/15 text-money-positive border border-money-positive/30 flex items-center gap-1">
                              <Check className="w-3 h-3" /> Enviado
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-border-dark text-text-secondary">
                              Pendente
                            </span>
                          )}
                          {item.status === 'atrasado' && (
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-money-negative/15 text-money-negative">
                              {item.daysOverdue}d atraso
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2 text-xs text-text-secondary mt-0.5 flex-wrap">
                          <span>{item.assetName}</span>
                          <span>•</span>
                          <span>Tel: {item.clientPhone || 'Não cadastrado'}</span>
                          <span>•</span>
                          <span className="font-bold text-action-primary tabular-nums">{formatCurrency(item.amount)}</span>
                        </div>
                      </div>
                    </div>

                    {/* Action buttons per client */}
                    <div className="flex items-center gap-1.5 self-end sm:self-auto shrink-0">
                      {/* Toggle Preview */}
                      <button
                        type="button"
                        onClick={() => setExpandedPreviewId(isExpanded ? null : item.id)}
                        className="p-2 text-text-secondary hover:text-text-primary hover:bg-surface-card rounded-lg transition-all active:scale-95 cursor-pointer text-xs flex items-center gap-1"
                        title="Visualizar texto da mensagem"
                      >
                        <span className="text-[11px] hidden sm:inline">Ver texto</span>
                        {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                      </button>

                      {/* Copy */}
                      <button
                        type="button"
                        onClick={() => handleCopyItemMessage(item)}
                        className="p-2 text-text-secondary hover:text-text-primary hover:bg-surface-card rounded-lg transition-all active:scale-95 cursor-pointer"
                        title="Copiar mensagem"
                      >
                        {copiedItemId === item.id ? (
                          <Check className="w-4 h-4 text-money-positive" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </button>

                      {/* Quick Pay */}
                      <button
                        type="button"
                        onClick={() => onPaySingle(item)}
                        className="p-2 text-money-positive hover:bg-money-positive/10 rounded-lg transition-all active:scale-95 cursor-pointer"
                        title="Dar baixa nesta parcela"
                      >
                        <CheckCheck className="w-4 h-4" />
                      </button>

                      {/* Send WhatsApp */}
                      <button
                        type="button"
                        onClick={() => handleSendItemMessage(item)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-sm ${
                          isSent
                            ? 'bg-border-dark text-money-positive hover:bg-border-dark-hover'
                            : 'bg-money-positive-hover hover:bg-money-positive-hover text-white'
                        }`}
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        {isSent ? 'Reenviar' : 'Enviar'}
                      </button>
                    </div>
                  </div>

                  {/* Expandable Preview */}
                  {isExpanded && (
                    <div className="mt-3 p-3 bg-surface-card rounded-lg border border-border-dark text-xs text-text-secondary font-mono whitespace-pre-wrap leading-relaxed animate-fadeIn">
                      {itemMessage}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-5 border-t border-border-subtle flex items-center justify-between gap-3 bg-surface-header shrink-0">
          <span className="text-xs text-text-secondary">
            {sentItemIds.filter((id) => batchQueueItems.some((i) => i.id === id)).length} de{' '}
            {batchQueueItems.length} enviados
          </span>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs sm:text-sm font-semibold text-text-muted hover:text-text-primary hover:bg-surface-hover rounded-xl border border-transparent hover:border-border-subtle transition-colors active:scale-95 cursor-pointer"
            >
              Concluir / Fechar
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  )}
</AnimatePresence>,
    document.body
  );
};
