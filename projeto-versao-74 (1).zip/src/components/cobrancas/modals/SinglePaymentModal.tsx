import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import { useBodyScrollLock } from '../../../hooks/useBodyScrollLock';
import { CheckCheck, X, Check, Smartphone, DollarSign, CreditCard } from 'lucide-react';
import { BillingItem } from '../types';
import { formatCurrency, formatDate } from '../../../utils/formatters';

interface SinglePaymentModalProps {
  item: BillingItem | null;
  isOpen?: boolean;
  onClose: () => void;
  onConfirm: (item: BillingItem, method: 'pix' | 'dinheiro' | 'transferencia' | 'cartao', notes: string) => void;
}

export const SinglePaymentModal: React.FC<SinglePaymentModalProps> = ({
  item,
  isOpen: propIsOpen,
  onClose,
  onConfirm,
}) => {
  const isOpen = propIsOpen !== undefined ? propIsOpen : Boolean(item);
  const prefersReducedMotion = useReducedMotion();
  const lastItemRef = useRef<BillingItem | null>(null);

  if (item) {
    lastItemRef.current = item;
  }
  const currentItem = item || lastItemRef.current;

  const [paymentNotes, setPaymentNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'dinheiro' | 'transferencia' | 'cartao'>('pix');

  useBodyScrollLock(isOpen);

  useEffect(() => {
    if (isOpen) {
      setPaymentNotes('');
      setPaymentMethod('pix');
    }
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (typeof document === 'undefined') return null;

  return createPortal(
    <AnimatePresence>
      {isOpen && currentItem && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Confirmar Pagamento"
          className="fixed inset-0 z-[100] flex items-center justify-center p-2.5 sm:p-4 overflow-y-auto overflow-x-hidden font-sans touch-pan-y w-full max-w-full"
          style={{ overflowX: 'hidden', touchAction: 'pan-y' }}
        >
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: prefersReducedMotion ? 0.05 : 0.2 }}
            className="fixed inset-0 bg-black/85 backdrop-blur-md"
            onClick={onClose}
          />

          {/* Modal Container */}
          <motion.div
            initial={prefersReducedMotion ? { opacity: 0 } : { opacity: 0, scale: 0.95, y: 10 }}
            animate={prefersReducedMotion ? { opacity: 1 } : { opacity: 1, scale: 1, y: 0 }}
            exit={prefersReducedMotion ? { opacity: 0 } : { opacity: 0, scale: 0.95, y: 10 }}
            transition={{
              duration: prefersReducedMotion ? 0.05 : 0.22,
              ease: [0.16, 1, 0.3, 1],
            }}
            className="relative bg-surface-card border border-border-subtle rounded-2xl sm:rounded-3xl w-full max-w-md min-w-0 overflow-hidden flex flex-col my-auto shadow-2xl z-10"
          >
            <div className="p-4 sm:p-5 border-b border-border-subtle flex items-center justify-between bg-surface-header gap-2 shrink-0">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
                  <CheckCheck className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-sm sm:text-base font-bold text-text-primary truncate">Confirmar Pagamento</h3>
                  <p className="text-[11px] sm:text-xs text-text-secondary truncate">Registro de quitação de parcela</p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="w-9 h-9 rounded-xl text-text-muted hover:text-text-primary hover:bg-surface-hover border border-transparent hover:border-border-subtle transition-colors flex items-center justify-center cursor-pointer shrink-0 active:scale-90"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            <div className="p-4 sm:p-5 space-y-4 overflow-y-auto overflow-x-hidden modal-scroll-container">
              {/* Item Summary Card */}
              <div className="bg-surface-subtle border border-border-subtle p-4 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-text-secondary uppercase tracking-wider">Cliente</span>
                  <span className="text-sm font-bold text-text-primary">{currentItem.clientName}</span>
                </div>
                <div className="flex items-center justify-between text-xs text-text-secondary">
                  <span>Ativo:</span>
                  <span className="text-text-primary font-medium">{currentItem.assetName}</span>
                </div>
                <div className="flex items-center justify-between text-xs text-text-secondary">
                  <span>Parcela:</span>
                  <span className="text-text-primary font-medium">
                    {currentItem.installmentNumber}/{currentItem.totalInstallments} (Venc: {formatDate(currentItem.dueDate)})
                  </span>
                </div>
                <div className="pt-2 border-t border-border-dark flex items-center justify-between">
                  <span className="text-xs font-bold text-action-primary">Valor Quitado:</span>
                  <span className="text-lg font-black text-money-positive tabular-nums">
                    {formatCurrency(currentItem.amount)}
                  </span>
                </div>
              </div>

              {/* Payment Method Selector */}
              <div>
                <label className="block text-xs font-semibold text-text-secondary mb-1.5">
                  Forma de Pagamento
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(['pix', 'dinheiro', 'transferencia', 'cartao'] as const).map((method) => (
                    <button
                      key={method}
                      type="button"
                      onClick={() => setPaymentMethod(method)}
                      className={`px-3 py-2 rounded-xl text-xs font-bold transition-colors duration-150 border flex items-center justify-center gap-1.5 cursor-pointer uppercase active:scale-95 ${
                        paymentMethod === method
                          ? 'bg-action-primary text-surface-base border-action-primary'
                          : 'bg-surface-base text-text-secondary border-border-dark hover:border-border-dark-hover'
                      }`}
                    >
                      {method === 'pix' && <Smartphone className="w-3.5 h-3.5" />}
                      {method === 'dinheiro' && <DollarSign className="w-3.5 h-3.5" />}
                      {method === 'transferencia' && <CreditCard className="w-3.5 h-3.5" />}
                      {method === 'cartao' && <CreditCard className="w-3.5 h-3.5" />}
                      {method}
                    </button>
                  ))}
                </div>
              </div>

              {/* Observação Opcional */}
              <div>
                <label className="block text-xs font-semibold text-text-secondary mb-1.5">
                  Observações (Opcional)
                </label>
                <input
                  type="text"
                  placeholder="Ex: Comprovante enviado no WhatsApp, pagamento adiantado..."
                  value={paymentNotes}
                  onChange={(e) => setPaymentNotes(e.target.value)}
                  className="w-full bg-surface-subtle border border-border-subtle hover:border-border-hover focus:border-action-primary focus:ring-1 focus:ring-action-primary rounded-xl px-3.5 py-2.5 text-xs text-text-primary placeholder:text-text-dim transition-colors duration-150 outline-none"
                />
              </div>
            </div>

            <div className="p-4 sm:p-5 border-t border-border-subtle flex items-center justify-end gap-2.5 bg-surface-header shrink-0">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs sm:text-sm font-semibold text-text-muted hover:text-text-primary hover:bg-surface-hover rounded-xl border border-transparent hover:border-border-subtle transition-colors cursor-pointer active:scale-95"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => onConfirm(currentItem, paymentMethod, paymentNotes)}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer active:scale-95 shadow-sm"
              >
                <Check className="w-4 h-4 stroke-[3]" />
                Confirmar Quitação
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body
  );
};
