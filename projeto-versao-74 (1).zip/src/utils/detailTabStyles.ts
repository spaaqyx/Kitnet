/**
 * src/utils/detailTabStyles.ts
 * 
 * Configuração padronizada de estilos luminosos e cores semânticas por função
 * para as abas de Detalhes de Motos e Kitnets.
 * 
 * Cada função possui uma identidade visual única e iluminada (neon glow):
 * - Geral / Dados: Roxo / Violeta
 * - Contrato & Parcelas: Verde Esmeralda
 * - Locatário / Inquilino: Azul Celeste (Sky)
 * - Vistoria: Verde Menta (Teal)
 * - Fotos: Rosa Choque (Pink)
 * - Manutenções: Âmbar / Laranja
 * - Quilometragem: Índigo / Azul Real
 * - Documentos: Rose / Coral
 */

export interface TabThemeConfig {
  activeBtn: string;
  activeIcon: string;
  activeBadge: string;
  hoverBtn: string;
}

export const DETAIL_TAB_THEMES: Record<string, TabThemeConfig> = {
  geral: {
    activeBtn:
      'bg-gradient-to-r from-purple-500/25 via-purple-500/15 to-violet-500/20 text-purple-800 dark:text-purple-200 border-purple-500/80 font-bold',
    activeIcon: 'text-purple-600 dark:text-purple-300',
    activeBadge: 'bg-purple-600 text-white dark:bg-purple-500 dark:text-slate-950 font-black',
    hoverBtn: 'hover:border-purple-500/50 hover:bg-purple-500/[0.08] hover:text-purple-600 dark:hover:text-purple-300',
  },
  contrato: {
    activeBtn:
      'bg-gradient-to-r from-emerald-500/25 via-emerald-500/15 to-teal-500/20 text-emerald-800 dark:text-emerald-200 border-emerald-500/80 font-bold',
    activeIcon: 'text-emerald-600 dark:text-emerald-300',
    activeBadge: 'bg-emerald-600 text-white dark:bg-emerald-500 dark:text-slate-950 font-black',
    hoverBtn: 'hover:border-emerald-500/50 hover:bg-emerald-500/[0.08] hover:text-emerald-600 dark:hover:text-emerald-300',
  },
  locatario: {
    activeBtn:
      'bg-gradient-to-r from-sky-500/25 via-sky-500/15 to-cyan-500/20 text-sky-800 dark:text-sky-200 border-sky-500/80 font-bold',
    activeIcon: 'text-sky-600 dark:text-sky-300',
    activeBadge: 'bg-sky-600 text-white dark:bg-sky-500 dark:text-slate-950 font-black',
    hoverBtn: 'hover:border-sky-500/50 hover:bg-sky-500/[0.08] hover:text-sky-600 dark:hover:text-sky-300',
  },
  inquilino: {
    activeBtn:
      'bg-gradient-to-r from-sky-500/25 via-sky-500/15 to-cyan-500/20 text-sky-800 dark:text-sky-200 border-sky-500/80 font-bold',
    activeIcon: 'text-sky-600 dark:text-sky-300',
    activeBadge: 'bg-sky-600 text-white dark:bg-sky-500 dark:text-slate-950 font-black',
    hoverBtn: 'hover:border-sky-500/50 hover:bg-sky-500/[0.08] hover:text-sky-600 dark:hover:text-sky-300',
  },
  manutencoes: {
    activeBtn:
      'bg-gradient-to-r from-amber-500/25 via-amber-500/15 to-orange-500/20 text-amber-800 dark:text-amber-200 border-amber-500/80 font-bold',
    activeIcon: 'text-amber-600 dark:text-amber-300',
    activeBadge: 'bg-amber-600 text-white dark:bg-amber-500 dark:text-slate-950 font-black',
    hoverBtn: 'hover:border-amber-500/50 hover:bg-amber-500/[0.08] hover:text-amber-600 dark:hover:text-amber-300',
  },
  km: {
    activeBtn:
      'bg-gradient-to-r from-indigo-500/25 via-indigo-500/15 to-blue-500/20 text-indigo-800 dark:text-indigo-200 border-indigo-500/80 font-bold',
    activeIcon: 'text-indigo-600 dark:text-indigo-300',
    activeBadge: 'bg-indigo-600 text-white dark:bg-indigo-500 dark:text-slate-950 font-black',
    hoverBtn: 'hover:border-indigo-500/50 hover:bg-indigo-500/[0.08] hover:text-indigo-600 dark:hover:text-indigo-300',
  },
  vistoria: {
    activeBtn:
      'bg-gradient-to-r from-teal-500/25 via-teal-500/15 to-emerald-500/20 text-teal-800 dark:text-teal-200 border-teal-500/80 font-bold',
    activeIcon: 'text-teal-600 dark:text-teal-300',
    activeBadge: 'bg-teal-600 text-white dark:bg-teal-500 dark:text-slate-950 font-black',
    hoverBtn: 'hover:border-teal-500/50 hover:bg-teal-500/[0.08] hover:text-teal-600 dark:hover:text-teal-300',
  },
  fotos: {
    activeBtn:
      'bg-gradient-to-r from-pink-500/25 via-pink-500/15 to-fuchsia-500/20 text-pink-800 dark:text-pink-200 border-pink-500/80 font-bold',
    activeIcon: 'text-pink-600 dark:text-pink-300',
    activeBadge: 'bg-pink-600 text-white dark:bg-pink-500 dark:text-slate-950 font-black',
    hoverBtn: 'hover:border-pink-500/50 hover:bg-pink-500/[0.08] hover:text-pink-600 dark:hover:text-pink-300',
  },
  documentos: {
    activeBtn:
      'bg-gradient-to-r from-rose-500/25 via-rose-500/15 to-red-500/20 text-rose-800 dark:text-rose-200 border-rose-500/80 font-bold',
    activeIcon: 'text-rose-600 dark:text-rose-300',
    activeBadge: 'bg-rose-600 text-white dark:bg-rose-500 dark:text-slate-950 font-black',
    hoverBtn: 'hover:border-rose-500/50 hover:bg-rose-500/[0.08] hover:text-rose-600 dark:hover:text-rose-300',
  },
};

const DEFAULT_THEME: TabThemeConfig = DETAIL_TAB_THEMES.geral;

export function getDetailTabTheme(tabId: string): TabThemeConfig {
  return DETAIL_TAB_THEMES[tabId] || DEFAULT_THEME;
}
