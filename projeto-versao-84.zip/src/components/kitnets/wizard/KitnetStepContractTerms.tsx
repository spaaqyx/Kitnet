import React from 'react';
import { Calendar, Users, User, UserX, ShieldCheck } from 'lucide-react';
import { formatDate, formatDateFullPT, getTodayLocalDateString, maskCPFInput } from '../../../utils/formatters';
import { NumericInput } from '../../NumericInput';

interface KitnetStepContractTermsProps {
  stepNumber?: number;
  contractTerms: {
    signatureDate: string;
    startDate: string;
    durationOption: number | 'custom';
    customMonths: number;
    endDate: string;
    witnessesCount?: number;
    witness1Name?: string;
    witness1Cpf?: string;
    witness2Name?: string;
    witness2Cpf?: string;
  };
  setContractTerms: React.Dispatch<React.SetStateAction<any>>;
}

export const KitnetStepContractTerms: React.FC<KitnetStepContractTermsProps> = ({
  stepNumber = 4,
  contractTerms,
  setContractTerms,
}) => {
  const witnessesCount = contractTerms.witnessesCount !== undefined ? Number(contractTerms.witnessesCount) : 0;
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between border-b border-white/[0.08] pb-3.5">
        <div className="flex items-center gap-2.5 text-white font-bold text-sm sm:text-base min-w-0">
          <span className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center text-xs font-black shrink-0">
            {stepNumber}
          </span>
          <span className="truncate">Vigência e Prazos do Contrato</span>
        </div>
        <span className="text-xs text-slate-400 hidden sm:inline shrink-0">
          Cálculo automático de datas
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-12 gap-4">
        <div className="sm:col-span-6 space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="block text-xs font-semibold text-slate-300">
              Data da Assinatura *
            </label>
            {contractTerms.signatureDate !== contractTerms.startDate && contractTerms.startDate && (
              <button
                type="button"
                onClick={() =>
                  setContractTerms((prev: any) => ({
                    ...prev,
                    signatureDate: prev.startDate,
                  }))
                }
                className="text-[11px] text-emerald-400 hover:text-emerald-300 underline cursor-pointer font-medium active:scale-95 transition-transform"
              >
                Igualar ao Início
              </button>
            )}
          </div>
          <input
            type="date"
            value={contractTerms.signatureDate}
            onChange={(e) =>
              setContractTerms({
                ...contractTerms,
                signatureDate: e.target.value,
              })
            }
            className="w-full h-11 bg-surface-base border border-white/[0.12] hover:border-white/[0.20] focus:bg-surface-base rounded-xl px-3.5 text-sm text-white focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/25 transition-all [color-scheme:light] dark:[color-scheme:dark]"
          />
          {contractTerms.signatureDate && (
            <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-medium px-1">
              <Calendar className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Assinatura: <strong className="text-white">{formatDateFullPT(contractTerms.signatureDate)}</strong></span>
            </div>
          )}
        </div>

        <div className="sm:col-span-6 space-y-1.5">
          <label className="block text-xs font-semibold text-slate-300">
            Data de Início da Locação *
          </label>
          <input
            type="date"
            value={contractTerms.startDate}
            onChange={(e) => {
              const newStartDate = e.target.value;
              setContractTerms((prev: any) => {
                const shouldSyncSignature =
                  !prev.signatureDate ||
                  prev.signatureDate === prev.startDate ||
                  prev.signatureDate === getTodayLocalDateString();
                return {
                  ...prev,
                  startDate: newStartDate,
                  signatureDate: shouldSyncSignature ? newStartDate : prev.signatureDate,
                };
              });
            }}
            className="w-full h-11 bg-surface-base border border-white/[0.12] hover:border-white/[0.20] focus:bg-surface-base rounded-xl px-3.5 text-sm text-white focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/25 transition-all [color-scheme:light] dark:[color-scheme:dark]"
          />
          {contractTerms.startDate && (
            <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-medium px-1">
              <Calendar className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Início da locação: <strong className="text-white">{formatDateFullPT(contractTerms.startDate)}</strong></span>
            </div>
          )}
        </div>

        {/* Prazo */}
        <div className="sm:col-span-12">
          <label className="block text-xs font-semibold text-slate-300 mb-2">
            Duração da Locação *
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {[
              { val: 6, label: '6 meses' },
              { val: 12, label: '12 meses (Padrão)' },
              { val: 24, label: '24 meses' },
              { val: 'custom', label: 'Personalizado' },
            ].map((opt) => (
              <button
                key={String(opt.val)}
                type="button"
                onClick={() =>
                  setContractTerms({
                    ...contractTerms,
                    durationOption: opt.val as any,
                  })
                }
                className={`p-2.5 sm:p-3 rounded-xl border text-center flex items-center justify-center transition-all cursor-pointer active:scale-95 ${
                  contractTerms.durationOption === opt.val
                    ? 'bg-emerald-500/15 border-emerald-500/60 text-emerald-300 font-bold ring-2 ring-emerald-500/25'
                    : 'bg-surface-base border-white/[0.08] text-slate-400 hover:text-white hover:border-white/[0.20]'
                }`}
              >
                <span className="text-xs font-semibold">{opt.label}</span>
              </button>
            ))}
          </div>
        </div>

        {contractTerms.durationOption === 'custom' && (
          <div className="sm:col-span-6">
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Número de Meses
            </label>
            <NumericInput
              mode="integer"
              min={1}
              max={60}
              value={contractTerms.customMonths}
              onChange={(val) =>
                setContractTerms({
                  ...contractTerms,
                  customMonths: val,
                })
              }
              className="w-full bg-surface-base border border-white/[0.12] hover:border-white/[0.20] focus:bg-surface-base rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/25 transition-all"
            />
          </div>
        )}

        {/* Card de Data de Término */}
        <div className="sm:col-span-12 p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-emerald-500/10 via-surface-base to-teal-500/10 border border-emerald-500/20 flex items-center justify-between shadow-lg shadow-emerald-500/5">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-400">
                Data de Término Calculada
              </div>
              <div className="text-sm sm:text-base font-bold text-white tracking-wide">
                {formatDate(contractTerms.endDate)}
              </div>
            </div>
          </div>
          <span className="text-xs px-3 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
            {contractTerms.durationOption === 'custom'
              ? `${contractTerms.customMonths} meses`
              : `${contractTerms.durationOption} meses`}
          </span>
        </div>
      </div>

      {/* SEÇÃO: TESTEMUNHAS DO CONTRATO */}
      <div className="p-4 sm:p-5 bg-surface-base border border-white/[0.08] rounded-2xl space-y-4 shadow-sm">
        <div className="flex items-center justify-between border-b border-white/[0.06] pb-3 gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
              <ShieldCheck className="w-3.5 h-3.5" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-white truncate">Testemunhas do Contrato de Locação</p>
              <p className="text-[11px] text-slate-400 truncate">
                Garante eficácia de título executivo extrajudicial (Art. 784, III do CPC)
              </p>
            </div>
          </div>

          <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 whitespace-nowrap shrink-0">
            {witnessesCount === 0 ? 'Sem Testemunhas' : `${witnessesCount} Testemunha${witnessesCount > 1 ? 's' : ''}`}
          </span>
        </div>

        {/* 3 Opções: 0, 1, 2 Testemunhas */}
        <div className="grid grid-cols-3 gap-2 sm:gap-3">
          <button
            type="button"
            onClick={() => setContractTerms((prev: any) => ({ ...prev, witnessesCount: 0 }))}
            className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center relative active:scale-95 ${
              witnessesCount === 0
                ? 'bg-emerald-500/15 border-emerald-500/50 text-white shadow-md shadow-emerald-500/15 ring-1 ring-emerald-500/40'
                : 'bg-surface-base border-white/[0.08] text-slate-400 hover:border-white/[0.18]'
            }`}
          >
            <span className="absolute -top-2.5 right-2 sm:right-auto sm:left-1/2 sm:-translate-x-1/2 bg-emerald-500 text-slate-950 text-[9px] font-black uppercase px-2 py-0.5 rounded-full shadow-xs whitespace-nowrap">
              Padrão
            </span>
            <UserX className="w-4 h-4 mb-1.5 opacity-80" />
            <span className="text-xs font-bold text-white leading-tight">Sem Testemunhas</span>
            <span className="text-[10px] text-slate-400 mt-0.5">Assinatura direta</span>
          </button>

          <button
            type="button"
            onClick={() => setContractTerms((prev: any) => ({ ...prev, witnessesCount: 1 }))}
            className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center active:scale-95 ${
              witnessesCount === 1
                ? 'bg-emerald-500/15 border-emerald-500/50 text-white shadow-md shadow-emerald-500/15 ring-1 ring-emerald-500/40'
                : 'bg-surface-base border-white/[0.08] text-slate-400 hover:border-white/[0.18]'
            }`}
          >
            <User className="w-4 h-4 mb-1.5 opacity-80" />
            <span className="text-xs font-bold text-white leading-tight">1 Testemunha</span>
            <span className="text-[10px] text-slate-400 mt-0.5">Apenas uma</span>
          </button>

          <button
            type="button"
            onClick={() => setContractTerms((prev: any) => ({ ...prev, witnessesCount: 2 }))}
            className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center active:scale-95 ${
              witnessesCount === 2
                ? 'bg-emerald-500/15 border-emerald-500/50 text-white shadow-md shadow-emerald-500/15 ring-1 ring-emerald-500/40'
                : 'bg-surface-base border-white/[0.08] text-slate-400 hover:border-white/[0.18]'
            }`}
          >
            <Users className="w-4 h-4 mb-1.5 opacity-80" />
            <span className="text-xs font-bold text-white leading-tight">2 Testemunhas</span>
            <span className="text-[10px] text-slate-400 mt-0.5">Título Executivo</span>
          </button>
        </div>

        {/* Inputs se houver testemunhas */}
        {witnessesCount > 0 && (
          <div className="space-y-3 pt-2 border-t border-white/[0.06]">
            {/* 1ª Testemunha */}
            <div className="p-3 bg-surface-base rounded-xl border border-white/[0.08] space-y-2.5">
              <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-[10px] font-bold">
                  1
                </span>
                1ª Testemunha Instrumentária
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[11px] font-medium text-slate-400 mb-1 block">
                    Nome Completo da Testemunha
                  </label>
                  <input
                    type="text"
                    value={contractTerms.witness1Name || ''}
                    onChange={(e) => setContractTerms((prev: any) => ({ ...prev, witness1Name: e.target.value }))}
                    placeholder="Ex: Carlos Eduardo da Silva"
                    className="w-full px-3 py-2 bg-surface-subtle border border-white/[0.1] rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-medium text-slate-400 mb-1 block">
                    CPF da Testemunha
                  </label>
                  <input
                    type="text"
                    inputMode="numeric"
                    maxLength={14}
                    value={contractTerms.witness1Cpf || ''}
                    onChange={(e) => setContractTerms((prev: any) => ({ ...prev, witness1Cpf: maskCPFInput(e.target.value) }))}
                    placeholder="000.000.000-00"
                    className="w-full px-3 py-2 bg-surface-subtle border border-white/[0.1] rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors font-mono"
                  />
                </div>
              </div>
            </div>

            {/* 2ª Testemunha */}
            {witnessesCount === 2 && (
              <div className="p-3 bg-surface-base rounded-xl border border-white/[0.08] space-y-2.5">
                <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-[10px] font-bold">
                    2
                  </span>
                  2ª Testemunha Instrumentária
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-[11px] font-medium text-slate-400 mb-1 block">
                      Nome Completo da Testemunha
                    </label>
                    <input
                      type="text"
                      value={contractTerms.witness2Name || ''}
                      onChange={(e) => setContractTerms((prev: any) => ({ ...prev, witness2Name: e.target.value }))}
                      placeholder="Ex: Mariana Ferreira Santos"
                      className="w-full px-3 py-2 bg-surface-subtle border border-white/[0.1] rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-medium text-slate-400 mb-1 block">
                      CPF da Testemunha
                    </label>
                    <input
                      type="text"
                      inputMode="numeric"
                      maxLength={14}
                      value={contractTerms.witness2Cpf || ''}
                      onChange={(e) => setContractTerms((prev: any) => ({ ...prev, witness2Cpf: maskCPFInput(e.target.value) }))}
                      placeholder="000.000.000-00"
                      className="w-full px-3 py-2 bg-surface-subtle border border-white/[0.1] rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors font-mono"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
