import React, { useEffect } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  BadgeAlert,
  Users,
  Calendar,
  FileSpreadsheet,
  FileText,
  Settings,
  Calculator,
  Phone,
  Smartphone,
  Lock,
  ChevronRight,
  ShieldCheck,
  Eye,
  EyeOff,
  Sun,
  Moon,
} from 'lucide-react';
import { TabType } from './Navigation';
import { useApp } from '../context/AppContext';
import { useTheme } from '../context/ThemeContext';
import { ThemeToggle } from './ui/theme-toggle';
import { useBodyScrollLock } from '../hooks/useBodyScrollLock';

interface MoreMenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTab: (tab: TabType) => void;
  onOpenSimulator: () => void;
  onOpenContacts: () => void;
  onOpenPwaGuide: () => void;
  overdueCount?: number;
}

export const MoreMenuDrawer: React.FC<MoreMenuDrawerProps> = ({
  isOpen,
  onClose,
  onSelectTab,
  onOpenSimulator,
  onOpenContacts,
  onOpenPwaGuide,
  overdueCount = 0,
}) => {
  const { lockApp, isDemoMode, toggleDemoMode, isReadOnlyMode, toggleReadOnlyMode } = useApp();
  const { isDark } = useTheme();

  useBodyScrollLock(isOpen);

  const handleClose = (callback?: () => void) => {
    onClose();
    if (callback) {
      try {
        callback();
      } catch (err) {
        console.error('Erro ao executar ação do menu:', err);
      }
    }
  };

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const operationalModules = [
    {
      id: 'cobrancas' as TabType,
      label: 'Central de Cobranças',
      desc: 'Cobrança WhatsApp e parcelas',
      icon: BadgeAlert,
      color: 'text-money-negative',
      bg: 'bg-money-negative/15',
      badge: overdueCount > 0 ? `${overdueCount} atrasos` : undefined,
    },
    {
      id: 'clientes' as TabType,
      label: 'Clientes & Score',
      desc: 'Cadastro e pontuação',
      icon: Users,
      color: 'text-action-primary',
      bg: 'bg-action-primary/15',
    },
    {
      id: 'calendario' as TabType,
      label: 'Calendário Operacional',
      desc: 'Vencimentos e manutenções',
      icon: Calendar,
      color: 'text-category-motos-alt',
      bg: 'bg-category-motos-alt/15',
    },
    {
      id: 'relatorios' as TabType,
      label: 'Relatórios & Exportação',
      desc: 'DRE e fluxo de caixa',
      icon: FileSpreadsheet,
      color: 'text-money-positive',
      bg: 'bg-money-positive/15',
    },
    {
      id: 'documentos' as TabType,
      label: 'Documentos & Contratos',
      desc: 'Gerador com assinatura',
      icon: FileText,
      color: 'text-category-kitnets-cyan',
      bg: 'bg-category-kitnets-cyan/15',
    },
    {
      id: 'configuracoes' as TabType,
      label: 'Ajustes & Backup',
      desc: 'Configuração e dados',
      icon: Settings,
      color: 'text-slate-700 dark:text-text-secondary',
      bg: 'bg-slate-200/80 dark:bg-white/10',
    },
  ];

  const quickTools = [
    {
      label: 'Simulador',
      fullName: 'Simulador de Compra',
      icon: Calculator,
      color: 'text-action-primary',
      bg: 'bg-action-primary/10 hover:bg-action-primary/20',
      border: 'border-action-primary/20',
      onClick: () => handleClose(onOpenSimulator),
    },
    {
      label: 'Contatos',
      fullName: 'Contatos Rápidos',
      icon: Phone,
      color: 'text-money-positive',
      bg: 'bg-money-positive/10 hover:bg-money-positive/20',
      border: 'border-money-positive/20',
      onClick: () => handleClose(onOpenContacts),
    },
    {
      label: 'Instalar PWA',
      fullName: 'Instalar App (PWA)',
      icon: Smartphone,
      color: 'text-category-kitnets-sky',
      bg: 'bg-category-kitnets-sky/10 hover:bg-category-kitnets-sky/20',
      border: 'border-category-kitnets-sky/20',
      onClick: () => handleClose(onOpenPwaGuide),
    },
    {
      label: 'Bloquear',
      fullName: 'Bloquear Aplicativo',
      icon: Lock,
      color: 'text-money-negative',
      bg: 'bg-money-negative/10 hover:bg-money-negative/20',
      border: 'border-money-negative/20',
      onClick: () => handleClose(lockApp),
    },
  ];

  return typeof document !== 'undefined'
    ? createPortal(
        <AnimatePresence>
          {isOpen && (
            <motion.div
              key="more-menu-portal"
              role="dialog"
              aria-modal="true"
              aria-label="Menu Completo"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center sm:p-4 font-sans pointer-events-auto"
            >
              {/* Backdrop suave e sem peso no GPU */}
              <motion.div
                key="more-menu-backdrop"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.22, ease: 'easeOut' }}
                onClick={() => handleClose()}
                className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs cursor-pointer -z-10"
              />

              {/* Caixa do Menu Sheet com animação fluida e aceleração de GPU */}
              <motion.div
                key="more-menu-sheet"
                initial={{ y: '100%', opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: '100%', opacity: 0 }}
                transition={{
                  duration: 0.28,
                  ease: [0.16, 1, 0.3, 1], // Curva nativa estilo iOS sheet
                }}
                className="relative w-full max-w-lg bg-surface-card border-t sm:border border-border-subtle rounded-t-[28px] sm:rounded-2xl p-3 sm:p-4.5 shadow-2xl shadow-black/60 dark:shadow-black/90 z-10 flex flex-col max-h-[92dvh] overflow-hidden will-change-transform pb-[calc(1rem+env(safe-area-inset-bottom,16px))] sm:pb-4"
              >
                {/* Puxador para mobile (Touch handle) */}
                <div className="w-10 h-1.5 bg-slate-300 dark:bg-white/20 rounded-full mx-auto mb-2 sm:hidden shrink-0" />

                {/* Header integrado em linha única */}
                <div className="flex items-center justify-between gap-2 pb-2 border-b border-border-subtle shrink-0">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="w-7 h-7 rounded-lg bg-violet-500/15 border border-violet-500/30 flex items-center justify-center text-violet-600 dark:text-violet-400 shrink-0">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 tracking-tight leading-none truncate">
                        Menu Completo
                      </h3>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate mt-0.5 hidden xs:block">
                        Acesso direto a todos os módulos
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleClose()}
                      aria-label="Fechar menu"
                      className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-white/[0.06] dark:hover:bg-white/[0.12] text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors duration-150 cursor-pointer active:scale-90 select-none"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Corpo com organização inteligente */}
                <div className="pt-2 pb-0.5 space-y-2 overflow-y-auto no-scrollbar overscroll-contain">
                  {/* Controles do Sistema lado a lado em 2 colunas compactas */}
                  <div className="grid grid-cols-2 gap-1.5 sm:gap-2">
                    {/* Clientes Demo Toggle */}
                    <div className="p-1.5 sm:p-2 rounded-xl bg-surface-subtle border border-purple-500/25 flex items-center justify-between gap-1.5 shadow-xs">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <div
                          className={`p-1.5 rounded-lg shrink-0 ${
                            isDemoMode ? 'bg-purple-500/25 text-purple-600 dark:text-purple-300' : 'bg-slate-200/60 dark:bg-white/5 text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          <Users className="w-3.5 h-3.5" />
                        </div>
                        <div className="min-w-0">
                          <span className="text-[11px] font-bold text-slate-900 dark:text-slate-200 block truncate leading-tight">
                            Clientes Demo
                          </span>
                          <span
                            className={`text-[8px] font-extrabold uppercase px-1 py-0.2 rounded inline-block ${
                              isDemoMode
                                ? 'bg-purple-500/20 text-purple-700 dark:text-purple-200 ring-1 ring-purple-400/40'
                                : 'bg-slate-200/80 dark:bg-white/10 text-slate-600 dark:text-slate-400'
                            }`}
                          >
                            {isDemoMode ? 'LIGADO' : 'DESLIGADO'}
                          </span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => toggleDemoMode()}
                        className={`px-2 py-1 rounded-lg text-[10px] font-bold transition-transform duration-150 cursor-pointer select-none active:scale-95 shrink-0 ${
                          isDemoMode
                            ? 'bg-purple-600/20 hover:bg-purple-600/30 text-purple-700 dark:text-purple-200 border border-purple-500/40'
                            : 'bg-slate-100 hover:bg-slate-200 dark:bg-white/5 dark:hover:bg-white/10 text-slate-700 dark:text-slate-300 border border-border-subtle'
                        }`}
                      >
                        {isDemoMode ? 'Desligar' : 'Ligar'}
                      </button>
                    </div>

                    {/* Modo Leitura Toggle */}
                    <div className="p-1.5 sm:p-2 rounded-xl bg-surface-subtle border border-border-subtle flex items-center justify-between gap-1.5 shadow-xs">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <div
                          className={`p-1.5 rounded-lg shrink-0 ${
                            isReadOnlyMode ? 'bg-violet-500/25 text-violet-600 dark:text-violet-300' : 'bg-slate-200/60 dark:bg-white/5 text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          {isReadOnlyMode ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                        </div>
                        <div className="min-w-0">
                          <span className="text-[11px] font-bold text-slate-900 dark:text-slate-200 block truncate leading-tight">
                            Modo Leitura
                          </span>
                          <span
                            className={`text-[8px] font-extrabold uppercase px-1 py-0.2 rounded inline-block ${
                              isReadOnlyMode
                                ? 'bg-violet-500/20 text-violet-700 dark:text-violet-200 ring-1 ring-violet-400/40'
                                : 'bg-slate-200/80 dark:bg-white/10 text-slate-600 dark:text-slate-400'
                            }`}
                          >
                            {isReadOnlyMode ? 'ATIVO' : 'INATIVO'}
                          </span>
                        </div>
                      </div>

                      <button
                        type="button"
                        id="drawer-btn-toggle-readonly"
                        onClick={() => {
                          const willTurnOn = !isReadOnlyMode;
                          toggleReadOnlyMode();
                          if (willTurnOn) {
                            handleClose(() => onSelectTab('dashboard'));
                          }
                        }}
                        className={`px-2 py-1 rounded-lg text-[10px] font-bold transition-transform duration-150 cursor-pointer select-none active:scale-95 shrink-0 ${
                          isReadOnlyMode
                            ? 'bg-violet-600 hover:bg-violet-500 text-white font-black shadow-xs'
                            : 'bg-slate-100 hover:bg-slate-200 dark:bg-white/5 dark:hover:bg-white/10 text-slate-700 dark:text-slate-300 border border-border-subtle'
                        }`}
                      >
                        {isReadOnlyMode ? 'Desligar' : 'Ligar'}
                      </button>
                    </div>

                    {/* Tema Claro / Escuro Switch */}
                    <div className="col-span-2 p-1.5 sm:p-2 rounded-xl bg-surface-subtle border border-border-subtle flex items-center justify-between gap-1.5 shadow-xs">
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="p-1.5 rounded-lg bg-violet-500/15 text-violet-600 dark:text-violet-400 shrink-0">
                          {isDark ? <Moon className="w-3.5 h-3.5" /> : <Sun className="w-3.5 h-3.5" />}
                        </div>
                        <div className="min-w-0">
                          <span className="text-[11px] font-bold text-slate-900 dark:text-slate-200 block truncate leading-tight">
                            Tema Visual
                          </span>
                          <span className="text-[9px] text-slate-500 dark:text-slate-400 block truncate leading-tight">
                            {isDark ? 'Modo Escuro Ativo' : 'Modo Claro Ativo'}
                          </span>
                        </div>
                      </div>
                      <ThemeToggle className="scale-85 shrink-0" />
                    </div>
                  </div>

                  {/* Módulos Operacionais em Grid de 2 Colunas Otimizado */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between px-0.5">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                        Módulos Operacionais
                      </span>
                      {overdueCount > 0 && (
                        <span className="text-[9px] font-bold text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-500/20 px-2 py-0.5 rounded-full border border-rose-200 dark:border-rose-500/30 shadow-xs">
                          {overdueCount} atrasados
                        </span>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-1.5 sm:gap-2">
                      {operationalModules.map((item) => {
                        const Icon = item.icon;
                        return (
                          <button
                            key={item.id}
                            type="button"
                            onClick={() => {
                              handleClose(() => onSelectTab(item.id));
                            }}
                            className="p-2 rounded-xl bg-surface-subtle hover:bg-surface-elevated border border-border-subtle hover:border-violet-500/40 flex items-center justify-between text-left transition-all duration-150 relative overflow-hidden cursor-pointer group select-none shadow-xs active:scale-[0.98]"
                          >
                            <div className="flex items-center gap-2 min-w-0 pr-1">
                              <div className={`p-1.5 rounded-lg ${item.bg} ${item.color} shrink-0`}>
                                <Icon className="w-4 h-4 transition-transform duration-150 group-hover:scale-110" />
                              </div>
                              <div className="min-w-0">
                                <span className="text-xs font-bold text-slate-900 dark:text-slate-100 block truncate group-hover:text-violet-600 dark:group-hover:text-violet-300 transition-colors duration-150 leading-tight">
                                  {item.label}
                                </span>
                                <span className="text-[10px] text-slate-500 dark:text-slate-400 block truncate leading-tight mt-0.5">
                                  {item.desc}
                                </span>
                              </div>
                            </div>

                            <ChevronRight className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500 group-hover:text-slate-900 dark:group-hover:text-slate-200 group-hover:translate-x-0.5 shrink-0 transition-transform duration-150" />
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Ações Rápidas em Grid de 4 Colunas Compacto */}
                  <div className="space-y-1 pt-1 border-t border-border-subtle">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 px-0.5 block">
                      Ações Rápidas
                    </span>

                    <div className="grid grid-cols-4 gap-1.5">
                      {quickTools.map((tool, idx) => {
                        const Icon = tool.icon;
                        return (
                          <button
                            key={idx}
                            type="button"
                            title={tool.fullName}
                            onClick={() => tool.onClick()}
                            className={`p-1.5 sm:p-2 rounded-xl bg-surface-subtle hover:bg-surface-elevated border ${tool.border} flex flex-col items-center justify-center text-center transition-transform duration-150 cursor-pointer group select-none shadow-xs active:scale-95 min-w-0`}
                          >
                            <div className={`p-1 rounded-md ${tool.bg} mb-1 shrink-0`}>
                              <Icon className={`w-3.5 h-3.5 ${tool.color} transition-transform duration-150 group-hover:scale-110`} />
                            </div>
                            <span className="text-[10px] sm:text-[11px] font-semibold text-slate-800 dark:text-slate-200 truncate leading-tight w-full">
                              {tool.label}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>,
        document.body
      )
    : null;
};
