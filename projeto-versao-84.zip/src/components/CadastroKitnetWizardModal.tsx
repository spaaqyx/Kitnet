import React, { useEffect, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import {
  X,
  Home,
  User,
  FileCheck,
  Calendar,
  DollarSign,
  CreditCard,
  FileText,
  ChevronRight,
  ChevronLeft,
  Check,
  AlertCircle,
} from 'lucide-react';
import { Kitnet, KitnetContract, KitnetTenant } from '../types';
import { useApp } from '../context/AppContext';
import { useBodyScrollLock } from '../hooks/useBodyScrollLock';
import { KitnetStepProperty } from './kitnets/wizard/KitnetStepProperty';
import { KitnetStepTenant } from './kitnets/wizard/KitnetStepTenant';
import { KitnetStepIncome } from './kitnets/wizard/KitnetStepIncome';
import { KitnetStepContractTerms } from './kitnets/wizard/KitnetStepContractTerms';
import { KitnetStepFinancials } from './kitnets/wizard/KitnetStepFinancials';
import { KitnetStepPayment } from './kitnets/wizard/KitnetStepPayment';
import { KitnetStepReviewContract } from './kitnets/wizard/KitnetStepReviewContract';
import { useKitnetWizard } from './kitnets/wizard/useKitnetWizard';
import { gsapButtonPress } from '../utils/gsapAnimations';
import { BaseWizardStepper } from './ui/BaseWizardStepper';

interface CadastroKitnetWizardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (
    kitnetId: string,
    contractDetails?: { kitnet: Kitnet; tenant: KitnetTenant; contract: KitnetContract }
  ) => void;
}

export const CadastroKitnetWizardModal: React.FC<CadastroKitnetWizardModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  useBodyScrollLock(isOpen);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);
  const { settings } = useApp();

  const {
    currentStep,
    setCurrentStep,
    copiedContract,
    contractTab,
    setContractTab,
    kitnetData,
    setKitnetData,
    tenantMode,
    setTenantMode,
    selectedTenantId,
    setSelectedTenantId,
    tenantData,
    setTenantData,
    incomeType,
    setIncomeType,
    incomeDetails,
    setIncomeDetails,
    documentsFiles,
    contractTerms,
    setContractTerms,
    financials,
    setFinancials,
    paymentConfig,
    setPaymentConfig,
    totalMonthly,
    handleTenantPhotoUpload,
    handleDocUpload,
    handleRemoveDoc,
    handleNext,
    handlePrev,
    getContractPayload,
    handleGenerateContract,
    handlePrintContract,
    handleCopyContractText,
    handleFinalSubmit,
    kitnetTenants,
    isAlugada,
    stepError,
    setStepError,
  } = useKitnetWizard({ isOpen, onSuccess, onClose });

  if (typeof document === 'undefined') return null;

  const steps = [
    { num: 1, label: 'Imóvel', icon: Home },
    { num: 2, label: 'Inquilino', icon: User },
    { num: 3, label: 'Renda & Docs', icon: FileCheck },
    { num: 4, label: 'Contrato', icon: Calendar },
    { num: 5, label: 'Valores', icon: DollarSign },
    { num: 6, label: 'Pagamento', icon: CreditCard },
    { num: 7, label: 'Emitir Contrato', icon: FileText },
  ];

  if (!isOpen || typeof document === 'undefined') return null;

  return createPortal(
    <div
      key="cadastro-kitnet-root"
      className="fixed inset-0 z-[100] flex items-center justify-center p-2 sm:p-4 overflow-y-auto overflow-x-hidden font-sans touch-pan-y w-full max-w-full"
      style={{ overflowX: 'hidden', touchAction: 'pan-y' }}
      role="dialog"
      aria-modal="true"
      aria-label="Cadastro de Kitnet"
    >
      {/* Backdrop */}
      <div
        key="wizard-backdrop"
        className="fixed inset-0 bg-black/80 backdrop-blur-md cursor-pointer animate-fadeIn"
        onClick={onClose}
      />

      {/* Dialog Container */}
      <div
        key="wizard-card"
        className="relative bg-surface-sidebar border border-border-subtle rounded-2xl sm:rounded-3xl w-full max-w-4xl mx-auto max-h-[92vh] sm:max-h-[88vh] shadow-2xl shadow-black/40 overflow-hidden flex flex-col my-auto min-w-0 z-10 animate-modal-enter"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-border-subtle flex items-center justify-between bg-surface-card shrink-0 gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div
              className={`w-9 h-9 sm:w-10 sm:h-10 rounded-2xl border flex items-center justify-center shrink-0 transition-colors ${
                isAlugada
                  ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-600 dark:text-emerald-400'
                  : kitnetData.status === 'reforma'
                  ? 'bg-amber-500/15 border-amber-500/30 text-amber-600 dark:text-amber-400'
                  : 'bg-sky-500/15 border-sky-500/30 text-sky-600 dark:text-sky-400'
              }`}
            >
              <Home className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-sm sm:text-base md:text-lg font-bold text-slate-900 dark:text-white truncate">
                  Cadastro de Kitnet & Locação
                </h2>
                <span
                  className={`text-[10px] sm:text-xs px-2.5 py-0.5 rounded-full font-semibold border shrink-0 transition-colors ${
                    isAlugada
                      ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30'
                      : kitnetData.status === 'reforma'
                      ? 'bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/30'
                      : 'bg-sky-500/15 text-sky-700 dark:text-sky-300 border-sky-500/30'
                  }`}
                >
                  {isAlugada ? `Passo ${currentStep} de 7` : 'Etapa Única'}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 hidden sm:block truncate">
                {isAlugada
                  ? 'Cadastre a kitnet, vincule o inquilino, configure valores, primeiro pagamento e emita o contrato.'
                  : 'Cadastre a kitnet e defina seu status operacional.'}
              </p>
            </div>
          </div>
          <button
            onClick={(e) => {
              gsapButtonPress(e.currentTarget);
              onClose();
            }}
            type="button"
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-surface-subtle border border-transparent hover:border-border-subtle transition-all cursor-pointer shrink-0 active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Wizard Step Stepper - Standardized with BaseWizardStepper */}
        {isAlugada && (
          <BaseWizardStepper
            steps={steps}
            currentStep={currentStep}
            onStepClick={(stepNum) => {
              setStepError(null);
              setCurrentStep(stepNum);
            }}
          />
        )}

        {/* FEEDBACK DE ERRO */}
        {stepError && (
          <div className="mx-4 sm:mx-6 mt-4 p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl flex items-center gap-2.5 text-xs text-rose-500 dark:text-rose-300 animate-shake shrink-0">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-500 dark:text-rose-400" />
            <span>{stepError}</span>
          </div>
        )}

        {/* Wizard Step Content Body */}
        <div
          className="p-4 sm:p-6 overflow-y-auto overflow-x-hidden flex-1 space-y-6 overscroll-contain modal-scroll-container pb-8 w-full max-w-full"
          style={{ WebkitOverflowScrolling: 'touch', touchAction: 'pan-y', overflowX: 'hidden' }}
        >
          {currentStep === 1 && (
            <KitnetStepProperty kitnetData={kitnetData} setKitnetData={setKitnetData} />
          )}

          {currentStep === 2 && isAlugada && (
            <KitnetStepTenant
              tenantMode={tenantMode}
              setTenantMode={setTenantMode}
              selectedTenantId={selectedTenantId}
              setSelectedTenantId={setSelectedTenantId}
              tenantData={tenantData}
              setTenantData={setTenantData}
              kitnetTenants={kitnetTenants}
              handleTenantPhotoUpload={handleTenantPhotoUpload}
              onRemovePhoto={() => setTenantData((prev) => ({ ...prev, photoUrl: '' }))}
            />
          )}

          {currentStep === 3 && isAlugada && (
            <KitnetStepIncome
              incomeType={incomeType}
              setIncomeType={setIncomeType}
              incomeDetails={incomeDetails}
              setIncomeDetails={setIncomeDetails}
              documentsFiles={documentsFiles}
              handleDocUpload={handleDocUpload}
              handleRemoveDoc={handleRemoveDoc}
            />
          )}

          {currentStep === 4 && isAlugada && (
            <KitnetStepContractTerms
              contractTerms={contractTerms}
              setContractTerms={setContractTerms}
            />
          )}

          {currentStep === 5 && isAlugada && (
            <KitnetStepFinancials
              financials={financials}
              setFinancials={setFinancials}
              totalMonthly={totalMonthly}
            />
          )}

          {currentStep === 6 && isAlugada && (
            <KitnetStepPayment
              paymentConfig={paymentConfig}
              setPaymentConfig={setPaymentConfig}
              contractTerms={contractTerms}
              financials={financials}
              totalMonthly={totalMonthly}
            />
          )}

          {currentStep === 7 && isAlugada && (
            <KitnetStepReviewContract
              settings={settings}
              kitnetData={kitnetData}
              tenantMode={tenantMode}
              tenantData={tenantData}
              selectedTenantId={selectedTenantId}
              kitnetTenants={kitnetTenants}
              financials={financials}
              contractTerms={contractTerms}
              paymentConfig={paymentConfig}
              contractTab={contractTab}
              setContractTab={setContractTab}
              copiedContract={copiedContract}
              handleCopyContractText={handleCopyContractText}
              handlePrintContract={handlePrintContract}
              handleGenerateContract={handleGenerateContract}
              getContractPayload={getContractPayload}
            />
          )}
        </div>

        {/* Wizard Footer Controls */}
        <div className="p-4 sm:p-5 border-t border-border-subtle bg-surface-card flex items-center justify-between gap-3 shrink-0">
          <div>
            {isAlugada && currentStep > 1 && (
              <button
                type="button"
                onClick={(e) => {
                  gsapButtonPress(e.currentTarget);
                  handlePrev();
                }}
                className="px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold text-text-secondary hover:text-text-primary bg-surface-subtle hover:bg-surface-hover border border-border-subtle flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Voltar</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={(e) => {
                gsapButtonPress(e.currentTarget);
                onClose();
              }}
              className="px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold text-text-muted hover:text-text-primary hover:bg-surface-hover border border-transparent hover:border-border-subtle transition-all cursor-pointer active:scale-95"
            >
              Cancelar
            </button>

            {/* SE NÃO FOR ALUGADA OU SE JÁ ESTIVER NA ÚLTIMA ETAPA (7) -> SALVAR */}
            {!isAlugada || currentStep === 7 ? (
              <button
                type="button"
                onClick={(e) => {
                  gsapButtonPress(e.currentTarget);
                  handleFinalSubmit(isAlugada);
                }}
                className={`px-4 sm:px-6 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-white flex items-center gap-2 transition-all cursor-pointer active:scale-95 shadow-sm ${
                  kitnetData.status === 'alugada'
                    ? 'bg-emerald-600 hover:bg-emerald-500 ring-1 ring-emerald-400/40'
                    : kitnetData.status === 'reforma'
                    ? 'bg-amber-600 hover:bg-amber-500 ring-1 ring-amber-400/40'
                    : 'bg-sky-600 hover:bg-sky-500 ring-1 ring-sky-400/40'
                }`}
              >
                <Check className="w-4 h-4 stroke-[2.5] shrink-0" />
                <span className="whitespace-nowrap">
                  {isAlugada ? (
                    <>
                      <span className="hidden sm:inline">Concluir Locação e Gerar Contrato</span>
                      <span className="sm:hidden">Concluir Locação</span>
                    </>
                  ) : kitnetData.status === 'reforma' ? (
                    'Salvar em Reforma'
                  ) : (
                    'Salvar Kitnet Disponível'
                  )}
                </span>
              </button>
            ) : (
              <button
                type="button"
                onClick={(e) => {
                  gsapButtonPress(e.currentTarget);
                  handleNext();
                }}
                className="px-4 sm:px-6 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-500 flex items-center gap-2 ring-1 ring-emerald-400/40 transition-all cursor-pointer active:scale-95 shadow-sm"
              >
                <span className="whitespace-nowrap">
                  {currentStep === 1 ? (
                    <>
                      <span className="hidden sm:inline">Avançar para Inquilino</span>
                      <span className="sm:hidden">Avançar</span>
                    </>
                  ) : (
                    'Avançar'
                  )}
                </span>
                <ChevronRight className="w-4 h-4 shrink-0" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
};
