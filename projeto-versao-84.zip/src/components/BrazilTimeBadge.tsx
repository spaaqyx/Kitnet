import React, { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';
import { getBrazilParts, BRAZIL_TIMEZONE } from '../utils/dateUtils';

interface BrazilTimeBadgeProps {
  className?: string;
  showSeconds?: boolean;
  showDate?: boolean;
  variant?: 'compact' | 'pill' | 'header';
}

/**
 * Componente que exibe a Data e Hora Oficial do Brasil (Brasília / America/Sao_Paulo)
 * Sincronizado dinamicamente em tempo real.
 */
export const BrazilTimeBadge: React.FC<BrazilTimeBadgeProps> = ({
  className = '',
  showSeconds = false,
  showDate = false,
  variant = 'pill',
}) => {
  const [timeStr, setTimeStr] = useState<string>(() => {
    const parts = getBrazilParts();
    const hh = String(parts.hour).padStart(2, '0');
    const mm = String(parts.minute).padStart(2, '0');
    const ss = String(parts.second).padStart(2, '0');
    return showSeconds ? `${hh}:${mm}:${ss}` : `${hh}:${mm}`;
  });
  const [dateStr, setDateStr] = useState<string>(() => {
    const parts = getBrazilParts();
    const dd = String(parts.day).padStart(2, '0');
    const mo = String(parts.month).padStart(2, '0');
    return `${dd}/${mo}`;
  });

  useEffect(() => {
    const updateTime = () => {
      const parts = getBrazilParts();
      const hh = String(parts.hour).padStart(2, '0');
      const mm = String(parts.minute).padStart(2, '0');
      const ss = String(parts.second).padStart(2, '0');
      const dd = String(parts.day).padStart(2, '0');
      const mo = String(parts.month).padStart(2, '0');

      const newTime = showSeconds ? `${hh}:${mm}:${ss}` : `${hh}:${mm}`;
      const newDate = `${dd}/${mo}`;

      setTimeStr((prev) => (prev === newTime ? prev : newTime));
      setDateStr((prev) => (prev === newDate ? prev : newDate));
    };

    const interval = setInterval(updateTime, showSeconds ? 1000 : 10000);
    return () => clearInterval(interval);
  }, [showSeconds]);

  if (!timeStr) return null;

  if (variant === 'compact') {
    return (
      <div
        className={`inline-flex items-center gap-1.5 text-xs text-slate-400 font-mono ${className}`}
        title={`Horário de Brasília (${BRAZIL_TIMEZONE} • UTC-3)`}
      >
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
        <span>{timeStr}</span>
      </div>
    );
  }

  if (variant === 'header') {
    return (
      <div
        className={`inline-flex items-center gap-2 px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-white/[0.04] border border-border-subtle text-xs text-slate-700 dark:text-slate-300 backdrop-blur-md shadow-xs ${className}`}
        title="Operação sincronizada com o Horário Oficial de Brasília (America/Sao_Paulo • UTC-3)"
      >
        <div className="flex items-center gap-1.5">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-60" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
          </span>
          <Clock className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
        </div>
        <div className="flex items-center gap-1 font-mono text-[11px] sm:text-xs">
          <span className="text-slate-500 dark:text-slate-400 font-sans font-medium text-[10px] sm:text-[11px] hidden xs:inline">
            Brasília
          </span>
          {showDate && dateStr && (
            <span className="text-slate-500 dark:text-slate-400 hidden sm:inline">{dateStr} •</span>
          )}
          <strong className="text-slate-900 dark:text-white font-bold tracking-tight">{timeStr}</strong>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-700 dark:text-emerald-300 text-xs font-medium tracking-wide shadow-xs ${className}`}
      title="Sincronizado com o Horário Oficial de Brasília (America/Sao_Paulo • UTC-3)"
    >
      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 dark:bg-emerald-400 animate-pulse" />
      <Clock className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
      <span className="font-mono text-[11px] font-bold text-emerald-700 dark:text-emerald-200">
        Brasília {timeStr}
      </span>
    </div>
  );
};
