import React, { useRef, useState, useEffect } from 'react';
import { ChevronRight, ChevronLeft } from 'lucide-react';
import { motion } from 'motion/react';

export interface ChipItem {
  id: string;
  label: string;
  count?: number | string;
  icon?: React.ComponentType<{ className?: string }>;
  badgeColor?: string;
}

interface ScrollableChipsProps {
  items: ChipItem[];
  activeId: string;
  onSelect: (id: string) => void;
  variant?: 'purple-solid' | 'purple-subtle' | 'blue-solid' | 'blue-subtle' | 'amber-solid' | 'amber-subtle' | 'moto' | 'kitnet' | 'tab' | 'subtle' | 'solid';
  size?: 'sm' | 'md';
  className?: string;
}

export const ScrollableChips: React.FC<ScrollableChipsProps> = ({
  items,
  activeId,
  onSelect,
  variant = 'purple-subtle',
  size = 'md',
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(false);

  const checkScroll = () => {
    if (!containerRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = containerRef.current;
    const nextLeft = scrollLeft > 12;
    const nextRight = scrollLeft < scrollWidth - clientWidth - 12;
    setShowLeftArrow((prev) => (prev !== nextLeft ? nextLeft : prev));
    setShowRightArrow((prev) => (prev !== nextRight ? nextRight : prev));
  };

  useEffect(() => {
    checkScroll();
    window.addEventListener('resize', checkScroll);
    return () => window.removeEventListener('resize', checkScroll);
  }, [items?.length]);

  const scroll = (direction: 'left' | 'right') => {
    if (!containerRef.current) return;
    const amount = containerRef.current.clientWidth * 0.65;
    containerRef.current.scrollBy({
      left: direction === 'left' ? -amount : amount,
      behavior: 'smooth',
    });
  };

  const getButtonStyles = (isActive: boolean) => {
    const basePadding = size === 'sm' ? 'px-3 py-1.5 text-xs' : 'px-3.5 py-2 text-xs sm:text-sm';

    if (variant === 'moto' || variant === 'amber-subtle') {
      if (isActive) {
        return `${basePadding} bg-category-motos/20 text-category-motos border border-category-motos/40 font-semibold shadow-xs`;
      }
      return `${basePadding} bg-surface-base text-text-secondary hover:text-text-primary hover:bg-surface-card border border-white/[0.08] font-medium`;
    }

    if (variant === 'kitnet' || variant === 'blue-subtle') {
      if (isActive) {
        return `${basePadding} bg-category-kitnets-sky/20 text-category-kitnets-sky border border-category-kitnets-sky/40 font-semibold shadow-xs`;
      }
      return `${basePadding} bg-surface-base text-text-secondary hover:text-text-primary hover:bg-surface-card border border-white/[0.08] font-medium`;
    }

    if (variant === 'amber-solid') {
      if (isActive) {
        return `${basePadding} bg-category-motos text-white font-semibold shadow-sm`;
      }
      return `${basePadding} bg-surface-base text-text-secondary hover:text-text-primary hover:bg-surface-card border border-white/[0.08] font-medium`;
    }

    if (variant === 'blue-solid') {
      if (isActive) {
        return `${basePadding} bg-category-kitnets-sky text-white font-semibold shadow-sm`;
      }
      return `${basePadding} bg-surface-base text-text-secondary hover:text-text-primary hover:bg-surface-card border border-white/[0.08] font-medium`;
    }

    if (variant === 'purple-solid' || variant === 'solid') {
      if (isActive) {
        return `${basePadding} bg-action-primary text-white font-semibold shadow-sm`;
      }
      return `${basePadding} bg-surface-base text-text-secondary hover:text-text-primary hover:bg-surface-card border border-white/[0.08] font-medium`;
    }

    if (variant === 'tab') {
      if (isActive) {
        return `${basePadding} bg-action-primary text-white font-semibold shadow-sm rounded-lg`;
      }
      return `${basePadding} bg-transparent text-text-secondary hover:text-text-primary hover:bg-white/[0.05] font-medium rounded-lg`;
    }

    // Default subtle variant (purple)
    if (isActive) {
      return `${basePadding} bg-action-primary/20 text-action-primary border border-action-primary/40 font-semibold shadow-xs`;
    }
    return `${basePadding} bg-surface-base text-text-secondary hover:text-text-primary hover:bg-surface-card border border-white/[0.08] font-medium`;
  };

  return (
    <div className={`relative flex items-center group/chips max-w-full overflow-hidden ${className}`}>
      {showLeftArrow && (
        <button
          type="button"
          onClick={() => scroll('left')}
          aria-label="Rolar para esquerda"
          className="absolute left-0 z-10 w-7 h-7 rounded-full bg-surface-base/95 border border-white/[0.15] text-text-primary hidden sm:flex items-center justify-center shadow-lg backdrop-blur-sm hover:bg-surface-card transition-all cursor-pointer active:scale-95"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
      )}

      <div
        ref={containerRef}
        onScroll={checkScroll}
        className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto py-1 px-1 no-scrollbar scroll-smooth w-full touch-pan-x"
        style={{
          scrollbarWidth: 'none',
          msOverflowStyle: 'none',
          WebkitOverflowScrolling: 'touch',
        }}
      >
        {items.map((item) => {
          const isActive = activeId === item.id;
          const Icon = item.icon;

          return (
            <motion.button
              key={item.id}
              type="button"
              id={`chip-${item.id}`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              transition={{ duration: 0.12 }}
              onClick={(e) => {
                onSelect(item.id);
                (e.currentTarget as HTMLElement).scrollIntoView({
                  behavior: 'smooth',
                  block: 'nearest',
                  inline: 'center',
                });
              }}
              className={`shrink-0 rounded-xl flex items-center gap-1.5 transition-all whitespace-nowrap cursor-pointer select-none ${getButtonStyles(
                isActive
              )}`}
            >
              {Icon && <Icon className="w-3.5 h-3.5 shrink-0" />}
              <span>{item.label}</span>
              {item.count !== undefined && item.count !== null && (
                <span
                  className={`ml-1 text-[11px] px-1.5 py-0.5 rounded-full font-mono font-bold ${
                    isActive
                      ? variant.includes('solid') || variant === 'tab'
                        ? 'bg-black/25 text-white'
                        : variant === 'moto' || variant === 'amber-subtle'
                        ? 'bg-category-motos/25 text-category-motos'
                        : variant === 'kitnet' || variant === 'blue-subtle'
                        ? 'bg-category-kitnets-sky/25 text-category-kitnets-sky'
                        : 'bg-action-primary/25 text-action-primary'
                      : 'bg-white/[0.08] text-text-secondary'
                  }`}
                >
                  {item.count}
                </span>
              )}
            </motion.button>
          );
        })}
      </div>

      {showRightArrow && (
        <button
          type="button"
          onClick={() => scroll('right')}
          aria-label="Rolar para direita"
          className="absolute right-0 z-10 w-7 h-7 rounded-full bg-surface-base/95 border border-white/[0.15] text-text-primary hidden sm:flex items-center justify-center shadow-lg backdrop-blur-sm hover:bg-surface-card transition-all cursor-pointer active:scale-95"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      )}
    </div>
  );
};
