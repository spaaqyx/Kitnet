import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import {
  X,
  Printer,
  Download,
  Palette,
  Eye,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Check,
  FileText,
} from 'lucide-react';
import { useBodyScrollLock } from '../../hooks/useBodyScrollLock';
import { gsapButtonPress } from '../../utils/gsapAnimations';

interface DocumentPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  htmlContent: string;
  docTitle: string;
  isMonochrome: boolean;
  onToggleMonochrome: () => void;
  onPrint: () => void;
  onDownload: () => void;
  isGenerating?: boolean;
}

export const DocumentPreviewModal: React.FC<DocumentPreviewModalProps> = ({
  isOpen,
  onClose,
  htmlContent,
  docTitle,
  isMonochrome,
  onToggleMonochrome,
  onPrint,
  onDownload,
  isGenerating = false,
}) => {
  useBodyScrollLock(isOpen);
  const [zoomLevel, setZoomLevel] = useState<number>(100);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen || typeof document === 'undefined') return null;

  const handleZoomIn = () => {
    setZoomLevel((prev) => Math.min(prev + 15, 150));
  };

  const handleZoomOut = () => {
    setZoomLevel((prev) => Math.max(prev - 15, 60));
  };

  const handleResetZoom = () => {
    setZoomLevel(100);
  };

  return createPortal(
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Pré-visualização do Documento"
      className="fixed inset-0 z-[100] flex flex-col bg-black/85 backdrop-blur-md animate-fadeIn"
    >
      {/* Header Bar */}
      <div className="bg-surface-card border-b border-border-dark px-4 py-3 sm:px-6 flex items-center justify-between gap-3 shrink-0 shadow-lg">
        {/* Title & Icon */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="p-2 bg-action-primary/15 text-action-light rounded-xl shrink-0">
            <Eye className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <h2 className="text-sm font-bold text-text-primary truncate">
              Pré-visualização do Documento
            </h2>
            <p className="text-[11px] text-text-secondary truncate max-w-[280px] sm:max-w-md">
              {docTitle}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Zoom controls (hidden on small mobile to save space) */}
          <div className="hidden md:flex items-center bg-surface-base border border-white/[0.08] rounded-xl p-1 gap-1">
            <button
              type="button"
              onClick={(e) => {
                gsapButtonPress(e.currentTarget);
                handleZoomOut();
              }}
              disabled={zoomLevel <= 60}
              className="p-1 text-text-secondary hover:text-text-primary disabled:opacity-30 rounded-lg hover:bg-white/[0.05] transition-colors cursor-pointer active:scale-95"
              title="Reduzir zoom"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-[11px] font-mono text-text-secondary px-1 min-w-[36px] text-center">
              {zoomLevel}%
            </span>
            <button
              type="button"
              onClick={(e) => {
                gsapButtonPress(e.currentTarget);
                handleZoomIn();
              }}
              disabled={zoomLevel >= 150}
              className="p-1 text-text-secondary hover:text-text-primary disabled:opacity-30 rounded-lg hover:bg-white/[0.05] transition-colors cursor-pointer active:scale-95"
              title="Aumentar zoom"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            {zoomLevel !== 100 && (
              <button
                type="button"
                onClick={(e) => {
                  gsapButtonPress(e.currentTarget);
                  handleResetZoom();
                }}
                className="p-1 text-action-primary hover:text-action-light rounded-lg hover:bg-action-primary/10 transition-colors cursor-pointer active:scale-95"
                title="Resetar zoom"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Monochrome / Color toggle */}
          <button
            type="button"
            onClick={(e) => {
              gsapButtonPress(e.currentTarget);
              onToggleMonochrome();
            }}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer active:scale-95 ${
              isMonochrome
                ? 'bg-zinc-800 text-white border-zinc-500 shadow-xs'
                : 'bg-surface-base text-text-secondary border-white/[0.08] hover:text-text-primary hover:bg-surface-card'
            }`}
            title="Alternar entre modo econômico (P&B) e cores"
          >
            <Palette className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isMonochrome ? 'P&B' : 'Colorido'}</span>
          </button>

          {/* Print Button */}
          <button
            type="button"
            onClick={(e) => {
              gsapButtonPress(e.currentTarget);
              onPrint();
            }}
            className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-surface-base text-text-primary border border-white/[0.08] hover:bg-surface-card hover:border-white/[0.15] flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
          >
            <Printer className="w-3.5 h-3.5 text-text-secondary" />
            <span className="hidden sm:inline">Imprimir</span>
          </button>

          {/* Download PDF Button */}
          <button
            type="button"
            onClick={(e) => {
              gsapButtonPress(e.currentTarget);
              onDownload();
            }}
            disabled={isGenerating}
            className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-action-primary hover:bg-action-hover text-surface-base flex items-center gap-1.5 transition-all active:scale-95 shadow-sm shadow-action-primary/20 cursor-pointer disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>PDF</span>
          </button>

          {/* Close Button */}
          <button
            type="button"
            onClick={(e) => {
              gsapButtonPress(e.currentTarget);
              onClose();
            }}
            className="p-1.5 text-text-secondary hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer ml-1 active:scale-95"
            title="Fechar pré-visualização"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Document Sheet Viewport */}
      <div className="flex-1 overflow-y-auto overflow-x-auto p-3 sm:p-6 md:p-8 bg-surface-base flex justify-center items-start">
        <div
          style={{
            transform: zoomLevel !== 100 ? `scale(${zoomLevel / 100})` : undefined,
            transformOrigin: 'top center',
            transition: 'transform 0.15s ease-out',
          }}
          className="w-full max-w-[840px] bg-white text-zinc-900 rounded-xl shadow-2xl overflow-visible border border-zinc-300 mb-12 animate-modal-enter"
        >
          <div
            className="select-text"
            dangerouslySetInnerHTML={{ __html: htmlContent }}
          />
        </div>
      </div>

      {/* Mobile Bottom Footer Helper */}
      <div className="bg-surface-card/95 border-t border-border-dark px-4 py-2 flex items-center justify-between text-[11px] text-text-secondary sm:hidden shrink-0">
        <span>Toque em Imprimir ou PDF para salvar</span>
        <button
          type="button"
          onClick={(e) => {
            gsapButtonPress(e.currentTarget);
            onClose();
          }}
          className="text-action-primary font-bold px-2 py-1 active:scale-95 transition-transform"
        >
          Fechar
        </button>
      </div>
    </div>,
    document.body
  );
};
