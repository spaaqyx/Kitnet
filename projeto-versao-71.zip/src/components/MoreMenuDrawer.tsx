import React, { useEffect } from 'react';
import { createPortal } from 'react-dom';
import {
  X,
  BadgeAlert,
  Users,
  Calendar,
  FileSpreadsheet,
  FileText,
  Settings,
  Calculator,
  Phone,
  Smartphone,
  Lock,
  ChevronRight,
  ShieldCheck,
  Eye,
  EyeOff,
} from 'lucide-react';
import { TabType } from './Navigation';
import { useApp } from '../context/AppContext';
import { useBodyScrollLock } from '../hooks/useBodyScrollLock';
import { gsapButtonPress } from '../utils/gsapAnimations';

interface MoreMenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTab: (tab: TabType) => void;
  onOpenSimulator: () => void;
  onOpenContacts: () => void;
  onOpenPwaGuide: () => void;
  overdueCount?: number;
}

export const MoreMenuDrawer: React.FC<MoreMenuDrawerProps> = ({
  isOpen,
  onClose,
  onSelectTab,
  onOpenSimulator,
  onOpenContacts,
  onOpenPwaGuide,
  overdueCount = 0,
}) => {
  const { lockApp, isDemoMode, toggleDemoMode, isReadOnlyMode, toggleReadOnlyMode } = useApp();

  useBodyScrollLock(isOpen);

  const handleClose = (callback?: () => void) => {
    onClose();
    if (callback) {
      try {
        callback();
      } catch (err) {
        console.error('Erro ao executar ação do menu:', err);
      }
    }
  };

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen || typeof document === 'undefined') return null;

  const operationalModules = [
    {
      id: 'cobrancas' as TabType,
      label: 'Central de Cobranças',
      desc: 'Cobrança WhatsApp e parcelas',
      icon: BadgeAlert,
      color: 'text-money-negative',
      bg: 'bg-money-negative/15',
      badge: overdueCount > 0 ? `${overdueCount} atrasos` : undefined,
    },
    {
      id: 'clientes' as TabType,
      label: 'Clientes & Score',
      desc: 'Cadastro e pontuação',
      icon: Users,
      color: 'text-action-primary',
      bg: 'bg-action-primary/15',
    },
    {
      id: 'calendario' as TabType,
      label: 'Calendário Operacional',
      desc: 'Vencimentos e manutenções',
      icon: Calendar,
      color: 'text-category-motos-alt',
      bg: 'bg-category-motos-alt/15',
    },
    {
      id: 'relatorios' as TabType,
      label: 'Relatórios & Exportação',
      desc: 'DRE e fluxo de caixa',
      icon: FileSpreadsheet,
      color: 'text-money-positive',
      bg: 'bg-money-positive/15',
    },
    {
      id: 'documentos' as TabType,
      label: 'Documentos & Contratos',
      desc: 'Gerador com assinatura',
      icon: FileText,
      color: 'text-category-kitnets-cyan',
      bg: 'bg-category-kitnets-cyan/15',
    },
    {
      id: 'configuracoes' as TabType,
      label: 'Ajustes & Backup',
      desc: 'Configuração e dados',
      icon: Settings,
      color: 'text-text-secondary',
      bg: 'bg-white/10',
    },
  ];

  const quickTools = [
    {
      label: 'Simulador',
      fullName: 'Simulador de Compra',
      icon: Calculator,
      color: 'text-action-primary',
      bg: 'bg-action-primary/10 hover:bg-action-primary/20',
      border: 'border-action-primary/20',
      onClick: () => handleClose(onOpenSimulator),
    },
    {
      label: 'Contatos',
      fullName: 'Contatos Rápidos',
      icon: Phone,
      color: 'text-money-positive',
      bg: 'bg-money-positive/10 hover:bg-money-positive/20',
      border: 'border-money-positive/20',
      onClick: () => handleClose(onOpenContacts),
    },
    {
      label: 'Instalar PWA',
      fullName: 'Instalar App (PWA)',
      icon: Smartphone,
      color: 'text-category-kitnets-sky',
      bg: 'bg-category-kitnets-sky/10 hover:bg-category-kitnets-sky/20',
      border: 'border-category-kitnets-sky/20',
      onClick: () => handleClose(onOpenPwaGuide),
    },
    {
      label: 'Bloquear',
      fullName: 'Bloquear Aplicativo',
      icon: Lock,
      color: 'text-money-negative',
      bg: 'bg-money-negative/10 hover:bg-money-negative/20',
      border: 'border-money-negative/20',
      onClick: () => handleClose(lockApp),
    },
  ];

  return createPortal(
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Menu Completo"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4 font-sans"
    >
      {/* Backdrop suave */}
      <div
        onClick={() => handleClose()}
        className="fixed inset-0 bg-black/80 backdrop-blur-md cursor-pointer animate-fadeIn"
      />

      {/* Caixa do Menu compacta e inteligente - Tudo visível de primeira sem necessidade de scroll */}
      <div
        className="relative w-full max-w-lg bg-surface-subtle border-t sm:border border-white/[0.12] rounded-t-[24px] sm:rounded-2xl p-3 sm:p-4 shadow-2xl shadow-black/90 z-10 flex flex-col max-h-[96dvh] overflow-hidden animate-modal-enter"
      >
        {/* Puxador para mobile */}
        <div className="w-8 h-1 bg-white/20 rounded-full mx-auto mb-1 sm:hidden shrink-0" />

        {/* Header integrado em linha única - Economiza espaço vertical precioso */}
        <div className="flex items-center justify-between gap-2 pb-2 border-b border-white/[0.08] shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-7 h-7 rounded-lg bg-violet-500/15 border border-violet-500/30 flex items-center justify-center text-violet-400 shrink-0">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm font-bold text-slate-100 tracking-tight leading-none truncate">
                Menu Completo
              </h3>
              <p className="text-[10px] text-slate-400 truncate mt-0.5 hidden xs:block">
                Acesso direto a todos os módulos
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={(e) => {
                gsapButtonPress(e.currentTarget);
                handleClose();
              }}
              aria-label="Fechar menu"
              className="p-1.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.12] text-slate-400 hover:text-white transition-colors duration-150 cursor-pointer active:scale-90 select-none"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Corpo com organização inteligente - Zero scroll em telas normais */}
        <div
          className="pt-2 pb-0.5 space-y-2 overflow-y-auto no-scrollbar"
        >
          {/* Controles do Sistema lado a lado em 2 colunas compactas */}
          <div className="grid grid-cols-2 gap-1.5 sm:gap-2">
            {/* Clientes Demo Toggle */}
            <div className="p-1.5 sm:p-2 rounded-xl bg-surface-card border border-purple-500/25 flex items-center justify-between gap-1.5 shadow-xs">
              <div className="flex items-center gap-1.5 min-w-0">
                <div
                  className={`p-1.5 rounded-lg shrink-0 ${
                    isDemoMode ? 'bg-purple-500/25 text-purple-300' : 'bg-white/5 text-slate-400'
                  }`}
                >
                  <Users className="w-3.5 h-3.5" />
                </div>
                <div className="min-w-0">
                  <span className="text-[11px] font-bold text-slate-200 block truncate leading-tight">
                    Clientes Demo
                  </span>
                  <span
                    className={`text-[8px] font-extrabold uppercase px-1 py-0.2 rounded inline-block ${
                      isDemoMode
                        ? 'bg-purple-500/30 text-purple-200 ring-1 ring-purple-400/40'
                        : 'bg-white/10 text-slate-400'
                    }`}
                  >
                    {isDemoMode ? 'LIGADO' : 'DESLIGADO'}
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={(e) => {
                  gsapButtonPress(e.currentTarget);
                  toggleDemoMode();
                }}
                className={`px-2 py-1 rounded-lg text-[10px] font-bold transition-all duration-150 cursor-pointer select-none active:scale-95 shrink-0 ${
                  isDemoMode
                    ? 'bg-purple-600/30 hover:bg-purple-600/40 text-purple-200 border border-purple-500/50'
                    : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/[0.08]'
                }`}
              >
                {isDemoMode ? 'Desligar' : 'Ligar'}
              </button>
            </div>

            {/* Modo Leitura Toggle */}
            <div className="p-1.5 sm:p-2 rounded-xl bg-surface-card border border-white/[0.08] flex items-center justify-between gap-1.5 shadow-xs">
              <div className="flex items-center gap-1.5 min-w-0">
                <div
                  className={`p-1.5 rounded-lg shrink-0 ${
                    isReadOnlyMode ? 'bg-violet-500/25 text-violet-300' : 'bg-white/5 text-slate-400'
                  }`}
                >
                  {isReadOnlyMode ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                </div>
                <div className="min-w-0">
                  <span className="text-[11px] font-bold text-slate-200 block truncate leading-tight">
                    Modo Leitura
                  </span>
                  <span
                    className={`text-[8px] font-extrabold uppercase px-1 py-0.2 rounded inline-block ${
                      isReadOnlyMode
                        ? 'bg-violet-500/30 text-violet-200 ring-1 ring-violet-400/40'
                        : 'bg-white/10 text-slate-400'
                    }`}
                  >
                    {isReadOnlyMode ? 'ATIVO' : 'INATIVO'}
                  </span>
                </div>
              </div>

              <button
                type="button"
                id="drawer-btn-toggle-readonly"
                onClick={(e) => {
                  gsapButtonPress(e.currentTarget);
                  const willTurnOn = !isReadOnlyMode;
                  toggleReadOnlyMode();
                  if (willTurnOn) {
                    handleClose(() => onSelectTab('dashboard'));
                  }
                }}
                className={`px-2 py-1 rounded-lg text-[10px] font-bold transition-all duration-150 cursor-pointer select-none active:scale-95 shrink-0 ${
                  isReadOnlyMode
                    ? 'bg-violet-600 hover:bg-violet-500 text-white font-black shadow-xs'
                    : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
                }`}
              >
                {isReadOnlyMode ? 'Desligar' : 'Ligar'}
              </button>
            </div>
          </div>

          {/* Módulos Operacionais em Grid de 2 Colunas Otimizado */}
          <div className="space-y-1">
            <div className="flex items-center justify-between px-0.5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Módulos Operacionais
              </span>
              {overdueCount > 0 && (
                <span
                  className="text-[9px] font-bold text-rose-300 bg-rose-500/20 px-2 py-0.5 rounded-full border border-rose-500/30 shadow-xs"
                >
                  {overdueCount} atrasados
                </span>
              )}
            </div>

            <div className="grid grid-cols-2 gap-1.5 sm:gap-2">
              {operationalModules.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={(e) => {
                      gsapButtonPress(e.currentTarget);
                      handleClose(() => onSelectTab(item.id));
                    }}
                    className="p-2 rounded-xl bg-surface-card hover:bg-surface-elevated border border-white/[0.08] hover:border-violet-500/40 flex items-center justify-between text-left transition-all duration-150 relative overflow-hidden cursor-pointer group select-none shadow-xs active:scale-95 hover:-translate-y-0.5 hover:scale-[1.015]"
                  >
                    <div className="flex items-center gap-2 min-w-0 pr-1">
                      <div className={`p-1.5 rounded-lg ${item.bg} ${item.color} shrink-0`}>
                        <Icon className="w-4 h-4 transition-transform duration-150 group-hover:scale-110" />
                      </div>
                      <div className="min-w-0">
                        <span className="text-xs font-bold text-slate-100 block truncate group-hover:text-violet-300 transition-colors duration-150 leading-tight">
                          {item.label}
                        </span>
                        <span className="text-[10px] text-slate-400 block truncate leading-tight mt-0.5">
                          {item.desc}
                        </span>
                      </div>
                    </div>

                    <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-slate-200 group-hover:translate-x-1 shrink-0 transition-all duration-150" />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Ações Rápidas em Grid de 4 Colunas Compacto - Todos os 4 cabem na horizontal sem quebrar */}
          <div className="space-y-1 pt-1 border-t border-white/[0.06]">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-0.5 block">
              Ações Rápidas
            </span>

            <div className="grid grid-cols-4 gap-1.5">
              {quickTools.map((tool, idx) => {
                const Icon = tool.icon;
                return (
                  <button
                    key={idx}
                    type="button"
                    title={tool.fullName}
                    onClick={(e) => {
                      gsapButtonPress(e.currentTarget);
                      tool.onClick();
                    }}
                    className={`p-1.5 sm:p-2 rounded-xl bg-surface-card hover:bg-surface-elevated border ${tool.border} flex flex-col items-center justify-center text-center transition-all duration-150 cursor-pointer group select-none shadow-xs active:scale-95 hover:-translate-y-0.5 hover:scale-105 min-w-0`}
                  >
                    <div className={`p-1 rounded-md ${tool.bg} mb-1 shrink-0`}>
                      <Icon className={`w-3.5 h-3.5 ${tool.color} transition-transform duration-150 group-hover:scale-110`} />
                    </div>
                    <span className="text-[10px] sm:text-[11px] font-semibold text-slate-200 truncate leading-tight w-full">
                      {tool.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
};

