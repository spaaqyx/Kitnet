"use client"

import * as React from "react"
import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import type { ButtonProps } from "@/components/ui/button";
import { MousePointerClick } from "lucide-react";

interface ParticleButtonProps extends ButtonProps {
    onSuccess?: () => void;
    successDuration?: number;
    showClickIcon?: boolean;
    particleColors?: string[];
    particleCount?: number;
}

function SuccessParticles({
    buttonRef,
    particleColors,
    particleCount = 14,
}: {
    buttonRef: React.RefObject<HTMLButtonElement | null>;
    particleColors?: string[];
    particleCount?: number;
}) {
    const rect = buttonRef.current?.getBoundingClientRect();
    if (!rect) return null;

    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    return (
        <AnimatePresence>
            {[...Array(particleCount)].map((_, i) => {
                const color = particleColors && particleColors.length > 0
                    ? particleColors[i % particleColors.length]
                    : undefined;

                return (
                    <motion.div
                        key={i}
                        className={cn(
                            "fixed w-1.5 h-1.5 rounded-full pointer-events-none z-[9999]",
                            !color && "bg-black dark:bg-white"
                        )}
                        style={{
                            left: centerX,
                            top: centerY,
                            backgroundColor: color,
                        }}
                        initial={{
                            scale: 0,
                            x: 0,
                            y: 0,
                            opacity: 1,
                        }}
                        animate={{
                            scale: [0, 1.4, 0],
                            x: [0, (i % 2 ? 1 : -1) * (Math.random() * 65 + 20)],
                            y: [0, -Math.random() * 65 - 20],
                            opacity: [1, 1, 0],
                        }}
                        transition={{
                            duration: 0.65,
                            delay: (i % 6) * 0.04,
                            ease: "easeOut",
                        }}
                    />
                );
            })}
        </AnimatePresence>
    );
}

const ParticleButton = React.forwardRef<HTMLButtonElement, ParticleButtonProps>(
  ({
    children,
    onClick,
    onSuccess,
    successDuration = 1000,
    className,
    showClickIcon = false,
    particleColors,
    particleCount = 14,
    ...props
  }, forwardedRef) => {
    const [showParticles, setShowParticles] = useState(false);
    const internalRef = useRef<HTMLButtonElement | null>(null);

    const setRef = (node: HTMLButtonElement | null) => {
        internalRef.current = node;
        if (typeof forwardedRef === 'function') {
            forwardedRef(node);
        } else if (forwardedRef) {
            (forwardedRef as React.MutableRefObject<HTMLButtonElement | null>).current = node;
        }
    };

    const handleClick = async (e: React.MouseEvent<HTMLButtonElement>) => {
        setShowParticles(true);

        if (onClick) {
            onClick(e);
        }
        if (onSuccess) {
            onSuccess();
        }

        setTimeout(() => {
            setShowParticles(false);
        }, successDuration);
    };

    return (
        <>
            {showParticles && (
                <SuccessParticles
                    buttonRef={internalRef}
                    particleColors={particleColors}
                    particleCount={particleCount}
                />
            )}
            <Button
                ref={setRef}
                onClick={handleClick}
                className={cn(
                    "relative",
                    showParticles && "scale-95",
                    "transition-transform duration-100",
                    className
                )}
                {...props}
            >
                {children}
                {showClickIcon && <MousePointerClick className="h-4 w-4 shrink-0" />}
            </Button>
        </>
    );
  }
);

ParticleButton.displayName = "ParticleButton";

export { ParticleButton, SuccessParticles };
export type { ParticleButtonProps };
