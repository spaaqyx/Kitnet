import { ParticleButton } from "@/components/ui/particle-button"

function ParticleButtonDemo() {
    return (
        <ParticleButton successDuration={1000} variant="default" showClickIcon>
            Click me!
        </ParticleButton>
    )
}

export { ParticleButtonDemo }
