import React, { useState, useRef, useLayoutEffect, cloneElement } from 'react';

// --- Internal Types and Defaults ---

const DefaultHomeIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
  </svg>
);
const DefaultCompassIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10" />
    <path d="m16.24 7.76-2.12 6.36-6.36 2.12 2.12-6.36 6.36-2.12z" />
  </svg>
);
const DefaultBellIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
    <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
  </svg>
);

export type NavItem = {
  id: string | number;
  icon: React.ReactElement;
  label?: string;
  onClick?: () => void;
  badge?: number;
  badgeColor?: string;
};

const defaultNavItems: NavItem[] = [
  { id: 'default-home', icon: <DefaultHomeIcon />, label: 'Home' },
  { id: 'default-explore', icon: <DefaultCompassIcon />, label: 'Explore' },
  { id: 'default-notifications', icon: <DefaultBellIcon />, label: 'Notifications' },
];

export type LimelightNavProps = {
  items?: NavItem[];
  defaultActiveIndex?: number;
  activeIndex?: number;
  onTabChange?: (index: number) => void;
  className?: string;
  limelightClassName?: string;
  iconContainerClassName?: string;
  iconClassName?: string;
  limelightColor?: string;
};

/**
 * An adaptive-width navigation bar with a "limelight" effect that highlights the active item.
 */
export const LimelightNav = ({
  items = defaultNavItems,
  defaultActiveIndex = 0,
  activeIndex: controlledActiveIndex,
  onTabChange,
  className,
  limelightClassName,
  iconContainerClassName,
  iconClassName,
  limelightColor,
}: LimelightNavProps) => {
  const [internalActiveIndex, setInternalActiveIndex] = useState(defaultActiveIndex);
  const activeIndex = controlledActiveIndex !== undefined ? controlledActiveIndex : internalActiveIndex;
  const [isReady, setIsReady] = useState(false);
  const navItemRefs = useRef<(HTMLAnchorElement | null)[]>([]);
  const limelightRef = useRef<HTMLDivElement | null>(null);

  useLayoutEffect(() => {
    if (items.length === 0) return;

    const limelight = limelightRef.current;
    const activeItem = navItemRefs.current[activeIndex];
    
    if (limelight && activeItem) {
      const newLeft = activeItem.offsetLeft + activeItem.offsetWidth / 2 - limelight.offsetWidth / 2;
      limelight.style.left = `${newLeft}px`;

      if (!isReady) {
        const timer = setTimeout(() => setIsReady(true), 50);
        return () => clearTimeout(timer);
      }
    }
  }, [activeIndex, isReady, items]);

  if (items.length === 0) {
    return null; 
  }

  const handleItemClick = (index: number, itemOnClick?: () => void) => {
    setInternalActiveIndex(index);
    onTabChange?.(index);
    itemOnClick?.();
  };

  return (
    <nav className={`relative inline-flex items-center h-16 rounded-lg bg-card text-foreground border border-border-subtle px-2 ${className || ''}`}>
      {items.map(({ id, icon, label, onClick, badge, badgeColor }, index) => (
        <a
          key={id}
          ref={(el) => {
            navItemRefs.current[index] = el;
          }}
          className={`relative z-20 flex h-full cursor-pointer items-center justify-center p-3 sm:p-5 active:scale-95 transition-transform select-none ${iconContainerClassName || ''}`}
          onClick={() => handleItemClick(index, onClick)}
          aria-label={label}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              handleItemClick(index, onClick);
            }
          }}
        >
          <div className="relative flex flex-col items-center justify-center">
            {cloneElement(icon as React.ReactElement<{ className?: string }>, {
              className: `w-6 h-6 sm:w-6.5 sm:h-6.5 transition-all duration-200 ease-in-out ${
                activeIndex === index
                  ? 'text-white opacity-100 scale-105'
                  : 'text-text-muted opacity-40 hover:opacity-75'
              } ${(icon as React.ReactElement<{ className?: string }>).props.className || ''} ${iconClassName || ''}`,
            })}
            {label && (
              <span
                className={`text-[11px] mt-1 transition-opacity duration-100 ${
                  activeIndex === index ? 'opacity-100 font-semibold' : 'opacity-50 font-normal'
                }`}
              >
                {label}
              </span>
            )}
            {badge !== undefined && badge > 0 && (
              <span
                className={`absolute -top-1 -right-1 min-w-4 h-4 px-1 rounded-full text-[10px] font-bold flex items-center justify-center ring-2 ring-surface-base shadow-sm ${
                  badgeColor || 'bg-money-negative text-white'
                }`}
              >
                {badge}
              </span>
            )}
          </div>
        </a>
      ))}

      <div 
        ref={limelightRef}
        className={`absolute top-0 z-10 w-12 h-[3.5px] rounded-full bg-white shadow-[0_0_12px_rgba(255,255,255,0.95),0_2px_8px_rgba(255,255,255,0.6)] ${
          isReady ? 'transition-[left] duration-300 ease-out' : ''
        } ${limelightClassName || ''}`}
        style={{
          left: '-999px',
          ...(limelightColor ? { backgroundColor: limelightColor, boxShadow: `0 0 12px ${limelightColor}, 0 2px 8px ${limelightColor}` } : {}),
        }}
      >
        {/* Downward Spotlight Cone matching IMG_0939 */}
        <div
          className="absolute left-[-26%] top-[3.5px] w-[152%] h-14 [clip-path:polygon(8%_100%,22%_0,78%_0,92%_100%)] pointer-events-none"
          style={{
            background: limelightColor
              ? `linear-gradient(to bottom, ${limelightColor}55 0%, ${limelightColor}15 60%, transparent 100%)`
              : 'linear-gradient(to bottom, rgba(255, 255, 255, 0.32) 0%, rgba(255, 255, 255, 0.10) 60%, transparent 100%)',
          }}
        />
        {/* Ambient light pool at bottom */}
        <div
          className="absolute top-11 left-[-15%] w-[130%] h-3.5 rounded-full blur-[6px] pointer-events-none"
          style={{
            backgroundColor: limelightColor ? `${limelightColor}33` : 'rgba(255, 255, 255, 0.18)',
          }}
        />
      </div>
    </nav>
  );
};
