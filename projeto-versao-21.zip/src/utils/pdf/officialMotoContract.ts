import {
  formatCurrency,
  formatDate,
  formatCPF,
  formatPhone,
  formatCurrencyExtenso,
  formatDateFullPT,
  addMonthsToDate,
  getTodayLocalDateString,
  getBrazilParts,
} from '../formatters';
import { getWeekdayName } from '../contractCalculations';
import { weeklyToMonthly, monthlyToWeekly } from '../../domain';
import { MotoDeliveryInspection } from '../../types';

export interface OfficialMotoContractData {
  locador: {
    name: string;
    cpf: string;
    cnpj?: string;
    rgCnh?: string;
    address: string;
    phone?: string;
    email?: string;
  };
  locatario: {
    name: string;
    profession: string;
    cpf: string;
    rg?: string;
    cnh: string;
    cnhCategory: string;
    address: string;
    phone: string;
    whatsapp: string;
    email: string;
  };
  moto: {
    brand: string;
    model: string;
    year: number | string;
    color: string;
    plate: string;
    renavam: string;
    chassi: string;
    initialKm: number;
  };
  inspection: MotoDeliveryInspection;
  terms: {
    startDate: string;
    startDateFormatted: string;
    endDateMin: string;
    endDateMinFormatted: string;
    minimumMonths: number;
    isWeekly: boolean;
    paymentFrequency: 'semanal' | 'mensal';
    weeklyValue: number;
    weeklyValueFormatted: string;
    weeklyValueExtenso: string;
    monthlyValue: number;
    monthlyValueFormatted: string;
    monthlyValueExtenso: string;
    dueDayName: string;
    dueDay: number;
    dueLimitTime: string;
    deposit: number;
    depositFormatted: string;
    depositExtenso: string;
    insuranceDeductible: string;
    contractCity: string;
    contractDateFormatted: string;
    witnessesCount: number;
    witness1Name?: string;
    witness1Cpf?: string;
    witness2Name?: string;
    witness2Cpf?: string;
  };
}

export interface ContractSection {
  number: number;
  title: string;
  paragraphs: string[];
  bullets?: string[];
}

/**
 * Normaliza qualquer origem de dados (form do wizard, MotoRentalContractPdfOptions, etc.)
 * para o objeto canônico único do contrato oficial de motos.
 */
export function extractOfficialMotoContractData(source: any, customSettings?: any): OfficialMotoContractData {
  const settings = customSettings || source?.settings || {};

  // LOCADOR
  const locadorName =
    source?.locadorName ||
    settings?.adminName ||
    'Wigne Leal Xavier Macedo';

  const locadorCpf =
    source?.locadorCpf ||
    settings?.adminCpf ||
    '155.521.029-59';

  const locadorCnpj = source?.locadorCnpj || settings?.adminCnpj || '';
  const locadorRgCnh = source?.locadorRgCnh || settings?.adminRg || '';
  const locadorAddress =
    source?.locadorAddress ||
    settings?.adminAddress ||
    settings?.cityState ||
    'Barra Velha - SC';

  // LOCATÁRIO
  const tenantRaw = source?.tenant || {};
  const form = source?.form || source;

  const tenantName =
    form?.tenantName ||
    tenantRaw?.fullName ||
    form?.fullName ||
    'Condutor Não Identificado';

  const tenantCpf =
    form?.tenantCpf ||
    tenantRaw?.cpf ||
    form?.cpf ||
    '000.000.000-00';

  const tenantRg =
    form?.tenantRg ||
    tenantRaw?.rg ||
    form?.rg ||
    '';

  const tenantProfession =
    form?.tenantProfession ||
    tenantRaw?.profession ||
    form?.profession ||
    form?.companyOrActivity ||
    'Autônomo / Entregador';

  const tenantCnh =
    form?.cnhNumber ||
    tenantRaw?.cnh?.number ||
    form?.cnh?.number ||
    'Em emissão / Não informada';

  const tenantCnhCategory =
    form?.cnhCategory ||
    tenantRaw?.cnh?.category ||
    form?.cnh?.category ||
    'A';

  const tenantPhone =
    form?.tenantPhone ||
    form?.tenantWhatsapp ||
    tenantRaw?.whatsapp ||
    tenantRaw?.phone ||
    form?.phone ||
    '';

  const tenantWhatsapp =
    form?.tenantWhatsapp ||
    form?.tenantPhone ||
    tenantRaw?.whatsapp ||
    tenantRaw?.phone ||
    tenantPhone;

  const tenantEmail =
    form?.tenantEmail ||
    tenantRaw?.email ||
    form?.email ||
    'Não informado';

  let tenantAddress = '';
  if (form?.tenantStreet && form?.tenantCity) {
    tenantAddress = `${form.tenantStreet}${form.tenantNumber ? `, nº ${form.tenantNumber}` : ''}${
      form.tenantNeighborhood ? `, ${form.tenantNeighborhood}` : ''
    }, ${form.tenantCity} - ${form.tenantState || 'SC'}`;
  } else if (tenantRaw?.address) {
    tenantAddress = tenantRaw.address;
  } else if (form?.tenantAddress) {
    tenantAddress = form.tenantAddress;
  } else if (form?.address) {
    tenantAddress = form.address;
  } else {
    tenantAddress = 'Endereço cadastrado no sistema';
  }

  // MOTO
  const motoRaw = source?.moto || {};
  const motoBrand = form?.brand || motoRaw?.brand || 'Honda';
  const motoModel = form?.model || motoRaw?.model || 'CG 160 Fan';
  const motoYear = form?.year || motoRaw?.year || getBrazilParts().year;
  const motoColor = form?.color || motoRaw?.color || 'Preta';
  const motoPlate = (form?.plate || motoRaw?.plate || 'SEM PLACA').toUpperCase();
  const motoRenavam = form?.renavam || motoRaw?.renavam || 'Conforme documentação';
  const motoChassi = form?.chassi || motoRaw?.chassi || 'Conforme documentação';
  const initialKm = Number(
    source?.initialKm !== undefined
      ? source.initialKm
      : form?.currentKm !== undefined
      ? form.currentKm
      : motoRaw?.currentKm !== undefined
      ? motoRaw.currentKm
      : motoRaw?.delivery?.initialKm !== undefined
      ? motoRaw.delivery.initialKm
      : 0
  );

  // CONDIÇÕES & PRAZOS
  const contractRaw = source?.contract || {};
  const startDate =
    source?.startDate ||
    form?.startDate ||
    contractRaw?.startDate ||
    getTodayLocalDateString();
  const startDateFormatted = formatDate(startDate);

  const minimumMonths = Number(
    source?.minimumMonths ||
    form?.durationMonths ||
    contractRaw?.durationMonths ||
    3
  );

  const endDateMin =
    source?.endDateMin ||
    form?.endDate ||
    addMonthsToDate(startDate, minimumMonths);
  const endDateMinFormatted = formatDate(endDateMin);

  const isWeekly =
    source?.paymentFrequency === 'semanal' ||
    form?.paymentFrequency === 'semanal' ||
    contractRaw?.paymentFrequency === 'semanal' ||
    (!source?.paymentFrequency && !form?.paymentFrequency && Boolean(form?.weeklyValue || contractRaw?.weeklyValue));

  const monthlyVal = Number(
    source?.monthlyValue !== undefined && source.monthlyValue > 0
      ? source.monthlyValue
      : form?.monthlyValue !== undefined && form.monthlyValue > 0
      ? form.monthlyValue
      : contractRaw?.monthlyValue || (contractRaw?.weeklyValue ? weeklyToMonthly(contractRaw.weeklyValue) : 0)
  );

  const weeklyVal = Number(
    source?.weeklyValue !== undefined && source.weeklyValue > 0
      ? source.weeklyValue
      : form?.weeklyValue !== undefined && form.weeklyValue > 0
      ? form.weeklyValue
      : contractRaw?.weeklyValue || (monthlyVal > 0 ? monthlyToWeekly(monthlyVal) : 0)
  );

  const weeklyValueExtenso = formatCurrencyExtenso(weeklyVal).replace(' reais', '').replace(' real', '');
  const monthlyValueExtenso = formatCurrencyExtenso(monthlyVal).replace(' reais', '').replace(' real', '');

  const dueDay = Number(
    source?.dueDay !== undefined
      ? source.dueDay
      : form?.dueDay !== undefined
      ? form.dueDay
      : contractRaw?.dueDay || 10
  );

  const dueDayOfWeekRaw =
    source?.dueDayOfWeek !== undefined
      ? source.dueDayOfWeek
      : form?.dueDayOfWeek !== undefined
      ? form.dueDayOfWeek
      : contractRaw?.dueDayOfWeek;

  let dueDayName = 'Segunda-feira';
  if (typeof dueDayOfWeekRaw === 'number') {
    dueDayName = getWeekdayName(dueDayOfWeekRaw);
  } else if (typeof dueDayOfWeekRaw === 'string' && dueDayOfWeekRaw.trim() !== '') {
    dueDayName = dueDayOfWeekRaw;
  }

  const dueLimitTime =
    source?.dueLimitTime ||
    form?.dueLimitTime ||
    '18:00';

  const depositVal = Number(
    source?.deposit !== undefined
      ? source.deposit
      : form?.deposit !== undefined
      ? form.deposit
      : contractRaw?.deposit !== undefined
      ? contractRaw.deposit
      : 1500
  );
  const depositExtenso = formatCurrencyExtenso(depositVal).replace(' reais', '').replace(' real', '').toUpperCase();

  const insuranceDeductibleRaw =
    source?.insuranceDeductible !== undefined && source.insuranceDeductible !== ''
      ? source.insuranceDeductible
      : form?.insuranceDeductible !== undefined && form.insuranceDeductible !== ''
      ? form.insuranceDeductible
      : contractRaw?.insuranceDeductible;

  const insuranceDeductible =
    insuranceDeductibleRaw !== undefined && insuranceDeductibleRaw !== ''
      ? typeof insuranceDeductibleRaw === 'number'
        ? formatCurrency(insuranceDeductibleRaw).replace('R$', '').trim()
        : String(insuranceDeductibleRaw)
      : '1.500,00';

  const contractCity =
    source?.contractCity ||
    form?.contractCity ||
    settings?.cityState ||
    'são jose - SC';

  const contractDateFormatted = formatDateFullPT(startDate);

  const witnessesCount =
    source?.witnessesCount !== undefined
      ? source.witnessesCount
      : form?.witnessesCount !== undefined
      ? form.witnessesCount
      : 2;

  const witness1Name = source?.witness1Name || form?.witness1Name || '';
  const witness1Cpf = source?.witness1Cpf || form?.witness1Cpf || '';
  const witness2Name = source?.witness2Name || form?.witness2Name || '';
  const witness2Cpf = source?.witness2Cpf || form?.witness2Cpf || '';

  // VISTORIA DE ENTREGA (ANEXO I)
  const rawInspection = source?.inspection || form?.inspection || contractRaw?.inspection;
  const inspectionDate =
    source?.inspectionDate ||
    form?.inspectionDate ||
    rawInspection?.date ||
    startDate;
  const inspectionTime =
    source?.inspectionTime ||
    form?.inspectionTime ||
    rawInspection?.time ||
    '10:00';
  const inspectionInitialKm = Number(
    source?.initialKm !== undefined
      ? source.initialKm
      : rawInspection?.initialKm !== undefined
      ? rawInspection.initialKm
      : initialKm
  );

  const defaultChecklistItem = (checked = true, status: 'bom' | 'regular' | 'ruim' = 'bom', notes = '') => ({
    checked: rawInspection ? Boolean(checked) : true,
    status: (status as 'bom' | 'regular' | 'ruim') || 'bom',
    notes: notes || '',
  });

  const inspection: MotoDeliveryInspection = {
    date: inspectionDate,
    time: inspectionTime,
    initialKm: inspectionInitialKm,
    checklist: {
      pneuDianteiro: rawInspection?.checklist?.pneuDianteiro || defaultChecklistItem(true, 'bom'),
      pneuTraseiro: rawInspection?.checklist?.pneuTraseiro || defaultChecklistItem(true, 'bom'),
      freioDianteiro: rawInspection?.checklist?.freioDianteiro || defaultChecklistItem(true, 'bom'),
      freioTraseiro: rawInspection?.checklist?.freioTraseiro || defaultChecklistItem(true, 'bom'),
      farolLanternas: rawInspection?.checklist?.farolLanternas || defaultChecklistItem(true, 'bom'),
      setas: rawInspection?.checklist?.setas || defaultChecklistItem(true, 'bom'),
      buzina: rawInspection?.checklist?.buzina || defaultChecklistItem(true, 'bom'),
      retrovisores: rawInspection?.checklist?.retrovisores || defaultChecklistItem(true, 'bom'),
      assentoBanco: rawInspection?.checklist?.assentoBanco || defaultChecklistItem(true, 'bom'),
      pinturaLataria: rawInspection?.checklist?.pinturaLataria || defaultChecklistItem(true, 'bom'),
    },
    fuelLevel: rawInspection?.fuelLevel || form?.fuelLevel || 'cheio',
    accessories: {
      capacete: rawInspection?.accessories?.capacete ?? form?.accessories?.capacete ?? true,
      capaChuva: rawInspection?.accessories?.capaChuva ?? form?.accessories?.capaChuva ?? true,
      suporteCelular: rawInspection?.accessories?.suporteCelular ?? form?.accessories?.suporteCelular ?? true,
      bauBauleto: rawInspection?.accessories?.bauBauleto ?? form?.accessories?.bauBauleto ?? false,
      chaveReserva: rawInspection?.accessories?.chaveReserva ?? form?.accessories?.chaveReserva ?? true,
      outros: rawInspection?.accessories?.outros ?? form?.accessories?.outros ?? false,
      outrosDescricao: rawInspection?.accessories?.outrosDescricao || form?.accessories?.outrosDescricao || '',
    },
    damagesDescription:
      rawInspection?.damagesDescription !== undefined
        ? rawInspection.damagesDescription
        : form?.damagesDescription !== undefined
        ? form.damagesDescription
        : 'Nenhuma avaria estrutural identificada na vistoria inicial. Veículo entregue revisado, lavado e em perfeitas condições operacionais.',
    videoType: rawInspection?.videoType || form?.videoType || (rawInspection?.videoUrl?.startsWith('data:') ? 'upload' : 'link'),
    videoUrl: rawInspection?.videoUrl || form?.videoUrl || '',
    videoFileName: rawInspection?.videoFileName || form?.videoFileName || '',
    adminSignature: rawInspection?.adminSignature || source?.adminSignature || form?.adminSignature || '',
    clientSignature: rawInspection?.clientSignature || source?.clientSignature || form?.clientSignature || '',
  };

  return {
    locador: {
      name: locadorName,
      cpf: locadorCpf,
      cnpj: locadorCnpj,
      rgCnh: locadorRgCnh,
      address: locadorAddress,
    },
    locatario: {
      name: tenantName,
      profession: tenantProfession,
      cpf: tenantCpf,
      rg: tenantRg,
      cnh: tenantCnh,
      cnhCategory: tenantCnhCategory,
      address: tenantAddress,
      phone: tenantPhone,
      whatsapp: tenantWhatsapp,
      email: tenantEmail,
    },
    moto: {
      brand: motoBrand,
      model: motoModel,
      year: motoYear,
      color: motoColor,
      plate: motoPlate,
      renavam: motoRenavam,
      chassi: motoChassi,
      initialKm,
    },
    inspection,
    terms: {
      startDate,
      startDateFormatted,
      endDateMin,
      endDateMinFormatted,
      minimumMonths,
      isWeekly,
      paymentFrequency: isWeekly ? 'semanal' : 'mensal',
      weeklyValue: weeklyVal,
      weeklyValueFormatted: formatCurrency(weeklyVal),
      weeklyValueExtenso,
      monthlyValue: monthlyVal,
      monthlyValueFormatted: formatCurrency(monthlyVal),
      monthlyValueExtenso,
      dueDayName,
      dueDay,
      dueLimitTime,
      deposit: depositVal,
      depositFormatted: formatCurrency(depositVal),
      depositExtenso,
      insuranceDeductible,
      contractCity,
      contractDateFormatted,
      witnessesCount,
      witness1Name,
      witness1Cpf,
      witness2Name,
      witness2Cpf,
    },
  };
}

/**
 * Retorna as 12 Cláusulas do Contrato Oficial de Motos,
 * preservando 100% dos textos, títulos, numerações, regras e estrutura jurídica.
 */
export function getOfficialMotoContractSections(data: OfficialMotoContractData): ContractSection[] {
  const { locador, locatario, moto, terms } = data;

  const locadorQualification = locador.cnpj
    ? `${locador.name}, pessoa jurídica de direito privado, inscrita no CNPJ sob o nº ${locador.cnpj}, com sede em ${locador.address}, doravante denominado simplesmente LOCADOR.`
    : `${locador.name}, pessoa física inscrita no CPF sob o nº ${formatCPF(locador.cpf)}${
        locador.rgCnh ? `, portador da CNH/RG nº ${locador.rgCnh}` : ''
      }, com sede/residente em ${locador.address}, doravante denominado simplesmente LOCADOR.`;

  const locatarioQualification = `${locatario.name}, Profissão: ${locatario.profession}, portador e inscrito no CPF sob o nº ${formatCPF(
    locatario.cpf
  )}, portador da CNH categoria "${locatario.cnhCategory}" nº ${locatario.cnh}, residente e domiciliado na: ${
    locatario.address
  }, telefone de contato com WhatsApp: ${formatPhone(locatario.whatsapp || locatario.phone) || 'Não informado'}, doravante denominado simplesmente LOCATÁRIO.`;

  return [
    {
      number: 1,
      title: 'CLÁUSULA 1º - IDENTIFICAÇÃO DAS PARTES CONTRATANTES',
      paragraphs: [
        `1.1. LOCADOR: ${locadorQualification}`,
        `1.2. LOCATÁRIO: ${locatarioQualification}`,
        `E-mail: ${locatario.email} LOCATÁRIO`,
        '1.3. As partes acima identificadas têm, entre si, justo e acertado o presente Contrato de Locação de Motocicleta, que se regerá pelas cláusulas seguintes e pelas condições descritas neste instrumento.',
        '1.4. Para formalização da locação, o LOCATÁRIO deverá fornecer obrigatoriamente:',
      ],
      bullets: [
        'Documento oficial com foto;',
        'CNH categoria "A" válida;',
        'Comprovante de residência atualizado;',
        'Selfie segurando a CNH;',
        'Telefone celular com WhatsApp ativo.',
      ],
    },
    {
      number: 2,
      title: 'CLÁUSULA 2º - DO OBJETO DO CONTRATO',
      paragraphs: [
        '2.1. O objeto deste contrato é a locação da motocicleta de propriedade do LOCADOR, a seguir identificada, a qual será entregue ao LOCATÁRIO em perfeitas condições de uso, funcionamento e segurança:',
      ],
      bullets: [
        `Marca/Modelo: ${moto.brand} ${moto.model}`,
        `Ano de Fabricação/Modelo: ${moto.year}`,
        `Cor Predominante: ${moto.color}`,
        `Placa: ${moto.plate}`,
        `RENAVAM: ${moto.renavam}`,
        `Quilometragem Inicial (Retirada): ${moto.initialKm.toLocaleString('pt-BR')} km`,
      ],
    },
    {
      number: 2,
      title: 'CLÁUSULA 2º (CONTINUAÇÃO) - DOCUMENTAÇÃO E ACESSÓRIOS',
      paragraphs: [
        '2.2. A motocicleta acima descrita é entregue com a documentação em dia (CRLV digital ou físico), ferramentas obrigatórias (se houver) e acessórios descritos no Termo de Vistoria (Anexo I), que passa a fazer parte integrante deste instrumento.',
      ],
    },
    {
      number: 3,
      title: 'CLÁUSULA 3º - DA UTILIZAÇÃO E DO USO EXCLUSIVO',
      paragraphs: [
        '3.1. A motocicleta destina-se exclusivamente ao uso legal do LOCATÁRIO, sendo permitida a utilização para transporte pessoal ou para fins de trabalho autônomo em plataformas de aplicativo de transporte e entregas (ex: Uber, 99, iFood, etc.).',
        '3.2. O uso da motocicleta é EXCLUSIVO do LOCATÁRIO, sendo expressamente PROIBIDO:',
      ],
      bullets: [
        'a) Sublocar, emprestar, ceder ou transferir a posse da motocicleta a terceiros sob qualquer pretexto, seja de forma gratuita ou onerosa;',
        'b) Conduzir o veículo sob o efeito de álcool, drogas ou qualquer substância que altere a capacidade psicomotora;',
        'c) Utilizar a motocicleta em competições, rachas, manobras perigosas, ou em vias não pavimentadas (off-road) e praias;',
        'd) Transportar carga de peso superior ao limite especificado pelo fabricante da motocicleta.',
      ],
    },
    {
      number: 3,
      title: 'CLÁUSULA 3º (CONTINUAÇÃO) - PENALIDADE POR USO INDEVIDO',
      paragraphs: [
        '3.3. O descumprimento de qualquer uma das proibições desta cláusula ensejará a rescisão imediata do contrato por justa causa, com a aplicação das penalidades previstas neste instrumento, além da perda integral da caução.',
      ],
    },
    {
      number: 4,
      title: 'CLÁUSULA 4º - DO PRAZO E DA RENOVAÇÃO AUTOMÁTICA',
      paragraphs: [
        `4.1. O presente contrato é firmado pelo prazo mínimo obrigatório de três meses, com início em ${terms.startDateFormatted} e término em ${terms.endDateMinFormatted}.`,
        '4.2. Findo o prazo estipulado no item 4.1, caso o LOCATÁRIO permaneça na posse da motocicleta sem oposição do LOCADOR, o contrato considerar-se-á prorrogado automaticamente por PRAZO INDETERMINADO, mantendo-se vigentes todas as cláusulas, obrigações e penalidades aqui pactuadas.',
        terms.isWeekly
          ? '4.3. No período de prazo indeterminado, a locação passará a ter vigência e renovação estritamente semanal, condicionada ao pagamento antecipado das diárias/semanais.'
          : '4.3. No período de prazo indeterminado, a locação passará a ter vigência e renovação mensal, condicionada ao pagamento pontual das parcelas pactuadas.',
      ],
    },
    {
      number: 5,
      title: 'CLÁUSULA 5º - DO VALOR, DA CAUÇÃO E DAS CONDIÇÕES DE PAGAMENTO',
      paragraphs: [
        terms.isWeekly
          ? `5.1. Pela locação da motocicleta descrita na Cláusula 2º, o LOCATÁRIO pagará ao LOCADOR o valor de R$ ${terms.weeklyValue.toFixed(2).replace('.', ',')} (${terms.weeklyValueExtenso} reais) por SEMANA, devendo o pagamento ser realizado de forma ANTECIPADA todo ${terms.dueDayName}, até às ${terms.dueLimitTime} horas.`
          : `5.1. Pela locação da motocicleta descrita na Cláusula 2º, o LOCATÁRIO pagará ao LOCADOR o valor de R$ ${terms.monthlyValue.toFixed(2).replace('.', ',')} (${terms.monthlyValueExtenso} reais) por MÊS, devendo o pagamento ser realizado de forma ANTECIPADA até o dia ${terms.dueDay} de cada mês, até às ${terms.dueLimitTime} horas.`,
        '5.2. O pagamento deverá ser efetuado exclusivamente via PIX, transferência bancária ou outra modalidade expressamente autorizada pelo LOCADOR. O atraso no pagamento ensejará a rescisão imediata do contrato e a aplicação de multa diária de R$ 10,00 até a efetiva devolução do veículo, sem prejuízo das demais sanções.',
        `5.3. A título de garantia das obrigações assumidas (depósito de segurança), o LOCATÁRIO deposita nas mãos do LOCADOR, neste ato, a quantia em dinheiro de R$ ${terms.deposit.toFixed(2).replace('.', ',')} (${terms.depositExtenso} REAIS) a título de CAUÇÃO.`,
        '5.4. O valor da caução ficará retido em poder do LOCADOR e será restituído ao LOCATÁRIO no prazo de até 3 (três) dias úteis após a devolução definitiva da motocicleta, desde que o veículo seja entregue nas mesmas condições em que foi retirado, deduzindo-se eventuais valores de multas de trânsito pendentes, avarias, falta de combustível, limpezas ou diárias em atraso.',
        '5.5. Caso o LOCATÁRIO rescinda o presente contrato antes do cumprimento do prazo mínimo obrigatório estabelecido na Cláusula 4.1, perderá o valor da caução a título de multa compensatória por rescisão antecipada, limitada ao valor efetivamente depositado.',
      ],
    },
    {
      number: 6,
      title: 'CLÁUSULA 6º - DAS MANUTENÇÕES E CUIDADOS COM A MOTOCICLETA',
      paragraphs: [
        '6.1. As manutenções preventivas decorrentes do desgaste natural pelo uso regular do veículo (tais como substituição de pneus devido ao atingimento do indicador TWI, troca do kit de relação/tração desgastado e reparos mecânicos ou elétricos aos quais o LOCATÁRIO não tenha dado causa) serão de responsabilidade e custeadas integralmente pelo LOCADOR, em oficina por ele credenciada ou indicada.',
        '6.2. É de responsabilidade exclusiva e obrigatória do LOCATÁRIO a verificação diária dos itens básicos de segurança e funcionamento da motocicleta, tais como: calibragem dos pneus, nível do fluido de freio, funcionamento do sistema de iluminação (farol, setas, lanterna) e sinalização sonora (buzina).',
        '6.3. O LOCATÁRIO obriga-se rigorosamente a efetuar a troca do óleo do motor a cada 1.000 (mil) quilômetros rodados, utilizando as especificações exatas recomendadas pelo fabricante. O LOCATÁRIO deverá enviar ao LOCADOR, via WhatsApp, uma foto legível do painel da motocicleta comprovando a quilometragem e a foto da respectiva nota fiscal/recibo do serviço de troca de óleo.',
        '6.4. Os danos causados por negligência, falta de óleo do motor, falta de combustível (que cause a queima da bomba de combustível), mau uso, acidentes, vandalismo ou condução inadequada serão de responsabilidade integral e exclusiva do LOCATÁRIO, incluindo despesas com guincho/reboque, peças e mão de obra profissional para o devido reparo.',
        '6.5. O LOCATÁRIO declara estar ciente de que a motocicleta objeto deste contrato possui sistema de rastreamento veicular ativo durante toda a vigência da locação.',
        '6.6. Em caso de inadimplência, descumprimento contratual, desaparecimento do veículo, suspeita de apropriação indébita ou qualquer situação que coloque em risco o patrimônio do LOCADOR, fica este autorizado a realizar o monitoramento da localização do veículo e, quando tecnicamente possível e seguro, proceder ao bloqueio remoto da motocicleta.',
        '6.7. A perda, extravio, dano ou inutilização da chave principal, chave reserva, controle remoto ou qualquer dispositivo de acionamento da motocicleta será de responsabilidade exclusiva do LOCATÁRIO, que responderá integralmente pelos custos de reposição, codificação, transporte e demais despesas necessárias.',
        '6.8. As despesas com remoção por guincho decorrentes de acidente causado pelo LOCATÁRIO, pane seca, negligência, utilização inadequada ou qualquer evento que não decorra de defeito mecânico natural do veículo serão suportadas integralmente pelo LOCATÁRIO.',
      ],
    },
    {
      number: 7,
      title: 'CLÁUSULA 7º - DO SISTEMA DE VISTORIAS (ONLINE E PRESENCIAL)',
      paragraphs: [
        '7.1. VISTORIA ONLINE SEMANAL: Semanalmente, juntamente com o envio do comprovante de pagamento do aluguel, o LOCATÁRIO deverá enviar ao WhatsApp do LOCADOR um vídeo nítido e contínuo mostrando a motocicleta em 360 graus. No vídeo, deve constar obrigatoriamente a traseira com a placa legível, as laterais direita e esquerda e o painel com a quilometragem atual do veículo.',
        '7.2. A não apresentação do vídeo de vistoria semanal no prazo estipulado acarretará ao LOCATÁRIO multa contratual de R$20,00 por dia de atraso. Caso o atraso ultrapasse 48 (quarenta e oito) horas, o LOCADOR poderá declarar a rescisão imediata do contrato por justa causa.',
        '7.3. VISTORIA PRESENCIAL MENSAL: O LOCATÁRIO compromete-se a apresentar a motocicleta 1 (uma) vez por mês para vistoria técnica presencial, em dia, hora e endereço previamente indicados pelo LOCADOR dentro do município de atuação da locação.',
        '7.4. A não apresentação da motocicleta para a vistoria presencial mensal agendada ensejará multa contratual de R$20,00 por dia de atraso. O atraso superior a 24 (vinte e quatro) horas autorizará o LOCADOR a rescindir o presente contrato imediatamente.',
      ],
    },
    {
      number: 8,
      title: 'CLÁUSULA 8º - DO SEGURO, SINISTROS E ACIDENTES',
      paragraphs: [
        `8.1. A motocicleta conta com seguro/proteção veicular compreensiva contra colisão, incêndio, roubo e furto. Fica estabelecido que o valor da franquia/cota de participação é de R$ ${terms.insuranceDeductible}. Em caso de sinistro que demande o acionamento do seguro, o LOCATÁRIO será o único e integral responsável pelo pagamento desta franquia.`,
        '8.2. DANOS ABAIXO DA FRANQUIA: Em caso de acidente ou colisão onde os danos parciais na motocicleta resultem em valores inferiores ao da franquia estipulada no item 8.1, o LOCATÁRIO arcará integralmente com todos os custos de reparação (peças e mão de obra), devendo os consertos serem realizados obrigatoriamente em oficina indicada pelo LOCADOR.',
        '8.3. O LOCADOR não se obriga a disponibilizar veículo reserva e não se responsabiliza por lucros cessantes do LOCATÁRIO caso este fique impossibilitado de trabalhar devido à indisponibilidade da motocicleta durante o período de reparos na oficina.',
        '8.4. O LOCATÁRIO é integralmente responsável por quaisquer danos materiais, corporais ou morais causados a terceiros, bem como por processos judiciais decorrentes de sua condução.',
        '8.5. Em caso de roubo ou furto, o LOCATÁRIO deverá acionar imediatamente as autoridades policiais via 190, comunicar o LOCADOR imediatamente e lavrar o Boletim de Ocorrência, fornecendo cópia do documento em até 24 (vinte e quatro) horas para os trâmites da seguradora.',
        '8.6. Em caso de perda total da motocicleta decorrente de acidente, colisão, incêndio, roubo ou furto durante a posse do LOCATÁRIO, este será responsável pelo pagamento da franquia contratual e por quaisquer valores, prejuízos, despesas ou diferenças não cobertas pela seguradora ou associação de proteção veicular.',
        '8.7. Em caso de acidente com lesão corporal, invalidez ou morte do LOCATÁRIO, o LOCADOR não responderá por indenizações pessoais, despesas médicas, hospitalares, previdenciárias ou securitárias, cabendo tais responsabilidades exclusivamente às coberturas eventualmente contratadas junto à seguradora, associação de proteção veicular ou terceiros responsáveis pelo evento.',
      ],
    },
    {
      number: 9,
      title: 'CLÁUSULA 9º - DAS INFRAÇÕES DE TRÂNSITO E CNH DIGITAL',
      paragraphs: [
        '9.1. O LOCATÁRIO é o único e integral responsável por todas as infrações de trânsito, multas, taxas e pontuações aplicadas à motocicleta durante a vigência deste contrato.',
        '9.2. O LOCATÁRIO compromete-se a aceitar e manter-se indicado como "Condutor Principal" e "Condutor Infrator" no aplicativo CNH DIGITAL do DETRAN logo no ato da retirada do veículo. Caso o LOCATÁRIO desative voluntária ou involuntariamente essa indicação sem autorização, o contrato será rescindido imediatamente por justa causa.',
        '9.3. O LOCATÁRIO autoriza expressamente o LOCADOR a realizar a sua indicação de condutor perante os órgãos de trânsito competentes (DETRAN, PRF, Município), fornecendo assinaturas, documentos e o que mais for necessário, sob pena de incorrer em multa contratual de R$30,00 caso perca o prazo legal de indicação.',
        '9.4. Fica expressamente proibido o deslocamento da motocicleta para fora dos limites do perímetro urbano da Região Metropolitana da locação sem a prévia e expressa autorização por escrito do LOCADOR, sob pena de rescisão contratual imediata e aplicação de multa de R$50,00.',
        '9.5. As multas, infrações e penalidades cometidas durante a vigência da locação permanecerão sob responsabilidade exclusiva do LOCATÁRIO, ainda que a notificação seja emitida ou recebida após o encerramento deste contrato.',
      ],
    },
    {
      number: 10,
      title: 'CLÁUSULA 10º - DA INADIMPLÊNCIA, RESCISÃO E APROPRIAÇÃO INDÉBITA',
      paragraphs: [
        '10.1. O atraso no pagamento do aluguel semanal por período superior a 48 (quarenta e oito) horas corridos importará na RESCISÃO AUTOMÁTICA do presente contrato por justa causa, independentemente de notificação judicial ou extrajudicial.',
        '10.2. Ocorrida a rescisão prevista no item 10.1, ou qualquer outra rescisão por descumprimento de cláusula, o LOCATÁRIO fica obrigado a efetuar a devolução imediata da motocicleta no local e horário determinados pelo LOCADOR.',
        '10.3. A não devolução da motocicleta pelo LOCATÁRIO em até 24 (vinte e quatro) horas após a comunicação de rescisão ou término do contrato poderá caracterizar, em tese, o crime de apropriação indébita, previsto no artigo 168 do Código Penal, autorizando o LOCADOR a adotar todas as medidas administrativas, civis e criminais cabíveis, inclusive comunicação às autoridades policiais e utilização dos recursos de rastreamento e bloqueio do veículo.',
      ],
    },
    {
      number: 11,
      title: 'CLÁUSULA 11º - DA INEXISTÊNCIA DE VÍNCULO TRABALHISTA E REGRAS GERAIS',
      paragraphs: [
        '11.1. Fica expressamente pactuada a total INEXISTÊNCIA DE VÍNCULO TRABALHISTA ou relação de emprego entre o LOCADOR e o LOCATÁRIO. O LOCATÁRIO declara-se profissional autônomo, não havendo entre as partes qualquer tipo de subordinação, cumprimento de horários, exclusividade ou controle de prestação de serviços.',
        '11.2. O LOCATÁRIO assume a posse autônoma e a responsabilidade civil e criminal exclusiva pela circulação e uso do veículo, isentando o LOCADOR de qualquer solidariedade em acidentes ou eventos danosos, inclusive quanto a lucros cessantes de terceiros.',
        '11.3. As comunicações, avisos e notificações decorrentes deste contrato poderão ser realizados de forma eletrônica, valendo as mensagens enviadas por WhatsApp ou e-mail nos números e endereços indicados na qualificação das partes como prova documental válida.',
      ],
    },
    {
      number: 12,
      title: 'CLÁUSULA 12º - DO FORO',
      paragraphs: [
        `12.1. Para dirimir quaisquer controvérsias ou questões decorrentes da aplicação e execução deste contrato, as partes elegem expressamente o foro da Comarca de ${terms.contractCity}, com renúncia expressa a qualquer outro, por mais privilegiado que seja ou venha a ser.`,
      ],
    },
  ];
}

/**
 * Retorna o texto bruto integral do contrato oficial com rigor de 1:1,
 * idêntico ao texto do PDF e à pré-visualização.
 */
export function getOfficialMotoContractRawText(data: OfficialMotoContractData): string {
  const sections = getOfficialMotoContractSections(data);
  const { locador, locatario, terms } = data;

  let out = `❖ CONTRATO DE LOCAÇÃO DE MOTOCICLETA COM PRAZO MÍNIMO E RENOVAÇÃO AUTOMÁTICA\n\n`;

  sections.forEach((sec) => {
    out += `${sec.title}\n\n`;
    sec.paragraphs.forEach((p) => {
      out += `${p}\n\n`;
    });
    if (sec.bullets && sec.bullets.length > 0) {
      sec.bullets.forEach((b) => {
        out += `• ${b}\n`;
      });
      out += `\n`;
    }
  });

  const closingText =
    terms.witnessesCount === 0
      ? 'E, por estarem assim justas e contratadas, as partes firmam o presente instrumento em 2 (duas) vias de igual teor e forma, para que produza seus regulares efeitos legais.'
      : terms.witnessesCount === 1
      ? 'E, por estarem assim justas e contratadas, as partes firmam o presente instrumento em 2 (duas) vias de igual teor e forma, na presença de 1 (uma) testemunha abaixo qualificada, para que produza seus regulares efeitos legais.'
      : 'E, por estarem assim justas e contratadas, as partes firmam o presente instrumento em 2 (duas) vias de igual teor e forma, na presença das testemunhas abaixo qualificadas, para que produza seus efeitos legais.';

  out += `${closingText}\n\n`;
  out += `Local: ${terms.contractCity} , Data: ${terms.contractDateFormatted}\n\n`;

  out += `__________________________________________________\n`;
  out += `LOCADOR: ${locador.name}\n`;
  out += `CPF: ${formatCPF(locador.cpf)}\n\n`;

  out += `__________________________________________________\n`;
  out += `LOCATÁRIO: ${locatario.name}\n`;
  out += `CPF: ${formatCPF(locatario.cpf)}\n\n`;

  if (terms.witnessesCount > 0) {
    out += `TESTEMUNHAS:\n\n`;
    out += `1. _________________________________\n`;
    out += `   Nome: ${terms.witness1Name || '____________________________'}\n`;
    out += `   CPF: ${terms.witness1Cpf ? formatCPF(terms.witness1Cpf) : '__________________'}\n\n`;

    if (terms.witnessesCount > 1) {
      out += `2. _________________________________\n`;
      out += `   Nome: ${terms.witness2Name || '____________________________'}\n`;
      out += `   CPF: ${terms.witness2Cpf ? formatCPF(terms.witness2Cpf) : '__________________'}\n\n`;
    }
  }

  out += `\n======================================================================\n`;
  out += getOfficialMotoContractAnnexText(data);

  return out;
}

/**
 * Retorna o texto integral e exato do ANEXO I - TERMO DE VISTORIA E RETIRADA
 * exatamente conforme a estrutura jurídica oficial enviada pelo usuário,
 * preenchida 100% pelos dados dinâmicos da vistoria.
 */
export function getOfficialMotoContractAnnexText(data: OfficialMotoContractData): string {
  const { locador, locatario, moto, inspection } = data;
  const chk = inspection.checklist;
  const acc = inspection.accessories;

  const fmtStatus = (item: { checked: boolean; status: string; notes?: string }, label: string) => {
    const isChk = item.checked ? '[X]' : '[ ]';
    const isBom = item.status === 'bom' ? '( X )' : '(   )';
    const isReg = item.status === 'regular' ? '( X )' : '(   )';
    const isRuim = item.status === 'ruim' ? '( X )' : '(   )';
    const obs = item.notes?.trim() ? item.notes.trim() : '____________________';
    return `${isChk} ${label} ${isBom} Bom ${isReg} Regular ${isRuim} Ruim | Obs: ${obs}`;
  };

  const fuel = inspection.fuelLevel;
  const fCheio = fuel === 'cheio' ? '[ X ]' : '[   ]';
  const f34 = fuel === '3/4' ? '[ X ]' : '[   ]';
  const f12 = fuel === '1/2' ? '[ X ]' : '[   ]';
  const f14 = fuel === '1/4' ? '[ X ]' : '[   ]';
  const fRes = fuel === 'reserva' ? '[ X ]' : '[   ]';

  // Formatação dos acessórios:
  // "Outra coisa, de acordo com o que eu vou desmarcando, vai atualizando no PDF e no contrato também, se eu desmarcar capacete, não é pra aparecer no PDF, assim ele vai se formatando automaticamente"
  const accList: string[] = [];
  if (acc.capacete) accList.push('[ X ] Capacete');
  if (acc.capaChuva) accList.push('[ X ] Capa de Chuva');
  if (acc.suporteCelular) accList.push('[ X ] Suporte de Celular');
  if (acc.bauBauleto) accList.push('[ X ] Baú/Bauleto');
  if (acc.chaveReserva) accList.push('[ X ] Chave Reserva');
  if (acc.outros) {
    accList.push(`[ X ] Outros: ${acc.outrosDescricao?.trim() || 'Sim'}`);
  }
  const accessoriesFormatted = accList.length > 0 ? accList.join('   ') : 'Nenhum acessório adicional entregue';

  const damagesText = inspection.damagesDescription?.trim()
    ? inspection.damagesDescription.trim()
    : 'Nenhuma avaria estrutural identificada. Veículo em perfeito estado de conservação.';

  let out = `ANEXO I - TERMO DE VISTORIA E RETIRADA\n\n`;
  out += `Este termo é parte integrante e indissociável do Contrato de Locação de Motocicleta firmado entre as partes.\n\n`;
  out += `Data da Vistoria: ${formatDate(inspection.date)} | Hora da Retirada: ${inspection.time || '10:00'}\n`;
  out += `Quilometragem Inicial: ${Number(inspection.initialKm || 0).toLocaleString('pt-BR')} km\n\n`;
  out += `CONDIÇÕES GERAIS DA MOTOCICLETA:\n\n`;
  out += `${fmtStatus(chk.pneuDianteiro, 'Pneu Dianteiro')}\n`;
  out += `${fmtStatus(chk.pneuTraseiro, 'Pneu Traseiro')}\n`;
  out += `${fmtStatus(chk.freioDianteiro, 'Freio Dianteiro')}\n`;
  out += `${fmtStatus(chk.freioTraseiro, 'Freio Traseiro')}\n`;
  out += `${fmtStatus(chk.farolLanternas, 'Farol e Lanternas')}\n`;
  out += `${fmtStatus(chk.setas, 'Setas (D / T)')}\n`;
  out += `${fmtStatus(chk.buzina, 'Buzina')}\n`;
  out += `${fmtStatus(chk.retrovisores, 'Retrovisores')}\n`;
  out += `${fmtStatus(chk.assentoBanco, 'Assento/Banco')}\n`;
  out += `${fmtStatus(chk.pinturaLataria, 'Pintura/Lataria')}\n\n`;
  out += `NÍVEL DE COMBUSTÍVEL NA RETIRADA:\n`;
  out += `${fCheio} Cheio   ${f34} 3/4   ${f12} 1/2   ${f14} 1/4   ${fRes} Reserva\n\n`;
  out += `ACESSÓRIOS ENTREGUES:\n`;
  out += `${accessoriesFormatted}\n\n`;
  out += `DESCRIÇÃO DETALHADA DE AVARIAS EXISTENTES (Riscos, amassados, peças quebradas):\n`;
  out += `${damagesText}\n\n`;
  out += `Nota: Além deste termo impresso, foi realizado e armazenado um vídeo de vistoria em 360 graus do veículo no ato da entrega, servindo ambos como prova das condições iniciais da motocicleta.\n`;
  if (inspection.videoUrl) {
    const videoRef = inspection.videoType === 'upload' && inspection.videoFileName ? `Arquivo: ${inspection.videoFileName}` : inspection.videoUrl;
    out += `Vídeo da Vistoria registrado: ${videoRef}\n`;
  }
  out += `\nO LOCATÁRIO declara que vistoriou a motocicleta, recebeu os acessórios marcados e concorda que o veículo está em perfeitas condições de uso, segurança e funcionamento, obrigando-se a devolvê-lo nas mesmas condições.\n\n`;
  out += `__________________________________________________\n`;
  out += `Assinatura do LOCADOR\n\n`;
  out += `__________________________________________________\n`;
  out += `Assinatura do LOCATÁRIO\n`;

  return out;
}
