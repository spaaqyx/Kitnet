import React from 'react';

interface IconProps {
  className?: string;
}

// 1. Pneu Dianteiro: Roda dianteira de moto com raios e sulcos de piso
export const IconPneuDianteiro: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="9" />
    <circle cx="12" cy="12" r="4.5" />
    <circle cx="12" cy="12" r="1.5" fill="currentColor" />
    <path d="M12 3v4.5" />
    <path d="M12 16.5V21" />
    <path d="M3 12h4.5" />
    <path d="M16.5 12H21" />
    <path d="M5.6 5.6l3.2 3.2" />
    <path d="M15.2 15.2l3.2 3.2" />
    <path d="M18.4 5.6l-3.2 3.2" />
    <path d="M8.8 15.2l-3.2 3.2" />
  </svg>
);

// 2. Pneu Traseiro: Roda traseira de moto reforçada com coroa de tração
export const IconPneuTraseiro: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="9" strokeDasharray="3 2" />
    <circle cx="12" cy="12" r="5.5" />
    <circle cx="12" cy="12" r="2.5" fill="currentColor" fillOpacity="0.3" />
    <path d="M12 2.5v4" />
    <path d="M12 17.5v4" />
    <path d="M2.5 12h4" />
    <path d="M17.5 12h4" />
    <path d="M6 6l2.8 2.8" />
    <path d="M15.2 15.2l2.8 2.8" />
    <path d="M18 6l-2.8 2.8" />
    <path d="M8.8 15.2l-2.8 2.8" />
  </svg>
);

// 3. Freio Dianteiro: Disco perfurado com pinça de freio esportiva
export const IconFreioDianteiro: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="8.5" />
    <circle cx="12" cy="12" r="3.5" />
    {/* Pinça de freio */}
    <path d="M15 3.5a9 9 0 0 1 5.5 5.5l-3.5 1.5a5 5 0 0 0-3.5-3.5z" fill="currentColor" fillOpacity="0.25" stroke="currentColor" />
    {/* Furos de ventilação do disco */}
    <circle cx="12" cy="6" r="0.8" fill="currentColor" />
    <circle cx="12" cy="18" r="0.8" fill="currentColor" />
    <circle cx="6" cy="12" r="0.8" fill="currentColor" />
    <circle cx="18" cy="12" r="0.8" fill="currentColor" />
    <circle cx="7.8" cy="7.8" r="0.8" fill="currentColor" />
    <circle cx="16.2" cy="16.2" r="0.8" fill="currentColor" />
    <circle cx="7.8" cy="16.2" r="0.8" fill="currentColor" />
  </svg>
);

// 4. Freio Traseiro: Disco traseiro com fixação e acionamento
export const IconFreioTraseiro: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="8" />
    <circle cx="12" cy="12" r="3" />
    {/* Pinça traseira */}
    <path d="M3.5 9a9 9 0 0 1 5.5-5.5l1.5 3.5a5 5 0 0 0-3.5 3.5z" fill="currentColor" fillOpacity="0.25" stroke="currentColor" />
    <circle cx="12" cy="6.5" r="0.75" fill="currentColor" />
    <circle cx="12" cy="17.5" r="0.75" fill="currentColor" />
    <circle cx="6.5" cy="12" r="0.75" fill="currentColor" />
    <circle cx="17.5" cy="12" r="0.75" fill="currentColor" />
    <line x1="9" y1="9" x2="15" y2="15" />
    <line x1="15" y1="9" x2="9" y2="15" />
  </svg>
);

// 5. Farol e Lanternas: Farol de moto com feixe de luz potente
export const IconFarolLanternas: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M4 7a8 8 0 0 0 0 10h4a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2H4z" fill="currentColor" fillOpacity="0.2" />
    <line x1="14" y1="6" x2="21" y2="4" strokeWidth="2" />
    <line x1="15" y1="10" x2="22" y2="9.5" strokeWidth="2" />
    <line x1="15" y1="14" x2="22" y2="14.5" strokeWidth="2" />
    <line x1="14" y1="18" x2="21" y2="20" strokeWidth="2" />
    <path d="M4 12h5" />
  </svg>
);

// 6. Setas / Piscas: Indicadores de direção duplos com setas laterais
export const IconSetas: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    {/* Seta Esquerda */}
    <path d="M7 6l-5 6 5 6" strokeWidth="2.2" />
    <path d="M2 12h8" strokeWidth="2" />
    {/* Seta Direita */}
    <path d="M17 6l5 6-5 6" strokeWidth="2.2" />
    <path d="M14 12h8" strokeWidth="2" />
    <circle cx="12" cy="12" r="1.5" fill="currentColor" />
  </svg>
);

// 7. Buzina: Corneta acústica com ondas sonoras potentes
export const IconBuzina: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="8" cy="12" r="5" fill="currentColor" fillOpacity="0.2" />
    <path d="M8 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z" />
    <path d="M15 8a6 6 0 0 1 0 8" strokeWidth="2" />
    <path d="M18 5a10 10 0 0 1 0 14" strokeWidth="2" />
    <path d="M21 2a14 14 0 0 1 0 20" strokeWidth="1.5" strokeDasharray="2 2" />
  </svg>
);

// 8. Retrovisores: Espelhos retrovisores aerodinâmicos
export const IconRetrovisores: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    {/* Espelho Esquerdo */}
    <path d="M4 5a3 3 0 0 1 5 0l2 4a3 3 0 0 1-5 0z" fill="currentColor" fillOpacity="0.2" />
    <path d="M8 10l-2 10" strokeWidth="2" />
    {/* Espelho Direito */}
    <path d="M15 5a3 3 0 0 1 5 0l2 4a3 3 0 0 1-5 0z" fill="currentColor" fillOpacity="0.2" />
    <path d="M16 10l2 10" strokeWidth="2" />
    <path d="M6 8l3-1" strokeOpacity="0.6" />
    <path d="M17 8l3-1" strokeOpacity="0.6" />
  </svg>
);

// 9. Assento / Banco: Banco anatômico de motocicleta de dois níveis
export const IconAssentoBanco: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path
      d="M3 15c1-3 4-5 8-5 3 0 4-2 7-2 3 0 4 2 3 6-1 2-4 2-8 2-4 0-8 0-10-1z"
      fill="currentColor"
      fillOpacity="0.25"
    />
    <path d="M11 10c0 2 1 3 3 3" strokeWidth="1.5" strokeOpacity="0.7" />
    <path d="M4 16h16" strokeWidth="1.5" strokeDasharray="3 2" />
  </svg>
);

// 10. Pintura / Lataria: Tanque & Carenagem polida com brilho
export const IconPinturaLataria: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path
      d="M12 2l7 4v6c0 5.25-3.5 10-7 11-3.5-1-7-5.75-7-11V6l7-4z"
      fill="currentColor"
      fillOpacity="0.15"
    />
    {/* Estrela de brilho / polimento */}
    <path d="M12 6l1 2.5L15.5 9.5 13 10.5 12 13l-1-2.5-2.5-1L11 8.5z" fill="currentColor" />
    <circle cx="16" cy="14" r="1" fill="currentColor" />
  </svg>
);

// 11. Capacete: Capacete fechado com viseira
export const IconCapacete: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path
      d="M12 3a9 9 0 0 0-9 9c0 3.5 1.5 5.5 3 6.5l3 1.5h7a5 5 0 0 0 5-5v-3a9 9 0 0 0-9-9z"
      fill="currentColor"
      fillOpacity="0.15"
    />
    {/* Viseira */}
    <path d="M8 11h9a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2h-7a4 4 0 0 1-4-4v-1a1 1 0 0 1 2-1z" fill="currentColor" fillOpacity="0.3" stroke="currentColor" />
  </svg>
);

// 12. Capa de Chuva: Casaco impermeável de motociclista
export const IconCapaChuva: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path
      d="M4 5l4-2 4 2 4-2 4 2-1 6-3-1v11H8V10L5 11 4 5z"
      fill="currentColor"
      fillOpacity="0.15"
    />
    <line x1="12" y1="3" x2="12" y2="21" strokeWidth="1.8" />
    <path d="M16 14l-1 2" strokeWidth="1.5" />
    <path d="M9 14l-1 2" strokeWidth="1.5" />
  </svg>
);

// 13. Suporte de Celular: Clamp de guidão com smartphone acoplado
export const IconSuporteCelular: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <rect x="7" y="3" width="10" height="15" rx="2" fill="currentColor" fillOpacity="0.15" />
    <line x1="10" y1="15" x2="14" y2="15" />
    <circle cx="12" cy="7" r="1.5" fill="currentColor" />
    {/* Garra de fixação no guidão */}
    <path d="M9 18l-2 4h10l-2-4" strokeWidth="2" />
    <path d="M5 8h2" strokeWidth="2" />
    <path d="M17 8h2" strokeWidth="2" />
    <path d="M5 13h2" strokeWidth="2" />
    <path d="M17 13h2" strokeWidth="2" />
  </svg>
);

// 14. Baú / Bauleto: Maleta traseira rígida com trava
export const IconBauBauleto: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <rect x="3" y="6" width="18" height="13" rx="3" fill="currentColor" fillOpacity="0.15" />
    <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    {/* Faixa refletiva e fechadura */}
    <line x1="3" y1="12" x2="21" y2="12" strokeWidth="1.5" strokeDasharray="3 2" />
    <rect x="10.5" y="10.5" width="3" height="3" rx="0.5" fill="currentColor" />
  </svg>
);

// 15. Chave Reserva: Chave de ignição com dentes e anel
export const IconChaveReserva: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="7.5" cy="15.5" r="4.5" fill="currentColor" fillOpacity="0.2" />
    <circle cx="7.5" cy="15.5" r="1.5" fill="currentColor" />
    <path d="M11 12l9-9" strokeWidth="2" />
    <path d="M18 5l2 2" strokeWidth="2" />
    <path d="M15 8l1.5 1.5" strokeWidth="2" />
    <path d="M19 4l1 1" strokeWidth="2" />
  </svg>
);

// 16. Outros Acessórios: Kit de ferramentas e equipamentos
export const IconOutros: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" fill="currentColor" fillOpacity="0.2" />
  </svg>
);

// 17. Bomba de Combustível com marcador líquido
export const IconCombustivel: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M3 22h12" />
    <path d="M4 22V4a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v18" fill="currentColor" fillOpacity="0.15" />
    <rect x="6" y="6" width="6" height="5" rx="1" strokeWidth="1.5" />
    {/* Mangueira de combustível */}
    <path d="M14 8h2a2 2 0 0 1 2 2v7a2 2 0 0 0 2 2 2 2 0 0 0 2-2V9l-2-2" strokeWidth="1.8" />
  </svg>
);

// 18. Status Bom: Círculo verde com Checkmark marcante
export const IconStatusBom: React.FC<IconProps> = ({ className = 'w-4 h-4' }) => (
  <svg viewBox="0 0 20 20" fill="currentColor" className={className}>
    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z" clipRule="evenodd" />
  </svg>
);

// 19. Status Regular: Triângulo amarelo com Exclamação
export const IconStatusRegular: React.FC<IconProps> = ({ className = 'w-4 h-4' }) => (
  <svg viewBox="0 0 20 20" fill="currentColor" className={className}>
    <path fillRule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
  </svg>
);

// 20. Status Ruim: Octógono / Alerta vermelho com X
export const IconStatusRuim: React.FC<IconProps> = ({ className = 'w-4 h-4' }) => (
  <svg viewBox="0 0 20 20" fill="currentColor" className={className}>
    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.28 7.22a.75.75 0 00-1.06 1.06L8.94 10l-1.72 1.72a.75.75 0 101.06 1.06L10 11.06l1.72 1.72a.75.75 0 101.06-1.06L11.06 10l1.72-1.72a.75.75 0 00-1.06-1.06L10 8.94 8.28 7.22z" clipRule="evenodd" />
  </svg>
);

// 21. Magic Sparkles / Marcar Todos como Bom
export const IconMagicWand: React.FC<IconProps> = ({ className = 'w-4 h-4' }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M15 4V2" />
    <path d="M15 16v-2" />
    <path d="M8 9h2" />
    <path d="M20 9h2" />
    <path d="M17.8 11.8L19 13" />
    <path d="M15 9h0" />
    <path d="M17.8 6.2L19 5" />
    <path d="M3 21l9-9" />
    <path d="M12.2 6.2L11 5" />
  </svg>
);
