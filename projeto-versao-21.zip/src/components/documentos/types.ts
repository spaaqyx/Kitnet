import { LucideIcon } from 'lucide-react';

export interface UnifiedClient {
  id: string;
  type: 'kitnet' | 'moto';
  tenantId: string;
  fullName: string;
  cpf: string;
  rg?: string;
  phone?: string;
  address?: string;
  assetLabel: string;
  assetDescription: string;
  deposit: number;
  rentOrMonthlyValue: number;
  monthlyValue: number;
  weeklyValue?: number;
  waterValue?: number;
  durationMonths?: number;
  totalAgreedValue?: number;
  paymentFrequency?: 'mensal' | 'semanal';
  insuranceDeductible?: string;
  contractId?: string;
  contractStartDate?: string;
  dueDay?: number;
  dueDayOfWeek?: number;
  initialKm?: number;
  plate?: string;
  brand?: string;
  model?: string;
  year?: number;
  color?: string;
  renavam?: string;
  chassi?: string;
  witnessesCount?: number;
  witness1Name?: string;
  witness1Cpf?: string;
  witness2Name?: string;
  witness2Cpf?: string;
}

export interface DocumentTypeItem {
  id: string;
  title: string;
  category: string;
  badge: string;
  badgeColor: string;
  icon: LucideIcon;
  desc: string;
}
