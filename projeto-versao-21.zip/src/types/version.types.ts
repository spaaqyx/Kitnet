export interface AppVersionItem {
  num?: number;
  version: string;
  displayName?: string;
  filename: string;
  downloadUrl: string;
  sizeBytes: number;
  sizeFormatted: string;
  sha256?: string;
  fileCount?: number;
  buildId?: string;
  updatedAt: string;
  formattedDateTime: string;
  formattedTime: string;
  formattedDate: string;
  isLatest: boolean;
}

export interface VersionComparison {
  hasPrevious: boolean;
  isFirstVersion?: boolean;
  oldVersion?: string;
  newVersion?: string;
  oldSizeFormatted: string;
  oldSizeBytes: number;
  newSizeFormatted: string;
  newSizeBytes: number;
  diffBytes: number;
  diffFormatted: string;
  diffPercent: string;
  isIncrease: boolean;
  filesChanged?: number;
  filesCreated?: number;
  filesRemoved?: number;
}

export interface ZipValidationCheck {
  id: string;
  label: string;
  passed: boolean;
  details?: string;
}

export interface ZipAnomalyAlert {
  id: string;
  title: string;
  description: string;
  severity: 'warning' | 'error';
}

export interface ProjectVersionInfo {
  version?: string;
  versionNumber?: number;
  buildId?: string;
  file?: string;
  filename?: string;
  downloadUrl?: string;
  size?: number;
  sizeBytes?: number;
  sizeFormatted?: string;
  fileCount?: number;
  generationTimeSeconds?: number;
  sha256?: string;
  generatedAt?: string;
  lastGenerated: string;
  updatedAt: string;
  lastBuildDateTime?: string;
  lastZipDateTime?: string;
  syncStatus?: 'synced' | 'outdated';
  syncStatusMessage?: string;
  formattedTime: string;
  formattedDate: string;
  formattedDateTime: string;
  currentVersion: AppVersionItem;
  previousVersion: AppVersionItem | null;
  comparison: VersionComparison;
  allVersions: AppVersionItem[];
  validationChecks?: ZipValidationCheck[];
  anomalies?: ZipAnomalyAlert[];
}

