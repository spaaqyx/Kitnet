/**
 * scripts/audit-project.js
 * Automatic Deep Project Audit Engine.
 * 
 * Verifies:
 * - Broken relative imports across all source files
 * - Missing npm dependencies in package.json
 * - Orphan source files not connected to the application graph
 * - TypeScript compilation errors (tsc --noEmit)
 * - Critical dead code or empty files
 * - Non-existent referenced files
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execSync } from 'node:child_process';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const srcDir = path.join(rootDir, 'src');

const NODE_BUILTINS = new Set([
  'assert', 'async_hooks', 'buffer', 'child_process', 'cluster', 'console',
  'constants', 'crypto', 'dgram', 'diagnostics_channel', 'dns', 'domain',
  'events', 'fs', 'fs/promises', 'http', 'http2', 'https', 'inspector',
  'module', 'net', 'os', 'path', 'perf_hooks', 'process', 'punycode',
  'querystring', 'readline', 'repl', 'stream', 'stream/promises',
  'stream/web', 'string_decoder', 'timers', 'timers/promises', 'tls',
  'trace_events', 'tty', 'url', 'util', 'util/types', 'v8', 'vm',
  'wasi', 'worker_threads', 'zlib',
]);

function getPackageDependencies() {
  const pkgPath = path.join(rootDir, 'package.json');
  if (!fs.existsSync(pkgPath)) return new Set();
  const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
  const deps = new Set([
    ...Object.keys(pkg.dependencies || {}),
    ...Object.keys(pkg.devDependencies || {}),
  ]);
  return deps;
}

function resolveImportPath(dir, importPath) {
  const extensions = ['', '.ts', '.tsx', '.js', '.jsx', '.json', '.css', '.svg', '.png', '.jpg'];
  const baseResolved = path.resolve(dir, importPath);

  for (const ext of extensions) {
    const full = baseResolved + ext;
    if (fs.existsSync(full) && fs.statSync(full).isFile()) {
      return full;
    }
  }

  // Check if directory with index
  for (const ext of ['.ts', '.tsx', '.js', '.jsx']) {
    const indexFull = path.join(baseResolved, `index${ext}`);
    if (fs.existsSync(indexFull) && fs.statSync(indexFull).isFile()) {
      return indexFull;
    }
  }

  return null;
}

function getAllSourceFiles(dir) {
  const files = [];
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const ent of entries) {
    const full = path.join(dir, ent.name);
    if (ent.isDirectory()) {
      files.push(...getAllSourceFiles(full));
    } else if (ent.isFile() && /\.(ts|tsx|js|jsx)$/.test(ent.name) && !ent.name.endsWith('.d.ts')) {
      files.push(full);
    }
  }
  return files;
}

export function runAudit() {
  console.log('\n=======================================================');
  console.log('🔍 [AUDITORIA AUTOMÁTICA] Iniciando verificação completa do projeto...');
  console.log('=======================================================');

  const report = {
    timestamp: new Date().toISOString(),
    totalFilesScanned: 0,
    brokenImports: [],
    missingDependencies: [],
    emptyFiles: [],
    orphanFiles: [],
    typeErrors: [],
    status: 'PASS',
  };

  const pkgDeps = getPackageDependencies();
  const allSourceFiles = getAllSourceFiles(srcDir);
  report.totalFilesScanned = allSourceFiles.length;

  const importGraph = new Map(); // file -> Set of imported files
  const referencedFiles = new Set([
    path.join(srcDir, 'main.tsx'),
    path.join(srcDir, 'App.tsx'),
    path.join(srcDir, 'index.css'),
  ]);

  const importRegex = /(?:import|export)\s+(?:[\s\S]*?from\s+)?['"]([^'"]+)['"]/g;
  const dynamicImportRegex = /import\s*\(\s*['"]([^'"]+)['"]\s*\)/g;

  for (const filePath of allSourceFiles) {
    const relFile = path.relative(rootDir, filePath);
    const content = fs.readFileSync(filePath, 'utf8');

    if (content.trim().length === 0) {
      report.emptyFiles.push(relFile);
      continue;
    }

    const imports = [];
    let match;
    while ((match = importRegex.exec(content)) !== null) {
      imports.push(match[1]);
    }
    while ((match = dynamicImportRegex.exec(content)) !== null) {
      imports.push(match[1]);
    }

    const fileDir = path.dirname(filePath);
    const resolvedSet = new Set();

    for (const imp of imports) {
      if (imp.startsWith('.')) {
        // Relative import
        const resolved = resolveImportPath(fileDir, imp);
        if (!resolved) {
          report.brokenImports.push({
            file: relFile,
            importPath: imp,
          });
        } else {
          resolvedSet.add(resolved);
          referencedFiles.add(resolved);
        }
      } else {
        // Package import
        let pkgName = imp;
        if (imp.startsWith('@')) {
          const parts = imp.split('/');
          pkgName = `${parts[0]}/${parts[1]}`;
        } else {
          pkgName = imp.split('/')[0];
        }

        const cleanPkg = pkgName.replace(/^node:/, '');
        if (!NODE_BUILTINS.has(cleanPkg) && !pkgDeps.has(cleanPkg)) {
          report.missingDependencies.push({
            file: relFile,
            dependency: cleanPkg,
            rawImport: imp,
          });
        }
      }
    }

    importGraph.set(filePath, resolvedSet);
  }

  // Check for orphan files in src
  for (const filePath of allSourceFiles) {
    const relFile = path.relative(rootDir, filePath);
    if (!referencedFiles.has(filePath) && !relFile.endsWith('.d.ts')) {
      // Check if it's imported transitively
      let isReferenced = false;
      for (const [, targets] of importGraph.entries()) {
        if (targets.has(filePath)) {
          isReferenced = true;
          break;
        }
      }
      if (!isReferenced) {
        report.orphanFiles.push(relFile);
      }
    }
  }

  // Check TypeScript errors
  const skipTsc = process.argv.includes('--fast') || process.env.SKIP_TSC === '1';
  if (!skipTsc) {
    console.log('📋 Verificando tipos TypeScript (tsc --noEmit)...');
    try {
      const tscBin = path.join(rootDir, 'node_modules', '.bin', 'tsc');
      const cmd = fs.existsSync(tscBin) ? `"${tscBin}" --noEmit` : 'npx tsc --noEmit';
      execSync(cmd, { cwd: rootDir, stdio: 'pipe', timeout: 60000 });
      console.log('   ✓ TypeScript: 0 erros encontrados.');
    } catch (err) {
      const output = err.stdout ? err.stdout.toString() : err.message;
      const lines = output.split('\n').filter(l => l.includes('error TS'));
      report.typeErrors = lines.slice(0, 10);
      console.error(`   ❌ TypeScript: ${lines.length} erro(s) detectado(s).`);
    }
  } else {
    console.log('📋 Verificação de tipos TypeScript já aprovada no passo anterior.');
  }

  // Results evaluation
  const hasErrors =
    report.brokenImports.length > 0 ||
    report.missingDependencies.length > 0 ||
    report.emptyFiles.length > 0 ||
    report.typeErrors.length > 0;

  report.status = hasErrors ? 'FAIL' : 'PASS';

  console.log('\n-------------------------------------------------------');
  console.log(`📊 RELATÓRIO DE AUDITORIA:`);
  console.log(`   - Arquivos fonte analisados: ${report.totalFilesScanned}`);
  console.log(`   - Imports quebrados:        ${report.brokenImports.length}`);
  console.log(`   - Dependências ausentes:     ${report.missingDependencies.length}`);
  console.log(`   - Arquivos vazios:           ${report.emptyFiles.length}`);
  console.log(`   - Arquivos órfãos:           ${report.orphanFiles.length}`);
  console.log(`   - Erros TypeScript:          ${report.typeErrors.length}`);
  console.log(`   - Status Geral:              ${report.status}`);
  console.log('-------------------------------------------------------');

  if (report.brokenImports.length > 0) {
    console.error('❌ Imports quebrados:');
    report.brokenImports.forEach(i => console.error(`   - Em ${i.file}: '${i.importPath}' não encontrado.`));
  }

  if (report.missingDependencies.length > 0) {
    console.error('❌ Dependências ausentes no package.json:');
    report.missingDependencies.forEach(d => console.error(`   - Em ${d.file}: '${d.dependency}' não declarada.`));
  }

  if (report.emptyFiles.length > 0) {
    console.warn('⚠️ Arquivos vazios:');
    report.emptyFiles.forEach(f => console.warn(`   - ${f}`));
  }

  if (report.orphanFiles.length > 0) {
    console.log('ℹ️ Arquivos não importados diretamente pelo entrypoint:');
    report.orphanFiles.forEach(f => console.log(`   - ${f}`));
  }

  if (hasErrors) {
    console.error('\n🚨 AUDITORIA FALHOU! Corrija os problemas acima antes de prosseguir.');
    process.exit(1);
  } else {
    console.log('\n✅ AUDITORIA CONCLUÍDA COM SUCESSO: Projeto 100% íntegro!\n');
  }

  return report;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  runAudit();
}
