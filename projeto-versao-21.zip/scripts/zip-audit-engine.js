/**
 * scripts/zip-audit-engine.js
 * Single Source of Truth for ZIP Auditing, Verification, Comparison, and Anomaly Detection.
 * Used by backend pipeline scripts, Vite dev server API, and test suites.
 */

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import JSZip from 'jszip';
import { computeSourceCodeHash, getStoredHash, hasSourceCodeChanged } from './source-hash.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

const BRAZIL_TIMEZONE = 'America/Sao_Paulo';

export function getBrazilDateInfo(dateObj = new Date()) {
  const formatter = new Intl.DateTimeFormat('pt-BR', {
    timeZone: BRAZIL_TIMEZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });

  const parts = formatter.formatToParts(dateObj);
  const partMap = {};
  for (const p of parts) {
    partMap[p.type] = p.value;
  }

  const dateStr = `${partMap.day}/${partMap.month}/${partMap.year}`;
  const timeStr = `${partMap.hour}:${partMap.minute}:${partMap.second}`;
  const datetimeStr = `${dateStr} às ${timeStr}`;
  const isoStr = dateObj.toISOString();

  return { dateStr, timeStr, datetimeStr, isoStr };
}

export function formatSize(bytes) {
  if (typeof bytes !== 'number' || isNaN(bytes) || bytes <= 0) return '0 KB';
  if (bytes >= 1024 * 1024) {
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }
  return `${(bytes / 1024).toFixed(1)} KB`;
}

export function computeFileSha256(filePath) {
  if (!fs.existsSync(filePath)) return '';
  const fileBuffer = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(fileBuffer).digest('hex');
}

/**
 * Validates a ZIP archive thoroughly.
 * Checks structure, minimum files, mandatory configs, nested archives, and anomalies.
 */
export async function auditZipFile(zipPath, expectedSha = null, previousZipSize = 0) {
  const checks = [];
  const anomalies = [];

  // Check 1: File exists
  const exists = fs.existsSync(zipPath);
  checks.push({
    id: 'zip_exists',
    label: 'Arquivo ZIP existe',
    passed: exists,
    details: exists ? `Encontrado em ${path.basename(zipPath)}` : 'Arquivo ZIP não encontrado no caminho especificado',
  });

  if (!exists) {
    anomalies.push({
      id: 'missing_zip',
      title: 'Arquivo ZIP ausente',
      description: 'O pacote ZIP não foi localizado no diretório de distribuição.',
      severity: 'error',
    });
    return {
      valid: false,
      fileCount: 0,
      sizeBytes: 0,
      sizeFormatted: '0 KB',
      sha256: '',
      checks,
      anomalies,
      fileList: [],
    };
  }

  const stat = fs.statSync(zipPath);
  const sizeBytes = stat.size;
  const sizeFormatted = formatSize(sizeBytes);
  const calculatedSha = computeFileSha256(zipPath);

  // Check 2: ZIP opens properly
  let zip;
  let fileList = [];
  let openPassed = false;
  try {
    const data = fs.readFileSync(zipPath);
    zip = await JSZip.loadAsync(data);
    fileList = Object.keys(zip.files).filter(f => !zip.files[f].dir);
    openPassed = fileList.length > 0;
    checks.push({
      id: 'zip_opens',
      label: 'Abertura e integridade do ZIP',
      passed: true,
      details: `Descompressão OK (${fileList.length} arquivos analisados)`,
    });
  } catch (err) {
    checks.push({
      id: 'zip_opens',
      label: 'Abertura e integridade do ZIP',
      passed: false,
      details: `Falha ao descomprimir: ${err.message}`,
    });
    anomalies.push({
      id: 'corrupt_zip',
      title: 'ZIP corrompido',
      description: 'Não foi possível descomprimir o pacote ZIP gerado.',
      severity: 'error',
    });
    return {
      valid: false,
      fileCount: 0,
      sizeBytes,
      sizeFormatted,
      sha256: calculatedSha,
      checks,
      anomalies,
      fileList: [],
    };
  }

  // Check 3: package.json exists
  const hasPkg = fileList.includes('package.json');
  checks.push({
    id: 'pkg_json',
    label: 'package.json existe',
    passed: hasPkg,
    details: hasPkg ? 'package.json localizado na raiz do pacote' : 'package.json não encontrado no ZIP',
  });
  if (!hasPkg) {
    anomalies.push({
      id: 'missing_package_json',
      title: 'package.json ausente',
      description: 'O arquivo essencial package.json não está presente no ZIP.',
      severity: 'error',
    });
  }

  // Check 4: src exists
  const hasSrc = fileList.some(f => f.startsWith('src/'));
  const hasAppTsx = fileList.includes('src/App.tsx');
  checks.push({
    id: 'src_exists',
    label: 'src/ existe',
    passed: hasSrc && hasAppTsx,
    details: hasSrc && hasAppTsx ? 'Diretório src/ íntegro com App.tsx e componentes' : 'Diretório src/ ou src/App.tsx ausente',
  });
  if (!hasSrc || !hasAppTsx) {
    anomalies.push({
      id: 'missing_src',
      title: 'Código-fonte src ausente',
      description: 'Arquivos essenciais de src/ (incluindo App.tsx) não foram encontrados no pacote.',
      severity: 'error',
    });
  }

  // Check 5: public exists
  const hasPublic = fileList.some(f => f.startsWith('public/')) || fileList.includes('index.html');
  checks.push({
    id: 'public_exists',
    label: 'public/ e entrypoint HTML existem',
    passed: hasPublic,
    details: hasPublic ? 'Recursos públicos e index.html validados' : 'Recursos públicos ou index.html ausentes',
  });

  // Check 6: configs exist
  const hasConfigs = fileList.includes('tsconfig.json') && fileList.includes('vite.config.ts');
  checks.push({
    id: 'configs_exist',
    label: 'Configurações do projeto existem (vite, tsconfig)',
    passed: hasConfigs,
    details: hasConfigs ? 'tsconfig.json e vite.config.ts validados' : 'Arquivos de configuração ausentes',
  });

  // Check 7: size greater than zero
  const sizeValid = sizeBytes > 5000;
  checks.push({
    id: 'size_nonzero',
    label: 'Tamanho maior que zero',
    passed: sizeValid,
    details: `${sizeFormatted} (${sizeBytes.toLocaleString('pt-BR')} bytes)`,
  });
  if (!sizeValid) {
    anomalies.push({
      id: 'suspicious_size',
      title: 'Tamanho do ZIP suspeito',
      description: `O tamanho do ZIP (${sizeBytes} bytes) é inferior ao limite mínimo de segurança (5 KB).`,
      severity: 'error',
    });
  }

  // Check 8: minimum files
  const minFilesPassed = fileList.length >= 20;
  checks.push({
    id: 'min_files',
    label: 'Quantidade mínima de arquivos',
    passed: minFilesPassed,
    details: `${fileList.length} arquivos incluídos (mínimo esperado: 20)`,
  });
  if (!minFilesPassed) {
    anomalies.push({
      id: 'low_file_count',
      title: 'Quantidade de arquivos muito baixa',
      description: `O pacote contém apenas ${fileList.length} arquivos, o que pode indicar empacotamento incompleto.`,
      severity: 'error',
    });
  }

  // Check 9: SHA valid
  const shaPassed = calculatedSha.length === 64 && (!expectedSha || calculatedSha.toLowerCase() === expectedSha.toLowerCase());
  checks.push({
    id: 'sha_valid',
    label: 'SHA-256 válido',
    passed: shaPassed,
    details: `SHA-256 verificado: ${calculatedSha.substring(0, 16)}...`,
  });
  if (!shaPassed) {
    anomalies.push({
      id: 'sha_mismatch',
      title: 'SHA-256 divergente ou inválido',
      description: 'O hash criptográfico calculado não corresponde ao hash registrado nos metadados.',
      severity: 'error',
    });
  }

  // Check 10: Nested archives or unwanted directories
  for (const name of fileList) {
    if (name.endsWith('.zip')) {
      anomalies.push({
        id: 'nested_zip',
        title: 'ZIP aninhado detectado',
        description: `O arquivo ZIP contém outro arquivo zip interno indevido: ${name}`,
        severity: 'error',
      });
      break;
    }
    if (name.includes('node_modules/') || name.includes('dist/')) {
      anomalies.push({
        id: 'unwanted_dir',
        title: 'Diretório indevido no ZIP',
        description: `O pacote contém artefatos de build ou dependências: ${name}`,
        severity: 'error',
      });
      break;
    }
  }

  // Check 11: Anomaly - Drop in size by > 50%
  if (previousZipSize > 0 && sizeBytes < previousZipSize * 0.5) {
    const dropPct = (((previousZipSize - sizeBytes) / previousZipSize) * 100).toFixed(1);
    anomalies.push({
      id: 'sharp_size_drop',
      title: 'Queda brusca de tamanho detectada',
      description: `O tamanho do ZIP caiu ${dropPct}% em relação à versão anterior (${formatSize(previousZipSize)} → ${sizeFormatted}).`,
      severity: 'warning',
    });
  }

  const allPassed = checks.every(c => c.passed) && anomalies.filter(a => a.severity === 'error').length === 0;

  return {
    valid: allPassed,
    fileCount: fileList.length,
    sizeBytes,
    sizeFormatted,
    sha256: calculatedSha,
    checks,
    anomalies,
    fileList,
  };
}

/**
 * Returns synchronization status between current source code on disk and current generated ZIP.
 */
export function getProjectSyncStatus() {
  const codeChanged = hasSourceCodeChanged();
  const storedHash = getStoredHash();
  const currentHash = computeSourceCodeHash();

  const pkgPath = path.join(rootDir, 'package.json');
  const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
  const versionNum = parseInt((pkg.version || '1').replace(/^(\d+).*/, '$1'), 10);

  const targetZipPath = path.join(rootDir, 'public', 'versions', `projeto-versao-${versionNum}.zip`);
  const zipExists = fs.existsSync(targetZipPath);

  let zipStat = null;
  let lastZipDateTime = 'Não gerado';
  if (zipExists) {
    zipStat = fs.statSync(targetZipPath);
    lastZipDateTime = getBrazilDateInfo(zipStat.mtime).datetimeStr;
  }

  const infoPath = path.join(rootDir, 'public', 'version-info.json');
  let lastBuildDateTime = lastZipDateTime;
  if (fs.existsSync(infoPath)) {
    try {
      const info = JSON.parse(fs.readFileSync(infoPath, 'utf8'));
      if (info.formattedDateTime) {
        lastBuildDateTime = info.formattedDateTime;
      }
    } catch {}
  }

  const isSynced = !codeChanged && zipExists;

  return {
    syncStatus: isSynced ? 'synced' : 'outdated',
    syncStatusMessage: isSynced ? 'Sincronizado' : 'ZIP desatualizado',
    lastBuildDateTime,
    lastZipDateTime,
    codeChanged,
    zipExists,
    versionNumber: versionNum,
    currentHash,
    storedHash,
  };
}
