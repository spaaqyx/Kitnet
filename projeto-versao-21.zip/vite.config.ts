import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { createRequire } from 'module';
import { defineConfig } from 'vite';
import { viteVersionApiPlugin } from './scripts/vite-version-api.js';

const require = createRequire(import.meta.url);
try {
  const { checkIntegrity } = require('./scripts/ensure-integrity.cjs');
  checkIntegrity();
} catch (e) {
  // Silent fallback
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), viteVersionApiPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
