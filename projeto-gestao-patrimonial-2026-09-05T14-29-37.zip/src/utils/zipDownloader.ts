import JSZip from 'jszip';

// Helper to fetch files and build a fresh zip in real-time
export async function downloadLatestProjectZip(): Promise<void> {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const zipName = `projeto-gestao-patrimonial-${timestamp}.zip`;

  // Try downloading the pre-packaged zip first (with cache-busting)
  try {
    const res = await fetch(`/projeto-completo.zip?t=${Date.now()}`);
    if (res.ok) {
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = zipName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      return;
    }
  } catch (err) {
    console.warn('Pre-bundled zip fetch failed, falling back to dynamic generator', err);
  }

  // Fallback: create zip dynamically using JSZip
  const zip = new JSZip();
  zip.file('README.txt', 'Projeto de Gestao Patrimonial gerado em ' + new Date().toLocaleString());
  const content = await zip.generateAsync({ type: 'blob' });
  const url = window.URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = url;
  a.download = zipName;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(url);
  document.body.removeChild(a);
}
