import os
import zipfile
import sys
import datetime

def make_zip():
    exclude_dirs = {'.git', 'node_modules', 'dist', '.cache', '__pycache__'}
    exclude_files = {'projeto-completo.zip'}
    
    root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    public_dir = os.path.join(root_dir, 'public')
    dist_dir = os.path.join(root_dir, 'dist')
    os.makedirs(public_dir, exist_ok=True)
    
    zip_path_public = os.path.join(public_dir, 'projeto-completo.zip')
    
    with zipfile.ZipFile(zip_path_public, 'w', zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(root_dir):
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            for f in files:
                if f in exclude_files or f.endswith('.pyc'):
                    continue
                full_path = os.path.join(root, f)
                arcname = os.path.relpath(full_path, root_dir)
                z.write(full_path, arcname)
                
    size_kb = round(os.path.getsize(zip_path_public) / 1024, 1)
    print(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] ZIP atualizado automaticamente em public/ ({size_kb} KB)")
    
    if os.path.exists(dist_dir):
        import shutil
        zip_path_dist = os.path.join(dist_dir, 'projeto-completo.zip')
        shutil.copy2(zip_path_public, zip_path_dist)
        print(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] ZIP copiado para dist/ ({size_kb} KB)")

if __name__ == '__main__':
    make_zip()
