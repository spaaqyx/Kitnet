import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const HASH_FILE = path.join(rootDir, '.build-source-hash');

/**
 * Computes deterministic consolidated hash of all relevant source files.
 * Excludes package.json "version" field, build outputs, version archives, and metadata.
 */
export function computeSourceCodeHash() {
  const hash = crypto.createHash('sha256');

  const checkDirs = ['src', 'public', 'scripts'];
  const checkFiles = [
    'package.json',
    'tsconfig.json',
    'vite.config.ts',
    'index.html',
    '.env.example',
    '.gitignore',
    'metadata.json',
  ];

  const excludeDirs = new Set([
    'node_modules',
    'dist',
    '.git',
    '.cache',
    '__pycache__',
    'versions',
    'tmp',
    '.system_generated',
  ]);

  const excludeFilesExact = new Set([
    '.build-source-hash',
    '.project-backup.zip',
    '.version',
    'version.txt',
    'VERSAO_ATUAL.txt',
    'version-info.json',
    'projeto-completo.zip',
    'bun.lock',
    'appVersion.ts',
  ]);

  const allFiles = [];

  function walk(dir) {
    if (!fs.existsSync(dir)) return;
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const ent of entries) {
      const name = ent.name;

      if (ent.isDirectory()) {
        if (excludeDirs.has(name) || name.startsWith('.')) {
          continue;
        }
        walk(path.join(dir, name));
      } else if (ent.isFile()) {
        if (
          name.endsWith('.zip') ||
          name.endsWith('.tmp') ||
          name.endsWith('.pyc') ||
          name.startsWith('.DS_Store') ||
          name.startsWith('projeto-versao-') ||
          excludeFilesExact.has(name)
        ) {
          continue;
        }

        const relPath = path.relative(rootDir, path.join(dir, name)).replace(/\\/g, '/');
        // Extra safeguard: skip anything inside any versions/ directory
        if (relPath.includes('versions/')) {
          continue;
        }
        allFiles.push(relPath);
      }
    }
  }

  for (const dirName of checkDirs) {
    walk(path.join(rootDir, dirName));
  }

  for (const fileName of checkFiles) {
    const fullPath = path.join(rootDir, fileName);
    if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
      allFiles.push(fileName);
    }
  }

  // Deduplicate and sort deterministically
  const uniqueFiles = Array.from(new Set(allFiles)).sort();

  for (const relPath of uniqueFiles) {
    const fullPath = path.join(rootDir, relPath);
    try {
      hash.update(relPath);
      if (relPath === 'package.json') {
        const pkgRaw = fs.readFileSync(fullPath, 'utf8');
        const pkgObj = JSON.parse(pkgRaw);
        // Exclude version from hash to avoid circular invalidation
        const { version, ...normalized } = pkgObj;
        hash.update(JSON.stringify(normalized));
      } else {
        const buf = fs.readFileSync(fullPath);
        hash.update(buf);
      }
    } catch {
      // Ignore transient read errors
    }
  }

  return hash.digest('hex');
}

/**
 * Returns stored hash from .build-source-hash or null if absent.
 */
export function getStoredHash() {
  if (!fs.existsSync(HASH_FILE)) return null;
  try {
    return fs.readFileSync(HASH_FILE, 'utf8').trim();
  } catch {
    return null;
  }
}

/**
 * Saves given hash to .build-source-hash.
 */
export function saveSourceHash(hashValue) {
  fs.writeFileSync(HASH_FILE, hashValue.trim(), 'utf8');
}

/**
 * Checks if current source code has changed compared to .build-source-hash.
 */
export function hasSourceCodeChanged() {
  const stored = getStoredHash();
  if (!stored) return true;
  const current = computeSourceCodeHash();
  return current !== stored;
}
