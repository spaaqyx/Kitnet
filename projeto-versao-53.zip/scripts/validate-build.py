#!/usr/bin/env python3
"""
scripts/validate-build.py
Post-build integrity verifier.
Verifies that:
1. APP_VERSION == ZIP_VERSION == METADATA_VERSION == ZIP_FILENAME_VERSION
2. METADATA_SHA256 == SHA256(real ZIP on disk)
3. METADATA_SIZE == real ZIP file size in bytes
4. ZIP archive is uncorrupted and contains essential files without forbidden artifacts.
5. dist/ distribution mirror contains the exact synchronized assets.
If any check fails, the build exits with failure code 1.
"""

import os
import sys
import json
import re
import hashlib
import zipfile

def compute_file_sha256(filepath: str) -> str:
    h = hashlib.sha256()
    with open(filepath, 'rb') as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()

def main():
    root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    public_dir = os.path.join(root_dir, 'public')
    dist_dir = os.path.join(root_dir, 'dist')

    print(f"\n🔍 [Kitnet Build] Executando Validação de Integridade do ZIP & Build...")

    # 1. Check package.json, version.txt, and .version
    pkg_path = os.path.join(root_dir, 'package.json')
    if not os.path.exists(pkg_path):
        print(f"❌ ERRO: package.json não encontrado!", file=sys.stderr)
        sys.exit(1)

    with open(pkg_path, 'r', encoding='utf-8') as f:
        pkg = json.load(f)
    pkg_version_str = pkg.get('version', '')
    match_pkg = re.match(r'^(\d+)', pkg_version_str)
    if not match_pkg:
        print(f"❌ ERRO: Campo version em package.json é inválido: {pkg_version_str}", file=sys.stderr)
        sys.exit(1)
    app_version_num = int(match_pkg.group(1))

    # Check version.txt if present
    txt_path = os.path.join(root_dir, 'version.txt')
    if os.path.exists(txt_path):
        with open(txt_path, 'r', encoding='utf-8') as f:
            txt_content = f.read()
        txt_match = re.search(r'(?:VERSAO|VERSÃO|VERSION|PROJETO)[\s_:]*(\d+)', txt_content, re.IGNORECASE) or re.search(r'^(\d+)', txt_content, re.MULTILINE)
        if txt_match and int(txt_match.group(1)) != app_version_num:
            print(f"❌ ERRO: Divergência entre version.txt (V{txt_match.group(1)}) e package.json (V{app_version_num})!", file=sys.stderr)
            sys.exit(1)

    # Check .version if present
    dot_ver_path = os.path.join(root_dir, '.version')
    if os.path.exists(dot_ver_path):
        with open(dot_ver_path, 'r', encoding='utf-8') as f:
            dot_ver_str = f.read().strip()
        dot_ver_match = re.search(r'^(\d+)', dot_ver_str)
        if dot_ver_match and int(dot_ver_match.group(1)) != app_version_num:
            print(f"❌ ERRO: Divergência entre .version (V{dot_ver_match.group(1)}) e package.json (V{app_version_num})!", file=sys.stderr)
            sys.exit(1)

    # 2. Check public/version-info.json
    info_path = os.path.join(public_dir, 'version-info.json')
    if not os.path.exists(info_path):
        print(f"❌ ERRO: public/version-info.json não encontrado!", file=sys.stderr)
        sys.exit(1)

    with open(info_path, 'r', encoding='utf-8') as f:
        metadata = json.load(f)

    meta_version_num = metadata.get('versionNumber')
    current_v = metadata.get('currentVersion', {})
    curr_num = current_v.get('num')
    curr_filename = current_v.get('filename')
    curr_download_url = current_v.get('downloadUrl')
    meta_size_bytes = metadata.get('sizeBytes')
    meta_sha256 = metadata.get('sha256')

    # Validate version consistency
    if app_version_num != meta_version_num or app_version_num != curr_num:
        print(f"❌ ERRO: Divergência de versão entre package.json (V{app_version_num}) e version-info.json (V{meta_version_num} / V{curr_num})!", file=sys.stderr)
        sys.exit(1)

    expected_filename = f"projeto-versao-{app_version_num}.zip"
    if curr_filename != expected_filename:
        print(f"❌ ERRO: Nome de arquivo de download inesperado ({curr_filename} != {expected_filename})!", file=sys.stderr)
        sys.exit(1)

    if curr_download_url != f"/versions/{expected_filename}":
        print(f"❌ ERRO: URL de download inesperada ({curr_download_url} != /versions/{expected_filename})!", file=sys.stderr)
        sys.exit(1)

    # 3. Validate ZIP in public/versions/
    public_zip = os.path.join(public_dir, 'versions', expected_filename)
    if not os.path.exists(public_zip):
        print(f"❌ ERRO: Arquivo ZIP não encontrado no caminho: {public_zip}", file=sys.stderr)
        sys.exit(1)

    real_size = os.path.getsize(public_zip)
    if real_size != meta_size_bytes:
        print(f"❌ ERRO: Tamanho do ZIP no disco ({real_size} bytes) difere do metadata ({meta_size_bytes} bytes)!", file=sys.stderr)
        sys.exit(1)

    real_sha256 = compute_file_sha256(public_zip)
    if real_sha256 != meta_sha256:
        print(f"❌ ERRO: SHA-256 do ZIP no disco ({real_sha256}) difere do metadata ({meta_sha256})!", file=sys.stderr)
        sys.exit(1)

    # Validate ZIP structure
    with zipfile.ZipFile(public_zip, 'r') as zf:
        if zf.testzip() is not None:
            print(f"❌ ERRO: Arquivo ZIP corrompido em {public_zip}!", file=sys.stderr)
            sys.exit(1)

        names = set(zf.namelist())

        for name in names:
            if name.endswith('.zip'):
                print(f"❌ ERRO: Arquivo ZIP aninhado dentro do ZIP: {name}", file=sys.stderr)
                sys.exit(1)
            if 'node_modules/' in name or name == 'node_modules' or name.startswith('node_modules/'):
                print(f"❌ ERRO: Diretório node_modules encontrado dentro do ZIP: {name}", file=sys.stderr)
                sys.exit(1)
            if 'dist/' in name or name == 'dist' or name.startswith('dist/'):
                print(f"❌ ERRO: Diretório dist encontrado dentro do ZIP: {name}", file=sys.stderr)
                sys.exit(1)
            if '.git/' in name or name == '.git' or name.startswith('.git/'):
                print(f"❌ ERRO: Diretório .git encontrado dentro do ZIP: {name}", file=sys.stderr)
                sys.exit(1)

        essential = ['src/App.tsx', 'src/main.tsx', 'package.json', 'index.html']
        for ess in essential:
            if ess not in names:
                print(f"❌ ERRO: Arquivo essencial '{ess}' ausente dentro do ZIP!", file=sys.stderr)
                sys.exit(1)

    # 4. Check dist/ synchronization if dist exists
    if os.path.exists(dist_dir):
        dist_zip = os.path.join(dist_dir, 'versions', expected_filename)
        dist_info = os.path.join(dist_dir, 'version-info.json')

        # Ensure dist has the zip and json
        if not os.path.exists(dist_zip):
            import shutil
            os.makedirs(os.path.dirname(dist_zip), exist_ok=True)
            shutil.copy2(public_zip, dist_zip)

        if not os.path.exists(dist_info):
            import shutil
            shutil.copy2(info_path, dist_info)

        dist_size = os.path.getsize(dist_zip)
        dist_sha256 = compute_file_sha256(dist_zip)

        if dist_size != real_size or dist_sha256 != real_sha256:
            print(f"❌ ERRO: Cópia em dist/ não coincide com public/ (dist: {dist_sha256}, public: {real_sha256})!", file=sys.stderr)
            sys.exit(1)

    print(f"✅ Validação de Integridade Concluída com Sucesso:")
    print(f"   ✓ Versão: V{app_version_num} (App == Metadata == ZIP Filename)")
    print(f"   ✓ Arquivo: {expected_filename}")
    formatted_size = f"{real_size:,}".replace(',', '.')
    print(f"   ✓ Tamanho: {formatted_size} (100% conferido)")
    print(f"   ✓ SHA-256: {real_sha256} (100% conferido)")
    print(f"   ✓ Integridade: ZIP testado, sem aninhamento, sem node_modules/dist")
    print(f"   ✓ Arquivos de produção e distribuição 100% sincronizados!\n")

if __name__ == '__main__':
    main()
