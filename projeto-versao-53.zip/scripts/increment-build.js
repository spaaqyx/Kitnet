#!/usr/bin/env node

/**
 * scripts/increment-build.js
 * 
 * The EXCLUSIVE single authority for incrementing the build number.
 * 
 * Rules:
 * 1. Project version is resolved safely via scripts/project-version.js (version.txt, .version, package.json).
 * 2. Runs ONLY after vite build has succeeded (never on failure).
 * 3. Inspects .build-source-hash to detect real code changes.
 * 4. If NO changes detected: maintains current version and skips increment.
 * 5. If changes detected: increments build number by exactly +1.
 * 6. Synchronizes package.json, version.txt, .version, and src/constants/appVersion.ts.
 */

import { hasSourceCodeChanged } from './source-hash.js';
import { getProjectVersion, syncVersionFiles } from './project-version.js';

try {
  const currentBuild = getProjectVersion();

  // Check if source code has actually changed since the last published build
  const force = process.argv.includes('--force') || process.env.FORCE_INCREMENT === '1';
  const changed = force || hasSourceCodeChanged();

  if (!changed) {
    console.log(`\n=======================================================`);
    console.log(`ℹ️ [Build Manager] Nenhuma alteração detectada no código-fonte.`);
    console.log(`   Versão mantida: V${currentBuild}`);
    console.log(`=======================================================\n`);
    process.exit(0);
  }

  const nextBuild = currentBuild + 1;
  syncVersionFiles(nextBuild);

  console.log(`\n=======================================================`);
  console.log(`🚀 [Build Manager] Alteração detectada! Build incrementada com sucesso:`);
  console.log(`   Build anterior: V${currentBuild}`);
  console.log(`   Nova Build:     V${nextBuild}`);
  console.log(`   Arquivos sincronizados: version.txt, .version, package.json, appVersion.ts`);
  console.log(`=======================================================\n`);
} catch (err) {
  console.error(`❌ [Build Manager] Erro ao incrementar versão da build: ${err.message}`);
  process.exit(1);
}
