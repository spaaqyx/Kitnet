/**
 * scripts/vite-version-api.js
 * Vite Plugin providing endpoints for Project Versioning, Audit, Validation, Live Synchronization,
 * and fail-safe ZIP downloading.
 */

import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import {
  auditZipFile,
  getProjectSyncStatus,
  getBrazilDateInfo,
} from './zip-audit-engine.js';
import {
  getProjectVersion,
} from './project-version.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

export function viteVersionApiPlugin() {
  return {
    name: 'vite-version-api-plugin',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        const url = req.url ? req.url.split('?')[0] : '';

        // Handlers para download seguro de arquivos ZIP (evita que o fallback do Vite retorne index.html em 404)
        if (url.startsWith('/versions/') || url === '/projeto-completo.zip') {
          const filename = url === '/projeto-completo.zip' ? 'projeto-completo.zip' : path.basename(url);

          const possiblePaths = [
            path.join(rootDir, 'public', 'versions', filename),
            path.join(rootDir, 'public', filename),
            path.join(rootDir, 'dist', 'versions', filename),
            path.join(rootDir, 'dist', filename),
            path.join(rootDir, filename),
            path.join(rootDir, '.project-backup.zip'),
          ];

          let foundPath = possiblePaths.find((p) => fs.existsSync(p) && fs.statSync(p).size > 100);

          // Se não encontrou o ZIP específico, tenta projeto-completo.zip ou o ZIP da versão atual
          if (!foundPath) {
            const currentVer = getProjectVersion();
            const fallbackPaths = [
              path.join(rootDir, 'public', 'versions', `projeto-versao-${currentVer}.zip`),
              path.join(rootDir, 'public', 'projeto-completo.zip'),
              path.join(rootDir, 'dist', 'projeto-completo.zip'),
              path.join(rootDir, '.project-backup.zip'),
            ];
            foundPath = fallbackPaths.find((p) => fs.existsSync(p) && fs.statSync(p).size > 100);
          }

          if (foundPath) {
            const stat = fs.statSync(foundPath);
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/zip');
            res.setHeader('Content-Length', stat.size);
            res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
            res.setHeader('Cache-Control', 'no-cache');
            if (req.method === 'HEAD') {
              return res.end();
            }
            const stream = fs.createReadStream(foundPath);
            return stream.pipe(res);
          }
        }

        // Only handle /api/version/*
        if (!url.startsWith('/api/version/')) {
          return next();
        }

        // Enable CORS and JSON
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

        if (req.method === 'OPTIONS') {
          res.statusCode = 204;
          return res.end();
        }

        // Route 1: GET /api/version/status
        if (url === '/api/version/status' && req.method === 'GET') {
          try {
            const status = getProjectSyncStatus();
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify(status));
          } catch (err) {
            res.statusCode = 500;
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ error: err.message }));
          }
        }

        // Route 2: POST /api/version/validate-zip
        if (url === '/api/version/validate-zip' && req.method === 'POST') {
          try {
            const versionNum = getProjectVersion();
            let targetZipPath = path.join(rootDir, 'public', 'versions', `projeto-versao-${versionNum}.zip`);

            if (!fs.existsSync(targetZipPath)) {
              const candidatePaths = [
                path.join(rootDir, 'public', 'versions', `projeto-versao-${versionNum}.zip`),
                path.join(rootDir, 'public', 'projeto-completo.zip'),
                path.join(rootDir, 'dist', 'versions', `projeto-versao-${versionNum}.zip`),
                path.join(rootDir, 'dist', 'projeto-completo.zip'),
                path.join(rootDir, '.project-backup.zip'),
              ];
              const found = candidatePaths.find((p) => fs.existsSync(p) && fs.statSync(p).size > 100);
              if (found) {
                targetZipPath = found;
              }
            }

            const infoPath = path.join(rootDir, 'public', 'version-info.json');
            let expectedSha = null;
            let previousZipSize = 0;
            if (fs.existsSync(infoPath)) {
              try {
                const info = JSON.parse(fs.readFileSync(infoPath, 'utf8'));
                expectedSha = info.currentVersion?.sha256 || info.sha256;
                previousZipSize = info.previousVersion?.sizeBytes || 0;
              } catch {}
            }

            const report = await auditZipFile(targetZipPath, expectedSha, previousZipSize);
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ success: true, ...report }));
          } catch (err) {
            res.statusCode = 500;
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ success: false, error: err.message }));
          }
        }

        // Route 3: POST /api/version/audit
        if (url === '/api/version/audit' && req.method === 'POST') {
          res.setHeader('Content-Type', 'text/plain; charset=utf-8');
          res.setHeader('Transfer-Encoding', 'chunked');
          res.setHeader('X-Accel-Buffering', 'no');
          res.setHeader('Cache-Control', 'no-cache, no-transform');

          const startTime = Date.now();
          const { timeStr } = getBrazilDateInfo();
          res.write(`[${timeStr}] 🔍 Iniciando auditoria do projeto...\n`);
          if (typeof res.flush === 'function') res.flush();

          const child = spawn('node', ['scripts/audit-project.js', '--fast'], {
            cwd: rootDir,
          });

          child.stdout.on('data', (data) => {
            const lines = data.toString().split('\n').filter(Boolean);
            for (const line of lines) {
              res.write(`[${getBrazilDateInfo().timeStr}] ${line}\n`);
              if (typeof res.flush === 'function') res.flush();
            }
          });

          child.stderr.on('data', (data) => {
            const lines = data.toString().split('\n').filter(Boolean);
            for (const line of lines) {
              res.write(`[${getBrazilDateInfo().timeStr}] ⚠️ ${line}\n`);
              if (typeof res.flush === 'function') res.flush();
            }
          });

          child.on('close', (code) => {
            const duration = ((Date.now() - startTime) / 1000).toFixed(1);
            if (code === 0) {
              res.write(`[${getBrazilDateInfo().timeStr}] ✅ Auditoria concluída com sucesso em ${duration}s!\n`);
            } else {
              res.write(`[${getBrazilDateInfo().timeStr}] ❌ Auditoria encerrada com avisos/código ${code}.\n`);
            }
            res.end();
          });
          return;
        }

        // Route 4: POST /api/version/generate-zip
        if (url === '/api/version/generate-zip' && req.method === 'POST') {
          res.setHeader('Content-Type', 'text/plain; charset=utf-8');
          res.setHeader('Transfer-Encoding', 'chunked');
          res.setHeader('X-Accel-Buffering', 'no');
          res.setHeader('Cache-Control', 'no-cache, no-transform');

          const startTime = Date.now();
          const { timeStr } = getBrazilDateInfo();
          res.write(`[${timeStr}] 📦 Iniciando geração de novo ZIP...\n`);
          if (typeof res.flush === 'function') res.flush();

          const child = spawn('node', ['scripts/generate-source-zip.js', '--force'], {
            cwd: rootDir,
            env: { ...process.env, FORCE_GENERATE_ZIP: 'true' },
          });

          child.stdout.on('data', (data) => {
            const lines = data.toString().split('\n').filter(Boolean);
            for (const line of lines) {
              res.write(`[${getBrazilDateInfo().timeStr}] ${line}\n`);
              if (typeof res.flush === 'function') res.flush();
            }
          });

          child.stderr.on('data', (data) => {
            const lines = data.toString().split('\n').filter(Boolean);
            for (const line of lines) {
              res.write(`[${getBrazilDateInfo().timeStr}] ⚠️ ${line}\n`);
              if (typeof res.flush === 'function') res.flush();
            }
          });

          child.on('close', (code) => {
            const duration = ((Date.now() - startTime) / 1000).toFixed(1);
            if (code === 0) {
              res.write(`[${getBrazilDateInfo().timeStr}] ✅ Novo ZIP gerado com sucesso em ${duration}s!\n`);
            } else {
              res.write(`[${getBrazilDateInfo().timeStr}] ❌ Geração encerrada com código de erro ${code}.\n`);
            }
            res.end();
          });
          return;
        }

        // Route 5: POST /api/version/sync (12-Step Full Pipeline)
        if (url === '/api/version/sync' && req.method === 'POST') {
          res.setHeader('Content-Type', 'text/plain; charset=utf-8');
          res.setHeader('Transfer-Encoding', 'chunked');
          res.setHeader('X-Accel-Buffering', 'no');
          res.setHeader('Cache-Control', 'no-cache, no-transform');

          const startTime = Date.now();
          const { timeStr } = getBrazilDateInfo();
          res.write(`[${timeStr}] 🚀 Iniciando sincronização completa da Central de Versionamento...\n`);
          if (typeof res.flush === 'function') res.flush();

          const child = spawn('node', ['scripts/pipeline.js'], {
            cwd: rootDir,
            env: { ...process.env, FORCE_GENERATE_ZIP: 'true' },
          });

          child.stdout.on('data', (data) => {
            const lines = data.toString().split('\n').filter(Boolean);
            for (const line of lines) {
              res.write(`[${getBrazilDateInfo().timeStr}] ${line}\n`);
              if (typeof res.flush === 'function') res.flush();
            }
          });

          child.stderr.on('data', (data) => {
            const lines = data.toString().split('\n').filter(Boolean);
            for (const line of lines) {
              res.write(`[${getBrazilDateInfo().timeStr}] ⚠️ ${line}\n`);
              if (typeof res.flush === 'function') res.flush();
            }
          });

          child.on('close', (code) => {
            const duration = ((Date.now() - startTime) / 1000).toFixed(1);
            if (code === 0) {
              res.write(`[${getBrazilDateInfo().timeStr}] ✅ Sincronização concluída com sucesso em ${duration}s!\n`);
              res.write(`[${getBrazilDateInfo().timeStr}] Status do projeto: Sincronizado\n`);
            } else {
              res.write(`[${getBrazilDateInfo().timeStr}] ❌ Falha na sincronização (código ${code}).\n`);
            }
            res.end();
          });
          return;
        }

        // Route 6: GET or HEAD /api/version/download-latest
        if (url === '/api/version/download-latest' && (req.method === 'GET' || req.method === 'HEAD')) {
          const currentVer = getProjectVersion();
          const targetFilename = `projeto-versao-${currentVer}.zip`;
          const candidatePaths = [
            path.join(rootDir, 'public', 'versions', targetFilename),
            path.join(rootDir, 'public', 'projeto-completo.zip'),
            path.join(rootDir, 'dist', 'versions', targetFilename),
            path.join(rootDir, 'dist', 'projeto-completo.zip'),
            path.join(rootDir, '.project-backup.zip'),
          ];

          const foundPath = candidatePaths.find((p) => fs.existsSync(p) && fs.statSync(p).size > 100);
          if (foundPath) {
            const stat = fs.statSync(foundPath);
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/zip');
            res.setHeader('Content-Length', stat.size);
            res.setHeader('Content-Disposition', `attachment; filename="${targetFilename}"`);
            if (req.method === 'HEAD') {
              return res.end();
            }
            const stream = fs.createReadStream(foundPath);
            return stream.pipe(res);
          }

          res.statusCode = 404;
          res.setHeader('Content-Type', 'application/json');
          return res.end(JSON.stringify({ error: 'Arquivo ZIP ainda não gerado. Execute a sincronização.' }));
        }

        return next();
      });
    },
  };
}
