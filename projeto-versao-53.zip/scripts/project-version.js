/**
 * scripts/project-version.js
 * 
 * Autoridade Central para Resolução e Sincronização da Versão do Projeto.
 * Garante que a versão seja preservada entre exportações, builds e sincronizações.
 * 
 * Lê de forma resiliente de:
 * 1. version.txt (arquivo legível na raiz do projeto)
 * 2. .version (arquivo de controle)
 * 3. package.json ("version": "X.0.0")
 * 4. Piso mínimo: 43 (conforme especificado pelo usuário)
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

const MINIMUM_PROJECT_VERSION = 44;
const BRAZIL_TIMEZONE = 'America/Sao_Paulo';

export function getBrazilFormattedDates(dateObj = new Date()) {
  const formatter = new Intl.DateTimeFormat('pt-BR', {
    timeZone: BRAZIL_TIMEZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });

  const parts = formatter.formatToParts(dateObj);
  const partMap = {};
  for (const p of parts) partMap[p.type] = p.value;

  const dateStr = `${partMap.day}/${partMap.month}/${partMap.year}`;
  const timeStr = `${partMap.hour}:${partMap.minute}:${partMap.second}`;
  const datetimeStr = `${dateStr} às ${timeStr}`;
  const isoStr = dateObj.toISOString();

  return { dateStr, timeStr, datetimeStr, isoStr };
}

/**
 * Lê o número de versão de version.txt se existir.
 */
function readVersionFromTxt() {
  const txtPath = path.join(rootDir, 'version.txt');
  if (!fs.existsSync(txtPath)) return null;
  try {
    const content = fs.readFileSync(txtPath, 'utf8');
    const match = content.match(/(?:VERSAO|VERSÃO|VERSION|PROJETO)[\s_:]*(\d+)/i) || content.match(/^(\d+)/m);
    if (match) return parseInt(match[1], 10);
  } catch {}
  return null;
}

/**
 * Lê o número de versão de .version se existir.
 */
function readVersionFromDotVersion() {
  const dotPath = path.join(rootDir, '.version');
  if (!fs.existsSync(dotPath)) return null;
  try {
    const content = fs.readFileSync(dotPath, 'utf8').trim();
    const match = content.match(/^(\d+)/);
    if (match) return parseInt(match[1], 10);
  } catch {}
  return null;
}

/**
 * Lê o número de versão de package.json se existir.
 */
function readVersionFromPackageJson() {
  const pkgPath = path.join(rootDir, 'package.json');
  if (!fs.existsSync(pkgPath)) return null;
  try {
    const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
    const match = (pkg.version || '').match(/^(\d+)/);
    if (match) return parseInt(match[1], 10);
  } catch {}
  return null;
}

/**
 * Retorna a versão real do projeto, calculada como o máximo entre todas as fontes
 * e com piso mínimo garantido em 43.
 * Sincroniza automaticamente todos os arquivos se algum estiver desatualizado ou faltando.
 */
export function getProjectVersion() {
  const txtVer = readVersionFromTxt();
  const dotVer = readVersionFromDotVersion();
  const pkgVer = readVersionFromPackageJson();

  const candidates = [txtVer, dotVer, pkgVer, MINIMUM_PROJECT_VERSION].filter(
    (v) => typeof v === 'number' && !isNaN(v) && v > 0
  );

  const highestVersion = candidates.length > 0 ? Math.max(...candidates) : MINIMUM_PROJECT_VERSION;

  // Se algum arquivo estiver ausente ou com versão inferior, sincroniza
  if (txtVer !== highestVersion || dotVer !== highestVersion || pkgVer !== highestVersion) {
    syncVersionFiles(highestVersion);
  }

  return highestVersion;
}

/**
 * Sincroniza version.txt, .version, package.json e appVersion.ts para a versão especificada.
 */
export function syncVersionFiles(versionNumber, buildId = null) {
  const { dateStr, datetimeStr, timeStr } = getBrazilFormattedDates();
  const resolvedBuildId = buildId || `BUILD-V${versionNumber}-${Date.now().toString(36).toUpperCase()}`;

  // 1. Grava version.txt e VERSAO_ATUAL.txt na raiz e mirrors
  try {
    const versionTxtContent = `=======================================================
SISTEMA: Gestão de Motos & Kitnets
VERSÃO ATUAL DO PROJETO: ${versionNumber}
VERSAO_NUMERO: ${versionNumber}
BUILD_ID: ${resolvedBuildId}
ARQUIVO_DOWNLOAD: projeto-versao-${versionNumber}.zip
DATA_ATUALIZACAO: ${datetimeStr}
HORA_BRASILIA: ${timeStr}
STATUS: Sincronizado e validado
=======================================================
`;
    fs.writeFileSync(path.join(rootDir, 'version.txt'), versionTxtContent, 'utf8');

    const versaoAtualTxtContent = `======================================================================
  CENTRAL DE VERSIONAMENTO - GESTÃO DE MOTOS & KITNETS
======================================================================

📌 IDENTIFICAÇÃO DO PROJETO:
   - PROJETO NÚMERO: ${versionNumber}
   - VERSÃO OFICIAL: Versão ${versionNumber}
   - BUILD IDENTIFIER: ${resolvedBuildId}
   - PACOTE ZIP OFICIAL: projeto-versao-${versionNumber}.zip
   - ÚLTIMA ATUALIZAÇÃO: ${datetimeStr} (Horário de Brasília)

📋 COMO EXECUTAR O PROJETO DO ZERO:
   1. Descompacte o arquivo 'projeto-versao-${versionNumber}.zip'
   2. Certifique-se de ter o Node.js v18+ instalado
   3. Execute no terminal:
        npm install
   4. Para iniciar o servidor de desenvolvimento:
        npm run dev
   5. Para validar, compilar e sincronizar todos os scripts:
        npm run sync

🚀 SCRIPTS DISPONÍVEIS:
   - npm run dev         -> Inicia o servidor Vite na porta 3000
   - npm run build       -> Gera a compilação de produção em dist/
   - npm run sync        -> Pipeline automatizada completa de 12 passos
   - npm run test        -> Executa suíte de testes automatizados
   - npm run lint        -> Valida tipagem estática e linter TypeScript
   - npm run audit       -> Auditoria de código, imports e arquivos órfãos
   - npm run package-zip -> Empacota o código-fonte atualizado em ZIP

✅ STATUS DE VALIDAÇÃO:
   - Integridade: 100% Validada
   - Compilação: 0 Erros
   - Sincronização: 100% Sincronizado com a Central de Download
======================================================================
`;
    fs.writeFileSync(path.join(rootDir, 'VERSAO_ATUAL.txt'), versaoAtualTxtContent, 'utf8');

    // Sincroniza espelhos em public/ e dist/
    const publicDir = path.join(rootDir, 'public');
    if (fs.existsSync(publicDir)) {
      fs.writeFileSync(path.join(publicDir, 'version.txt'), versionTxtContent, 'utf8');
      fs.writeFileSync(path.join(publicDir, 'VERSAO_ATUAL.txt'), versaoAtualTxtContent, 'utf8');
    }

    const distDir = path.join(rootDir, 'dist');
    if (fs.existsSync(distDir)) {
      fs.writeFileSync(path.join(distDir, 'version.txt'), versionTxtContent, 'utf8');
      fs.writeFileSync(path.join(distDir, 'VERSAO_ATUAL.txt'), versaoAtualTxtContent, 'utf8');
    }
  } catch (err) {
    console.warn(`[project-version] Aviso ao escrever version.txt / VERSAO_ATUAL.txt: ${err.message}`);
  }

  // 2. Grava .version
  try {
    fs.writeFileSync(path.join(rootDir, '.version'), String(versionNumber), 'utf8');
  } catch (err) {
    console.warn(`[project-version] Aviso ao escrever .version: ${err.message}`);
  }

  // 3. Atualiza package.json
  const pkgPath = path.join(rootDir, 'package.json');
  if (fs.existsSync(pkgPath)) {
    try {
      const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
      const targetPkgVersion = `${versionNumber}.0.0`;
      if (pkg.version !== targetPkgVersion) {
        pkg.version = targetPkgVersion;
        fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n', 'utf8');
      }
    } catch (err) {
      console.warn(`[project-version] Aviso ao atualizar package.json: ${err.message}`);
    }
  }

  // 4. Atualiza src/constants/appVersion.ts
  const appVersionTsPath = path.join(rootDir, 'src', 'constants', 'appVersion.ts');
  try {
    const appVersionContent = `/**
 * src/constants/appVersion.ts
 * 
 * Fonte Única da Verdade para a versão e build da aplicação no cliente.
 * Atualizado automaticamente pelo sistema de build (scripts/generate-source-zip.js e scripts/project-version.js).
 * NUNCA utilize números fixos mágicos como fallback no código.
 */

export const CURRENT_APP_VERSION_NUMBER = ${versionNumber};
export const CURRENT_APP_VERSION_STRING = 'Versão ${versionNumber}';
export const CURRENT_APP_BUILD_ID = '${resolvedBuildId}';
export const CURRENT_APP_ZIP_FILENAME = 'projeto-versao-${versionNumber}.zip';
export const CURRENT_APP_ZIP_URL = '/versions/projeto-versao-${versionNumber}.zip';
export const CURRENT_APP_GENERIC_ZIP_URL = '/projeto-completo.zip';

export const CURRENT_APP_BUILD_DATE = '${dateStr}';
export const CURRENT_APP_BUILD_DATETIME = '${datetimeStr}';
`;
    fs.writeFileSync(appVersionTsPath, appVersionContent, 'utf8');
  } catch (err) {
    console.warn(`[project-version] Aviso ao atualizar appVersion.ts: ${err.message}`);
  }
}

/**
 * Incrementa a versão do projeto em +1 e sincroniza todos os arquivos.
 */
export function incrementProjectVersion(buildId = null) {
  const current = getProjectVersion();
  const next = current + 1;
  syncVersionFiles(next, buildId);
  return next;
}

