const CACHE_NAME = 'gp-patrimonial-v4';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon.svg',
];

// Install Event: pre-cache shell assets WITHOUT skipping waiting automatically.
// The new service worker MUST wait in 'waiting' state until user explicitly confirms update.
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS).catch((err) => {
        console.warn('[SW] Pre-caching non-fatal warning:', err);
      });
    })
    // CRITICAL FIX: Do NOT call self.skipWaiting() here.
    // Automatic skipWaiting inside install forces controllerchange on open clients, causing reload loops.
  );
});

// Activate Event: clean up legacy caches and claim clients once activated
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => {
            console.info('[SW] Removing outdated cache:', name);
            return caches.delete(name);
          })
      );
    }).then(() => self.clients.claim())
  );
});

// Listen for custom messages - skipWaiting ONLY runs when the user explicitly triggers applyUpdate
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    console.info('[SW] Received explicit SKIP_WAITING signal from UI update prompt.');
    self.skipWaiting();
  }
});

// Fetch Event: Network-First with Cache Fallback for navigation, Stale-While-Revalidate for assets
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = request.url;

  // 1. Completely bypass non-GET requests and non-HTTP schemes
  if (request.method !== 'GET' || !url.startsWith('http')) {
    return;
  }

  // 2. NEVER intercept or cache APIs, version control, ZIPs, or development assets
  if (
    url.includes('/api/') ||
    url.includes('/version.txt') ||
    url.includes('version.txt') ||
    url.includes('VERSAO_ATUAL.txt') ||
    url.includes('version-info.json') ||
    url.includes('.version') ||
    url.includes('.build-source-hash') ||
    url.includes('.zip') ||
    url.includes('/versions/') ||
    url.includes('projeto-completo.zip') ||
    url.includes('/src/') ||
    url.includes('/@vite/') ||
    url.includes('/@fs/') ||
    url.includes('/@id/') ||
    url.includes('node_modules') ||
    url.includes('hot-update') ||
    url.includes('accounts.google.com')
  ) {
    return;
  }

  // 3. Handle SPA Navigation requests (Network-first with cached index.html fallback)
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const contentType = networkResponse.headers.get('content-type') || '';
            if (contentType.includes('text/html')) {
              const responseClone = networkResponse.clone();
              caches.open(CACHE_NAME).then((cache) => {
                cache.put(request, responseClone);
              });
            }
          }
          return networkResponse;
        })
        .catch(async () => {
          const cachedResponse = await caches.match(request);
          if (cachedResponse) return cachedResponse;
          const fallbackIndex = await caches.match('/index.html') || await caches.match('/');
          if (fallbackIndex) return fallbackIndex;
          return new Response(
            '<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Offline - Gestão Patrimonial</title></head><body style="background:#121214;color:#f2f1ed;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center;padding:20px;"><div><h2 style="margin-bottom:8px;">Você está offline</h2><p style="color:#a1a1aa;margin-bottom:20px;">O aplicativo continua funcionando localmente. Reconecte-se para sincronizar.</p><button onclick="if(navigator.onLine){window.location.reload();}else{alert(\'Ainda sem conexão à internet.\');}" style="background:#8b5cf6;color:#ffffff;font-weight:bold;padding:12px 24px;border:none;border-radius:12px;cursor:pointer;">Tentar Novamente</button></div></body></html>',
            { headers: { 'Content-Type': 'text/html; charset=utf-8' } }
          );
        })
    );
    return;
  }

  // 4. Handle static assets (Stale-While-Revalidate with status 200 validation)
  event.respondWith(
    caches.match(request).then((cachedResponse) => {
      const fetchPromise = fetch(request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const responseClone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(request, responseClone);
            });
          }
          return networkResponse;
        })
        .catch(() => {
          return cachedResponse;
        });

      return cachedResponse || fetchPromise;
    })
  );
});
