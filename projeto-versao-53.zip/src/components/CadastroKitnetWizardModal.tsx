import React, { useEffect } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Home,
  User,
  FileCheck,
  Calendar,
  DollarSign,
  CreditCard,
  FileText,
  ChevronRight,
  ChevronLeft,
  Check,
  AlertCircle,
} from 'lucide-react';
import { Kitnet, KitnetContract, KitnetTenant } from '../types';
import { useApp } from '../context/AppContext';
import { useBodyScrollLock } from '../hooks/useBodyScrollLock';
import { KitnetStepProperty } from './kitnets/wizard/KitnetStepProperty';
import { KitnetStepTenant } from './kitnets/wizard/KitnetStepTenant';
import { KitnetStepIncome } from './kitnets/wizard/KitnetStepIncome';
import { KitnetStepContractTerms } from './kitnets/wizard/KitnetStepContractTerms';
import { KitnetStepFinancials } from './kitnets/wizard/KitnetStepFinancials';
import { KitnetStepPayment } from './kitnets/wizard/KitnetStepPayment';
import { KitnetStepReviewContract } from './kitnets/wizard/KitnetStepReviewContract';
import { useKitnetWizard } from './kitnets/wizard/useKitnetWizard';

interface CadastroKitnetWizardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (
    kitnetId: string,
    contractDetails?: { kitnet: Kitnet; tenant: KitnetTenant; contract: KitnetContract }
  ) => void;
}

export const CadastroKitnetWizardModal: React.FC<CadastroKitnetWizardModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  useBodyScrollLock(isOpen);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);
  const { settings } = useApp();

  const {
    currentStep,
    setCurrentStep,
    copiedContract,
    contractTab,
    setContractTab,
    kitnetData,
    setKitnetData,
    tenantMode,
    setTenantMode,
    selectedTenantId,
    setSelectedTenantId,
    tenantData,
    setTenantData,
    incomeType,
    setIncomeType,
    incomeDetails,
    setIncomeDetails,
    documentsFiles,
    contractTerms,
    setContractTerms,
    financials,
    setFinancials,
    paymentConfig,
    setPaymentConfig,
    totalMonthly,
    handleTenantPhotoUpload,
    handleDocUpload,
    handleRemoveDoc,
    handleNext,
    handlePrev,
    getContractPayload,
    handleGenerateContract,
    handlePrintContract,
    handleCopyContractText,
    handleFinalSubmit,
    kitnetTenants,
    isAlugada,
    stepError,
    setStepError,
  } = useKitnetWizard({ isOpen, onSuccess, onClose });

  if (typeof document === 'undefined') return null;

  const steps = [
    { num: 1, label: 'Imóvel', icon: Home },
    { num: 2, label: 'Inquilino', icon: User },
    { num: 3, label: 'Renda & Docs', icon: FileCheck },
    { num: 4, label: 'Contrato', icon: Calendar },
    { num: 5, label: 'Valores', icon: DollarSign },
    { num: 6, label: 'Pagamento', icon: CreditCard },
    { num: 7, label: 'Emitir Contrato', icon: FileText },
  ];

  const stepperRef = React.useRef<HTMLDivElement>(null);
  const stepButtonRefs = React.useRef<{ [key: number]: HTMLButtonElement | null }>({});

  // Auto-scroll fluido para a aba ativa sempre que avançar ou trocar de etapa
  React.useEffect(() => {
    if (isAlugada && stepButtonRefs.current[currentStep]) {
      stepButtonRefs.current[currentStep]?.scrollIntoView({
        behavior: 'smooth',
        inline: 'center',
        block: 'nearest',
      });
    }
  }, [currentStep, isAlugada]);

  return createPortal(
    <AnimatePresence>
      {isOpen && (
        <motion.div
          key="cadastro-kitnet-root"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.18 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-2 sm:p-4 overflow-y-auto overflow-x-hidden font-sans touch-pan-y w-full max-w-full"
          style={{ overflowX: 'hidden', touchAction: 'pan-y' }}
          role="dialog"
          aria-modal="true"
          aria-label="Cadastro de Kitnet"
        >
          {/* Backdrop */}
          <motion.div
            key="wizard-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
            onClick={onClose}
          />

          {/* Dialog Container */}
          <motion.div
            key="wizard-card"
            initial={{ opacity: 0, scale: 0.95, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 12 }}
            transition={{ type: 'spring', damping: 28, stiffness: 350 }}
            className="relative bg-[#0B0D13] border border-white/[0.12] rounded-2xl sm:rounded-3xl w-full max-w-4xl max-h-[92vh] sm:max-h-[88vh] shadow-2xl shadow-black/80 overflow-hidden flex flex-col my-auto min-w-0 z-10"
            onClick={(e) => e.stopPropagation()}
          >
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-white/[0.08] flex items-center justify-between bg-[#0E111A]/90 backdrop-blur-sm shrink-0 gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div
              className={`w-9 h-9 sm:w-10 sm:h-10 rounded-2xl border flex items-center justify-center shrink-0 transition-colors ${
                isAlugada
                  ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400'
                  : kitnetData.status === 'reforma'
                  ? 'bg-amber-500/15 border-amber-500/30 text-amber-400'
                  : 'bg-sky-500/15 border-sky-500/30 text-sky-400'
              }`}
            >
              <Home className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-sm sm:text-base md:text-lg font-bold text-white truncate">
                  Cadastro de Kitnet & Locação
                </h2>
                <span
                  className={`text-[10px] sm:text-xs px-2.5 py-0.5 rounded-full font-semibold border shrink-0 transition-colors ${
                    isAlugada
                      ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                      : kitnetData.status === 'reforma'
                      ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                      : 'bg-sky-500/15 text-sky-300 border-sky-500/30'
                  }`}
                >
                  {isAlugada ? `Passo ${currentStep} de 7` : 'Etapa Única'}
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block truncate">
                {isAlugada
                  ? 'Cadastre a kitnet, vincule o inquilino, configure valores, primeiro pagamento e emita o contrato.'
                  : 'Cadastre a kitnet e defina seu status operacional.'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/[0.08] border border-transparent hover:border-white/[0.10] transition-all cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Wizard Step Stepper - Only needed when status is alugada */}
        {isAlugada && (
          <div className="relative bg-[#090B10] border-b border-white/[0.08] px-3 sm:px-5 py-2.5 shrink-0 overflow-hidden">
            {/* Soft fade masks on left and right for seamless scroll indication */}
            <div className="pointer-events-none absolute left-0 top-0 bottom-0 w-6 bg-gradient-to-r from-[#090B10] to-transparent z-10" />
            <div className="pointer-events-none absolute right-0 top-0 bottom-0 w-6 bg-gradient-to-l from-[#090B10] to-transparent z-10" />

            <div
              ref={stepperRef}
              className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto scrollbar-none scroll-smooth py-0.5 px-2"
              style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
            >
              {steps.map((s, idx) => {
                const Icon = s.icon;
                const isCompleted = currentStep > s.num;
                const isCurrent = currentStep === s.num;
                return (
                  <React.Fragment key={s.num}>
                    <motion.button
                      ref={(el) => {
                        stepButtonRefs.current[s.num] = el;
                      }}
                      type="button"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => {
                        setStepError(null);
                        setCurrentStep(s.num);
                      }}
                      className={`group relative flex items-center gap-2 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 whitespace-nowrap border ${
                        isCurrent
                          ? 'bg-gradient-to-r from-emerald-500/20 via-emerald-500/15 to-teal-500/20 text-emerald-300 border-emerald-500/60 shadow-lg shadow-emerald-500/15 ring-1 ring-emerald-400/30'
                          : isCompleted
                          ? 'bg-emerald-500/[0.08] text-emerald-400/90 border-emerald-500/30 hover:bg-emerald-500/[0.14] hover:border-emerald-500/50'
                          : 'bg-[#0E111A]/80 text-slate-400 border-white/[0.06] hover:text-slate-200 hover:border-white/[0.16] hover:bg-white/[0.04]'
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 transition-colors ${
                          isCurrent
                            ? 'bg-emerald-500 text-slate-950 shadow-sm shadow-emerald-500/50'
                            : isCompleted
                            ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-500/40'
                            : 'bg-white/[0.08] text-slate-400 group-hover:text-slate-300'
                        }`}
                      >
                        {isCompleted ? <Check className="w-3 h-3 stroke-[3]" /> : s.num}
                      </div>
                      <Icon
                        className={`w-3.5 h-3.5 shrink-0 transition-colors ${
                          isCurrent
                            ? 'text-emerald-300'
                            : isCompleted
                            ? 'text-emerald-400/80'
                            : 'text-slate-400'
                        }`}
                      />
                      <span className="tracking-tight">{s.label}</span>
                    </motion.button>
                    {idx < steps.length - 1 && (
                      <ChevronRight
                        className={`w-3.5 h-3.5 shrink-0 mx-0.5 transition-colors ${
                          currentStep > s.num ? 'text-emerald-500/60' : 'text-white/[0.15]'
                        }`}
                      />
                    )}
                  </React.Fragment>
                );
              })}
            </div>
          </div>
        )}

        {/* FEEDBACK DE ERRO */}
        {stepError && (
          <div className="mx-4 sm:mx-6 mt-4 p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl flex items-center gap-2.5 text-xs text-rose-300 animate-shake shrink-0">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{stepError}</span>
          </div>
        )}

        {/* Wizard Step Content Body */}
        <div
          className="p-4 sm:p-6 overflow-y-auto overflow-x-hidden flex-1 space-y-6 overscroll-contain modal-scroll-container pb-8 w-full max-w-full"
          style={{ WebkitOverflowScrolling: 'touch', touchAction: 'pan-y', overflowX: 'hidden' }}
        >
          {currentStep === 1 && (
            <KitnetStepProperty kitnetData={kitnetData} setKitnetData={setKitnetData} />
          )}

          {currentStep === 2 && isAlugada && (
            <KitnetStepTenant
              tenantMode={tenantMode}
              setTenantMode={setTenantMode}
              selectedTenantId={selectedTenantId}
              setSelectedTenantId={setSelectedTenantId}
              tenantData={tenantData}
              setTenantData={setTenantData}
              kitnetTenants={kitnetTenants}
              handleTenantPhotoUpload={handleTenantPhotoUpload}
              onRemovePhoto={() => setTenantData((prev) => ({ ...prev, photoUrl: '' }))}
            />
          )}

          {currentStep === 3 && isAlugada && (
            <KitnetStepIncome
              incomeType={incomeType}
              setIncomeType={setIncomeType}
              incomeDetails={incomeDetails}
              setIncomeDetails={setIncomeDetails}
              documentsFiles={documentsFiles}
              handleDocUpload={handleDocUpload}
              handleRemoveDoc={handleRemoveDoc}
            />
          )}

          {currentStep === 4 && isAlugada && (
            <KitnetStepContractTerms
              contractTerms={contractTerms}
              setContractTerms={setContractTerms}
            />
          )}

          {currentStep === 5 && isAlugada && (
            <KitnetStepFinancials
              financials={financials}
              setFinancials={setFinancials}
              totalMonthly={totalMonthly}
            />
          )}

          {currentStep === 6 && isAlugada && (
            <KitnetStepPayment
              paymentConfig={paymentConfig}
              setPaymentConfig={setPaymentConfig}
              contractTerms={contractTerms}
              financials={financials}
              totalMonthly={totalMonthly}
            />
          )}

          {currentStep === 7 && isAlugada && (
            <KitnetStepReviewContract
              settings={settings}
              kitnetData={kitnetData}
              tenantMode={tenantMode}
              tenantData={tenantData}
              selectedTenantId={selectedTenantId}
              kitnetTenants={kitnetTenants}
              financials={financials}
              contractTerms={contractTerms}
              paymentConfig={paymentConfig}
              contractTab={contractTab}
              setContractTab={setContractTab}
              copiedContract={copiedContract}
              handleCopyContractText={handleCopyContractText}
              handlePrintContract={handlePrintContract}
              handleGenerateContract={handleGenerateContract}
              getContractPayload={getContractPayload}
            />
          )}
        </div>

        {/* Wizard Footer Controls */}
        <div className="p-4 sm:p-5 border-t border-white/[0.08] bg-[#0E111A]/90 flex items-center justify-between gap-3 shrink-0">
          <div>
            {isAlugada && currentStep > 1 && (
              <button
                type="button"
                onClick={handlePrev}
                className="px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold text-slate-300 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Voltar</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              Cancelar
            </button>

            {/* SE NÃO FOR ALUGADA OU SE JÁ ESTIVER NA ÚLTIMA ETAPA (7) -> SALVAR */}
            {!isAlugada || currentStep === 7 ? (
              <button
                type="button"
                onClick={() => handleFinalSubmit(isAlugada)}
                className={`px-4 sm:px-6 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-slate-950 flex items-center gap-2 shadow-lg transition-all cursor-pointer active:scale-95 ${
                  kitnetData.status === 'alugada'
                    ? 'bg-emerald-500 hover:bg-emerald-400 shadow-emerald-500/25 ring-1 ring-emerald-400/40'
                    : kitnetData.status === 'reforma'
                    ? 'bg-amber-500 hover:bg-amber-400 shadow-amber-500/25 ring-1 ring-amber-400/40'
                    : 'bg-sky-500 hover:bg-sky-400 shadow-sky-500/25 ring-1 ring-sky-400/40'
                }`}
              >
                <Check className="w-4 h-4 stroke-[2.5] shrink-0" />
                <span className="whitespace-nowrap">
                  {isAlugada ? (
                    <>
                      <span className="hidden sm:inline">Concluir Locação e Gerar Contrato</span>
                      <span className="sm:hidden">Concluir Locação</span>
                    </>
                  ) : kitnetData.status === 'reforma' ? (
                    'Salvar em Reforma'
                  ) : (
                    'Salvar Kitnet Disponível'
                  )}
                </span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleNext}
                className="px-4 sm:px-6 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-slate-950 bg-emerald-500 hover:bg-emerald-400 flex items-center gap-2 shadow-lg shadow-emerald-500/25 ring-1 ring-emerald-400/40 transition-all cursor-pointer active:scale-95 hover:brightness-110"
              >
                <span className="whitespace-nowrap">
                  {currentStep === 1 ? (
                    <>
                      <span className="hidden sm:inline">Avançar para Inquilino</span>
                      <span className="sm:hidden">Avançar</span>
                    </>
                  ) : (
                    'Avançar'
                  )}
                </span>
                <ChevronRight className="w-4 h-4 shrink-0" />
              </button>
            )}
          </div>
        </div>
      </motion.div>
    </motion.div>
  )}
</AnimatePresence>,
document.body
);
};
