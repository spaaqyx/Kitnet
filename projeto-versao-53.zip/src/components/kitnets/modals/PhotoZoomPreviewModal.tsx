import React from 'react';
import { PhotoZoomModal } from '../../ui/PhotoZoomModal';

interface PhotoZoomPreviewModalProps {
  photoPreview: { url: string; title: string } | null;
  onClose: () => void;
}

export const PhotoZoomPreviewModal: React.FC<PhotoZoomPreviewModalProps> = ({
  photoPreview,
  onClose,
}) => {
  return <PhotoZoomModal photoPreview={photoPreview} onClose={onClose} />;
};
