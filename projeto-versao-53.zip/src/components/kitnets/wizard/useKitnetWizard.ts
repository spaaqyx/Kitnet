import React, { useState, useEffect } from 'react';
import { useApp } from '../../../context/AppContext';
import { Kitnet, KitnetContract, KitnetTenant, KitnetStatus, IncomeType } from '../../../types';
import { getTodayLocalDateString } from '../../../utils/formatters';
import {
  generateKitnetContractPdfFile,
  getKitnetContractRawText,
  openKitnetContractPrintWindow,
} from '../../../utils/pdfGenerator';
import { compressImage } from '../../../utils/imageUtils';
import confetti from 'canvas-confetti';

interface UseKitnetWizardProps {
  isOpen: boolean;
  onSuccess: (
    kitnetId: string,
    contractDetails?: { kitnet: Kitnet; tenant: KitnetTenant; contract: KitnetContract }
  ) => void;
  onClose: () => void;
}

export function useKitnetWizard({ isOpen, onSuccess, onClose }: UseKitnetWizardProps) {
  const {
    addKitnet,
    kitnetTenants,
    addKitnetTenant,
    createKitnetContract,
    addDocument,
    settings,
  } = useApp();

  const [currentStep, setCurrentStep] = useState<number>(1);
  const [stepError, setStepError] = useState<string | null>(null);
  const [copiedContract, setCopiedContract] = useState<boolean>(false);
  const [contractTab, setContractTab] = useState<'preview' | 'text'>('preview');

  // ETAPA 1 — DADOS DA KITNET
  const [kitnetData, setKitnetData] = useState({
    number: '',
    name: '',
    address: '',
    description: '',
    status: 'disponivel' as KitnetStatus,
    statusNote: 'Pronta para locação imediata',
    monthlyRentBase: 0,
    monthlyWaterBase: 0,
    monthlyInternetBase: 0,
    otherFeesBase: 0,
    depositBase: 0,
    photos: {
      livingRoom: '',
      bedroom: '',
      bathroom: '',
      kitchen: '',
      outdoor: '',
    } as Record<string, string>,
  });

  // ETAPA 2 — DADOS DO INQUILINO
  const [tenantMode, setTenantMode] = useState<'new' | 'existing'>('new');
  const [selectedTenantId, setSelectedTenantId] = useState<string>('');
  const [tenantData, setTenantData] = useState({
    fullName: '',
    cpf: '',
    rg: '',
    birthDate: '1995-01-01',
    phone: '',
    whatsapp: '',
    email: '',
    photoUrl: '',
    maritalStatus: 'solteiro' as 'solteiro' | 'casado' | 'uniao_estavel' | 'divorciado' | 'viuvo',
    profession: '',
  });

  const handleTenantPhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      alert('Selecione um arquivo de imagem válido.');
      return;
    }
    try {
      const compressed = await compressImage(file, 800, 800, 0.82);
      setTenantData((prev) => ({ ...prev, photoUrl: compressed }));
      setDocumentsFiles((prev) => ({ ...prev, photo: compressed }));
    } catch (err) {
      console.error('Erro ao processar foto do inquilino:', err);
      alert('Não foi possível processar a imagem. Tente novamente.');
    }
  };

  // ETAPA 3 — COMPROVAÇÃO DE RENDA & DOCUMENTOS
  const [incomeType, setIncomeType] = useState<IncomeType>('CLT');
  const [incomeDetails, setIncomeDetails] = useState({
    companyOrActivity: '',
    roleOrProfession: '',
    monthlyIncome: 0,
    cnpj: '',
  });
  const [documentsFiles, setDocumentsFiles] = useState<{
    photo?: string;
    proofOfIncome?: string;
    bankStatement?: string;
    socialContract?: string;
    proofOfAddress?: string;
  }>({});

  // ETAPA 4 — DADOS DO CONTRATO
  const [contractTerms, setContractTerms] = useState({
    signatureDate: getTodayLocalDateString(),
    startDate: getTodayLocalDateString(),
    durationOption: 12 as number | 'custom',
    customMonths: 12,
    endDate: '',
    witnessesCount: 0,
    witness1Name: '',
    witness1Cpf: '',
    witness2Name: '',
    witness2Cpf: '',
  });

  const calculateEndDate = (startDateStr: string, months: number): string => {
    if (!startDateStr) return '';
    try {
      const [year, month, day] = startDateStr.split('-').map(Number);
      const date = new Date(year, month - 1, day);
      date.setMonth(date.getMonth() + months);
      const y = date.getFullYear();
      const m = String(date.getMonth() + 1).padStart(2, '0');
      const d = String(date.getDate()).padStart(2, '0');
      return `${y}-${m}-${d}`;
    } catch {
      return '';
    }
  };

  useEffect(() => {
    const effectiveMonths =
      contractTerms.durationOption === 'custom'
        ? Number(contractTerms.customMonths) || 12
        : contractTerms.durationOption;
    const computedEnd = calculateEndDate(contractTerms.startDate, effectiveMonths);
    setContractTerms((prev) => ({ ...prev, endDate: computedEnd }));
  }, [contractTerms.startDate, contractTerms.durationOption, contractTerms.customMonths]);

  // ETAPA 5 — VALORES
  const [financials, setFinancials] = useState({
    rentValue: 0,
    waterValue: 0,
    internetValue: 0,
    otherFees: 0,
    deposit: 0,
    cleaningFee: 400,
  });

  const totalMonthly =
    Number(financials.rentValue || 0) +
    Number(financials.waterValue || 0) +
    Number(financials.internetValue || 0) +
    Number(financials.otherFees || 0);

  // ETAPA 6 — PAGAMENTO
  const [paymentConfig, setPaymentConfig] = useState({
    dueDay: 10,
    paymentMethod: 'PIX Instantâneo',
    pixKey: settings.adminPixKey || '',
    notes: 'Pagamento pontual até o dia de vencimento. Vistoria de entrada anexada ao contrato.',
    firstPaymentReceived: false,
    firstPaymentPaidDate: getTodayLocalDateString(),
    firstPaymentMethod: 'PIX Instantâneo',
    firstPaymentNotes: '',
  });

  const isAlugada = kitnetData.status === 'alugada';

  const resetWizardState = React.useCallback(() => {
    setCurrentStep(1);
    setStepError(null);
    setCopiedContract(false);
    setContractTab('preview');
    setKitnetData({
      number: '',
      name: '',
      address: '',
      description: '',
      status: 'disponivel',
      statusNote: 'Pronta para locação imediata',
      monthlyRentBase: 0,
      monthlyWaterBase: 0,
      monthlyInternetBase: 0,
      otherFeesBase: 0,
      depositBase: 0,
      photos: {
        livingRoom: '',
        bedroom: '',
        bathroom: '',
        kitchen: '',
        outdoor: '',
      },
    });
    setTenantMode('new');
    setSelectedTenantId('');
    setTenantData({
      fullName: '',
      cpf: '',
      rg: '',
      birthDate: '1995-01-01',
      phone: '',
      whatsapp: '',
      email: '',
      photoUrl: '',
      maritalStatus: 'solteiro',
      profession: '',
    });
    setIncomeType('CLT');
    setIncomeDetails({
      companyOrActivity: '',
      roleOrProfession: '',
      monthlyIncome: 0,
      cnpj: '',
    });
    setDocumentsFiles({});
    setContractTerms({
      signatureDate: getTodayLocalDateString(),
      startDate: getTodayLocalDateString(),
      durationOption: 12,
      customMonths: 12,
      endDate: '',
      witnessesCount: 0,
      witness1Name: '',
      witness1Cpf: '',
      witness2Name: '',
      witness2Cpf: '',
    });
    setFinancials({
      rentValue: 0,
      waterValue: 0,
      internetValue: 0,
      otherFees: 0,
      deposit: 0,
      cleaningFee: 400,
    });
    setPaymentConfig({
      dueDay: 10,
      paymentMethod: 'PIX Instantâneo',
      pixKey: settings?.adminPixKey || '',
      notes: 'Pagamento pontual até o dia de vencimento. Vistoria de entrada anexada ao contrato.',
      firstPaymentReceived: false,
      firstPaymentPaidDate: getTodayLocalDateString(),
      firstPaymentMethod: 'PIX Instantâneo',
      firstPaymentNotes: '',
    });
  }, [settings?.adminPixKey]);

  // Reseta o estado toda vez que o modal for reaberto
  const prevOpenRef = React.useRef(isOpen);
  useEffect(() => {
    if (!prevOpenRef.current && isOpen) {
      resetWizardState();
    }
    prevOpenRef.current = isOpen;
  }, [isOpen, resetWizardState]);

  // Sincroniza a data do 1º pagamento com a data de início da locação
  useEffect(() => {
    if (contractTerms.startDate) {
      setPaymentConfig((prev) => ({
        ...prev,
        firstPaymentPaidDate: contractTerms.startDate,
      }));
    }
  }, [contractTerms.startDate]);

  // Se o modal for aberto, reseta o erro
  useEffect(() => {
    if (isOpen) {
      setStepError(null);
    }
  }, [isOpen]);

  // Se o status mudar para diferente de alugada (disponivel ou reforma), reseta para a etapa 1
  useEffect(() => {
    if (!isAlugada) {
      setCurrentStep(1);
    }
  }, [isAlugada]);

  useEffect(() => {
    if (kitnetData.number && (!kitnetData.name || kitnetData.name.startsWith('Kitnet '))) {
      const expectedName = `Kitnet ${kitnetData.number}`;
      setKitnetData((prev) => {
        if (prev.name === expectedName) return prev;
        return {
          ...prev,
          name: expectedName,
        };
      });
    }
  }, [kitnetData.number, kitnetData.name]);

  const handleDocUpload = (key: string, file: File) => {
    if (!file) return;
    setDocumentsFiles((prev) => ({
      ...prev,
      [key]: file.name,
    }));
  };

  const handleRemoveDoc = (key: string) => {
    setDocumentsFiles((prev) => {
      const updated = { ...prev };
      delete (updated as any)[key];
      return updated;
    });
  };

  const handleNext = () => {
    setStepError(null);
    if (currentStep === 1) {
      if (!kitnetData.number.trim()) {
        setStepError('Por favor, informe o Número da Kitnet.');
        return;
      }
      if (!kitnetData.name.trim()) {
        setStepError('Por favor, informe o Nome da Kitnet.');
        return;
      }
      if (!kitnetData.address || !kitnetData.address.trim()) {
        alert('Por favor, preencha o endereço completo da Kitnet.');
        setStepError('Por favor, preencha o endereço completo da Kitnet.');
        return;
      }
      if (kitnetData.status !== 'alugada') {
        setKitnetData((prev) => ({
          ...prev,
          status: 'alugada',
          statusNote: 'Contrato ativo de locação',
        }));
      }
      setCurrentStep(2);
      return;
    }

    if (currentStep === 2) {
      if (tenantMode === 'new') {
        if (!tenantData.fullName.trim()) {
          setStepError('Informe o Nome Completo do inquilino.');
          return;
        }
        if (!tenantData.cpf.trim()) {
          setStepError('Informe o CPF do inquilino.');
          return;
        }
      } else if (!selectedTenantId) {
        setStepError('Selecione um inquilino já cadastrado na lista.');
        return;
      }
    }

    if (currentStep === 4) {
      if (!contractTerms.startDate) {
        setStepError('Por favor, informe a Data de Início da locação.');
        return;
      }
    }

    if (currentStep === 5) {
      if (!financials.rentValue || financials.rentValue <= 0) {
        alert('Por favor, informe o valor do aluguel.');
        setStepError('Por favor, informe o valor do aluguel.');
        return;
      }
    }

    if (currentStep < 7) {
      setCurrentStep((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    setStepError(null);
    if (currentStep > 1) {
      setCurrentStep((prev) => prev - 1);
    }
  };

  const getContractPayload = () => {
    const effectiveMonths =
      contractTerms.durationOption === 'custom'
        ? Number(contractTerms.customMonths) || 12
        : contractTerms.durationOption;

    const effectiveNumber = kitnetData.number?.trim() || '';
    const effectiveName =
      kitnetData.name?.trim() ||
      (effectiveNumber ? `Kitnet ${effectiveNumber}` : 'Kitnet');

    const mockKitnet: Kitnet = {
      id: 'temp-kitnet',
      name: effectiveName,
      number: effectiveNumber,
      address: kitnetData.address || '',
      description: kitnetData.description,
      status: kitnetData.status,
      monthlyRentBase: financials.rentValue,
      monthlyWaterBase: financials.waterValue,
      monthlyInternetBase: financials.internetValue,
      otherFeesBase: financials.otherFees,
      depositBase: financials.deposit,
      cleaningFeeBase: financials.cleaningFee,
      photos: kitnetData.photos,
    };

    const effectiveTenant: KitnetTenant =
      tenantMode === 'new'
        ? {
            id: 'temp-tenant',
            fullName: tenantData.fullName || 'Inquilino(a)',
            cpf: tenantData.cpf || '000.000.000-00',
            rg: tenantData.rg || '',
            birthDate: tenantData.birthDate,
            phone: tenantData.phone || '(00) 00000-0000',
            whatsapp: tenantData.whatsapp || tenantData.phone,
            email: tenantData.email || '',
            photoUrl: tenantData.photoUrl,
            address: kitnetData.address,
            maritalStatus: tenantData.maritalStatus,
            profession: tenantData.profession,
            incomeType: incomeType,
            documents: {
              ...documentsFiles,
              ...(tenantData.photoUrl ? { photo: tenantData.photoUrl } : {}),
            },
          }
        : kitnetTenants.find((t) => t.id === selectedTenantId) || {
            id: 'temp-tenant',
            fullName: 'Inquilino Selecionado',
            cpf: '000.000.000-00',
            rg: '',
            birthDate: '1990-01-01',
            phone: '(00) 00000-0000',
            email: '',
            address: kitnetData.address,
            maritalStatus: 'solteiro',
            incomeType: 'CLT',
            documents: {},
          };

    const mockContract: KitnetContract = {
      id: 'temp-contract',
      kitnetId: 'temp-kitnet',
      tenantId: effectiveTenant.id,
      startDate: contractTerms.startDate,
      endDate: contractTerms.endDate,
      signatureDate: contractTerms.signatureDate,
      durationMonths: effectiveMonths,
      rentValue: financials.rentValue,
      waterValue: financials.waterValue,
      internetValue: financials.internetValue,
      otherFees: financials.otherFees,
      deposit: financials.deposit,
      cleaningFee: financials.cleaningFee,
      dueDay: paymentConfig.dueDay,
      paymentMethod: paymentConfig.paymentMethod,
      pixKey: paymentConfig.pixKey,
      status: 'ativo',
      installments: [],
      notes: paymentConfig.notes,
      witnessesCount: contractTerms.witnessesCount !== undefined ? contractTerms.witnessesCount : 0,
      witness1Name: contractTerms.witness1Name || '',
      witness1Cpf: contractTerms.witness1Cpf || '',
      witness2Name: contractTerms.witness2Name || '',
      witness2Cpf: contractTerms.witness2Cpf || '',
    };

    return { kitnet: mockKitnet, contract: mockContract, tenant: effectiveTenant, settings };
  };

  const validateRentalPrerequisites = () => {
    if (!kitnetData.address || !kitnetData.address.trim()) {
      alert('Por favor, preencha o endereço completo da Kitnet.');
      setStepError('Por favor, preencha o endereço completo da Kitnet.');
      return false;
    }
    const rentValue = financials.rentValue || kitnetData.monthlyRentBase;
    if (!rentValue || rentValue <= 0) {
      alert('Por favor, informe o valor do aluguel.');
      setStepError('Por favor, informe o valor do aluguel.');
      return false;
    }
    return true;
  };

  const handleGenerateContract = (autoDownload = true) => {
    if (!validateRentalPrerequisites()) return null;
    const payload = getContractPayload();
    return generateKitnetContractPdfFile({
      ...payload,
      autoDownload,
    });
  };

  const handlePrintContract = () => {
    if (!validateRentalPrerequisites()) return;
    const payload = getContractPayload();
    openKitnetContractPrintWindow(payload);
  };

  const handleCopyContractText = () => {
    if (!validateRentalPrerequisites()) return;
    const payload = getContractPayload();
    const rawText = getKitnetContractRawText(payload);
    navigator.clipboard.writeText(rawText).then(() => {
      setCopiedContract(true);
      setTimeout(() => setCopiedContract(false), 2500);
    });
  };

  const handleFinalSubmit = (withContract = true) => {
    setStepError(null);

    if (!kitnetData.number?.trim()) {
      setStepError('Por favor, informe o Número da Kitnet.');
      setCurrentStep(1);
      return;
    }
    if (!kitnetData.name?.trim()) {
      setStepError('Por favor, informe o Nome da Kitnet.');
      setCurrentStep(1);
      return;
    }

    let finalTenantId = selectedTenantId;

    const hasTenantData = Boolean(
      (tenantMode === 'new' && tenantData.fullName?.trim()) ||
      (tenantMode === 'existing' && selectedTenantId) ||
      currentStep > 1 ||
      kitnetData.status === 'alugada'
    );
    const shouldCreateContract = withContract && hasTenantData;
    const isAlugadaFlow = shouldCreateContract || kitnetData.status === 'alugada';

    if (isAlugadaFlow) {
      if (!kitnetData.address || !kitnetData.address.trim()) {
        alert('Por favor, preencha o endereço completo da Kitnet.');
        setStepError('Por favor, preencha o endereço completo da Kitnet.');
        setCurrentStep(1);
        return;
      }
      const rentValue = financials.rentValue || kitnetData.monthlyRentBase;
      if (!rentValue || rentValue <= 0) {
        alert('Por favor, informe o valor do aluguel.');
        setStepError('Por favor, informe o valor do aluguel.');
        setCurrentStep(5);
        return;
      }
    }

    if (shouldCreateContract) {
      if (tenantMode === 'new') {
        if (!tenantData.fullName?.trim()) {
          setStepError('Informe o Nome Completo do inquilino.');
          setCurrentStep(2);
          return;
        }
        if (!tenantData.cpf?.trim()) {
          setStepError('Informe o CPF do inquilino.');
          setCurrentStep(2);
          return;
        }
      } else if (!selectedTenantId) {
        setStepError('Selecione um inquilino cadastrado na lista.');
        setCurrentStep(2);
        return;
      }
    }

    const finalStatus: KitnetStatus = shouldCreateContract ? 'alugada' : kitnetData.status;

    let finalStatusNote = kitnetData.statusNote?.trim() || undefined;
    if (finalStatus === 'alugada') {
      finalStatusNote = tenantData.fullName?.trim()
        ? `Locatário: ${tenantData.fullName.trim()}`
        : 'Contrato ativo de locação';
    } else if (finalStatus === 'reforma') {
      finalStatusNote = finalStatusNote || 'Em reforma / manutenção';
    } else {
      finalStatusNote = finalStatusNote || 'Pronta para locação imediata';
    }

    const finalKitnetNumber = kitnetData.number?.trim() || '';
    const finalKitnetName =
      kitnetData.name?.trim() ||
      (finalKitnetNumber ? `Kitnet ${finalKitnetNumber}` : 'Kitnet sem identificação');

    const newKitnetId = addKitnet({
      name: finalKitnetName,
      number: finalKitnetNumber,
      address: kitnetData.address,
      description: kitnetData.description,
      status: finalStatus,
      statusNote: finalStatusNote,
      monthlyRentBase: Number(financials.rentValue || kitnetData.monthlyRentBase),
      monthlyWaterBase: Number(financials.waterValue || kitnetData.monthlyWaterBase),
      monthlyInternetBase: Number(financials.internetValue || 0),
      otherFeesBase: Number(financials.otherFees || 0),
      depositBase: Number(financials.deposit || kitnetData.depositBase),
      cleaningFeeBase: Number(financials.cleaningFee !== undefined ? financials.cleaningFee : 400),
      photos: kitnetData.photos,
      documents: [],
    });

    if (shouldCreateContract) {
      if (tenantMode === 'new') {
        finalTenantId = addKitnetTenant({
          fullName: tenantData.fullName || 'Inquilino(a)',
          cpf: tenantData.cpf || '000.000.000-00',
          rg: tenantData.rg || '',
          birthDate: tenantData.birthDate,
          phone: tenantData.phone || '(00) 00000-0000',
          whatsapp: tenantData.whatsapp || tenantData.phone || '(00) 00000-0000',
          email: tenantData.email,
          photoUrl: tenantData.photoUrl,
          address: kitnetData.address,
          maritalStatus: tenantData.maritalStatus,
          profession: tenantData.profession,
          incomeType: incomeType,
          documents: {
            ...documentsFiles,
            ...(tenantData.photoUrl ? { photo: tenantData.photoUrl } : {}),
          },
        });
      }

      let createdContractId = '';
      if (finalTenantId) {
        const effectiveMonths =
          contractTerms.durationOption === 'custom'
            ? Number(contractTerms.customMonths) || 12
            : contractTerms.durationOption;

        createdContractId = createKitnetContract({
          kitnetId: newKitnetId,
          tenantId: finalTenantId,
          startDate: contractTerms.startDate,
          endDate: contractTerms.endDate,
          signatureDate: contractTerms.signatureDate,
          durationMonths: effectiveMonths,
          rentValue: Number(financials.rentValue),
          waterValue: Number(financials.waterValue),
          internetValue: Number(financials.internetValue || 0),
          otherFees: Number(financials.otherFees || 0),
          deposit: Number(financials.deposit),
          cleaningFee: Number(financials.cleaningFee !== undefined ? financials.cleaningFee : 400),
          dueDay: Number(paymentConfig.dueDay),
          paymentMethod: paymentConfig.paymentMethod,
          pixKey: paymentConfig.pixKey,
          status: 'ativo',
          notes: paymentConfig.notes,
          witnessesCount: contractTerms.witnessesCount !== undefined ? contractTerms.witnessesCount : 0,
          witness1Name: contractTerms.witness1Name || '',
          witness1Cpf: contractTerms.witness1Cpf || '',
          witness2Name: contractTerms.witness2Name || '',
          witness2Cpf: contractTerms.witness2Cpf || '',
          firstPaymentReceived: paymentConfig.firstPaymentReceived,
          firstPaymentPaidDate: paymentConfig.firstPaymentPaidDate,
          firstPaymentMethod: paymentConfig.firstPaymentMethod,
          firstPaymentNotes: paymentConfig.firstPaymentNotes,
          allowProRata: true,
        });

        try {
          const pdfRes = handleGenerateContract(false);
          if (pdfRes?.dataUri) {
            addDocument({
              title: `Contrato Locação ${finalKitnetName} - ${tenantData.fullName || 'Inquilino'}`,
              category: 'kitnet',
              relatedId: newKitnetId,
              relatedName: finalKitnetName,
              fileUrl: pdfRes.dataUri,
              fileType: 'pdf',
              fileSize: '145 KB',
            });
          }
        } catch (err) {
          console.error('Erro ao anexar PDF de contrato:', err);
        }
      }

      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {}

      if (finalTenantId) {
        const createdKitnet: Kitnet = {
          id: newKitnetId,
          number: finalKitnetNumber,
          name: finalKitnetName,
          address: kitnetData.address,
          description: kitnetData.description,
          status: 'alugada',
          monthlyRentBase: Number(financials.rentValue),
          monthlyWaterBase: Number(financials.waterValue),
          monthlyInternetBase: Number(financials.internetValue || 0),
          otherFeesBase: Number(financials.otherFees || 0),
          depositBase: Number(financials.deposit),
          photos: kitnetData.photos,
        };
        const createdTenant: KitnetTenant = {
          id: finalTenantId,
          fullName: tenantData.fullName,
          cpf: tenantData.cpf,
          rg: tenantData.rg,
          birthDate: tenantData.birthDate,
          phone: tenantData.phone,
          whatsapp: tenantData.whatsapp || tenantData.phone,
          email: tenantData.email,
          photoUrl: tenantData.photoUrl,
          address: kitnetData.address,
          maritalStatus: tenantData.maritalStatus,
          profession: tenantData.profession,
          incomeType: incomeType,
          documents: {},
        };
        const createdContract: KitnetContract = {
          id: createdContractId || `contract-kitnet-${Date.now()}`,
          kitnetId: newKitnetId,
          tenantId: finalTenantId,
          startDate: contractTerms.startDate,
          endDate: contractTerms.endDate,
          signatureDate: contractTerms.signatureDate,
          durationMonths:
            contractTerms.durationOption === 'custom'
              ? Number(contractTerms.customMonths) || 12
              : contractTerms.durationOption,
          rentValue: Number(financials.rentValue),
          waterValue: Number(financials.waterValue),
          internetValue: Number(financials.internetValue || 0),
          otherFees: Number(financials.otherFees || 0),
          deposit: Number(financials.deposit),
          dueDay: Number(paymentConfig.dueDay),
          paymentMethod: paymentConfig.paymentMethod,
          pixKey: paymentConfig.pixKey,
          status: 'ativo',
          installments: [],
        };
        onSuccess(newKitnetId, {
          kitnet: createdKitnet,
          tenant: createdTenant,
          contract: createdContract,
        });
      } else {
        onSuccess(newKitnetId);
      }
    } else {
      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {}
      onSuccess(newKitnetId);
    }
    resetWizardState();
    onClose();
  };

  return {
    currentStep,
    setCurrentStep,
    resetWizardState,
    copiedContract,
    contractTab,
    setContractTab,
    kitnetData,
    setKitnetData,
    tenantMode,
    setTenantMode,
    selectedTenantId,
    setSelectedTenantId,
    tenantData,
    setTenantData,
    incomeType,
    setIncomeType,
    incomeDetails,
    setIncomeDetails,
    documentsFiles,
    setDocumentsFiles,
    contractTerms,
    setContractTerms,
    financials,
    setFinancials,
    paymentConfig,
    setPaymentConfig,
    totalMonthly,
    handleTenantPhotoUpload,
    handleDocUpload,
    handleRemoveDoc,
    handleNext,
    handlePrev,
    getContractPayload,
    handleGenerateContract,
    handlePrintContract,
    handleCopyContractText,
    handleFinalSubmit,
    kitnetTenants,
    isAlugada,
    stepError,
    setStepError,
  };
}
