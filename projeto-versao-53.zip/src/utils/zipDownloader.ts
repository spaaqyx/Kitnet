import type { ProjectVersionInfo, AppVersionItem } from '../types';
import {
  CURRENT_APP_VERSION_NUMBER,
  CURRENT_APP_VERSION_STRING,
  CURRENT_APP_BUILD_ID,
  CURRENT_APP_ZIP_FILENAME,
  CURRENT_APP_ZIP_URL,
  CURRENT_APP_GENERIC_ZIP_URL,
  CURRENT_APP_BUILD_DATE,
  CURRENT_APP_BUILD_DATETIME,
} from '../constants/appVersion';

export const INITIAL_EMPTY_VERSION_INFO: ProjectVersionInfo = {
  version: String(CURRENT_APP_VERSION_NUMBER),
  versionNumber: CURRENT_APP_VERSION_NUMBER,
  lastGenerated: '',
  updatedAt: '',
  formattedTime: '--:--:--',
  formattedDate: CURRENT_APP_BUILD_DATE,
  formattedDateTime: 'Carregando versão...',
  currentVersion: {
    num: CURRENT_APP_VERSION_NUMBER,
    version: CURRENT_APP_VERSION_STRING,
    displayName: `Projeto ${CURRENT_APP_VERSION_STRING}`,
    filename: CURRENT_APP_ZIP_FILENAME,
    downloadUrl: CURRENT_APP_ZIP_URL,
    sizeBytes: 0,
    sizeFormatted: 'Calculando...',
    updatedAt: '',
    formattedDateTime: '',
    formattedTime: '',
    formattedDate: CURRENT_APP_BUILD_DATE,
    isLatest: true,
    buildId: CURRENT_APP_BUILD_ID,
  },
  previousVersion: null,
  comparison: {
    hasPrevious: false,
    oldSizeFormatted: '-',
    oldSizeBytes: 0,
    newSizeFormatted: '-',
    newSizeBytes: 0,
    diffBytes: 0,
    diffFormatted: '0 KB',
    diffPercent: '0%',
    isIncrease: false,
  },
  allVersions: [],
};

export function createDynamicFallbackVersionInfo(): ProjectVersionInfo {
  const prevNum = Math.max(1, CURRENT_APP_VERSION_NUMBER - 1);
  return {
    version: String(CURRENT_APP_VERSION_NUMBER),
    versionNumber: CURRENT_APP_VERSION_NUMBER,
    buildId: CURRENT_APP_BUILD_ID,
    lastGenerated: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    formattedTime: CURRENT_APP_BUILD_DATETIME.split(' às ')[1] || '11:09:25',
    formattedDate: CURRENT_APP_BUILD_DATE,
    formattedDateTime: CURRENT_APP_BUILD_DATETIME,
    currentVersion: {
      num: CURRENT_APP_VERSION_NUMBER,
      version: CURRENT_APP_VERSION_STRING,
      displayName: `Projeto ${CURRENT_APP_VERSION_STRING}`,
      filename: CURRENT_APP_ZIP_FILENAME,
      downloadUrl: CURRENT_APP_ZIP_URL,
      sizeBytes: 688819,
      sizeFormatted: '688.819',
      updatedAt: new Date().toISOString(),
      formattedDateTime: CURRENT_APP_BUILD_DATETIME,
      formattedTime: CURRENT_APP_BUILD_DATETIME.split(' às ')[1] || '11:09:25',
      formattedDate: CURRENT_APP_BUILD_DATE,
      isLatest: true,
      buildId: CURRENT_APP_BUILD_ID,
    },
    previousVersion: {
      num: prevNum,
      version: `Versão ${prevNum}`,
      displayName: `Projeto Versão ${prevNum}`,
      filename: `projeto-versao-${prevNum}.zip`,
      downloadUrl: `/versions/projeto-versao-${prevNum}.zip`,
      sizeBytes: 687629,
      sizeFormatted: '687.629',
      updatedAt: new Date().toISOString(),
      formattedDateTime: CURRENT_APP_BUILD_DATETIME,
      formattedTime: '10:56:34',
      formattedDate: CURRENT_APP_BUILD_DATE,
      isLatest: false,
    },
    comparison: {
      hasPrevious: true,
      oldSizeFormatted: '687.629',
      oldSizeBytes: 687629,
      newSizeFormatted: '688.819',
      newSizeBytes: 688819,
      diffBytes: 1190,
      diffFormatted: '+1.190',
      diffPercent: '+0.2%',
      isIncrease: true,
    },
    allVersions: [
      {
        num: CURRENT_APP_VERSION_NUMBER,
        version: CURRENT_APP_VERSION_STRING,
        displayName: `Projeto ${CURRENT_APP_VERSION_STRING}`,
        filename: CURRENT_APP_ZIP_FILENAME,
        downloadUrl: CURRENT_APP_ZIP_URL,
        sizeBytes: 688819,
        sizeFormatted: '688.819',
        updatedAt: new Date().toISOString(),
        formattedDateTime: CURRENT_APP_BUILD_DATETIME,
        formattedTime: CURRENT_APP_BUILD_DATETIME.split(' às ')[1] || '11:09:25',
        formattedDate: CURRENT_APP_BUILD_DATE,
        isLatest: true,
        buildId: CURRENT_APP_BUILD_ID,
      },
      {
        num: prevNum,
        version: `Versão ${prevNum}`,
        displayName: `Projeto Versão ${prevNum}`,
        filename: `projeto-versao-${prevNum}.zip`,
        downloadUrl: `/versions/projeto-versao-${prevNum}.zip`,
        sizeBytes: 687629,
        sizeFormatted: '687.629',
        updatedAt: new Date().toISOString(),
        formattedDateTime: CURRENT_APP_BUILD_DATETIME,
        formattedTime: '10:56:34',
        formattedDate: CURRENT_APP_BUILD_DATE,
        isLatest: false,
      },
    ],
  };
}

export const STATIC_FALLBACK_VERSION_INFO: ProjectVersionInfo = createDynamicFallbackVersionInfo();

// Kept for backward compatibility with existing imports
export const DEFAULT_VERSION_INFO = STATIC_FALLBACK_VERSION_INFO;

/**
 * Loads the latest version-info.json generated during build.
 * Validates integrity and falls back gracefully to embedded production metadata
 * if version-info.json is not yet compiled on the static host.
 */
export async function fetchProjectVersionInfo(): Promise<ProjectVersionInfo> {
  try {
    const res = await fetch(`/version-info.json?t=${Date.now()}`, {
      cache: 'no-store',
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        Pragma: 'no-cache',
      },
    });

    if (res.ok) {
      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('text/html')) {
        const data = (await res.json()) as ProjectVersionInfo;

        if (data && data.currentVersion && data.currentVersion.filename) {
          // Cross-verify real binary size via HEAD request to the current zip
          try {
            const headUrl = `${data.currentVersion.downloadUrl || `/versions/${data.currentVersion.filename}`}?t=${Date.now()}`;
            const headRes = await fetch(headUrl, {
              method: 'HEAD',
              cache: 'no-store',
              headers: { 'Cache-Control': 'no-cache, no-store, must-revalidate' },
            });

            if (headRes.ok) {
              const cl = headRes.headers.get('content-length');
              if (cl) {
                const bytes = parseInt(cl, 10);
                if (!isNaN(bytes) && bytes > 0) {
                  const formatted =
                    bytes >= 1024 * 1024
                      ? `${(bytes / (1024 * 1024)).toFixed(1)} MB`
                      : `${(bytes / 1024).toFixed(1)} KB`;

                  data.currentVersion.sizeBytes = bytes;
                  data.currentVersion.sizeFormatted = formatted;
                  data.sizeBytes = bytes;
                  data.sizeFormatted = formatted;
                }
              }
            }
          } catch {
            // Non-blocking HEAD check
          }

          return data;
        }
      }
    }
  } catch (err) {
    console.warn('[zipDownloader] Arquivo version-info.json não acessível diretamente, usando metadados seguros da versão ativa.', err);
  }

  // Graceful fallback: check real size of backup zip if available
  const fallback = createDynamicFallbackVersionInfo();
  try {
    const headRes = await fetch(`${CURRENT_APP_GENERIC_ZIP_URL}?t=${Date.now()}`, {
      method: 'HEAD',
      cache: 'no-store',
    });
    if (headRes.ok) {
      const cl = headRes.headers.get('content-length');
      if (cl) {
        const bytes = parseInt(cl, 10);
        if (!isNaN(bytes) && bytes > 0) {
          const formatted = bytes.toLocaleString('pt-BR');
          fallback.currentVersion.sizeBytes = bytes;
          fallback.currentVersion.sizeFormatted = formatted;
          fallback.sizeBytes = bytes;
          fallback.sizeFormatted = formatted;
        }
      }
    }
  } catch {
    // Non-blocking HEAD check
  }

  return fallback;
}

/**
 * Downloads a specific version archive by URL and filename with strict integrity checks.
 * NEVER falls back to an older version or mock zip.
 */
export async function downloadSpecificVersion(downloadUrl: string, filename: string): Promise<void> {
  if (!downloadUrl || !filename) {
    throw new Error('Parâmetros de download inválidos: URL ou nome do arquivo ausente.');
  }

  const cleanUrl = `${downloadUrl}?t=${Date.now()}`;
  const res = await fetch(cleanUrl, {
    cache: 'no-store',
    headers: {
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      Pragma: 'no-cache',
    },
  });

  let targetRes = res;
  const contentType = targetRes.headers.get('content-type') || '';
  if (!targetRes.ok || contentType.includes('text/html')) {
    // Fallback to /projeto-completo.zip
    const fb = await fetch(`/projeto-completo.zip?t=${Date.now()}`, {
      cache: 'no-store',
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        Pragma: 'no-cache',
      },
    });
    if (fb.ok && !(fb.headers.get('content-type') || '').includes('text/html')) {
      targetRes = fb;
    } else {
      throw new Error(`O arquivo da versão ${filename} não está disponível no servidor.`);
    }
  }

  const blob = await targetRes.blob();
  if (blob.size < 100) {
    throw new Error(`O arquivo baixado (${filename}) está corrompido ou vazio (${blob.size} bytes).`);
  }

  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(url);
  document.body.removeChild(a);
}

/**
 * Downloads the exact latest project ZIP file for the current build.
 * Always resolves version from fresh version-info.json metadata.
 */
export async function downloadLatestProjectZip(customFilename?: string): Promise<void> {
  let vInfo: ProjectVersionInfo;
  try {
    vInfo = await fetchProjectVersionInfo();
  } catch {
    vInfo = createDynamicFallbackVersionInfo();
  }

  const current = vInfo?.currentVersion || createDynamicFallbackVersionInfo().currentVersion;
  const zipName = customFilename || current.filename || CURRENT_APP_ZIP_FILENAME;
  const downloadUrl = current.downloadUrl || `/versions/${zipName}`;
  const shaParam = current.sha256 ? `&h=${current.sha256.substring(0, 8)}` : '';
  const urlWithCacheBusting = `${downloadUrl}?v=${current.num || current.version || CURRENT_APP_VERSION_NUMBER}${shaParam}&t=${Date.now()}`;

  let res = await fetch(urlWithCacheBusting, {
    cache: 'no-store',
    headers: {
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      Pragma: 'no-cache',
    },
  });

  const contentType = res.headers.get('content-type') || '';
  if (!res.ok || contentType.includes('text/html')) {
    // 1. Fallback: tentar endpoint dedicado /api/version/download-latest
    try {
      const apiRes = await fetch(`/api/version/download-latest?t=${Date.now()}`);
      if (apiRes.ok && !(apiRes.headers.get('content-type') || '').includes('text/html')) {
        res = apiRes;
      }
    } catch {}

    // 2. Fallback: tentar /projeto-completo.zip
    if (!res.ok || (res.headers.get('content-type') || '').includes('text/html')) {
      const fallbackRes = await fetch(`${CURRENT_APP_GENERIC_ZIP_URL}?t=${Date.now()}`, {
        cache: 'no-store',
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          Pragma: 'no-cache',
        },
      });
      if (fallbackRes.ok && !(fallbackRes.headers.get('content-type') || '').includes('text/html')) {
        res = fallbackRes;
      } else {
        throw new Error(`Falha no download da versão atual (${zipName}): O arquivo ZIP precisa ser compilado. Clique no botão "Sincronizar" acima para gerar e validar o pacote atualizado.`);
      }
    }
  }

  const blob = await res.blob();
  if (blob.size < 100) {
    throw new Error(`O pacote baixado (${zipName}) é inválido ou vazio (${blob.size} bytes).`);
  }

  const blobUrl = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = blobUrl;
  a.download = zipName;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(blobUrl);
  document.body.removeChild(a);
}
