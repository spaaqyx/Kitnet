import { useState, useEffect, useCallback, useRef } from 'react';

export interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[];
  readonly userChoice: Promise<{
    outcome: 'accepted' | 'dismissed';
    platform: string;
  }>;
  prompt(): Promise<void>;
}

export interface PWAState {
  isOnline: boolean;
  isInstallable: boolean;
  isInstalled: boolean;
  isStandalone: boolean;
  hasUpdate: boolean;
  promptInstall: () => Promise<boolean>;
  applyUpdate: () => void;
}

// Module-level guard to guarantee singleton registration across component lifecycles
let hasAttemptedRegistration = false;
const LAST_RELOAD_KEY = 'pwa_last_update_reload_ts';
const UPDATE_IN_PROGRESS_KEY = 'pwa_update_in_progress';
const RELOAD_THROTTLE_WINDOW_MS = 10000; // 10 seconds anti-loop threshold

export function usePWA(): PWAState {
  const [isOnline, setIsOnline] = useState<boolean>(() => {
    return typeof navigator !== 'undefined' ? navigator.onLine : true;
  });

  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState<boolean>(false);
  const [hasUpdate, setHasUpdate] = useState<boolean>(false);
  const [waitingWorker, setWaitingWorker] = useState<ServiceWorker | null>(null);
  const isApplyingUpdateRef = useRef<boolean>(false);

  const isStandalone = typeof window !== 'undefined' && (
    window.matchMedia('(display-mode: standalone)').matches ||
    (window.navigator as any).standalone === true ||
    document.referrer.includes('android-app://')
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Capture PWA installation prompt
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setInstallPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    const isIframe = typeof window !== 'undefined' && window.self !== window.top;
    const isDev = Boolean((import.meta as any)?.env?.DEV);
    let handleVisibilityChange: (() => void) | null = null;

    // If running in development or inside preview iframe, avoid SW caching to prevent refresh conflicts
    if (isIframe || isDev) {
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.getRegistrations().then((registrations) => {
          for (const reg of registrations) {
            reg.unregister();
          }
        }).catch(() => {});
      }
      return () => {
        window.removeEventListener('online', handleOnline);
        window.removeEventListener('offline', handleOffline);
        window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
        window.removeEventListener('appinstalled', handleAppInstalled);
      };
    }

    // Register Service Worker in production/standalone environment
    if ('serviceWorker' in navigator && process.env.NODE_ENV !== 'test' && !hasAttemptedRegistration) {
      hasAttemptedRegistration = true;

      navigator.serviceWorker
        .register('/sw.js', { updateViaCache: 'none' })
        .then((registration) => {
          // If a worker is already waiting and we have an active controller, notify UI
          if (registration.waiting && navigator.serviceWorker.controller) {
            setWaitingWorker(registration.waiting);
            setHasUpdate(true);
          }

          // Monitor for new service worker installation
          registration.addEventListener('updatefound', () => {
            const newWorker = registration.installing;
            if (newWorker) {
              newWorker.addEventListener('statechange', () => {
                // An update only counts if an active controller already exists (not first-time install)
                if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                  setWaitingWorker(newWorker);
                  setHasUpdate(true);
                }
              });
            }
          });

          // Safe throttled update check on visibility change (at most once every 60 min)
          let lastCheckTime = Date.now();
          handleVisibilityChange = () => {
            if (document.visibilityState === 'visible') {
              const now = Date.now();
              if (now - lastCheckTime > 60 * 60 * 1000) {
                lastCheckTime = now;
                registration.update().catch(() => {});
              }
            }
          };
          document.addEventListener('visibilitychange', handleVisibilityChange);
        })
        .catch((err) => {
          console.info('[PWA] Service Worker registration skipped:', err);
        });
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
      if (handleVisibilityChange) {
        document.removeEventListener('visibilitychange', handleVisibilityChange);
      }
    };
  }, []);

  const promptInstall = useCallback(async (): Promise<boolean> => {
    if (!installPrompt) return false;
    try {
      await installPrompt.prompt();
      const choice = await installPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setIsInstalled(true);
        setInstallPrompt(null);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }, [installPrompt]);

  // Rock-solid applyUpdate: handles SKIP_WAITING and guarantees no reload loop
  const applyUpdate = useCallback(() => {
    if (isApplyingUpdateRef.current) return;
    isApplyingUpdateRef.current = true;

    // Check anti-loop throttle guard
    try {
      const lastReload = sessionStorage.getItem(LAST_RELOAD_KEY);
      if (lastReload) {
        const elapsed = Date.now() - parseInt(lastReload, 10);
        if (elapsed < RELOAD_THROTTLE_WINDOW_MS) {
          console.warn(`[PWA Guard] Update reload suppressed: previous reload happened ${elapsed}ms ago.`);
          setHasUpdate(false);
          isApplyingUpdateRef.current = false;
          return;
        }
      }
      sessionStorage.setItem(LAST_RELOAD_KEY, String(Date.now()));
      sessionStorage.setItem(UPDATE_IN_PROGRESS_KEY, 'true');
    } catch {
      // Non-blocking
    }

    let hasReloaded = false;
    let safetyTimer: ReturnType<typeof setTimeout> | null = null;

    const performSafeReload = () => {
      if (hasReloaded) return;
      hasReloaded = true;
      if (safetyTimer) {
        clearTimeout(safetyTimer);
        safetyTimer = null;
      }
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.removeEventListener('controllerchange', performSafeReload);
      }
      window.location.reload();
    };

    if ('serviceWorker' in navigator) {
      // Listen for controllerchange: reload ONLY ONCE when new worker takes over
      navigator.serviceWorker.addEventListener('controllerchange', performSafeReload);
    }

    if (waitingWorker) {
      waitingWorker.postMessage({ type: 'SKIP_WAITING' });
    }

    // Safety timeout: if controllerchange doesn't fire within 1500ms, reload safely
    safetyTimer = setTimeout(() => {
      if (!hasReloaded) {
        performSafeReload();
      }
    }, 1500);

    setHasUpdate(false);
  }, [waitingWorker]);

  return {
    isOnline,
    isInstallable: !!installPrompt,
    isInstalled,
    isStandalone,
    hasUpdate,
    promptInstall,
    applyUpdate,
  };
}
