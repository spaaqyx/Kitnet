import { useRef, useEffect, useCallback } from 'react';

interface UseScrollActiveIntoViewOptions {
  inline?: ScrollLogicalPosition;
  block?: ScrollLogicalPosition;
  delayMs?: number;
}

/**
 * Hook para centralizar automaticamente e de forma fluida os botões de abas/filtros
 * na barra horizontal conforme o usuário clica ou a etapa ativa avança,
 * eliminando a necessidade de arrastar manualmente na tela pequena.
 */
export function useScrollActiveIntoView<T extends HTMLElement = HTMLButtonElement>(
  activeKey: string | number | undefined | null,
  options: UseScrollActiveIntoViewOptions = {}
) {
  const { inline = 'center', block = 'nearest', delayMs = 35 } = options;
  const containerRef = useRef<HTMLDivElement | null>(null);
  const itemsMapRef = useRef<Map<string | number, T>>(new Map());

  const registerItem = useCallback(
    (key: string | number) => (node: T | null) => {
      if (node) {
        itemsMapRef.current.set(key, node);
      } else {
        itemsMapRef.current.delete(key);
      }
    },
    []
  );

  const scrollItemIntoView = useCallback(
    (key: string | number, customInline?: ScrollLogicalPosition) => {
      const el = itemsMapRef.current.get(key);
      if (!el) return;

      const container = containerRef.current;
      if (container) {
        // Rola APENAS o container horizontal interno, NUNCA a janela/documento vertical
        const containerRect = container.getBoundingClientRect();
        const elRect = el.getBoundingClientRect();
        const currentScroll = container.scrollLeft;
        const relativeLeft = elRect.left - containerRect.left;
        const targetScroll = currentScroll + relativeLeft - (container.clientWidth / 2) + (elRect.width / 2);

        container.scrollTo({
          left: Math.max(0, targetScroll),
          behavior: 'smooth',
        });
      } else {
        el.scrollIntoView({
          behavior: 'smooth',
          inline: customInline || inline,
          block,
        });
      }
    },
    [inline, block]
  );

  const isFirstMountRef = useRef(true);

  useEffect(() => {
    if (activeKey === undefined || activeKey === null) return;

    // Evita disparo na montagem inicial para itens padrão (ex: 'geral', 'todos'),
    // prevenindo conflitos enquanto o acordeão ainda está expandindo sua altura
    if (isFirstMountRef.current) {
      isFirstMountRef.current = false;
      if (activeKey === 'geral' || activeKey === 'todos' || activeKey === 1 || activeKey === 'todas') {
        return;
      }
    }

    const timer = setTimeout(() => {
      scrollItemIntoView(activeKey);
    }, delayMs);

    return () => clearTimeout(timer);
  }, [activeKey, delayMs, scrollItemIntoView]);

  return {
    containerRef,
    registerItem,
    scrollItemIntoView,
  };
}
