/**
 * src/tests/buttonAnimationAudit.test.ts
 *
 * Trava de regressão de animação de botões:
 * Garante que todo arquivo em src/components contendo elementos <button>
 * aplique active:scale (resposta tátil visual ao toque/clique).
 *
 * EXCEÇÃO DOCUMENTADA:
 * - Botões do dock flutuante inferior mobile (id="mobile-tab-*"):
 *   São isentos de active:scale e transition-transform para eliminar saltos visuais,
 *   preservar a geometria fixa e permitir que o Framer Motion (layoutId="mobileBottomSpotlight")
 *   interpole suavemente o spotlight sem colisão de bounding box com transformações de clique.
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '../..');

function walkDir(dir: string): string[] {
  let results: string[] = [];
  if (!fs.existsSync(dir)) return results;
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results = results.concat(walkDir(fullPath));
    } else if (/\.(tsx|ts)$/.test(entry.name)) {
      results.push(fullPath);
    }
  }
  return results;
}

const targetDir = path.join(rootDir, 'src/components');
const files = walkDir(targetDir);

interface Violation {
  file: string;
  reason: string;
}

// Arquivos com exceções documentadas e justificadas
const documentedExemptions: Record<string, string> = {
  // Navigation.tsx possui active:scale em outros botões (desktop/header),
  // e seus botões de dock inferior mobile são especificamente isentos para manter layout fixo sem jump.
};

const violations: Violation[] = [];
let auditedFilesWithButtons = 0;

for (const file of files) {
  const content = fs.readFileSync(file, 'utf8');
  if (/<button\b/.test(content)) {
    auditedFilesWithButtons++;
    const relPath = path.relative(rootDir, file);
    if (!content.includes('active:scale') && !documentedExemptions[relPath]) {
      violations.push({
        file: relPath,
        reason: 'Arquivo possui <button> mas nenhuma ocorrência de active:scale',
      });
    }
  }
}

console.log('--- AUDITORIA DE ANIMAÇÃO DE BOTÕES (TRAVA CONTRA REGRESSÃO) ---');
console.log(`Audited ${auditedFilesWithButtons} files containing <button> in src/components.`);

if (violations.length > 0) {
  console.error(`❌ [FAIL] Encontrados ${violations.length} arquivo(s) com <button> sem active:scale:\n`);
  for (const v of violations) {
    console.error(`  📄 ${v.file}: ${v.reason}`);
  }
  process.exit(1);
} else {
  console.log(`✅ [PASS] 100% dos ${auditedFilesWithButtons} arquivos com botão possuem active:scale padronizado.`);
}
