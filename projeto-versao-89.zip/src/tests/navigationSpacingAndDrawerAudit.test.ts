/**
 * src/tests/navigationSpacingAndDrawerAudit.test.ts
 *
 * Trava de regressão para:
 * 1. Padronização de espaçamento do dock inferior em todas as abas (App.tsx e Views).
 * 2. Animação fluida e sem conflitos no "Menu Completo" (MoreMenuDrawer e Navigation).
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '../..');

console.log('--- AUDITORIA DE ESPAÇAMENTO DA NAVEGAÇÃO E ANIMAÇÃO DO MENU COMPLETO ---');

let hasErrors = false;

// 1. Verificar App.tsx
const appTsxPath = path.join(rootDir, 'src/App.tsx');
const appTsx = fs.readFileSync(appTsxPath, 'utf8');

if (!appTsx.includes('pb-[calc(7.75rem+env(safe-area-inset-bottom')) {
  console.error('❌ [FAIL] src/App.tsx não possui o padding padronizado pb-[calc(7.75rem+env(safe-area-inset-bottom...]');
  hasErrors = true;
} else {
  console.log('✓ [PASS] src/App.tsx possui espaçamento padronizado para navegação inferior.');
}

// 2. Verificar Navigation.tsx (spotlight index inclui isMoreMenuOpen)
const navTsxPath = path.join(rootDir, 'src/components/Navigation.tsx');
const navTsx = fs.readFileSync(navTsxPath, 'utf8');

if (!navTsx.includes('if (isMoreMenuOpen) return 4;')) {
  console.error('❌ [FAIL] src/components/Navigation.tsx não inclui isMoreMenuOpen no activeMobileIndex do spotlight.');
  hasErrors = true;
} else {
  console.log('✓ [PASS] src/components/Navigation.tsx sincroniza o spotlight do limelight ao abrir o Menu Completo.');
}

if (!navTsx.includes('setIsMoreMenuOpen((prev) => !prev)')) {
  console.error('❌ [FAIL] src/components/Navigation.tsx não possui toggle no botão Menu Completo.');
  hasErrors = true;
} else {
  console.log('✓ [PASS] src/components/Navigation.tsx alterna o Menu Completo suavemente.');
}

// 2b. Verificar ausência de salto de layout no dock inferior mobile (zero active:scale e zero scale-105)
if (navTsx.includes('active:scale-95 transition-transform duration-150 py-0.5')) {
  console.error('❌ [FAIL] src/components/Navigation.tsx ainda contém active:scale-95 no dock inferior mobile, provocando salto de layout.');
  hasErrors = true;
} else if (navTsx.includes('drop-shadow-[0_0_7px_rgba(139,92,246,0.5)] scale-105')) {
  console.error('❌ [FAIL] src/components/Navigation.tsx ainda contém scale-105 no ícone ativo, provocando salto visual.');
  hasErrors = true;
} else {
  console.log('✓ [PASS] src/components/Navigation.tsx dock inferior mobile possui geometria fixa e zero saltos visuais.');
}

// 3. Verificar MoreMenuDrawer.tsx (AnimatePresence, motion/react, zero conflito GSAP em botões)
const drawerTsxPath = path.join(rootDir, 'src/components/MoreMenuDrawer.tsx');
const drawerTsx = fs.readFileSync(drawerTsxPath, 'utf8');

if (!drawerTsx.includes('AnimatePresence') || !drawerTsx.includes('motion/react')) {
  console.error('❌ [FAIL] src/components/MoreMenuDrawer.tsx não utiliza AnimatePresence e motion/react para animação fluida.');
  hasErrors = true;
} else {
  console.log('✓ [PASS] src/components/MoreMenuDrawer.tsx utiliza AnimatePresence e motion/react com saída suave.');
}

if (drawerTsx.includes('gsapButtonPress')) {
  console.error('❌ [FAIL] src/components/MoreMenuDrawer.tsx ainda contém chamadas a gsapButtonPress conflitantes com CSS transitions.');
  hasErrors = true;
} else {
  console.log('✓ [PASS] src/components/MoreMenuDrawer.tsx não possui conflito entre GSAP e CSS transitions em botões.');
}

// 4. Verificar ausência de pb- aleatório na raiz das views
const viewFiles = [
  'DashboardView.tsx',
  'MotosView.tsx',
  'KitnetsView.tsx',
  'FinanceiroView.tsx',
  'CentralDeCobrancasView.tsx',
  'ClientesView.tsx',
  'CalendarioOperacionalView.tsx',
  'RelatoriosView.tsx',
  'DocumentosView.tsx',
  'SettingsAndTimelineView.tsx',
];

for (const vf of viewFiles) {
  const filePath = path.join(rootDir, 'src/components', vf);
  if (fs.existsSync(filePath)) {
    const content = fs.readFileSync(filePath, 'utf8');
    // Pegar as primeiras 15 linhas do return principal
    const returnIndex = content.indexOf('return (');
    if (returnIndex !== -1) {
      const returnSnippet = content.substring(returnIndex, returnIndex + 300);
      const firstTag = returnSnippet.substring(0, returnSnippet.indexOf('>'));
      if (/\bpb-\d\b/.test(firstTag)) {
        console.error(`❌ [FAIL] ${vf} possui classe pb- despadronizada no elemento raiz: ${firstTag}`);
        hasErrors = true;
      }
    }
  }
}

if (hasErrors) {
  process.exit(1);
} else {
  console.log('✅ [SUCCESS] Todas as 10 abas e o Menu Completo passaram 100% nas travas de espaçamento e animação!\n');
}
