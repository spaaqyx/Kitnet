/**
 * Safe and Resilient Storage Adapter
 * Protects against QuotaExceededError, iframe security restrictions,
 * corrupt JSON parses, and mobile memory discards.
 */

const memoryStorageFallback = new Map<string, string>();

// IndexedDB async persistence layer to survive localStorage quota exhaustion
const IDB_NAME = 'gp_motos_kitnets_idb';
const IDB_STORE = 'keyval';
let idbPromise: Promise<IDBDatabase | null> | null = null;

function getIndexedDB(): Promise<IDBDatabase | null> {
  if (typeof window === 'undefined' || !window.indexedDB) {
    return Promise.resolve(null);
  }
  if (!idbPromise) {
    idbPromise = new Promise((resolve) => {
      try {
        const request = window.indexedDB.open(IDB_NAME, 1);
        request.onupgradeneeded = () => {
          const db = request.result;
          if (!db.objectStoreNames.contains(IDB_STORE)) {
            db.createObjectStore(IDB_STORE);
          }
        };
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => {
          console.warn('[SafeStorage] IndexedDB open failed:', request.error);
          resolve(null);
        };
      } catch (err) {
        console.warn('[SafeStorage] IndexedDB initialization error:', err);
        resolve(null);
      }
    });
  }
  return idbPromise;
}

function persistToIndexedDB(key: string, value: string): Promise<boolean> {
  return getIndexedDB().then((db) => {
    if (!db) return false;
    return new Promise<boolean>((resolve) => {
      try {
        const tx = db.transaction(IDB_STORE, 'readwrite');
        const store = tx.objectStore(IDB_STORE);
        const req = store.put(value, key);
        req.onsuccess = () => resolve(true);
        req.onerror = () => {
          console.warn(`[SafeStorage] Failed to save key "${key}" to IndexedDB:`, req.error);
          resolve(false);
        };
      } catch (e) {
        console.warn(`[SafeStorage] Failed to save key "${key}" to IndexedDB:`, e);
        resolve(false);
      }
    });
  }).catch(() => false);
}

function removeFromIndexedDB(key: string): void {
  getIndexedDB().then((db) => {
    if (!db) return;
    try {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      tx.objectStore(IDB_STORE).delete(key);
    } catch (e) {
      console.warn(`[SafeStorage] Failed to delete key "${key}" from IndexedDB:`, e);
    }
  }).catch(() => {});
}

export function getFromIndexedDB(key: string): Promise<string | null> {
  return new Promise((resolve) => {
    getIndexedDB().then((db) => {
      if (!db) return resolve(null);
      try {
        const tx = db.transaction(IDB_STORE, 'readonly');
        const store = tx.objectStore(IDB_STORE);
        const req = store.get(key);
        req.onsuccess = () => resolve(req.result ?? null);
        req.onerror = () => resolve(null);
      } catch {
        resolve(null);
      }
    }).catch(() => resolve(null));
  });
}

export async function syncFromIndexedDBToMemory(): Promise<void> {
  const db = await getIndexedDB();
  if (!db) return;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(IDB_STORE, 'readonly');
      const store = tx.objectStore(IDB_STORE);
      const req = store.openCursor();
      req.onsuccess = (e) => {
        const cursor = (e.target as IDBRequest<IDBCursorWithValue>).result;
        if (cursor) {
          const k = String(cursor.key);
          const val = String(cursor.value);
          if (!memoryStorageFallback.has(k)) {
            memoryStorageFallback.set(k, val);
          }
          if (canUseLocalStorage && !window.localStorage.getItem(k)) {
            try {
              window.localStorage.setItem(k, val);
            } catch {
              // quota reached
            }
          }
          cursor.continue();
        } else {
          resolve();
        }
      };
      req.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

// Auto-run IndexedDB sync in background on script load
if (typeof window !== 'undefined') {
  syncFromIndexedDBToMemory().catch(() => {});
}

function isStorageAvailable(type: 'localStorage' | 'sessionStorage'): boolean {
  if (typeof window === 'undefined') return false;
  try {
    const storage = window[type];
    if (!storage) return false;
    const testKey = '__gp_test_storage__';
    storage.setItem(testKey, testKey);
    storage.removeItem(testKey);
    return true;
  } catch {
    return false;
  }
}

const canUseLocalStorage = isStorageAvailable('localStorage');
const canUseSessionStorage = isStorageAvailable('sessionStorage');

export const safeLocalStorage = {
  getItem: (key: string): string | null => {
    try {
      if (canUseLocalStorage) {
        return window.localStorage.getItem(key);
      }
    } catch (e) {
      console.warn(`[SafeStorage] Could not read localStorage key "${key}":`, e);
    }
    return memoryStorageFallback.get(key) ?? null;
  },

  setItem: (key: string, value: string): boolean => {
    // Always mirror to IndexedDB for persistent backup beyond 5MB
    persistToIndexedDB(key, value);

    try {
      if (canUseLocalStorage) {
        window.localStorage.setItem(key, value);
        memoryStorageFallback.set(key, value);
        return true;
      }
    } catch (e: any) {
      console.warn(`[SafeStorage] localStorage.setItem failed for key "${key}". Falling back to memory & IndexedDB storage.`, e);
      // If quota exceeded, notify system and attempt cleaning
      if (e?.name === 'QuotaExceededError' || e?.code === 22 || e?.code === 1014) {
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('storage-quota-warning'));
        }
        try {
          cleanNonEssentialStorage();
          if (canUseLocalStorage) {
            window.localStorage.setItem(key, value);
            return true;
          }
        } catch {
          // Keep in memory fallback & IndexedDB
        }
      }
    }
    memoryStorageFallback.set(key, value);
    return false;
  },

  setItemAsync: async (key: string, value: string): Promise<boolean> => {
    const idbSuccess = await persistToIndexedDB(key, value);
    memoryStorageFallback.set(key, value);
    try {
      if (canUseLocalStorage) {
        window.localStorage.setItem(key, value);
        return true;
      }
    } catch (e: any) {
      if (e?.name === 'QuotaExceededError' || e?.code === 22 || e?.code === 1014) {
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('storage-quota-warning'));
        }
      }
    }
    return idbSuccess;
  },

  removeItem: (key: string): void => {
    removeFromIndexedDB(key);
    try {
      if (canUseLocalStorage) {
        window.localStorage.removeItem(key);
      }
    } catch (e) {
      console.warn(`[SafeStorage] Could not remove localStorage key "${key}":`, e);
    }
    memoryStorageFallback.delete(key);
  },

  clear: (): void => {
    try {
      if (canUseLocalStorage) {
        window.localStorage.clear();
      }
    } catch (e) {
      console.warn('[SafeStorage] Could not clear localStorage:', e);
    }
    memoryStorageFallback.clear();
  },

  keys: (): string[] => {
    try {
      if (canUseLocalStorage) {
        return Object.keys(window.localStorage);
      }
    } catch (e) {
      console.warn('[SafeStorage] Could not list localStorage keys:', e);
    }
    return Array.from(memoryStorageFallback.keys());
  },
};

export const safeSessionStorage = {
  getItem: (key: string): string | null => {
    try {
      if (canUseSessionStorage) {
        return window.sessionStorage.getItem(key);
      }
    } catch (e) {
      console.warn(`[SafeStorage] Could not read sessionStorage key "${key}":`, e);
    }
    return safeLocalStorage.getItem(`session_${key}`);
  },

  setItem: (key: string, value: string): void => {
    try {
      if (canUseSessionStorage) {
        window.sessionStorage.setItem(key, value);
      }
    } catch (e) {
      console.warn(`[SafeStorage] Could not set sessionStorage key "${key}":`, e);
    }
    safeLocalStorage.setItem(`session_${key}`, value);
  },

  removeItem: (key: string): void => {
    try {
      if (canUseSessionStorage) {
        window.sessionStorage.removeItem(key);
      }
    } catch (e) {
      console.warn(`[SafeStorage] Could not remove sessionStorage key "${key}":`, e);
    }
    safeLocalStorage.removeItem(`session_${key}`);
  },
};

/**
 * Safely parses JSON with a default fallback, never throwing exceptions
 */
export function safeJsonParse<T>(jsonString: string | null | undefined, fallback: T): T {
  if (!jsonString) return fallback;
  try {
    const parsed = JSON.parse(jsonString);
    return parsed !== null && parsed !== undefined ? (parsed as T) : fallback;
  } catch (e) {
    console.warn('[SafeStorage] JSON parse failed, returning fallback:', e);
    return fallback;
  }
}

/**
 * Detailed information on browser storage utilization and quotas
 */
export interface StorageUsageDetails {
  usedBytes: number;
  usedMB: number;
  usedFormatted: string;
  maxQuotaBytes: number;
  maxQuotaMB: number;
  percentage: number;
  isNearLimit: boolean;
  isCritical: boolean;
  keysCount: number;
}

/**
 * Calculates current storage usage in bytes and percentage against ~5MB quota
 */
export function getStorageUsage(): {
  usedBytes: number;
  usedMB: number;
  percentage: number;
  isNearLimit: boolean;
} {
  const details = getDetailedStorageUsage();
  return {
    usedBytes: details.usedBytes,
    usedMB: details.usedMB,
    percentage: details.percentage,
    isNearLimit: details.isNearLimit,
  };
}

/**
 * Calculates detailed storage metrics including formatted strings and keys count
 */
export function getDetailedStorageUsage(): StorageUsageDetails {
  try {
    let totalBytes = 0;
    let keysCount = 0;
    if (canUseLocalStorage) {
      keysCount = window.localStorage.length;
      for (let i = 0; i < window.localStorage.length; i++) {
        const key = window.localStorage.key(i);
        if (key) {
          const val = window.localStorage.getItem(key) || '';
          totalBytes += (key.length + val.length) * 2; // UTF-16 approximate
        }
      }
    }
    const maxQuota = 5 * 1024 * 1024; // 5 MB standard browser limit
    const usedMB = Number((totalBytes / (1024 * 1024)).toFixed(2));
    const percentage = Math.min(100, Math.round((totalBytes / maxQuota) * 100));
    const isNearLimit = percentage >= 70; // 70% threshold (3.5MB)
    const isCritical = percentage >= 90; // 90% threshold (4.5MB)

    const formatBytes = (bytes: number): string => {
      if (bytes < 1024) return `${bytes} B`;
      if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
      return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
    };

    return {
      usedBytes: totalBytes,
      usedMB,
      usedFormatted: formatBytes(totalBytes),
      maxQuotaBytes: maxQuota,
      maxQuotaMB: 5.0,
      percentage,
      isNearLimit,
      isCritical,
      keysCount,
    };
  } catch {
    return {
      usedBytes: 0,
      usedMB: 0,
      usedFormatted: '0 B',
      maxQuotaBytes: 5 * 1024 * 1024,
      maxQuotaMB: 5.0,
      percentage: 0,
      isNearLimit: false,
      isCritical: false,
      keysCount: 0,
    };
  }
}

/**
 * Asynchronously queries the browser's storage manager API (navigator.storage.estimate)
 */
export async function getStorageQuotaEstimate(): Promise<{
  usageBytes: number;
  quotaBytes: number;
  usageFormatted: string;
  quotaFormatted: string;
  percentage: number;
} | null> {
  if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.estimate) {
    try {
      const est = await navigator.storage.estimate();
      const usage = est.usage || 0;
      const quota = est.quota || 0;
      const pct = quota > 0 ? Math.min(100, Math.round((usage / quota) * 100)) : 0;
      const fmt = (bytes: number) => {
        if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
        if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
        return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
      };
      return {
        usageBytes: usage,
        quotaBytes: quota,
        usageFormatted: fmt(usage),
        quotaFormatted: fmt(quota),
        percentage: pct,
      };
    } catch {
      return null;
    }
  }
  return null;
}

/**
 * Removes temporary/transient keys to free up localStorage if quota is tight
 */
function cleanNonEssentialStorage(): void {
  try {
    if (!canUseLocalStorage) return;
    const keysToRemove = [];
    for (let i = 0; i < window.localStorage.length; i++) {
      const k = window.localStorage.key(i);
      if (k && (k.startsWith('gp_last_notified_') || k.startsWith('temp_') || k.startsWith('draft_'))) {
        keysToRemove.push(k);
      }
    }
    keysToRemove.forEach((k) => window.localStorage.removeItem(k));
  } catch {
    // Ignore
  }
}
