import React from 'react';
import { Motorbike, Home, CheckCircle2, AlertCircle, Clock, Calendar, FileText } from 'lucide-react';
import { MotoContract, KitnetContract, Moto, Kitnet } from '../../../types';
import { isInstallmentOverdue } from '../../../utils/formatters';

interface ClientDetailContractsTabProps {
  userContracts: (MotoContract | KitnetContract)[];
  tenantType: 'moto' | 'kitnet';
  motos: Moto[];
  kitnets: Kitnet[];
  formatCurrency: (value: number) => string;
  formatDate: (dateStr: string) => string;
}

export const ClientDetailContractsTab: React.FC<ClientDetailContractsTabProps> = ({
  userContracts,
  tenantType,
  motos,
  kitnets,
  formatCurrency,
  formatDate,
}) => {
  if (userContracts.length === 0) {
    return (
      <div className="p-8 rounded-2xl bg-surface-subtle border border-border-subtle text-center space-y-2">
        <FileText className="w-8 h-8 text-text-muted mx-auto" />
        <h4 className="text-sm font-bold text-white">Nenhum contrato ativo encontrado</h4>
        <p className="text-xs text-text-muted">Este cliente ainda não possui vínculos contratuais registrados.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4 font-sans text-text-primary">
      {userContracts.map((contract) => {
        const moto = tenantType === 'moto' ? motos.find((m) => m.id === (contract as MotoContract).motoId) : null;
        const kitnet = tenantType === 'kitnet' ? kitnets.find((k) => k.id === (contract as KitnetContract).kitnetId) : null;
        const paid = contract.installments.filter((i) => i.status === 'pago');
        const percent = Math.round((paid.length / contract.durationMonths) * 100);

        return (
          <div key={contract.id} className="bg-surface-subtle p-4 sm:p-5 rounded-2xl border border-border-subtle shadow-lg space-y-4">
            {/* Header info */}
            <div className="flex items-center justify-between gap-3 pb-3 border-b border-border-subtle flex-wrap">
              <div className="flex items-center gap-2.5">
                <div
                  className={`p-2 rounded-xl border ${
                    tenantType === 'moto'
                      ? 'bg-orange-500/10 border-orange-500/20 text-orange-400'
                      : 'bg-sky-500/10 border-sky-500/20 text-sky-400'
                  }`}
                >
                  {tenantType === 'moto' ? <Motorbike className="w-4 h-4" /> : <Home className="w-4 h-4" />}
                </div>
                <div>
                  <span className="font-bold text-white text-sm block">
                    {moto ? `${moto.brand} ${moto.model} (${moto.plate})` : kitnet ? `${kitnet.name} - Nº ${kitnet.number}` : 'Contrato Ativo'}
                  </span>
                  <span className="text-[11px] text-text-muted font-mono">ID Contrato: #{contract.id.slice(0, 8)}</span>
                </div>
              </div>

              <span
                className={`px-2.5 py-1 rounded-lg text-[10px] font-bold tracking-wider uppercase border shadow-sm ${
                  contract.status === 'ativo'
                    ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                    : 'bg-slate-700/30 text-text-secondary border-border-subtle'
                }`}
              >
                {contract.status.toUpperCase()}
              </span>
            </div>

            {/* Visual Progress - Clean */}
            <div className="space-y-2 py-1">
              <div className="flex justify-between text-xs text-text-secondary">
                <span className="font-medium">
                  Progresso: <strong className="text-white">{paid.length}</strong> de <strong className="text-white">{contract.durationMonths}</strong> parcelas pagas
                </span>
                <strong
                  className={`font-mono ${
                    tenantType === 'moto' ? 'text-orange-400' : 'text-sky-400'
                  }`}
                >
                  {percent}%
                </strong>
              </div>
              <div className="w-full bg-surface-subtle rounded-full h-2 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    tenantType === 'moto'
                      ? 'bg-gradient-to-r from-orange-500 to-amber-400'
                      : 'bg-gradient-to-r from-sky-500 to-teal-400'
                  }`}
                  style={{ width: `${percent}%` }}
                />
              </div>
            </div>

            {/* Installments Table */}
            <div className="space-y-2 pt-2 border-t border-border-subtle">
              <span className="text-[11px] font-bold text-text-muted uppercase tracking-wider block">
                Grade de Parcelas & Vencimentos:
              </span>
              <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1 no-scrollbar">
                {contract.installments.map((inst) => {
                  const isPaid = inst.status === 'pago';
                  const isOverdue = isInstallmentOverdue(inst);
                  const statusLabel = isPaid ? 'PAGO' : isOverdue ? 'ATRASADO' : 'PENDENTE';

                  const badgeClass = isPaid
                    ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                    : isOverdue
                    ? 'bg-rose-500/15 text-rose-400 border-rose-500/30'
                    : 'bg-violet-500/15 text-violet-300 border-violet-500/30';

                  return (
                    <div
                      key={inst.id}
                      className="py-2 px-3 hover:bg-surface-hover rounded-xl flex items-center justify-between text-xs transition-colors border-b border-border-subtle last:border-0"
                    >
                      <div className="flex items-center gap-2.5">
                        {isPaid ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        ) : isOverdue ? (
                          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                        ) : (
                          <Clock className="w-4 h-4 text-violet-400 shrink-0" />
                        )}
                        <div>
                          <span className="font-semibold text-white">
                            Parcela {inst.number}/{contract.durationMonths}
                          </span>
                          <span className="text-text-muted ml-2 font-mono text-[11px]">
                            Vencimento: {formatDate(inst.dueDate)}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2.5 shrink-0">
                        <span className="font-mono font-bold text-white text-xs">{formatCurrency(inst.amount)}</span>
                        <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border shadow-xs ${badgeClass}`}>
                          {statusLabel}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

