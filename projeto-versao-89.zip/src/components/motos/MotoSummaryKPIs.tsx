import React from 'react';
import { motion } from 'motion/react';
import { Plus, Percent, ShieldCheck, Motorbike, Crosshair, Calculator } from 'lucide-react';
import { AnimatedNumber } from '../AnimatedNumber';

interface MotoSummaryKPIsProps {
  totalMotos: number;
  occupancyPercentage: number;
  occupiedMotos: number;
  activeMonthlyRevenue: number;
  activeWeeklyRevenue?: number;
  availableMotos: number;
  maintenanceMotos: number;
  currentFilter?: string;
  onAddNewMoto: () => void;
  onOpenSimulator?: () => void;
  onFilterClick?: (filter: string) => void;
}

export const MotoSummaryKPIs: React.FC<MotoSummaryKPIsProps> = ({
  totalMotos,
  occupancyPercentage,
  occupiedMotos,
  activeMonthlyRevenue,
  activeWeeklyRevenue = 0,
  availableMotos,
  maintenanceMotos,
  currentFilter,
  onAddNewMoto,
  onOpenSimulator,
  onFilterClick,
}) => {
  return (
    <div className="bg-surface-sidebar rounded-2xl border border-border-subtle p-4 sm:p-5 shadow-lg shadow-black/40">
      {/* Header with Title, Badge and Buttons */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2.5">
          <h1 className="text-lg sm:text-xl font-bold text-text-primary tracking-tight">
            Gestão da Frota de Motos
          </h1>
          <span className="px-2.5 py-0.5 rounded-lg text-xs font-semibold bg-purple-500/10 dark:bg-surface-elevated text-purple-700 dark:text-action-light border border-purple-500/30 dark:border-action-primary/30">
            {totalMotos} {totalMotos === 1 ? 'moto' : 'motos'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {onOpenSimulator && (
            <button
              type="button"
              onClick={onOpenSimulator}
              className="h-8.5 sm:h-9 px-3 rounded-xl bg-surface-subtle hover:bg-surface-card text-text-secondary hover:text-slate-900 dark:hover:text-white border border-border-subtle hover:border-action-primary/40 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer active:scale-95 shadow-xs shrink-0"
            >
              <Calculator className="w-3.5 h-3.5 text-violet-500 dark:text-violet-400 shrink-0" />
              <span className="hidden sm:inline text-text-muted">Simulador de</span>
              <span className="font-semibold text-text-primary">Lucro</span>
            </button>
          )}

          <motion.button
            id="btn-add-moto-main"
            type="button"
            onClick={onAddNewMoto}
            whileTap={{ scale: 0.96 }}
            className="group h-8.5 sm:h-9 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-1.5 bg-action-primary hover:bg-action-hover text-white shadow-sm cursor-pointer transition-colors shrink-0"
          >
            <Plus className="w-4 h-4 text-white shrink-0 transition-transform duration-150 group-hover:rotate-90" />
            <span className="tracking-tight whitespace-nowrap">Cadastrar Moto</span>
          </motion.button>
        </div>
      </div>

      {/* Compact 4-Metric Grid (2x2 on mobile, 4 columns on tablet/desktop) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3 mt-3.5 sm:mt-4">
        {/* 1. Total de Motos */}
        <div
          onClick={() => onFilterClick && onFilterClick('todos')}
          className="bg-surface-card dark:bg-surface-subtle rounded-xl p-3 sm:p-3.5 border border-border-subtle hover:border-action-primary/40 transition-all cursor-pointer group flex flex-col justify-between shadow-xs"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] sm:text-xs text-text-muted dark:text-text-secondary font-medium truncate">
              Total da Frota
            </span>
            <div className="w-7 h-7 rounded-lg bg-purple-500/15 flex items-center justify-center text-purple-600 dark:text-purple-400 shrink-0 border border-purple-500/25">
              <Motorbike className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-1.5">
            <div className="text-lg sm:text-xl font-bold text-text-primary tracking-tight">
              <AnimatedNumber value={totalMotos} />
            </div>
            <span className="text-[10px] sm:text-[11px] text-text-muted block mt-0.5 truncate">
              {totalMotos} cadastradas
            </span>
          </div>
        </div>

        {/* 2. Taxa de Ocupação */}
        <div
          onClick={() => onFilterClick && onFilterClick('alugada')}
          className="bg-surface-card dark:bg-surface-subtle rounded-xl p-3 sm:p-3.5 border border-border-subtle hover:border-money-positive/40 transition-all cursor-pointer group flex flex-col justify-between shadow-xs"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] sm:text-xs text-text-muted dark:text-text-secondary font-medium truncate">
              Ocupação
            </span>
            <div className="w-7 h-7 rounded-lg bg-emerald-500/15 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shrink-0 border border-emerald-500/25">
              <Percent className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-1.5">
            <div className="text-lg sm:text-xl font-bold text-money-positive tracking-tight">
              <AnimatedNumber value={occupancyPercentage} format="percent" />
            </div>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="text-[10px] sm:text-[11px] text-text-muted truncate">
                {occupiedMotos}/{totalMotos} alugadas
              </span>
            </div>
          </div>
        </div>

        {/* 3. Receita Mensal Ativa */}
        <div
          onClick={() => onFilterClick && onFilterClick('alugada')}
          className="bg-surface-card dark:bg-surface-subtle rounded-xl p-3 sm:p-3.5 border border-border-subtle hover:border-money-positive/40 transition-all cursor-pointer group flex flex-col justify-between shadow-xs"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] sm:text-xs text-text-muted dark:text-text-secondary font-medium truncate">
              Receita Mensal
            </span>
            <div className="w-7 h-7 rounded-lg bg-emerald-500/15 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shrink-0 border border-emerald-500/25">
              <Crosshair className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-1.5">
            <div className="text-lg sm:text-xl font-bold text-money-positive tracking-tight truncate">
              <AnimatedNumber value={activeMonthlyRevenue} format="currency" />
            </div>
            <span className="text-[10px] sm:text-[11px] text-text-muted block mt-0.5 truncate">
              {activeWeeklyRevenue > 0
                ? `${activeWeeklyRevenue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}/sem em contratos`
                : `${occupiedMotos} ${occupiedMotos === 1 ? 'moto alugada' : 'motos alugadas'}`}
            </span>
          </div>
        </div>

        {/* 4. Disponíveis / Manutenção */}
        <div
          onClick={() => {
            if (!onFilterClick) return;
            if (currentFilter === 'disponivel' && maintenanceMotos > 0) {
              onFilterClick('manutencao');
            } else if (currentFilter === 'manutencao' && availableMotos > 0) {
              onFilterClick('disponivel');
            } else if (availableMotos > 0) {
              onFilterClick('disponivel');
            } else if (maintenanceMotos > 0) {
              onFilterClick('manutencao');
            } else {
              onFilterClick('disponivel');
            }
          }}
          className="bg-surface-card dark:bg-surface-subtle rounded-xl p-3 sm:p-3.5 border border-border-subtle hover:border-sky-500/40 transition-all cursor-pointer group flex flex-col justify-between shadow-xs"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] sm:text-xs text-text-muted dark:text-text-secondary font-medium truncate">
              Disp. / Manutenção
            </span>
            <div className="w-7 h-7 rounded-lg bg-sky-500/15 flex items-center justify-center text-sky-600 dark:text-sky-400 shrink-0 border border-sky-500/25">
              <ShieldCheck className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-1.5">
            <div className="text-lg sm:text-xl font-bold text-text-primary tracking-tight">
              {availableMotos} / {maintenanceMotos}
            </div>
            <span className="text-[10px] sm:text-[11px] text-text-muted block mt-0.5 truncate">
              {availableMotos} livres • {maintenanceMotos} manutenção
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
