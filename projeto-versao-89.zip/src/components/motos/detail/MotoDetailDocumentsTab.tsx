import React from 'react';
import { Moto } from '../../../types';
import { FileText, ExternalLink } from 'lucide-react';

interface MotoDetailDocumentsTabProps {
  moto: Moto;
}

export const MotoDetailDocumentsTab: React.FC<MotoDetailDocumentsTabProps> = ({ moto }) => {
  return (
    <div className="space-y-3">
      <h4 className="text-xs font-semibold uppercase tracking-wider text-text-secondary">
        Arquivos & Comprovantes da Moto
      </h4>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {[
          { name: 'CRLV Digital', key: 'crlv', url: moto.documents?.crlv },
          { name: 'Nota Fiscal de Compra', key: 'nf', url: moto.documents?.notaFiscal },
          { name: 'Apólice do Seguro', key: 'seg', url: moto.documents?.seguro },
        ].map((doc, idx) => (
          <div
            key={idx}
            className="p-3 bg-surface-base rounded-xl border border-border-subtle flex items-center justify-between text-xs"
          >
            <div className="flex items-center gap-2.5">
              <FileText className="w-4 h-4 text-emerald-400" />
              <span className="font-medium text-text-primary">{doc.name}</span>
            </div>
            {doc.url ? (
              <a
                href={doc.url}
                target="_blank"
                rel="noreferrer"
                className="px-2.5 py-1 rounded bg-surface-card hover:bg-surface-elevated text-[11px] text-emerald-400 font-medium flex items-center gap-1 border border-border-subtle"
              >
                <span>Ver</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            ) : (
              <span className="text-[10px] text-text-muted">Pendente</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
