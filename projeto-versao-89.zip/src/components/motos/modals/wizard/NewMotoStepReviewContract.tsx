import React, { useState } from 'react';
import {
  FileText,
  Copy,
  Printer,
  Download,
  Check,
  FileCheck,
  ShieldCheck,
  Calendar,
  Clock,
  Gauge,
  Fuel,
  Video,
  CheckCircle2,
  AlertCircle,
  Sparkles,
} from 'lucide-react';
import { formatCPF, formatDate } from '../../../../utils/formatters';
import {
  generateMotoRentalContractPdfFile,
  MotoRentalContractPdfOptions,
} from '../../../../utils/pdf/motoPdfGenerator';
import {
  extractOfficialMotoContractData,
  getOfficialMotoContractSections,
  getOfficialMotoContractRawText,
} from '../../../../utils/pdf/officialMotoContract';
import { copyTextToClipboard, printContractDocument } from '../../../../utils/printHelper';
import {
  IconPneuDianteiro,
  IconPneuTraseiro,
  IconFreioDianteiro,
  IconFreioTraseiro,
  IconFarolLanternas,
  IconSetas,
  IconBuzina,
  IconRetrovisores,
  IconAssentoBanco,
  IconPinturaLataria,
  IconCombustivel,
  IconCapacete,
  IconCapaChuva,
  IconSuporteCelular,
  IconBauBauleto,
  IconChaveReserva,
  IconOutros,
  IconStatusBom,
  IconStatusRegular,
  IconStatusRuim,
} from './inspectionIcons';
import { HighlightMissingText } from '../../../../components/HighlightMissingText';

interface NewMotoStepReviewContractProps {
  form: any;
  settings: any;
}

export const NewMotoStepReviewContract: React.FC<NewMotoStepReviewContractProps> = ({
  form,
  settings,
}) => {
  const [contractTab, setContractTab] = useState<'preview' | 'text'>('preview');
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Fonte canônica única de dados do contrato oficial
  const contractData = extractOfficialMotoContractData(form, settings);
  const sections = getOfficialMotoContractSections(contractData);
  const rawContractText = getOfficialMotoContractRawText(contractData);

  const getPdfOptions = (autoDownload = true): MotoRentalContractPdfOptions => ({
    moto: {
      id: 'preview',
      brand: contractData.moto.brand,
      model: contractData.moto.model,
      plate: contractData.moto.plate,
      year: Number(contractData.moto.year),
      color: contractData.moto.color,
      renavam: contractData.moto.renavam,
      chassi: contractData.moto.chassi,
      currentKm: Number(contractData.moto.initialKm),
      purchasePrice: Number(form.purchasePrice) || 0,
      purchaseDate: form.purchaseDate || contractData.terms.startDate,
      status: 'alugada' as const,
      insuranceDeductible: contractData.terms.depositFormatted,
      documents: [],
      photos: [],
      kmLogs: [],
    } as any,
    tenant: {
      id: 'preview',
      fullName: contractData.locatario.name,
      cpf: contractData.locatario.cpf.replace(/\D/g, ''),
      rg: contractData.locatario.rg || '',
      phone: contractData.locatario.phone.replace(/\D/g, ''),
      whatsapp: contractData.locatario.whatsapp.replace(/\D/g, ''),
      email: contractData.locatario.email,
      address: contractData.locatario.address,
      profession: contractData.locatario.profession,
      company: form.tenantCompany || 'Autônomo',
      income: Number(form.monthlyIncome) || contractData.terms.weeklyValue * 4,
      cnh: {
        number: contractData.locatario.cnh,
        category: contractData.locatario.cnhCategory,
        expirationDate: form.cnhExpiration || '',
      },
      birthDate: form.tenantBirthDate || '',
      documents: form.documents || {},
      approvalChecklist: {
        cnhValid: true,
        docsChecked: true,
        addressValidated: true,
        incomeAnalyzed: true,
        depositReceived: true,
        contractSigned: true,
        result: 'aprovado' as const,
      },
    } as any,
    contract: {
      id: 'preview',
      motoId: 'preview',
      tenantId: 'preview',
      durationMonths: contractData.terms.minimumMonths,
      paymentFrequency: contractData.terms.isWeekly ? 'semanal' : 'mensal',
      startDate: contractData.terms.startDate,
      dueDay: form.dueDay || 10,
      dueDayOfWeek: form.dueDayOfWeek ?? 1,
      monthlyValue: contractData.terms.monthlyValue,
      weeklyValue: contractData.terms.weeklyValue,
      deposit: contractData.terms.deposit,
      depositStatus: form.depositStatus || 'retida',
      totalAgreedValue: contractData.terms.isWeekly
        ? Math.round(contractData.terms.minimumMonths * (52 / 12) * contractData.terms.weeklyValue)
        : contractData.terms.monthlyValue * contractData.terms.minimumMonths,
      insuranceDeductible: contractData.terms.depositFormatted,
      status: 'ativo' as const,
      installments: [],
      inspection: contractData.inspection,
    } as any,
    inspection: contractData.inspection,
    settings,
    autoDownload,
  });

  const validateBeforeAction = () => {
    if (!contractData.moto.hasModel) {
      alert('Por favor, informe o Modelo da moto para emitir o contrato.');
      return false;
    }
    if (!contractData.moto.hasPlate) {
      alert('Por favor, informe a Placa da moto para emitir o contrato.');
      return false;
    }
    return true;
  };

  const handleCopy = async () => {
    if (!validateBeforeAction()) return;
    const success = await copyTextToClipboard(rawContractText);
    if (success) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handlePrint = () => {
    if (!validateBeforeAction()) return;
    printContractDocument('Contrato Oficial de Locação de Motocicleta', rawContractText);
  };

  const handleDownloadPdf = () => {
    if (!validateBeforeAction()) return;
    try {
      setDownloading(true);
      generateMotoRentalContractPdfFile(getPdfOptions(true));
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3000);
    } catch (err) {
      console.error('Erro ao gerar PDF da moto:', err);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="space-y-4 sm:space-y-5 font-sans" id="moto-contract-review-container">
      {/* CABEÇALHO DA ETAPA */}
      <div className="flex items-center justify-between border-b border-border-subtle pb-3.5">
        <div className="flex items-center gap-2.5 text-white font-bold text-sm sm:text-base min-w-0">
          <span className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center text-xs font-black shrink-0">
            7
          </span>
          <span className="truncate">Contrato Oficial de Locação & Emissão</span>
        </div>
        <span className="text-xs text-emerald-400 font-semibold bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20 hidden sm:inline-block whitespace-nowrap shrink-0">
          12 Cláusulas Oficiais + Anexo I
        </span>
      </div>

      {/* AVISO SE FALTAR DADOS DO VEÍCULO */}
      {(!contractData.moto.hasModel || !contractData.moto.hasPlate) && (
        <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/25 text-xs text-rose-300 flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
          <div>
            <strong className="block text-rose-200">Atenção: Dados da motocicleta incompletos</strong>
            <span>
              {!contractData.moto.hasModel ? 'O Modelo da moto não foi preenchido. ' : ''}
              {!contractData.moto.hasPlate ? 'A Placa da moto não foi preenchida. ' : ''}
              Preencha os dados do veículo na Etapa 1 para emitir o contrato oficial.
            </span>
          </div>
        </div>
      )}

      {/* RESUMO RÁPIDO DO CONTRATO */}
      <div className="p-4 sm:p-5 rounded-2xl bg-surface-base border border-border-subtle text-xs">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="space-y-1">
            <span className="text-text-muted text-[11px] font-medium block">Locador & Veículo:</span>
            <strong className="text-text-primary text-sm block truncate font-bold">
              <HighlightMissingText text={contractData.locador.name} />
            </strong>
            <span className="text-text-secondary truncate block text-[11px]">
              <HighlightMissingText
                text={
                  contractData.moto.hasModel
                    ? `${contractData.moto.brandModelDisplay}${
                        contractData.moto.year && contractData.moto.year !== 'Não informado'
                          ? ` (${contractData.moto.year})`
                          : ''
                      }`
                    : contractData.moto.brandModelDisplay
                }
              />{' '}
              •{' '}
              <span
                className={`font-mono font-semibold ${
                  contractData.moto.hasPlate ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                <HighlightMissingText text={contractData.moto.plate} />
              </span>
            </span>
          </div>

          <div className="space-y-1">
            <span className="text-text-muted text-[11px] font-medium block">Locatário / Condutor:</span>
            <strong className="text-text-primary text-sm block truncate font-bold">
              <HighlightMissingText text={contractData.locatario.name} />
            </strong>
            <span className="text-text-secondary block text-[11px] font-mono">
              CPF: <HighlightMissingText text={formatCPF(contractData.locatario.cpf)} /> • CNH: <HighlightMissingText text={`${contractData.locatario.cnh} (${contractData.locatario.cnhCategory})`} />
            </span>
          </div>

          <div className="space-y-1">
            <span className="text-text-muted text-[11px] font-medium block">Valores & Pagamento:</span>
            <strong className="text-emerald-400 text-sm block font-mono font-bold">
              {contractData.terms.isWeekly
                ? `${contractData.terms.weeklyValueFormatted} / semana`
                : `${contractData.terms.monthlyValueFormatted} / mês`}
            </strong>
            <span className="text-text-secondary block text-[11px]">
              {contractData.terms.minimumMonths} meses de prazo mínimo • Vencimento: {contractData.terms.dueDayName} até às {contractData.terms.dueLimitTime}
            </span>
          </div>
        </div>
      </div>

      {/* TOOLBAR UNIFICADA RESPONSIVA */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2.5 sm:gap-3 p-2.5 sm:p-3.5 rounded-2xl bg-surface-base border border-border-subtle">
        {/* Toggle de Modo: Minuta Formatada vs Texto Puro */}
        <div className="grid grid-cols-2 w-full sm:w-auto items-center gap-1 p-1 bg-surface-base border border-border-subtle rounded-xl">
          <button
            type="button"
            id="btn-tab-preview"
            onClick={() => setContractTab('preview')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 ${
              contractTab === 'preview'
                ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 shadow-sm'
                : 'text-text-muted hover:text-text-primary'
            }`}
          >
            <FileCheck className="w-3.5 h-3.5" />
            <span className="truncate">Contrato Formatado</span>
          </button>

          <button
            type="button"
            id="btn-tab-text"
            onClick={() => setContractTab('text')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 ${
              contractTab === 'text'
                ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 shadow-sm'
                : 'text-text-muted hover:text-text-primary'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span className="truncate">Texto Puro</span>
          </button>
        </div>

        {/* Botões de Ação Direta */}
        <div className="grid grid-cols-2 sm:flex sm:items-center gap-2 w-full sm:w-auto">
          <button
            type="button"
            id="btn-copy-contract"
            onClick={handleCopy}
            className="px-3 py-2 rounded-xl bg-surface-subtle hover:bg-surface-hover border border-border-subtle text-text-primary font-semibold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer"
            title="Copiar texto integral do contrato oficial"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400 font-bold truncate">Copiado!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-text-muted" />
                <span className="truncate">Copiar Texto</span>
              </>
            )}
          </button>

          <button
            type="button"
            id="btn-print-contract"
            onClick={handlePrint}
            className="px-3 py-2 rounded-xl bg-surface-subtle hover:bg-surface-hover border border-border-subtle text-text-primary font-semibold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer"
            title="Imprimir contrato oficial completo"
          >
            <Printer className="w-3.5 h-3.5 text-text-muted" />
            <span className="truncate">Imprimir</span>
          </button>

          <button
            type="button"
            id="btn-download-pdf"
            onClick={handleDownloadPdf}
            disabled={downloading}
            className="col-span-2 sm:col-span-1 px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 hover:brightness-110 active:scale-95 transition-all cursor-pointer ring-1 ring-emerald-400/40"
            title="Baixar Contrato Oficial em PDF"
          >
            {downloadSuccess ? (
              <>
                <Check className="w-4 h-4 stroke-[3]" />
                <span>PDF Baixado!</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Baixar PDF Oficial</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* VISUALIZAÇÃO INTEGRAL DO CONTRATO OFICIAL */}
      {contractTab === 'preview' ? (
        <div
          id="official-contract-preview-scroll"
          className="p-5 sm:p-8 bg-surface-base border border-border-subtle rounded-2xl space-y-6 max-h-[62vh] overflow-y-auto font-sans shadow-2xl custom-scrollbar text-text-primary"
        >
          {/* CABEÇALHO FORMAL DO CONTRATO */}
          <div className="text-center pb-5 border-b border-border-subtle space-y-2">
            <div className="inline-flex items-center gap-1.5 bg-emerald-500/10 text-emerald-400 px-3 py-1 rounded-full border border-emerald-500/20 text-[10px] font-bold tracking-wider uppercase">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Contrato Oficial de Locação de Motocicleta</span>
            </div>
            <h2 className="text-base sm:text-lg font-black text-text-primary uppercase tracking-wide">
              CONTRATO DE LOCAÇÃO DE MOTOCICLETA COM PRAZO MÍNIMO E RENOVAÇÃO AUTOMÁTICA
            </h2>
            <p className="text-xs text-text-muted max-w-xl mx-auto">
              Instrumento Jurídico de Locação com Todas as Cláusulas Oficiais, Direitos, Deveres e Anexo I de Vistoria
            </p>
          </div>

          {/* TODAS AS CLÁUSULAS OFICIAIS RENDERIZADAS EM 100% PARIDADE */}
          <div className="space-y-5 text-xs leading-relaxed text-text-secondary divide-y divide-border-subtle">
            {sections.map((section, idx) => (
              <div key={idx} className={idx === 0 ? '' : 'pt-4'}>
                <h3 className="font-bold text-emerald-400 uppercase text-xs mb-2">
                  {section.title}
                </h3>
                <div className="space-y-2">
                  {section.paragraphs.map((p, pIdx) => {
                    // Detecção de marcadores ou alíneas
                    const isBullet =
                      p.startsWith('•') ||
                      p.startsWith('-') ||
                      /^[a-z]\)/i.test(p);
                    const isSubheading =
                      p.startsWith('1.1.') ||
                      p.startsWith('1.2.') ||
                      p.startsWith('Dados do Veículo:');

                    return (
                      <p
                        key={pIdx}
                        className={`${
                          isBullet
                            ? 'pl-4 text-text-primary border-l border-emerald-500/30 ml-1 py-0.5'
                            : isSubheading
                            ? 'font-medium text-text-primary'
                            : 'text-text-secondary'
                        }`}
                      >
                        <HighlightMissingText text={p} />
                      </p>
                    );
                  })}

                  {/* Renderiza bullets da seção para garantir que nenhuma cláusula (ex: Cláusula 3) seja truncada */}
                  {section.bullets && section.bullets.length > 0 && (
                    <div className="space-y-1.5 pt-1 pl-1">
                      {section.bullets.map((b, bIdx) => (
                        <div
                          key={bIdx}
                          className="flex items-start gap-2 pl-3 py-1 border-l-2 border-emerald-500/40 text-text-primary text-xs bg-emerald-500/[0.02] rounded-r-lg"
                        >
                          <span className="text-emerald-400 font-bold shrink-0">•</span>
                          <span><HighlightMissingText text={b} /></span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* LOCAL, DATA E ASSINATURAS DO CONTRATO PRINCIPAL */}
          <div className="pt-6 border-t border-border-subtle space-y-6">
            <p className="text-center text-xs text-text-secondary font-medium">
              {contractData.terms.witnessesCount === 0
                ? 'E, por estarem assim justas e contratadas, as partes assinam o presente contrato em 2 (duas) vias de igual teor e forma, para que produza seus regulares efeitos legais.'
                : contractData.terms.witnessesCount === 1
                ? 'E, por estarem assim justas e contratadas, as partes assinam o presente contrato em 2 (duas) vias de igual teor e forma, na presença de 1 (uma) testemunha instrumentária.'
                : 'E, por estarem assim justas e contratadas, as partes assinam o presente contrato em 2 (duas) vias de igual teor e forma, perante 2 (duas) testemunhas instrumentárias.'}
            </p>

            <p className="text-center font-bold text-xs text-text-primary">
              {contractData.terms.contractCity}, {contractData.terms.contractDateFormatted}.
            </p>

            {/* LINHAS DE ASSINATURA PRINCIPAIS */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-4">
              <div className="text-center border-t border-border-strong pt-2 space-y-0.5">
                <strong className="text-text-primary text-xs block font-bold">
                  <HighlightMissingText text={contractData.locador.name} />
                </strong>
                <span className="text-[11px] text-text-muted block uppercase tracking-wider">
                  LOCADOR (Proprietário)
                </span>
                <span className="text-[10px] text-text-muted block font-mono">
                  CPF: <HighlightMissingText text={formatCPF(contractData.locador.cpf)} />
                </span>
              </div>

              <div className="text-center border-t border-border-strong pt-2 space-y-0.5">
                <strong className="text-text-primary text-xs block font-bold">
                  <HighlightMissingText text={contractData.locatario.name} />
                </strong>
                <span className="text-[11px] text-text-muted block uppercase tracking-wider">
                  LOCATÁRIO (Condutor)
                </span>
                <span className="text-[10px] text-text-muted block font-mono">
                  CPF: <HighlightMissingText text={formatCPF(contractData.locatario.cpf)} />
                </span>
              </div>
            </div>

            {/* TESTEMUNHAS - APARECE SOMENTE SE WITNESSESCOUNT > 0 */}
            {contractData.terms.witnessesCount > 0 && (
              <div className="pt-4 border-t border-border-subtle">
                <span className="text-[10px] text-text-muted block uppercase tracking-wider font-bold mb-3 text-center">
                  TESTEMUNHA{contractData.terms.witnessesCount > 1 ? 'S INSTRUMENTÁRIAS' : ' INSTRUMENTÁRIA'}:
                </span>
                <div className={`grid grid-cols-1 ${contractData.terms.witnessesCount > 1 ? 'sm:grid-cols-2' : 'max-w-md mx-auto'} gap-6 text-[11px] text-text-secondary`}>
                  <div className="border-t border-border-subtle pt-2">
                    <p>1. Nome: {contractData.terms.witness1Name ? <span className="text-text-primary font-semibold">{contractData.terms.witness1Name}</span> : '_____________________________________'}</p>
                    <p className="mt-1">CPF: {contractData.terms.witness1Cpf ? <span className="text-text-primary font-mono">{formatCPF(contractData.terms.witness1Cpf)}</span> : '________________________________________'}</p>
                  </div>
                  {contractData.terms.witnessesCount > 1 && (
                    <div className="border-t border-border-subtle pt-2">
                      <p>2. Nome: {contractData.terms.witness2Name ? <span className="text-text-primary font-semibold">{contractData.terms.witness2Name}</span> : '_____________________________________'}</p>
                      <p className="mt-1">CPF: {contractData.terms.witness2Cpf ? <span className="text-text-primary font-mono">{formatCPF(contractData.terms.witness2Cpf)}</span> : '________________________________________'}</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* ANEXO I – TERMO DE VISTORIA E RETIRADA DO VEÍCULO (INTEGRAL E 100% SINCRONIZADO) */}
          <div className="pt-8 border-t-2 border-emerald-500/30 space-y-6">
            <div className="p-5 sm:p-7 rounded-2xl bg-surface-sidebar border border-border-subtle space-y-6 shadow-xl">
              {/* CABEÇALHO DO ANEXO I */}
              <div className="text-center pb-5 border-b border-border-subtle space-y-2">
                <div className="inline-flex items-center gap-1.5 bg-emerald-500/10 text-emerald-400 px-3 py-1 rounded-full border border-emerald-500/20 text-[10px] font-bold tracking-wider uppercase">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Anexo Oficial Integrante</span>
                </div>
                <h3 className="text-sm sm:text-base font-black text-text-primary uppercase tracking-wide">
                  ANEXO I – TERMO DE VISTORIA E RETIRADA DO VEÍCULO
                </h3>
                <p className="text-xs text-text-muted max-w-xl mx-auto">
                  Este termo é parte integrante e indissociável do Contrato de Locação de Motocicleta com Prazo Mínimo e Renovação Automática firmado entre as partes.
                </p>
              </div>

              {/* DADOS DE IDENTIFICAÇÃO E RETIRADA */}
              <div className="p-4 rounded-xl bg-surface-subtle border border-border-subtle space-y-3">
                <div className="text-[11px] font-bold text-text-secondary uppercase tracking-wider flex items-center gap-2">
                  <Gauge className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Dados da Entrega e Vistoria Inicial</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
                  <div className="p-2.5 rounded-lg bg-surface-card border border-border-subtle">
                    <span className="text-text-muted block text-[10px]">Data da Retirada:</span>
                    <strong className="text-text-primary font-sans text-xs">
                      {formatDate(contractData.inspection.date)}
                    </strong>
                  </div>
                  <div className="p-2.5 rounded-lg bg-surface-card border border-border-subtle">
                    <span className="text-text-muted block text-[10px]">Hora da Retirada:</span>
                    <strong className="text-text-primary font-sans text-xs">
                      {contractData.inspection.time || '10:00'}
                    </strong>
                  </div>
                  <div className="p-2.5 rounded-lg bg-surface-card border border-border-subtle">
                    <span className="text-text-muted block text-[10px]">Odômetro Inicial:</span>
                    <strong className="text-emerald-400 text-xs">
                      {Number(contractData.inspection.initialKm).toLocaleString('pt-BR')} km
                    </strong>
                  </div>
                  <div className="p-2.5 rounded-lg bg-surface-card border border-border-subtle">
                    <span className="text-text-muted block text-[10px]">Placa do Veículo:</span>
                    <strong className="text-emerald-400 text-xs">
                      {contractData.moto.plate}
                    </strong>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1 text-[11px] text-text-secondary">
                  <div>
                    <span className="text-text-muted block text-[10px]">Veículo:</span>
                    <span className="font-semibold text-text-primary">{contractData.moto.brand} {contractData.moto.model}</span>
                  </div>
                  <div>
                    <span className="text-text-muted block text-[10px]">Ano / Cor:</span>
                    <span className="font-semibold text-text-primary">{contractData.moto.year} • {contractData.moto.color}</span>
                  </div>
                  <div>
                    <span className="text-text-muted block text-[10px]">Chassi:</span>
                    <span className="font-mono text-text-primary text-[10px]">{contractData.moto.chassi}</span>
                  </div>
                  <div>
                    <span className="text-text-muted block text-[10px]">Renavam:</span>
                    <span className="font-mono text-text-primary text-[10px]">{contractData.moto.renavam || 'Conforme Doc.'}</span>
                  </div>
                </div>
              </div>

              {/* TABELA COMPLETA DOS 10 ITENS DE VISTORIA FÍSICA COM ÍCONES SVG */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Condições Gerais da Motocicleta (10 Itens Vistoriados)</span>
                  </h4>
                  <span className="text-[10px] text-text-muted font-mono">
                    Todos os itens testados e verificados
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                  {[
                    { key: 'pneuDianteiro' as const, label: 'Pneu Dianteiro', Icon: IconPneuDianteiro },
                    { key: 'pneuTraseiro' as const, label: 'Pneu Traseiro', Icon: IconPneuTraseiro },
                    { key: 'freioDianteiro' as const, label: 'Freio Dianteiro', Icon: IconFreioDianteiro },
                    { key: 'freioTraseiro' as const, label: 'Freio Traseiro', Icon: IconFreioTraseiro },
                    { key: 'farolLanternas' as const, label: 'Farol e Lanternas', Icon: IconFarolLanternas },
                    { key: 'setas' as const, label: 'Setas (D / T)', Icon: IconSetas },
                    { key: 'buzina' as const, label: 'Buzina', Icon: IconBuzina },
                    { key: 'retrovisores' as const, label: 'Retrovisores', Icon: IconRetrovisores },
                    { key: 'assentoBanco' as const, label: 'Assento / Banco', Icon: IconAssentoBanco },
                    { key: 'pinturaLataria' as const, label: 'Pintura / Lataria', Icon: IconPinturaLataria },
                  ].map(({ key, label, Icon }, i) => {
                    const item = contractData.inspection.checklist?.[key] || { checked: true, status: 'bom', notes: '' };
                    const isBom = item.status === 'bom';
                    const isRegular = item.status === 'regular';
                    const isRuim = item.status === 'ruim';

                    return (
                      <div
                        key={key}
                        className="p-3 rounded-xl bg-surface-card border border-border-subtle space-y-1.5 hover:border-border-hover transition-colors"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded-lg bg-surface-subtle flex items-center justify-center text-text-secondary shrink-0">
                              <Icon className="w-3.5 h-3.5" />
                            </div>
                            <span className="text-xs font-semibold text-text-primary">
                              {i + 1}. {label}
                            </span>
                          </div>

                          <div className="flex items-center gap-1 text-[11px] font-bold">
                            {isBom && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                                <IconStatusBom className="w-3 h-3 text-emerald-400" />
                                <span>[X] Bom</span>
                              </span>
                            )}
                            {isRegular && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-400 border border-amber-500/30">
                                <IconStatusRegular className="w-3 h-3 text-amber-400" />
                                <span>[X] Regular</span>
                              </span>
                            )}
                            {isRuim && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-rose-500/15 text-rose-400 border border-rose-500/30">
                                <IconStatusRuim className="w-3 h-3 text-rose-400" />
                                <span>[X] Ruim</span>
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="text-[11px] text-text-muted pl-8">
                          <span className="text-text-muted text-[10px]">Obs: </span>
                          <span className={item.notes ? 'text-text-secondary italic' : 'text-text-muted italic'}>
                            {item.notes || 'Sem avarias relatadas / Em perfeito estado'}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* NÍVEL DE COMBUSTÍVEL NA RETIRADA */}
              <div className="p-4 rounded-xl bg-black/25 border border-border-subtle space-y-2.5">
                <div className="flex items-center gap-2 text-xs font-bold text-text-secondary">
                  <IconCombustivel className="w-4 h-4 text-emerald-400" />
                  <span className="uppercase tracking-wider">Nível de Combustível na Retirada:</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {[
                    { key: 'cheio', label: 'Cheio (100%)' },
                    { key: '3/4', label: '3/4 Tanque' },
                    { key: '1/2', label: '1/2 Tanque' },
                    { key: '1/4', label: '1/4 Tanque' },
                    { key: 'reserva', label: 'Reserva' },
                  ].map((level) => {
                    const isSelected = contractData.inspection.fuelLevel === level.key;
                    return (
                      <div
                        key={level.key}
                        className={`p-2 rounded-lg text-center text-xs font-semibold border transition-all ${
                          isSelected
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 font-bold'
                            : 'bg-surface-subtle text-text-muted border-border-subtle'
                        }`}
                      >
                        <span>{isSelected ? '[ X ]' : '[   ]'} {level.label}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* ACESSÓRIOS ENTREGUES */}
              <div className="p-4 rounded-xl bg-black/25 border border-border-subtle space-y-2.5">
                <div className="flex items-center gap-2 text-xs font-bold text-text-secondary">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span className="uppercase tracking-wider">Acessórios Entregues com a Motocicleta:</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                  {[
                    { key: 'capacete', label: 'Capacete', Icon: IconCapacete, active: contractData.inspection.accessories?.capacete },
                    { key: 'capaChuva', label: 'Capa de Chuva', Icon: IconCapaChuva, active: contractData.inspection.accessories?.capaChuva },
                    { key: 'suporteCelular', label: 'Suporte de Celular', Icon: IconSuporteCelular, active: contractData.inspection.accessories?.suporteCelular },
                    { key: 'bauBauleto', label: 'Baú / Bauleto', Icon: IconBauBauleto, active: contractData.inspection.accessories?.bauBauleto },
                    { key: 'chaveReserva', label: 'Chave Reserva', Icon: IconChaveReserva, active: contractData.inspection.accessories?.chaveReserva },
                    {
                      key: 'outros',
                      label: contractData.inspection.accessories?.outrosDescricao
                        ? `Outros: ${contractData.inspection.accessories.outrosDescricao}`
                        : 'Outros Itens',
                      Icon: IconOutros,
                      active: contractData.inspection.accessories?.outros,
                    },
                  ].map((acc) => (
                    <div
                      key={acc.key}
                      className={`p-2 rounded-lg flex items-center gap-2 border text-xs ${
                        acc.active
                          ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40 font-semibold'
                          : 'bg-surface-subtle text-text-muted border-border-subtle'
                      }`}
                    >
                      <acc.Icon className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">{acc.active ? '[X]' : '[ ]'} {acc.label}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* DESCRIÇÃO DE AVARIAS EXISTENTES */}
              <div className="p-4 rounded-xl bg-black/25 border border-border-subtle space-y-1.5">
                <span className="text-[11px] font-bold text-text-secondary uppercase tracking-wider block">
                  Descrição Detalhada de Avarias Existentes (Lataria, Pintura, Ralados, etc.):
                </span>
                <p className="text-xs text-text-secondary leading-relaxed bg-surface-subtle p-3 rounded-lg border border-border-subtle italic">
                  {contractData.inspection.damagesDescription ||
                    'Nenhuma avaria estrutural identificada na vistoria inicial. Veículo entregue revisado, lavado e em perfeitas condições operacionais.'}
                </p>
              </div>

              {/* REGISTRO EM VÍDEO 360° */}
              <div className="p-4 rounded-xl bg-indigo-500/10 border border-indigo-500/20 space-y-1.5 text-xs">
                <div className="flex items-center gap-2 text-indigo-300 font-bold uppercase tracking-wide">
                  <Video className="w-4 h-4 text-indigo-400" />
                  <span>Registro em Vídeo 360° da Entrega:</span>
                </div>
                <p className="text-indigo-200/80 leading-relaxed text-[11.5px]">
                  Nota: Além deste termo impresso, foi realizado e armazenado um vídeo de vistoria em 360 graus do veículo no ato da entrega, servindo ambos como prova das condições iniciais da motocicleta.
                </p>
                {contractData.inspection.videoUrl && (
                  <p className="text-[11px] text-indigo-300 font-mono pt-1">
                    Arquivo/Link: {contractData.inspection.videoUrl}
                  </p>
                )}
              </div>

              {/* DECLARAÇÃO DE CIÊNCIA E ACEITE DO LOCATÁRIO */}
              <div className="p-4 rounded-xl bg-surface-subtle border border-border-subtle space-y-2">
                <p className="text-xs text-text-secondary leading-relaxed">
                  Pelo presente termo, o <strong>LOCATÁRIO</strong> declara que vistoriou a motocicleta acima qualificada, conferiu todos os 10 itens de segurança, recebeu os acessórios marcados e concorda que o veículo está em perfeitas condições de uso, segurança e funcionamento, obrigando-se a devolvê-lo nas mesmas condições em que o recebeu.
                </p>
              </div>

              {/* ASSINATURAS DO TERMO DE VISTORIA (ANEXO I) */}
              <div className="pt-4 border-t border-border-subtle space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-4">
                  <div className="text-center border-t border-border-strong pt-2 space-y-0.5">
                    <strong className="text-text-primary text-xs block font-bold">
                      <HighlightMissingText text={contractData.locador.name} />
                    </strong>
                    <span className="text-[10px] text-text-muted block uppercase tracking-wider">
                      Assinatura do LOCADOR
                    </span>
                    <span className="text-[10px] text-text-muted block font-mono">
                      CPF: <HighlightMissingText text={formatCPF(contractData.locador.cpf)} />
                    </span>
                  </div>

                  <div className="text-center border-t border-border-strong pt-2 space-y-0.5">
                    <strong className="text-text-primary text-xs block font-bold">
                      <HighlightMissingText text={contractData.locatario.name} />
                    </strong>
                    <span className="text-[10px] text-text-muted block uppercase tracking-wider">
                      Assinatura do LOCATÁRIO
                    </span>
                    <span className="text-[10px] text-text-muted block font-mono">
                      CPF: <HighlightMissingText text={formatCPF(contractData.locatario.cpf)} />
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* ABA DE TEXTO PURO DO CONTRATO OFICIAL */
        <div className="p-4 sm:p-5 bg-surface-base border border-border-subtle rounded-2xl max-h-[62vh] overflow-y-auto font-mono text-xs text-text-secondary shadow-2xl">
          <div className="flex items-center justify-between text-xs text-text-muted pb-2 mb-3 border-b border-border-subtle">
            <span>Texto oficial e integral do contrato para envio por WhatsApp ou e-mail:</span>
            <span className="text-[11px] font-mono text-emerald-400">12 Cláusulas + Anexo I • UTF-8</span>
          </div>
          <pre className="whitespace-pre-wrap leading-relaxed font-mono select-all text-[11px] sm:text-xs">
            {rawContractText}
          </pre>
        </div>
      )}
    </div>
  );
};
