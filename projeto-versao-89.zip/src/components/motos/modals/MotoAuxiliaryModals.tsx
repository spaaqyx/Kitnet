import React, { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import {
  AlertTriangle,
  LogOut,
  X,
  CheckCircle2,
  FileText,
} from 'lucide-react';
import { Moto, MotoContract, MotoTenant } from '../../../types';
import { NumericInput } from '../../NumericInput';
import { generateMotoRentalContractPdfFile } from '../../../utils/pdfGenerator';
import { monthlyToWeekly, weeklyToMonthly } from '../../../domain';
import { PhotoZoomModal } from '../../common/PhotoZoomModal';
import { STANDARD_EASE } from '../../../utils/motion';
import { useBodyScrollLock } from '../../../hooks/useBodyScrollLock';

// Modal: Confirmar Exclusão de Moto
interface DeleteMotoConfirmModalProps {
  moto: Moto | null;
  onClose: () => void;
  onConfirm: () => void;
}

export const DeleteMotoConfirmModal: React.FC<DeleteMotoConfirmModalProps> = ({
  moto,
  onClose,
  onConfirm,
}) => {
  const isOpen = Boolean(moto);
  const shouldReduceMotion = useReducedMotion();
  const lastMotoRef = useRef(moto);

  if (moto) {
    lastMotoRef.current = moto;
  }

  const currentMoto = moto || lastMotoRef.current;
  useBodyScrollLock(isOpen);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (typeof document === 'undefined') return null;

  return createPortal(
    <AnimatePresence>
      {isOpen && currentMoto && (
        <motion.div
          key="delete-moto-backdrop"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          role="dialog"
          aria-modal="true"
          aria-label="Confirmar Exclusão da Moto"
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md font-sans"
          onClick={onClose}
        >
          <motion.div
            key="delete-moto-card"
            initial={{ opacity: 0, scale: shouldReduceMotion ? 1 : 0.96, y: shouldReduceMotion ? 0 : 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: shouldReduceMotion ? 1 : 0.96, y: shouldReduceMotion ? 0 : 8 }}
            transition={{ duration: 0.22, ease: STANDARD_EASE }}
            className="bg-surface-sidebar border border-border-subtle rounded-2xl sm:rounded-3xl w-full max-w-lg mx-auto p-6 shadow-2xl shadow-black/80 space-y-4 my-auto overflow-hidden animate-modal-enter"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-12 rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 mx-auto shadow-inner">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="text-center space-y-2">
              <h3 className="text-base font-bold text-white">
                Apagar Moto {currentMoto.brand} {currentMoto.model}?
              </h3>
              <p className="text-xs text-text-muted">
                Placa: <strong className="text-white font-mono">{currentMoto.plate}</strong> • Renavam:{' '}
                <span className="font-mono text-text-secondary">{currentMoto.renavam || 'N/A'}</span>
              </p>
              <div className="p-3.5 bg-rose-950/30 border border-rose-800/40 rounded-xl text-left text-xs text-rose-300 space-y-1.5">
                <p className="font-semibold text-rose-200 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                  <span>Atenção:</span>
                </p>
                <ul className="list-disc list-inside space-y-1 text-[11px] text-rose-300/90 pl-1">
                  <li>Esta ação é permanente e não poderá ser desfeita.</li>
                  <li>Contratos, parcelas e históricos vinculados a este veículo serão removidos.</li>
                  {currentMoto.status === 'alugada' && (
                    <li className="font-bold text-amber-300">
                      Esta moto possui locação ativa! Finalize a locação antes ou confirme a exclusão total.
                    </li>
                  )}
                </ul>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-border-subtle">
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2.5 bg-surface-subtle hover:bg-surface-hover text-text-secondary hover:text-white border border-border-subtle rounded-xl text-xs font-semibold transition-colors duration-150 cursor-pointer active:scale-95"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={onConfirm}
                className="px-5 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs transition-colors duration-150 cursor-pointer active:scale-95"
              >
                Confirmar e Apagar
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
};

// Modal: Finalizar Locação de Moto
interface TerminateMotoModalProps {
  data: { moto: Moto; contract: MotoContract } | null;
  form: { finalKm: number; notes: string };
  setForm: React.Dispatch<React.SetStateAction<{ finalKm: number; notes: string }>>;
  onClose: () => void;
  onConfirm: () => void;
  formatCurrency: (value: number) => string;
}

export const TerminateMotoModal: React.FC<TerminateMotoModalProps> = ({
  data,
  form,
  setForm,
  onClose,
  onConfirm,
  formatCurrency,
}) => {
  const isOpen = Boolean(data);
  const shouldReduceMotion = useReducedMotion();
  const lastDataRef = useRef(data);

  if (data) {
    lastDataRef.current = data;
  }

  const currentData = data || lastDataRef.current;
  useBodyScrollLock(isOpen);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (typeof document === 'undefined') return null;

  return createPortal(
    <AnimatePresence>
      {isOpen && currentData && (
        <motion.div
          key="terminate-moto-backdrop"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          role="dialog"
          aria-modal="true"
          aria-label="Finalizar Locação de Moto"
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md font-sans"
          onClick={onClose}
        >
          <motion.div
            key="terminate-moto-card"
            initial={{ opacity: 0, scale: shouldReduceMotion ? 1 : 0.96, y: shouldReduceMotion ? 0 : 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: shouldReduceMotion ? 1 : 0.96, y: shouldReduceMotion ? 0 : 8 }}
            transition={{ duration: 0.22, ease: STANDARD_EASE }}
            className="bg-surface-sidebar border border-border-subtle rounded-2xl sm:rounded-3xl w-full max-w-lg mx-auto p-6 shadow-2xl shadow-black/80 space-y-4 my-auto overflow-hidden animate-modal-enter"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-border-subtle pb-3.5">
              <h3 className="text-base font-bold text-white flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-400">
                  <LogOut className="w-4 h-4" />
                </div>
                <span>Finalizar Locação / Devolução</span>
              </h3>
              <button
                type="button"
                onClick={onClose}
                className="text-text-muted hover:text-text-primary p-1.5 rounded-lg hover:bg-surface-hover transition-colors duration-150 cursor-pointer active:scale-95"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3.5 bg-surface-base rounded-xl border border-border-subtle space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-text-muted">Moto:</span>
                <span className="font-bold text-white">
                  {currentData.moto.brand} {currentData.moto.model} ({currentData.moto.plate})
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-text-muted">Contrato:</span>
                <span className="text-text-primary">
                  {currentData.contract.durationMonths} meses • {formatCurrency(currentData.contract.monthlyValue)}/mês
                </span>
              </div>
            </div>

            <div className="space-y-3.5 text-xs">
              <div>
                <label className="block text-xs font-semibold text-text-secondary mb-1.5">
                  KM Final de Devolução (KM atual: {currentData.moto.currentKm})
                </label>
                <NumericInput
                  mode="integer"
                  min={0}
                  value={form.finalKm || currentData.moto.currentKm}
                  onChange={(val) => setForm({ ...form, finalKm: val })}
                  className="w-full bg-surface-base border border-border-subtle hover:border-border-subtle focus:bg-surface-base rounded-xl px-3.5 py-2.5 text-sm text-white font-bold focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/25 transition-colors duration-150"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-text-secondary mb-1.5">
                  Observações da Entrega / Devolução
                </label>
                <textarea
                  rows={3}
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  className="w-full bg-surface-base border border-border-subtle hover:border-border-subtle focus:bg-surface-base rounded-xl px-3.5 py-2.5 text-sm text-white placeholder:text-text-dim focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/25 transition-colors duration-150"
                />
              </div>

              <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-300 text-[11px] leading-relaxed">
                Ao finalizar, o contrato será marcado como <strong>finalizado</strong> e a moto voltará a ficar com status <strong>Disponível</strong> para novos contratos.
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-border-subtle">
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2.5 bg-surface-subtle hover:bg-surface-hover text-text-secondary hover:text-white border border-border-subtle rounded-xl text-xs font-semibold transition-colors duration-150 cursor-pointer active:scale-95"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={onConfirm}
                className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs transition-colors duration-150 cursor-pointer active:scale-95"
              >
                Confirmar Finalização
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
};

// Modal: Lightbox de Foto
interface PhotoLightboxModalProps {
  photo: { url: string; title: string } | null;
  onClose: () => void;
}

export const PhotoLightboxModal: React.FC<PhotoLightboxModalProps> = ({ photo, onClose }) => {
  return <PhotoZoomModal photo={photo} onClose={onClose} />;
};

// Modal: Sucesso do Cadastro & Gerar Contrato Oficial
interface NewContractSuccessModalProps {
  data: {
    moto: Moto;
    tenant: MotoTenant;
    contract: MotoContract;
  } | null;
  onClose: () => void;
  settings: any;
  formatCurrency: (value: number) => string;
  formatCPF: (cpf: string) => string;
}

export const NewContractSuccessModal: React.FC<NewContractSuccessModalProps> = ({
  data,
  onClose,
  settings,
  formatCurrency,
  formatCPF,
}) => {
  const isOpen = Boolean(data);
  const shouldReduceMotion = useReducedMotion();
  const lastDataRef = useRef(data);

  if (data) {
    lastDataRef.current = data;
  }

  const currentData = data || lastDataRef.current;
  useBodyScrollLock(isOpen);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (typeof document === 'undefined') return null;

  return createPortal(
    <AnimatePresence>
      {isOpen && currentData && (
        <motion.div
          key="new-contract-success-backdrop"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          role="dialog"
          aria-modal="true"
          aria-label="Cadastro Concluído com Sucesso"
          className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md font-sans"
          onClick={onClose}
        >
          <motion.div
            key="new-contract-success-card"
            initial={{ opacity: 0, scale: shouldReduceMotion ? 1 : 0.96, y: shouldReduceMotion ? 0 : 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: shouldReduceMotion ? 1 : 0.96, y: shouldReduceMotion ? 0 : 8 }}
            transition={{ duration: 0.22, ease: STANDARD_EASE }}
            className="bg-surface-sidebar border border-amber-500/30 rounded-2xl sm:rounded-3xl p-6 w-full max-w-lg mx-auto shadow-2xl shadow-black/90 space-y-5 my-auto overflow-hidden animate-modal-enter"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3.5">
              <div className="p-3 bg-amber-500/15 rounded-2xl text-amber-400 border border-amber-500/30 shrink-0">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Cadastro Concluído com Sucesso!</h3>
                <p className="text-xs text-text-muted mt-0.5">
                  Moto e locatário cadastrados e vinculados no sistema.
                </p>
              </div>
            </div>

            <div className="p-4 bg-surface-base border border-border-subtle rounded-2xl space-y-2.5 text-xs">
              <div className="flex items-center justify-between text-text-muted">
                <span>Motocicleta:</span>
                <span className="font-semibold text-white">
                  {currentData.moto.brand} {currentData.moto.model} ({currentData.moto.plate || 'S/ Placa'})
                </span>
              </div>
              <div className="flex items-center justify-between text-text-muted">
                <span>Locatário:</span>
                <span className="font-semibold text-amber-400">
                  {currentData.tenant.fullName}
                </span>
              </div>
              <div className="flex items-center justify-between text-text-muted">
                <span>CPF:</span>
                <span className="font-mono text-white">
                  {formatCPF(currentData.tenant.cpf)}
                </span>
              </div>
              <div className="flex items-center justify-between text-text-muted">
                <span>Frequência / Valor:</span>
                <span className="font-semibold text-emerald-400">
                  {currentData.contract.paymentFrequency === 'semanal'
                    ? `${formatCurrency(currentData.contract.weeklyValue || (currentData.contract.monthlyValue ? monthlyToWeekly(currentData.contract.monthlyValue) : (currentData.contract.installments?.[0]?.amount || 0)))} / semana`
                    : `${formatCurrency(currentData.contract.monthlyValue || (currentData.contract.weeklyValue ? weeklyToMonthly(currentData.contract.weeklyValue) : (currentData.contract.installments?.[0]?.amount || 0)))} / mês`}
                </span>
              </div>
            </div>

            <div className="space-y-3 pt-1">
              <button
                type="button"
                onClick={() => {
                  generateMotoRentalContractPdfFile({
                    moto: currentData.moto,
                    tenant: currentData.tenant,
                    contract: currentData.contract,
                    settings,
                    startDate: currentData.contract.startDate,
                    weeklyValue:
                      currentData.contract.weeklyValue ||
                      (currentData.contract.monthlyValue ? monthlyToWeekly(currentData.contract.monthlyValue) : 0),
                    dueDayOfWeek:
                      currentData.contract.dueDayOfWeek !== undefined
                        ? ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'][
                            currentData.contract.dueDayOfWeek
                          ]
                        : 'Segunda-feira',
                    dueLimitTime: '18:00',
                    deposit: currentData.contract.deposit || 0,
                    insuranceDeductible: currentData.contract.insuranceDeductible || '0,00',
                    contractCity: settings.cityState || 'são jose - SC',
                    initialKm:
                      currentData.moto.delivery?.initialKm ||
                      currentData.moto.currentKm ||
                      0,
                    autoDownload: true,
                  });
                }}
                className="w-full py-3.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition-colors duration-150 active:scale-98 cursor-pointer"
              >
                <FileText className="w-4 h-4" />
                <span>Gerar Contrato de Locação (Baixar PDF)</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="w-full py-3 bg-surface-subtle hover:bg-surface-hover text-text-secondary hover:text-white font-semibold border border-border-subtle rounded-xl text-xs transition-colors duration-150 cursor-pointer active:scale-95"
              >
                Fechar e Ver Moto Cadastrada
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
};
