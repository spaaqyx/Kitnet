import React, { useState, useEffect, useCallback } from 'react';
import { Database, Download, Copy, Upload, Loader2, Check, AlertCircle, FileJson, HardDrive, RefreshCw, ShieldCheck } from 'lucide-react';
import { SystemSettings } from '../../types';
import { safeLocalStorage, getDetailedStorageUsage, getStorageQuotaEstimate, StorageUsageDetails } from '../../utils/storage';
import { SourceCodeDownloadBox } from './SourceCodeDownloadBox';
import { gsapButtonPress } from '../../utils/gsapAnimations';

interface SettingsBackupSectionProps {
  settings: SystemSettings;
  exportBackup: () => void;
  importBackup: (content: string) => boolean;
  getBackupJsonString?: () => string;
}

export const SettingsBackupSection: React.FC<SettingsBackupSectionProps> = ({
  settings,
  exportBackup,
  importBackup,
  getBackupJsonString,
}) => {
  const [copySuccess, setCopySuccess] = useState<boolean>(false);
  const [importStatus, setImportStatus] = useState<{ message: string; isError?: boolean } | null>(null);
  const [isExportingBackup, setIsExportingBackup] = useState<boolean>(false);
  const [isRefreshingStorage, setIsRefreshingStorage] = useState<boolean>(false);

  // Storage estimation metrics state
  const [storageMetrics, setStorageMetrics] = useState<StorageUsageDetails>(() => getDetailedStorageUsage());
  const [systemQuota, setSystemQuota] = useState<{ usageFormatted: string; quotaFormatted: string; percentage: number } | null>(null);

  const refreshStorageMetrics = useCallback(async () => {
    setIsRefreshingStorage(true);
    const detailed = getDetailedStorageUsage();
    setStorageMetrics(detailed);

    const est = await getStorageQuotaEstimate();
    if (est) {
      setSystemQuota({
        usageFormatted: est.usageFormatted,
        quotaFormatted: est.quotaFormatted,
        percentage: est.percentage,
      });
    }
    setTimeout(() => setIsRefreshingStorage(false), 300);
  }, []);

  useEffect(() => {
    refreshStorageMetrics();
  }, [refreshStorageMetrics]);

  const handleExportBackupWithFeedback = () => {
    setIsExportingBackup(true);
    setTimeout(() => {
      exportBackup();
      setIsExportingBackup(false);
      refreshStorageMetrics();
    }, 600);
  };

  const handleCopyBackup = () => {
    let jsonToCopy = '';
    if (getBackupJsonString) {
      jsonToCopy = getBackupJsonString();
    } else {
      // Fallback robusto que serializa todos os dados das chaves locais
      const backupObj: Record<string, any> = {
        timestamp: new Date().toISOString(),
        version: '1.0',
        settings,
      };
      const keys = safeLocalStorage.keys().filter((k) => k.startsWith('gestao_patrimonial_'));
      keys.forEach((k) => {
        const val = safeLocalStorage.getItem(k);
        if (val) {
          try {
            const subKey = k.replace('gestao_patrimonial_', '');
            backupObj[subKey] = JSON.parse(val);
          } catch {
            // Ignora chaves com formatação simples
          }
        }
      });
      jsonToCopy = JSON.stringify(backupObj, null, 2);
    }

    navigator.clipboard.writeText(jsonToCopy);
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 3000);
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const success = importBackup(content);
        if (success) {
          setImportStatus({ message: 'Backup restaurado com sucesso!' });
          refreshStorageMetrics();
        } else {
          setImportStatus({ message: 'Erro ao ler arquivo de backup.', isError: true });
        }
        setTimeout(() => setImportStatus(null), 4000);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="rounded-2xl bg-surface-subtle/90 border border-border-subtle p-5 sm:p-6 shadow-xl shadow-black/30 space-y-4 backdrop-blur-md">
      {/* Header */}
      <div className="flex items-center justify-between pb-3.5 border-b border-border-subtle">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-violet-500/10 border border-violet-500/20 flex items-center justify-center text-violet-400">
            <Database className="w-4 h-4" />
          </div>
          <h3 className="text-xs font-bold text-text-primary uppercase tracking-wider">
            Dados & Backup
          </h3>
        </div>
        <span className="inline-flex items-center gap-1 text-[11px] bg-surface-subtle text-text-muted border border-border-subtle px-2.5 py-1 rounded-full font-mono">
          <FileJson className="w-3 h-3 text-violet-400" />
          JSON
        </span>
      </div>

      <p className="text-xs text-text-muted leading-relaxed">
        Exporte todos os cadastros, contratos, despesas e auditorias em formato JSON para salvar uma cópia ou migrar de aparelho.
      </p>

      {/* ESTIMADOR DE QUOTA DO STORAGE LOCAL */}
      <div className="rounded-xl bg-surface-card/80 border border-border-subtle p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-violet-400" />
            <span className="text-xs font-bold text-text-primary">Armazenamento do Navegador</span>
          </div>

          <div className="flex items-center gap-2">
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                storageMetrics.isCritical
                  ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                  : storageMetrics.isNearLimit
                  ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                  : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
              }`}
            >
              {storageMetrics.isCritical
                ? 'Crítico'
                : storageMetrics.isNearLimit
                ? 'Atenção'
                : 'Espaço Saudável'}
            </span>

            <button
              type="button"
              onClick={refreshStorageMetrics}
              disabled={isRefreshingStorage}
              className="p-1 rounded-lg text-text-muted hover:text-text-primary hover:bg-surface-hover transition-colors cursor-pointer"
              title="Recalcular espaço utilizado"
            >
              <RefreshCw className={`w-3 h-3 ${isRefreshingStorage ? 'animate-spin text-violet-400' : ''}`} />
            </button>
          </div>
        </div>

        {/* Progress bar */}
        <div className="space-y-1.5">
          <div className="w-full h-2 rounded-full bg-surface-base border border-border-subtle overflow-hidden">
            <div
              className={`h-full transition-all duration-500 rounded-full ${
                storageMetrics.isCritical
                  ? 'bg-rose-500'
                  : storageMetrics.isNearLimit
                  ? 'bg-amber-500'
                  : 'bg-gradient-to-r from-emerald-500 to-teal-400'
              }`}
              style={{ width: `${Math.max(2, storageMetrics.percentage)}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-text-muted font-mono">
            <span>
              {storageMetrics.usedFormatted} de ~{storageMetrics.maxQuotaMB}.0 MB ({storageMetrics.percentage}%)
            </span>
            <span>{storageMetrics.keysCount} registros</span>
          </div>
        </div>

        {systemQuota && (
          <div className="pt-1 text-[10px] text-text-dim flex items-center gap-1.5">
            <ShieldCheck className="w-3 h-3 text-emerald-400 shrink-0" />
            <span>
              Memória do dispositivo alocada: {systemQuota.usageFormatted} de {systemQuota.quotaFormatted} (IndexedDB ativo)
            </span>
          </div>
        )}
      </div>

      {/* Main Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
        {/* Export JSON button */}
        <button
          type="button"
          onClick={(e) => {
            gsapButtonPress(e.currentTarget);
            handleExportBackupWithFeedback();
          }}
          disabled={isExportingBackup}
          className="p-3.5 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 active:scale-[0.98] cursor-pointer select-none touch-manipulation transition-all relative overflow-hidden disabled:opacity-75 disabled:pointer-events-none disabled:cursor-not-allowed group"
        >
          {isExportingBackup ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-white" />
              <span>Gerando Arquivo JSON...</span>
            </>
          ) : (
            <>
              <Download className="w-4 h-4 group-hover:-translate-y-0.5 transition-transform" />
              <span>Exportar Backup Completo</span>
            </>
          )}
        </button>

        {/* Copy JSON button */}
        <button
          type="button"
          onClick={(e) => {
            gsapButtonPress(e.currentTarget);
            handleCopyBackup();
          }}
          className="p-3.5 rounded-xl bg-surface-card hover:bg-surface-elevated border border-border-subtle hover:border-violet-500/40 text-text-primary font-semibold text-xs flex items-center justify-center gap-2 active:scale-[0.98] cursor-pointer select-none touch-manipulation transition-all shadow-md group"
        >
          {copySuccess ? (
            <>
              <Check className="w-4 h-4 text-emerald-400" />
              <span className="text-emerald-300 font-bold">Copiado para o Clipboard!</span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4 text-violet-400 group-hover:scale-110 transition-transform" />
              <span>Copiar Dados (JSON)</span>
            </>
          )}
        </button>
      </div>

      {/* Download Source Code ZIP & Version Manager */}
      <div className="pt-2">
        <SourceCodeDownloadBox />
      </div>

      {/* Restore Section */}
      <div className="pt-2 flex items-center justify-between flex-wrap gap-2 text-xs">
        <label
          onClick={(e) => gsapButtonPress(e.currentTarget)}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-surface-card hover:bg-surface-elevated border border-border-subtle hover:border-violet-500/40 text-text-secondary hover:text-white cursor-pointer transition-all active:scale-95 shadow-xs"
        >
          <Upload className="w-3.5 h-3.5 text-violet-400" />
          <span>Restaurar de Arquivo JSON</span>
          <input type="file" accept=".json" onChange={handleFileImport} className="hidden" />
        </label>

        {importStatus && (
          <span
            className={`inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1 rounded-lg ${
              importStatus.isError
                ? 'text-rose-400 bg-rose-500/10 border border-rose-500/20'
                : 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/20'
            }`}
          >
            {importStatus.isError ? <AlertCircle className="w-3.5 h-3.5" /> : <Check className="w-3.5 h-3.5" />}
            {importStatus.message}
          </span>
        )}
      </div>
    </div>
  );
};


