import React, { useState, useMemo, memo, useRef, useEffect, Suspense, lazy } from 'react';
import { Eye, EyeOff } from 'lucide-react';
import { gsap } from 'gsap';
import { useApp } from '../context/AppContext';
import { TabType } from './Navigation';
import { useDashboardMetrics } from './dashboard/useDashboardMetrics';
import { DashboardOverviewHero } from './dashboard/DashboardOverviewHero';
import { DashboardAssetsSummary } from './dashboard/DashboardAssetsSummary';
import { DashboardAlertsList } from './dashboard/DashboardAlertsList';
import { isInstallmentOverdue } from '../utils/formatters';
import { getTodayLocalDateString, daysBetweenDates } from '../domain';
import { useRenderTracker, useLifecycleLogger } from '../utils/perfLogger';

const loadReportExportModal = () =>
  import('./ReportExportModal').then((m) => ({ default: m.ReportExportModal }));

const ReportExportModal = lazy(loadReportExportModal);

/**
 * Pré-carregamento imediato/em tempo ocioso do componente ReportExportModal.
 * Evita atrasos de rede e compilação no momento do clique.
 */
export const preloadReportExportModal = () => {
  try {
    loadReportExportModal();
  } catch (err) {
    console.error('Falha no preload do modal de relatórios:', err);
  }
};

/**
 * Fallback visual mínimo e consistente com o BaseModal.
 * Evita tela sem resposta (fallback={null}), zero salto de layout na Dashboard e zero deslocamento de botão.
 */
const ReportModalFallback: React.FC = () => {
  if (typeof document === 'undefined') return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-[100] flex items-center justify-center p-2.5 sm:p-4 overflow-y-auto overflow-x-hidden font-sans"
    >
      {/* Backdrop idêntico ao BaseModal */}
      <div className="fixed inset-0 bg-black/75 dark:bg-black/85 backdrop-blur-xs" />

      {/* Card Skeleton / Feedback visual imediato */}
      <div className="relative bg-surface-card border border-border-subtle rounded-2xl sm:rounded-3xl w-full max-w-3xl mx-auto p-6 sm:p-8 shadow-2xl shadow-black/40 overflow-hidden flex flex-col items-center justify-center gap-3.5 z-10 animate-modal-enter min-h-[200px]">
        <div className="w-10 h-10 rounded-2xl border border-border-subtle bg-surface-subtle flex items-center justify-center text-emerald-500 shadow-xs">
          <div className="w-5 h-5 rounded-full border-2 border-emerald-500/20 border-t-emerald-500 animate-spin" />
        </div>
        <span className="text-xs sm:text-sm font-semibold text-text-secondary">
          Carregando relatório executivo...
        </span>
      </div>
    </div>
  );
};

const DashboardPerformanceChart = lazy(() =>
  import('./dashboard/DashboardPerformanceChart').then((m) => ({ default: m.DashboardPerformanceChart }))
);

interface DashboardViewProps {
  onNavigateTab: (tab: TabType) => void;
  onOpenWhatsAppModal: (contractId?: string, installmentId?: string) => void;
}

export const DashboardViewComponent: React.FC<DashboardViewProps> = ({
  onNavigateTab,
  onOpenWhatsAppModal,
}) => {
  useRenderTracker('DashboardView');
  useLifecycleLogger('DashboardView');

  const {
    motos,
    motoTenants,
    motoContracts,
    kitnets,
    kitnetContracts,
    kitnetTenants,
    expenses,
    settings,
    requestBrowserNotifications,
    isReadOnlyMode,
    toggleReadOnlyMode,
  } = useApp();

  const [notificationState, setNotificationState] = useState<string>(() => {
    return typeof Notification !== 'undefined' ? Notification.permission : 'default';
  });
  const [showReportModal, setShowReportModal] = useState<boolean>(false);
  const [chartViewMode, setChartViewMode] = useState<'evolution' | 'comparison'>('evolution');

  // Pré-carregamento em tempo ocioso (idle time) após a primeira pintura da Dashboard
  useEffect(() => {
    if (typeof window === 'undefined') return;
    if ('requestIdleCallback' in window) {
      const handle = (window as any).requestIdleCallback(
        () => {
          preloadReportExportModal();
        },
        { timeout: 2000 }
      );
      return () => {
        if ('cancelIdleCallback' in window) {
          (window as any).cancelIdleCallback(handle);
        }
      };
    } else {
      const timer = setTimeout(() => {
        preloadReportExportModal();
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleEnableNotifications = async () => {
    const perm = await requestBrowserNotifications();
    setNotificationState(perm ? 'granted' : 'denied');
  };

  const metrics = useDashboardMetrics({
    motos,
    motoTenants,
    motoContracts,
    kitnets,
    kitnetContracts,
    kitnetTenants,
    expenses,
    settings,
  });

  // Calculate installment breakdown counts
  const { overdueCount, dueTodayCount, upcomingCount } = useMemo(() => {
    const todayStr = getTodayLocalDateString();

    let overdue = 0;
    let dueToday = 0;
    let upcoming = 0;

    const allInstallments = [
      ...motoContracts.flatMap((c) => c.installments),
      ...kitnetContracts.flatMap((c) => c.installments),
    ];

    allInstallments.forEach((inst) => {
      if (inst.status !== 'pago') {
        if (isInstallmentOverdue(inst)) {
          overdue++;
        } else if (inst.dueDate === todayStr) {
          dueToday++;
        } else {
          const diff = daysBetweenDates(todayStr, inst.dueDate);
          if (diff > 0 && diff <= 7) {
            upcoming++;
          }
        }
      }
    });

    return { overdueCount: overdue, dueTodayCount: dueToday, upcomingCount: upcoming };
  }, [motoContracts, kitnetContracts]);

  const totalBens = metrics.totalMotos + metrics.totalKitnets;
  const totalAlugados = metrics.motosAlugadas + metrics.kitnetsAlugadas;
  const taxaOcupacaoGeral = totalBens > 0 ? (totalAlugados / totalBens) * 100 : 0;

  const dashboardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!dashboardRef.current) return;
    const ctx = gsap.context(() => {
      // Sequence the Asset Summary and Bottom Cards smoothly after the Hero KPI cards
      gsap.from('.gsap-asset-summary-card', {
        y: -22,
        opacity: 0,
        duration: 0.55,
        stagger: 0.08,
        ease: 'power2.out',
        delay: 0.28,
        clearProps: 'all',
      });

      gsap.from('.gsap-bottom-card', {
        y: -22,
        opacity: 0,
        duration: 0.55,
        stagger: 0.08,
        ease: 'power2.out',
        delay: 0.45,
        clearProps: 'all',
      });
    }, dashboardRef);

    return () => ctx.revert();
  }, []);

  return (
    <div ref={dashboardRef} className="space-y-5 font-sans">
      {/* Banner de Modo Leitura ativo com botão direto para desativar */}
      {isReadOnlyMode && (
        <aside
          aria-label="Aviso de Modo Leitura"
          className="p-3.5 sm:p-4 rounded-2xl bg-amber-500/15 border border-amber-500/35 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-amber-900 dark:text-amber-200 shadow-sm"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
              <Eye className="w-5 h-5" />
            </div>
            <div className="text-xs sm:text-sm">
              <span className="font-bold text-text-primary">Modo Leitura Ativo:</span>
              <p className="text-text-muted dark:text-text-secondary text-xs mt-0.5">
                O aplicativo está em modo de apenas visualização. Para restaurar todas as abas e edições, desative o modo leitura.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => toggleReadOnlyMode()}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs sm:text-sm rounded-xl shrink-0 cursor-pointer active:scale-95 transition-all shadow-sm flex items-center justify-center gap-2 self-start sm:self-auto"
          >
            <EyeOff className="w-4 h-4" />
            <span>Desativar Modo Leitura</span>
          </button>
        </aside>
      )}

      {/* 1. Exact Main Hero Dashboard (Header, 4 KPIs, Alert Banner, Quick Actions, Quick Access) */}
      <DashboardOverviewHero
        notificationState={notificationState}
        onEnableNotifications={handleEnableNotifications}
        onOpenReportModal={() => setShowReportModal(true)}
        onPreloadReportModal={preloadReportExportModal}
        onNavigateTab={onNavigateTab}
        faturamentoBrutoMensal={metrics.faturamentoBrutoMensal}
        receitaMesAtualTotal={metrics.receitaMesAtualTotal}
        receitaMesAtualMotos={metrics.receitaMesAtualMotos}
        receitaMesAtualKitnets={metrics.receitaMesAtualKitnets}
        receitaAnualProjetada={metrics.receitaAnualProjetada}
        faturamentoMensalMotos={metrics.faturamentoMensalMotos}
        faturamentoMensalKitnets={metrics.faturamentoMensalKitnets}
        totalReceitaRecebida={metrics.totalReceitaRecebida}
        totalAReceber={metrics.totalAReceber}
        totalInadimplenciaGeral={metrics.totalInadimplenciaGeral}
        totalMotos={metrics.totalMotos}
        totalKitnets={metrics.totalKitnets}
        motosAlugadas={metrics.motosAlugadas}
        kitnetsAlugadas={metrics.kitnetsAlugadas}
        totalContratosAtivos={metrics.totalContratosAtivos}
        patrimonioTotalAvaliado={metrics.patrimonioTotalAvaliado}
        overdueCount={overdueCount}
        dueTodayCount={dueTodayCount}
        upcomingCount={upcomingCount}
        taxaOcupacaoGeral={taxaOcupacaoGeral}
        monthlyEvolutionData={metrics.monthlyEvolutionData}
      />

      {/* 2. Gestão & Performance de Ativos (Frota de Motos & Imóveis Kitnets) - Oculto no Modo Leitura */}
      {!isReadOnlyMode && (
        <DashboardAssetsSummary
          totalMotos={metrics.totalMotos}
          motosAlugadas={metrics.motosAlugadas}
          motosDisponiveis={metrics.motosDisponiveis}
          motosManutencao={metrics.motosManutencao}
          taxaOcupacaoMotos={metrics.taxaOcupacaoMotos}
          faturamentoMensalMotos={metrics.faturamentoMensalMotos}
          receitaMesAtualMotos={metrics.receitaMesAtualMotos}
          inadimplenciaMotos={metrics.inadimplenciaMotos}
          inadimplenciaPctMotos={metrics.inadimplenciaPctMotos}
          valorInvestidoMotos={metrics.valorInvestidoMotos}
          totalKitnets={metrics.totalKitnets}
          kitnetsAlugadas={metrics.kitnetsAlugadas}
          kitnetsDisponiveis={metrics.kitnetsDisponiveis}
          kitnetsManutencao={metrics.kitnetsManutencao}
          taxaOcupacaoKitnets={metrics.taxaOcupacaoKitnets}
          faturamentoMensalKitnets={metrics.faturamentoMensalKitnets}
          receitaMesAtualKitnets={metrics.receitaMesAtualKitnets}
          inadimplenciaKitnets={metrics.inadimplenciaKitnets}
          inadimplenciaPctKitnets={metrics.inadimplenciaPctKitnets}
          valorInvestidoKitnets={metrics.valorInvestidoKitnets}
          onNavigateTab={onNavigateTab}
          onOpenReportModal={() => setShowReportModal(true)}
        />
      )}

      {/* 3. Alertas & Comparativo Gráfico - Oculto no Modo Leitura */}
      {!isReadOnlyMode && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <DashboardAlertsList
            alertItems={metrics.alertItems}
            onOpenWhatsAppModal={onOpenWhatsAppModal}
          />

          <Suspense
            fallback={
              <div className="lg:col-span-2 bg-surface-card border border-border-dark rounded-2xl p-6 min-h-[360px] flex flex-col items-center justify-center gap-3">
                <div className="w-8 h-8 rounded-full border-2 border-emerald-500/20 border-t-emerald-500 animate-spin" />
                <span className="text-xs text-text-secondary font-medium">Carregando comparativo gráfico...</span>
              </div>
            }
          >
            <DashboardPerformanceChart
              chartViewMode={chartViewMode}
              setChartViewMode={setChartViewMode}
              monthlyEvolutionData={metrics.monthlyEvolutionData}
              revenueExpenseData={metrics.revenueExpenseData}
            />
          </Suspense>
        </div>
      )}

      {/* Modal: Relatório Executivo Exportável */}
      {showReportModal && (
        <Suspense fallback={<ReportModalFallback />}>
          <ReportExportModal
            isOpen={showReportModal}
            onClose={() => setShowReportModal(false)}
          />
        </Suspense>
      )}
    </div>
  );
};

export const DashboardView = memo(DashboardViewComponent);


