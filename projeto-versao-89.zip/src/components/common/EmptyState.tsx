import React from 'react';

export interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
  actionIcon?: React.ReactNode;
  category?: 'motos' | 'kitnets' | string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon,
  title,
  description,
  actionLabel,
  onAction,
  actionIcon,
  category = 'motos',
}) => {
  const isKitnets = category === 'kitnets';
  const btnClass = isKitnets
    ? 'bg-category-kitnets-sky hover:bg-category-kitnets-cyan text-white shadow-category-kitnets-sky/20'
    : 'bg-category-motos hover:bg-category-motos text-white shadow-category-motos/20';

  return (
    <div className="flex flex-col items-center justify-center p-8 text-center rounded-2xl bg-surface-subtle/80 border border-border-subtle my-4">
      {icon && <div className="mb-4 text-text-muted">{icon}</div>}
      <h3 className="text-base font-bold text-white mb-1.5">{title}</h3>
      {description && (
        <p className="text-xs text-text-muted max-w-sm mb-5 leading-relaxed">
          {description}
        </p>
      )}
      {actionLabel && onAction && (
        <button
          type="button"
          onClick={onAction}
          className={`h-10 px-4 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer shadow-md active:scale-95 ${btnClass}`}
        >
          {actionIcon}
          <span>{actionLabel}</span>
        </button>
      )}
    </div>
  );
};
