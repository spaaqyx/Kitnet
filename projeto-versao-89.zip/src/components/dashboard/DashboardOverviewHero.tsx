import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import {
  gsapCardHoverEnter,
  gsapCardHoverLeave,
  gsapButtonPress,
} from '../../utils/gsapAnimations';
import { COLORS } from '../../styles/colors';
import {
  FileText,
  Calculator,
  TrendingUp,
  Wallet,
  AlertTriangle,
  Phone,
  Smartphone,
  Bell,
  Users,
  Coins,
  FileSpreadsheet,
  ArrowUpRight,
  ArrowRight,
  FileCheck2,
  Motorbike,
} from 'lucide-react';
import { TabType } from '../Navigation';
import { formatCurrency } from '../../utils/formatters';
import { AnimatedNumber } from '../AnimatedNumber';
import { useLifecycleLogger } from '../../utils/perfLogger';
import { useApp } from '../../context/AppContext';

interface DashboardOverviewHeroProps {
  notificationState: string;
  onEnableNotifications: () => void;
  onOpenReportModal: () => void;
  onPreloadReportModal?: () => void;
  onNavigateTab: (tab: TabType) => void;
  faturamentoBrutoMensal: number;
  receitaMesAtualTotal?: number;
  receitaMesAtualMotos?: number;
  receitaMesAtualKitnets?: number;
  receitaAnualProjetada?: number;
  faturamentoMensalMotos?: number;
  faturamentoMensalKitnets?: number;
  totalReceitaRecebida?: number;
  totalAReceber?: number;
  totalInadimplenciaGeral: number;
  totalMotos: number;
  totalKitnets: number;
  motosAlugadas: number;
  kitnetsAlugadas: number;
  totalContratosAtivos: number;
  patrimonioTotalAvaliado?: number;
  overdueCount: number;
  dueTodayCount: number;
  upcomingCount: number;
  taxaOcupacaoGeral: number;
  monthlyEvolutionData?: Array<{ mes: string; receita: number; despesa: number; lucro: number }>;
}

/**
 * Gera os caminhos SVG da sparkline baseados em dados reais.
 * Se não houver dados ou todos forem 0, retorna uma linha de base reta e sem onda fictícia.
 */
function getSparklinePaths(dataPoints: number[]) {
  const max = Math.max(...dataPoints, 0);
  if (max === 0 || dataPoints.length === 0) {
    return {
      line: '',
      fill: '',
      hasData: false,
    };
  }

  const min = Math.min(...dataPoints, 0);
  const range = max - min || 1;
  const n = dataPoints.length;
  const coords = dataPoints.map((val, idx) => {
    const x = n > 1 ? (idx / (n - 1)) * 100 : 50;
    const y = 26 - ((val - min) / range) * 20;
    return { x: Math.round(x * 10) / 10, y: Math.round(y * 10) / 10 };
  });

  let line = `M ${coords[0].x},${coords[0].y}`;
  for (let i = 0; i < coords.length - 1; i++) {
    const p0 = coords[i];
    const p1 = coords[i + 1];
    const cx = (p0.x + p1.x) / 2;
    line += ` C ${cx},${p0.y} ${cx},${p1.y} ${p1.x},${p1.y}`;
  }

  const fill = `${line} L 100,32 L 0,32 Z`;
  return { line, fill, hasData: true };
}

export const DashboardOverviewHero: React.FC<DashboardOverviewHeroProps> = ({
  notificationState,
  onEnableNotifications,
  onOpenReportModal,
  onPreloadReportModal,
  onNavigateTab,
  faturamentoBrutoMensal,
  receitaMesAtualTotal,
  receitaMesAtualMotos,
  receitaMesAtualKitnets,
  receitaAnualProjetada,
  faturamentoMensalMotos,
  faturamentoMensalKitnets,
  totalReceitaRecebida,
  totalAReceber,
  totalInadimplenciaGeral,
  totalMotos,
  totalKitnets,
  motosAlugadas,
  kitnetsAlugadas,
  totalContratosAtivos,
  patrimonioTotalAvaliado = 0,
  overdueCount,
  dueTodayCount,
  upcomingCount,
  taxaOcupacaoGeral,
  monthlyEvolutionData,
}) => {
  useLifecycleLogger('DashboardOverviewHero');
  const { isReadOnlyMode } = useApp();

  const totalBens = totalMotos + totalKitnets;
  const totalAlugados = motosAlugadas + kitnetsAlugadas;

  const aReceber = totalAReceber !== undefined ? totalAReceber : faturamentoBrutoMensal + totalInadimplenciaGeral;
  const anualFaturamento = receitaAnualProjetada !== undefined && receitaAnualProjetada > 0
    ? receitaAnualProjetada
    : faturamentoBrutoMensal * 12;

  // Receita Realizada / Recebida no Mês Atual (sobe em tempo real a cada baixa dada)
  const revenueReceivedThisMonth = receitaMesAtualTotal ?? 0;

  // 1. Cálculo real da variação de Faturamento vs Mês Anterior
  const prevMonthRevenue =
    monthlyEvolutionData && monthlyEvolutionData.length >= 2
      ? monthlyEvolutionData[monthlyEvolutionData.length - 2].receita
      : 0;

  const currentRevenueForDiff = revenueReceivedThisMonth > 0 ? revenueReceivedThisMonth : faturamentoBrutoMensal;

  let faturamentoVariacaoText = '0,0% vs mês ant.';
  let faturamentoVariacaoColor = 'text-text-secondary';

  if (currentRevenueForDiff === 0 && prevMonthRevenue === 0) {
    faturamentoVariacaoText = '0,0% vs mês ant.';
    faturamentoVariacaoColor = 'text-text-secondary';
  } else if (prevMonthRevenue > 0) {
    const diff = ((currentRevenueForDiff - prevMonthRevenue) / prevMonthRevenue) * 100;
    const sign = diff > 0 ? '+' : '';
    faturamentoVariacaoText = `${sign}${diff.toFixed(1).replace('.', ',')}% vs mês ant. ${diff >= 0 ? '↗' : '↘'}`;
    faturamentoVariacaoColor = diff >= 0 ? 'text-money-positive' : 'text-money-negative';
  } else if (currentRevenueForDiff > 0 && prevMonthRevenue === 0) {
    faturamentoVariacaoText = '+100% vs mês ant. ↗';
    faturamentoVariacaoColor = 'text-money-positive';
  }

  // 2. Indicador real de A Receber
  const totalPendingCobranças = overdueCount + dueTodayCount + upcomingCount;
  let aReceberSubtitleText = '0 pendências';
  let aReceberSubtitleColor = 'text-text-secondary';

  if (aReceber > 0 || totalPendingCobranças > 0) {
    aReceberSubtitleText = `${totalPendingCobranças} ${
      totalPendingCobranças === 1 ? 'cobrança pendente' : 'cobranças pendentes'
    }`;
    aReceberSubtitleColor = 'text-category-kitnets-cyan';
  }

  // 3. Sparklines dinâmicas baseadas em dados reais
  const faturamentoHistory =
    monthlyEvolutionData && monthlyEvolutionData.length > 0
      ? monthlyEvolutionData.map((p) => p.receita)
      : [0, 0, 0, 0, 0, revenueReceivedThisMonth || faturamentoBrutoMensal];

  const faturamentoSpark = getSparklinePaths(
    (revenueReceivedThisMonth === 0 && faturamentoBrutoMensal === 0) || faturamentoHistory.every((v) => v === 0)
      ? [0, 0, 0, 0, 0, 0]
      : faturamentoHistory
  );

  const aReceberSpark = getSparklinePaths(
    aReceber === 0 ? [0, 0, 0, 0, 0, 0] : [aReceber * 0.7, aReceber * 0.85, aReceber, aReceber, aReceber]
  );

  const inadimplenciaSpark = getSparklinePaths(
    totalInadimplenciaGeral === 0 ? [0, 0, 0, 0, 0, 0] : [0, 0, totalInadimplenciaGeral * 0.6, totalInadimplenciaGeral]
  );

  const patrimonioSpark = getSparklinePaths(
    patrimonioTotalAvaliado === 0
      ? [0, 0, 0, 0, 0, 0]
      : [patrimonioTotalAvaliado * 0.9, patrimonioTotalAvaliado * 0.95, patrimonioTotalAvaliado, patrimonioTotalAvaliado, patrimonioTotalAvaliado]
  );

  const heroContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!heroContainerRef.current) return;
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power2.out' } });

      tl.from('.gsap-dashboard-header', {
        y: -18,
        opacity: 0,
        duration: 0.5,
        clearProps: 'all',
      })
      .from('.gsap-kpi-card', {
        y: -22,
        opacity: 0,
        duration: 0.55,
        stagger: 0.08,
        clearProps: 'all',
      }, '-=0.28')
      .from('.gsap-alert-banner', {
        y: -18,
        opacity: 0,
        duration: 0.48,
        clearProps: 'all',
      }, '-=0.25')
      .from('.gsap-quick-action-item', {
        y: -16,
        opacity: 0,
        duration: 0.48,
        stagger: 0.06,
        clearProps: 'all',
      }, '-=0.25')
      .from('.gsap-patrimonio-card', {
        y: -20,
        opacity: 0,
        duration: 0.52,
        stagger: 0.07,
        clearProps: 'all',
      }, '-=0.25');
    }, heroContainerRef);

    return () => ctx.revert();
  }, []);

  return (
    <div ref={heroContainerRef} className="space-y-4 sm:space-y-5">
      {/* 1. Header Title & Top Actions */}
      <div className="gsap-dashboard-header flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-text-primary tracking-tight">
            Dashboard
          </h1>
          <p className="text-xs sm:text-sm text-text-secondary mt-0.5">
            Visão geral e indicadores consolidados em tempo real
          </p>
        </div>

        {!isReadOnlyMode && (
          <div className="flex flex-wrap sm:flex-nowrap items-center gap-2 sm:gap-2.5 w-full sm:w-auto">
            <button
              type="button"
              onPointerEnter={onPreloadReportModal}
              onTouchStart={onPreloadReportModal}
              onFocus={onPreloadReportModal}
              onClick={() => {
                onOpenReportModal();
              }}
              className="group h-9 sm:h-10 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 bg-action-primary hover:bg-action-hover text-white shadow-md shadow-action-primary/25 cursor-pointer transition-colors active:scale-95 shrink-0 whitespace-nowrap flex-1 sm:flex-initial select-none border-0"
            >
              <FileText className="w-4 h-4 text-white shrink-0 group-hover:scale-110 transition-transform" />
              <span>Exportar relatório</span>
            </button>
          </div>
        )}
      </div>

      {/* 2. Top Metric Cards Grid (4 Cards: Faturamento, A Receber, Inadimplência, Patrimônio da Frota) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Card 1: Faturamento do Mês */}
        <div
          onMouseEnter={(e) => gsapCardHoverEnter(e.currentTarget, -4, 1.012)}
          onMouseLeave={(e) => gsapCardHoverLeave(e.currentTarget)}
          className="gsap-kpi-card group p-4.5 rounded-2xl bg-surface-card border border-border-subtle hover:border-action-primary/50 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between relative overflow-hidden transition-colors cursor-default"
        >
          {/* Subtle Top Glow Accent */}
          <div className="absolute top-0 left-0 right-0 h-[2.5px] bg-gradient-to-r from-transparent via-action-primary/60 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />

          <div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-semibold text-text-secondary">Faturamento (Mês)</span>
                <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-purple-100 dark:bg-action-primary/15 text-purple-700 dark:text-action-primary border border-purple-200 dark:border-action-primary/25">
                  Previsão
                </span>
              </div>
              <div className="w-7 h-7 rounded-lg bg-purple-100 dark:bg-action-primary/15 flex items-center justify-center text-purple-600 dark:text-action-primary group-hover:scale-110 transition-transform">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>

            <div className="mt-3">
              <div className="text-2xl font-extrabold text-text-primary dark:text-text-primary tracking-tight tabular-nums">
                <AnimatedNumber
                  value={faturamentoBrutoMensal}
                  format="currency"
                  cacheKey="hero_faturamento_bruto"
                />
              </div>
              <div className="flex items-center justify-between mt-1.5 text-[11px]">
                <span className={`font-semibold ${faturamentoVariacaoColor}`}>{faturamentoVariacaoText}</span>
                <span className="text-text-secondary font-mono text-[11px]">
                  Ano: <strong className="text-text-primary dark:text-text-primary font-semibold">{formatCurrency(anualFaturamento)}</strong>
                </span>
              </div>
            </div>
          </div>

          {/* Dynamic Purple Sparkline */}
          {faturamentoSpark.hasData && (
            <div className="mt-3 w-full h-8 relative">
              <svg viewBox="0 0 100 32" preserveAspectRatio="none" className="w-full h-full overflow-visible">
                <defs>
                  <linearGradient id="purpleGlowGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={COLORS.action.primary} stopOpacity={0.35} />
                    <stop offset="100%" stopColor={COLORS.action.primary} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <path
                  d={faturamentoSpark.line}
                  fill="none"
                  stroke={COLORS.action.primary}
                  strokeWidth={2.5}
                  strokeLinecap="round"
                />
                <path
                  d={faturamentoSpark.fill}
                  fill="url(#purpleGlowGradient)"
                />
              </svg>
            </div>
          )}
        </div>

        {/* Card 2: A receber */}
        <div
          onMouseEnter={(e) => gsapCardHoverEnter(e.currentTarget, -4, 1.012)}
          onMouseLeave={(e) => gsapCardHoverLeave(e.currentTarget)}
          className="gsap-kpi-card group p-4.5 rounded-2xl bg-surface-card border border-border-subtle hover:border-category-kitnets-cyan/50 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between relative overflow-hidden transition-colors cursor-default"
        >
          {/* Subtle Top Glow Accent */}
          <div className="absolute top-0 left-0 right-0 h-[2.5px] bg-gradient-to-r from-transparent via-category-kitnets-cyan/60 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />

          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-text-secondary">A receber</span>
            <div className="w-7 h-7 rounded-lg bg-sky-100 dark:bg-category-kitnets-cyan/15 flex items-center justify-center text-sky-600 dark:text-category-kitnets-cyan group-hover:scale-110 transition-transform">
              <Wallet className="w-4 h-4" />
            </div>
          </div>

          <div className="mt-3">
            <div className="text-2xl font-extrabold text-text-primary dark:text-text-primary tracking-tight tabular-nums">
              <AnimatedNumber value={aReceber} format="currency" cacheKey="hero_a_receber" />
            </div>
            <div className={`flex items-center gap-1 mt-1 text-[11px] font-semibold ${aReceberSubtitleColor}`}>
              <span>{aReceberSubtitleText}</span>
            </div>
          </div>

          {/* Dynamic Cyan Sparkline */}
          {aReceberSpark.hasData && (
            <div className="mt-3 w-full h-8 relative">
              <svg viewBox="0 0 100 32" preserveAspectRatio="none" className="w-full h-full overflow-visible">
                <defs>
                  <linearGradient id="cyanGlowGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={COLORS.category.kitnetsCyan} stopOpacity={0.35} />
                    <stop offset="100%" stopColor={COLORS.category.kitnetsCyan} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <path
                  d={aReceberSpark.line}
                  fill="none"
                  stroke={COLORS.category.kitnetsCyan}
                  strokeWidth={2.5}
                  strokeLinecap="round"
                />
                <path
                  d={aReceberSpark.fill}
                  fill="url(#cyanGlowGradient)"
                />
              </svg>
            </div>
          )}
        </div>

        {/* Card 3: Inadimplência */}
        <div
          onMouseEnter={(e) => gsapCardHoverEnter(e.currentTarget, -4, 1.012)}
          onMouseLeave={(e) => gsapCardHoverLeave(e.currentTarget)}
          onClick={(e) => {
            if (!isReadOnlyMode) {
              gsapButtonPress(e.currentTarget);
              onNavigateTab('cobrancas');
            }
          }}
          className={`gsap-kpi-card group p-4.5 rounded-2xl bg-surface-card border border-border-subtle shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between relative overflow-hidden transition-colors ${
            isReadOnlyMode ? 'cursor-default' : 'hover:border-money-negative/50 cursor-pointer'
          }`}
        >
          {/* Subtle Top Glow Accent */}
          <div className="absolute top-0 left-0 right-0 h-[2.5px] bg-gradient-to-r from-transparent via-money-negative/60 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />

          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-text-secondary">Inadimplência</span>
            <div className="w-7 h-7 rounded-lg bg-rose-100 dark:bg-money-negative/15 flex items-center justify-center text-rose-600 dark:text-money-negative group-hover:scale-110 transition-transform">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>

          <div className="mt-3">
            <div className="text-2xl font-extrabold text-money-negative tracking-tight tabular-nums">
              <AnimatedNumber value={totalInadimplenciaGeral} format="currency" cacheKey="hero_inadimplencia" />
            </div>
            <div className="flex items-center gap-1 mt-1 text-[11px] font-semibold text-money-negative">
              <span>{`${overdueCount} ${overdueCount === 1 ? 'cobrança em atraso' : 'cobranças em atraso'}`}</span>
            </div>
          </div>

          {/* Dynamic Red Sparkline */}
          {inadimplenciaSpark.hasData && (
            <div className="mt-3 w-full h-8 relative">
              <svg viewBox="0 0 100 32" preserveAspectRatio="none" className="w-full h-full overflow-visible">
                <defs>
                  <linearGradient id="redGlowGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={COLORS.money.negative} stopOpacity={0.35} />
                    <stop offset="100%" stopColor={COLORS.money.negative} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <path
                  d={inadimplenciaSpark.line}
                  fill="none"
                  stroke={COLORS.money.negative}
                  strokeWidth={2.5}
                  strokeLinecap="round"
                />
                <path
                  d={inadimplenciaSpark.fill}
                  fill="url(#redGlowGradient)"
                />
              </svg>
            </div>
          )}
        </div>

        {/* Card 4: Patrimônio da Frota (Motos) */}
        <div
          onMouseEnter={(e) => gsapCardHoverEnter(e.currentTarget, -4, 1.012)}
          onMouseLeave={(e) => gsapCardHoverLeave(e.currentTarget)}
          onClick={(e) => {
            gsapButtonPress(e.currentTarget);
            onNavigateTab('motos');
          }}
          className="gsap-kpi-card group p-4.5 rounded-2xl bg-surface-card border border-border-subtle hover:border-category-motos/50 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between relative overflow-hidden cursor-pointer transition-colors"
        >
          {/* Subtle Top Glow Accent */}
          <div className="absolute top-0 left-0 right-0 h-[2.5px] bg-gradient-to-r from-transparent via-category-motos/60 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-semibold text-text-secondary">Patrimônio da Frota</span>
              <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-100 dark:bg-category-motos/15 text-amber-700 dark:text-category-motos border border-amber-200 dark:border-category-motos/25">
                Frota
              </span>
            </div>
            <div className="w-7 h-7 rounded-lg bg-amber-100 dark:bg-category-motos/15 flex items-center justify-center text-amber-600 dark:text-category-motos group-hover:scale-110 transition-transform">
              <Motorbike className="w-4 h-4" />
            </div>
          </div>

          <div className="mt-3">
            <div className="text-2xl font-extrabold text-text-primary dark:text-text-primary tracking-tight tabular-nums">
              <AnimatedNumber value={patrimonioTotalAvaliado} format="currency" cacheKey="hero_patrimonio" />
            </div>
            <div className="flex items-center justify-between mt-1 text-[11px]">
              <span className="text-amber-600 dark:text-category-motos font-semibold">
                {`${totalMotos} ${totalMotos === 1 ? 'moto' : 'motos'}`}
              </span>
              <span className="text-text-secondary">
                {`${motosAlugadas} alugadas`}
              </span>
            </div>
          </div>

          {/* Dynamic Amber/Orange Sparkline */}
          {patrimonioSpark.hasData && (
            <div className="mt-3 w-full h-8 relative">
              <svg viewBox="0 0 100 32" preserveAspectRatio="none" className="w-full h-full overflow-visible">
                <defs>
                  <linearGradient id="orangeGlowGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={COLORS.category.motos} stopOpacity={0.35} />
                    <stop offset="100%" stopColor={COLORS.category.motos} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <path
                  d={patrimonioSpark.line}
                  fill="none"
                  stroke={COLORS.category.motos}
                  strokeWidth={2.5}
                  strokeLinecap="round"
                />
                <path
                  d={patrimonioSpark.fill}
                  fill="url(#orangeGlowGradient)"
                />
              </svg>
            </div>
          )}
        </div>
      </div>

      {/* 3. Alert Banner: Atenção necessária - Oculto no Modo Leitura e apenas exibido se houver pendências reais */}
      {!isReadOnlyMode && (totalInadimplenciaGeral > 0 || overdueCount > 0 || dueTodayCount > 0) && (
        <div
          className={`gsap-alert-banner p-3.5 sm:p-4.5 rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-3.5 shadow-xs transition-colors ${
            overdueCount > 0 || totalInadimplenciaGeral > 0
              ? 'bg-rose-50/80 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/40 text-rose-950 dark:text-rose-100'
              : 'bg-amber-50/80 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 text-amber-950 dark:text-amber-100'
          }`}
        >
          <div className="flex items-center gap-3 min-w-0 flex-1">
            <div
              className={`w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center shrink-0 ${
                overdueCount > 0 || totalInadimplenciaGeral > 0
                  ? 'bg-rose-100 dark:bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-500/30'
                  : 'bg-amber-100 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-500/30'
              }`}
            >
              <AlertTriangle className="w-4.5 h-4.5 sm:w-5 sm:h-5" />
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span
                  className={`text-[11px] font-bold uppercase tracking-wider ${
                    overdueCount > 0 || totalInadimplenciaGeral > 0
                      ? 'text-rose-600 dark:text-rose-400'
                      : 'text-amber-600 dark:text-amber-400'
                  }`}
                >
                  {overdueCount > 0 ? 'Atenção necessária' : 'Lembrete de Vencimentos'}
                </span>
              </div>
              <div className="text-sm sm:text-base font-bold text-text-primary dark:text-text-primary mt-0.5 flex flex-wrap items-baseline gap-1.5">
                <span>{formatCurrency(totalInadimplenciaGeral)}</span>
                <span className="text-xs font-normal text-text-secondary">em cobranças com pendência</span>
              </div>
              {/* Status Breakdown Pills */}
              <div className="flex flex-wrap items-center gap-2.5 mt-1.5 text-xs font-medium">
                {overdueCount > 0 && (
                  <span className="flex items-center gap-1.5 text-rose-600 dark:text-rose-400 font-semibold">
                    <span className="w-2 h-2 rounded-full bg-rose-500" />
                    {`${overdueCount} ${overdueCount === 1 ? 'vencida' : 'vencidas'}`}
                  </span>
                )}
                {dueTodayCount > 0 && (
                  <span className="flex items-center gap-1.5 text-amber-600 dark:text-amber-400 font-semibold">
                    <span className="w-2 h-2 rounded-full bg-amber-500" />
                    {`${dueTodayCount} ${dueTodayCount === 1 ? 'vence hoje' : 'vencem hoje'}`}
                  </span>
                )}
                {upcomingCount > 0 && (
                  <span className="flex items-center gap-1.5 text-text-secondary">
                    <span className="w-2 h-2 rounded-full bg-text-muted" />
                    {`${upcomingCount} a vencer`}
                  </span>
                )}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={(e) => {
              gsapButtonPress(e.currentTarget);
              onNavigateTab('cobrancas');
            }}
            className={`w-full sm:w-auto px-4 py-2 rounded-xl text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 shrink-0 self-stretch sm:self-auto md:self-center select-none shadow-sm ${
              overdueCount > 0 || totalInadimplenciaGeral > 0
                ? 'bg-rose-600 hover:bg-rose-500 shadow-rose-600/20'
                : 'bg-amber-600 hover:bg-amber-500 shadow-amber-600/20'
            }`}
          >
            <span>Ver cobranças</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 4. Section: Ações rápidas - Oculto em Modo Leitura */}
      {!isReadOnlyMode && (
        <div className="space-y-3">
          <h2 className="text-base font-bold text-text-primary dark:text-text-primary">Ações rápidas</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {/* Action 1: Ativar Alertas */}
            <button
              type="button"
              onClick={(e) => {
                gsapButtonPress(e.currentTarget);
                onEnableNotifications();
              }}
              className="gsap-quick-action-item p-3.5 rounded-2xl bg-surface-card hover:bg-slate-50 dark:bg-surface-base dark:hover:bg-surface-card border border-border-subtle hover:border-slate-300 dark:hover:border-border-subtle flex items-center gap-3 text-left transition-colors cursor-pointer group active:scale-95 select-none shadow-xs"
            >
              <div className="w-9 h-9 rounded-xl bg-purple-100 dark:bg-action-primary/15 flex items-center justify-center text-purple-600 dark:text-action-primary shrink-0 group-hover:scale-105 transition-transform">
                <Bell className="w-4 h-4" />
              </div>
              <span className="text-xs sm:text-sm font-semibold text-text-primary dark:text-text-primary truncate">
                {notificationState === 'granted' ? 'Alertas Ativos' : 'Ativar Alertas'}
              </span>
            </button>

            {/* Action 2: Documentos */}
            <button
              type="button"
              onClick={(e) => {
                gsapButtonPress(e.currentTarget);
                onNavigateTab('documentos');
              }}
              className="gsap-quick-action-item p-3.5 rounded-2xl bg-surface-card hover:bg-slate-50 dark:bg-surface-base dark:hover:bg-surface-card border border-border-subtle hover:border-slate-300 dark:hover:border-border-subtle flex items-center gap-3 text-left transition-colors cursor-pointer group active:scale-95 select-none shadow-xs"
            >
              <div className="w-9 h-9 rounded-xl bg-purple-100 dark:bg-action-primary/15 flex items-center justify-center text-purple-600 dark:text-action-primary shrink-0 group-hover:scale-105 transition-transform">
                <FileText className="w-4 h-4" />
              </div>
              <span className="text-xs sm:text-sm font-semibold text-text-primary dark:text-text-primary truncate">Documentos</span>
            </button>

            {/* Action 3: Relatórios DRE */}
            <button
              type="button"
              onClick={(e) => {
                gsapButtonPress(e.currentTarget);
                onNavigateTab('relatorios');
              }}
              className="gsap-quick-action-item p-3.5 rounded-2xl bg-surface-card hover:bg-slate-50 dark:bg-surface-base dark:hover:bg-surface-card border border-border-subtle hover:border-slate-300 dark:hover:border-border-subtle flex items-center gap-3 text-left transition-colors cursor-pointer group active:scale-95 select-none shadow-xs"
            >
              <div className="w-9 h-9 rounded-xl bg-purple-100 dark:bg-action-primary/15 flex items-center justify-center text-purple-600 dark:text-action-primary shrink-0 group-hover:scale-105 transition-transform">
                <FileSpreadsheet className="w-4 h-4" />
              </div>
              <span className="text-xs sm:text-sm font-semibold text-text-primary dark:text-text-primary truncate">Relatórios DRE</span>
            </button>
          </div>
        </div>
      )}

      {/* 5. Section: Acesso rápido - Oculto no Modo Leitura */}
      {!isReadOnlyMode && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-text-primary dark:text-text-primary">Patrimônio & Ocupação</h2>
            <button
              type="button"
              onClick={() => onNavigateTab('financeiro')}
              className="text-xs font-semibold text-action-primary hover:text-action-light transition-colors cursor-pointer active:scale-95"
            >
              Ver todos
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {/* Card 1: Central de Contratos */}
            <div
              onMouseEnter={(e) => gsapCardHoverEnter(e.currentTarget, -3, 1.01)}
              onMouseLeave={(e) => gsapCardHoverLeave(e.currentTarget)}
              onClick={(e) => {
                gsapButtonPress(e.currentTarget);
                onNavigateTab('cobrancas');
              }}
              className="gsap-patrimonio-card p-4 rounded-2xl bg-surface-card border border-border-subtle hover:border-category-kitnets-sky/40 flex flex-col justify-between transition-colors cursor-pointer group select-none shadow-xs hover:shadow-md"
            >
              <div className="flex items-start justify-between">
                <div className="w-10 h-10 rounded-xl bg-sky-100 dark:bg-category-kitnets-sky/15 flex items-center justify-center text-sky-600 dark:text-category-kitnets-sky">
                  <FileCheck2 className="w-5 h-5" />
                </div>
                <ArrowUpRight className="w-4 h-4 text-text-secondary group-hover:text-category-kitnets-sky group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
              </div>

              <div className="mt-4">
                <h3 className="text-sm font-bold text-text-primary dark:text-text-primary">Central de Contratos</h3>
                <p className="text-xs text-text-secondary mt-0.5">
                  {`${totalContratosAtivos} ${totalContratosAtivos === 1 ? 'contrato ativo' : 'contratos ativos'}`}
                </p>

                {/* Progress Bar */}
                <div className="mt-3 flex items-center justify-between gap-3">
                  <div className="flex-1 h-1.5 rounded-full bg-surface-subtle overflow-hidden">
                    <div
                      className="h-full rounded-full bg-category-kitnets-sky transition-all duration-500"
                      style={{ width: `${Math.min(100, Math.max(0, taxaOcupacaoGeral))}%` }}
                    />
                  </div>
                  <span className="text-[11px] font-semibold text-sky-600 dark:text-category-kitnets-sky whitespace-nowrap">
                    {Math.round(taxaOcupacaoGeral)}% ocupação
                  </span>
                </div>
              </div>
            </div>

            {/* Card 2: Clientes & Score */}
            <div
              onMouseEnter={(e) => gsapCardHoverEnter(e.currentTarget, -3, 1.01)}
              onMouseLeave={(e) => gsapCardHoverLeave(e.currentTarget)}
              onClick={(e) => {
                gsapButtonPress(e.currentTarget);
                onNavigateTab('clientes');
              }}
              className="gsap-patrimonio-card p-4 rounded-2xl bg-surface-card border border-border-subtle hover:border-action-primary/40 flex flex-col justify-between transition-colors cursor-pointer group select-none shadow-xs hover:shadow-md"
            >
              <div className="flex items-start justify-between">
                <div className="w-10 h-10 rounded-xl bg-purple-100 dark:bg-action-primary/15 flex items-center justify-center text-purple-600 dark:text-action-primary">
                  <Users className="w-5 h-5" />
                </div>
                <ArrowUpRight className="w-4 h-4 text-text-secondary group-hover:text-action-primary group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
              </div>

              <div className="mt-4">
                <h3 className="text-sm font-bold text-text-primary dark:text-text-primary">Clientes & Score</h3>
                <p className="text-xs text-text-secondary mt-0.5">
                  {`${totalContratosAtivos} ${totalContratosAtivos === 1 ? 'cliente ativo' : 'clientes ativos'}`}
                </p>

                {/* Progress Bar */}
                <div className="mt-3 flex items-center justify-between gap-3">
                  <div className="flex-1 h-1.5 rounded-full bg-surface-subtle overflow-hidden">
                    <div className="h-full rounded-full bg-action-primary transition-all duration-500" style={{ width: totalContratosAtivos > 0 ? '84%' : '0%' }} />
                  </div>
                  <span className="text-[11px] font-semibold text-purple-600 dark:text-action-primary whitespace-nowrap">
                    {totalContratosAtivos > 0 ? 'Score médio 842' : 'Sem histórico'}
                  </span>
                </div>
              </div>
            </div>

            {/* Card 3: Receitas & Despesas */}
            <div
              onMouseEnter={(e) => gsapCardHoverEnter(e.currentTarget, -3, 1.01)}
              onMouseLeave={(e) => gsapCardHoverLeave(e.currentTarget)}
              onClick={(e) => {
                gsapButtonPress(e.currentTarget);
                onNavigateTab('financeiro');
              }}
              className="gsap-patrimonio-card p-4 rounded-2xl bg-surface-card border border-border-subtle hover:border-category-motos/40 flex flex-col justify-between transition-colors cursor-pointer group select-none shadow-xs hover:shadow-md"
            >
              <div className="flex items-start justify-between">
                <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-category-motos/15 flex items-center justify-center text-amber-600 dark:text-category-motos">
                  <Coins className="w-5 h-5" />
                </div>
                <ArrowUpRight className="w-4 h-4 text-text-secondary group-hover:text-category-motos group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
              </div>

              <div className="mt-4">
                <h3 className="text-sm font-bold text-text-primary dark:text-text-primary">Receitas & Despesas</h3>
                <p className="text-xs text-text-secondary mt-0.5">Fluxo de caixa</p>

                {/* Progress Bar */}
                <div className="mt-3 flex items-center justify-between gap-3">
                  <div className="flex-1 h-1.5 rounded-full bg-surface-subtle overflow-hidden">
                    <div className="h-full rounded-full bg-category-motos transition-all duration-500" style={{ width: faturamentoBrutoMensal > 0 ? '70%' : '0%' }} />
                  </div>
                  <span className={`text-[11px] font-semibold whitespace-nowrap ${faturamentoBrutoMensal > 0 ? 'text-money-positive' : 'text-text-secondary'}`}>
                    {faturamentoBrutoMensal > 0 ? 'Saldo positivo' : 'Sem lançamentos'}
                  </span>
                </div>
              </div>
            </div>

            {/* Card 4: Relatórios & Exportação */}
            <div
              onMouseEnter={(e) => gsapCardHoverEnter(e.currentTarget, -3, 1.01)}
              onMouseLeave={(e) => gsapCardHoverLeave(e.currentTarget)}
              onClick={(e) => {
                gsapButtonPress(e.currentTarget);
                onNavigateTab('relatorios');
              }}
              className="gsap-patrimonio-card p-4 rounded-2xl bg-surface-card border border-border-subtle hover:border-emerald-500/40 flex flex-col justify-between transition-colors cursor-pointer group select-none shadow-xs hover:shadow-md"
            >
              <div className="flex items-start justify-between">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-500/15 flex items-center justify-center text-emerald-600 dark:text-money-positive">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <ArrowUpRight className="w-4 h-4 text-text-secondary group-hover:text-emerald-500 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
              </div>

              <div className="mt-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-text-primary dark:text-text-primary">Relatórios & DRE</h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/30">
                    Excel & PDF
                  </span>
                </div>
                <p className="text-xs text-text-secondary mt-0.5">Demonstrativos consolidados</p>

                {/* Subtitle / status */}
                <div className="mt-3 flex items-center justify-between gap-3">
                  <div className="flex-1 h-1.5 rounded-full bg-surface-subtle overflow-hidden">
                    <div className="h-full rounded-full bg-emerald-500 transition-all duration-500" style={{ width: totalBens > 0 ? '100%' : '0%' }} />
                  </div>
                  <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 whitespace-nowrap">
                    Exportação Pronta
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
