import React from 'react';
import {
  Wallet,
  Calendar,
  AlertTriangle,
  ShieldCheck,
  Printer,
  Scale,
} from 'lucide-react';
import { CategoryStamp } from '../CategoryIcons';
import { formatCurrency } from '../../utils/formatters';
import { AnimatedNumber } from '../AnimatedNumber';
import { TabType } from '../Navigation';
import { useLifecycleLogger } from '../../utils/perfLogger';
import { useApp } from '../../context/AppContext';

interface DashboardAssetsSummaryProps {
  totalMotos: number;
  motosAlugadas: number;
  motosDisponiveis: number;
  motosManutencao: number;
  taxaOcupacaoMotos: number;
  faturamentoMensalMotos: number;
  receitaMesAtualMotos?: number;
  inadimplenciaMotos: number;
  inadimplenciaPctMotos?: number;
  valorInvestidoMotos?: number;
  totalKitnets: number;
  kitnetsAlugadas: number;
  kitnetsDisponiveis: number;
  kitnetsManutencao: number;
  taxaOcupacaoKitnets: number;
  faturamentoMensalKitnets: number;
  receitaMesAtualKitnets?: number;
  inadimplenciaKitnets: number;
  inadimplenciaPctKitnets?: number;
  valorInvestidoKitnets?: number;
  onNavigateTab: (tab: TabType) => void;
  onOpenReportModal?: () => void;
}

export const DashboardAssetsSummary: React.FC<DashboardAssetsSummaryProps> = ({
  totalMotos,
  motosAlugadas,
  motosDisponiveis,
  motosManutencao,
  taxaOcupacaoMotos,
  faturamentoMensalMotos,
  receitaMesAtualMotos = 0,
  inadimplenciaMotos,
  inadimplenciaPctMotos = 0,
  valorInvestidoMotos = 0,
  totalKitnets,
  kitnetsAlugadas,
  kitnetsDisponiveis,
  kitnetsManutencao,
  taxaOcupacaoKitnets,
  faturamentoMensalKitnets,
  receitaMesAtualKitnets = 0,
  inadimplenciaKitnets,
  inadimplenciaPctKitnets = 0,
  valorInvestidoKitnets = 0,
  onNavigateTab,
  onOpenReportModal,
}) => {
  useLifecycleLogger('DashboardAssetsSummary');
  const { isReadOnlyMode } = useApp();

  return (
    <div className="space-y-3">
      {/* Optional Top Section Header with Relatório Completo button */}
      <div className="flex items-center justify-between gap-3 pb-1 border-b border-border-subtle">
        <div>
          <h3 className="text-xs sm:text-sm font-bold text-text-primary flex items-center gap-2">
            <Scale className="w-4 h-4 text-action-primary" />
            <span>Gestão Operacional & Financeira de Ativos</span>
          </h3>
          <p className="text-[11px] text-text-muted">
            Acompanhamento em tempo real de ocupação, faturamento mensal, projeções e patrimônio
          </p>
        </div>
        {onOpenReportModal && !isReadOnlyMode && (
          <button
            type="button"
            onClick={onOpenReportModal}
            className="group h-8.5 sm:h-9 px-3.5 rounded-xl text-xs font-bold flex items-center gap-1.5 bg-action-primary hover:bg-action-hover text-white dark:bg-surface-subtle dark:hover:bg-surface-card dark:text-white dark:border dark:border-action-primary/40 shadow-xs cursor-pointer transition-all shrink-0 active:scale-95 border-0"
          >
            <Printer className="w-3.5 h-3.5 text-white dark:text-action-light shrink-0" />
            <span>Relatório Completo</span>
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-5">
        {/* ================= CARD 1: FROTA DE MOTOS ================= */}
        <div
          className="gsap-asset-summary-card bg-surface-card rounded-2xl border border-border-subtle p-4 sm:p-5 space-y-3.5 flex flex-col justify-between shadow-xs hover:shadow-md dark:shadow-lg dark:shadow-black/40 hover:border-slate-300 dark:hover:border-border-subtle transition-all"
        >
          {/* Card Header */}
          <div className="flex items-center justify-between pb-3 border-b border-amber-200/60 dark:border-category-motos/20">
            <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
              <CategoryStamp category="moto" size="md" />
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-sm font-bold text-text-primary dark:text-text-primary">
                    Frota de Motos
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 dark:bg-category-motos/15 text-amber-700 dark:text-category-motos border border-amber-200 dark:border-category-motos/30">
                    {totalMotos} {totalMotos === 1 ? 'unidade' : 'unidades'}
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-500/20 font-mono">
                    {motosAlugadas}/{totalMotos} Alugadas
                  </span>
                </div>
                <p className="text-xs text-text-muted dark:text-text-secondary truncate mt-0.5">
                  Locação com opção de compra semanal/mensal
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onNavigateTab('motos')}
              className="text-xs text-action-primary hover:text-action-light hover:underline font-bold flex items-center gap-1 cursor-pointer whitespace-nowrap active:scale-95 transition-all shrink-0 ml-2"
            >
              Ver Frota →
            </button>
          </div>

          {/* Grid of 4 Metrics (2 columns on mobile, 4 columns on large screens) */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 text-xs">
            {/* 1. Alugadas */}
            <div className="p-3 bg-surface-subtle rounded-xl border border-border-subtle flex flex-col justify-between min-w-0">
              <span className="text-[10px] text-text-muted font-bold uppercase tracking-wider truncate">
                Alugadas
              </span>
              <div className="text-sm sm:text-base font-bold text-money-positive mt-1 tabular-nums flex items-baseline gap-1 truncate font-mono">
                <AnimatedNumber value={motosAlugadas} format="number" cacheKey="asset_motos_alugadas" />
                <span className="text-xs text-text-muted font-normal">({taxaOcupacaoMotos}%)</span>
              </div>
              <div className="w-full h-1.5 bg-surface-highlight rounded-full mt-2 overflow-hidden">
                <div
                  style={{ width: `${taxaOcupacaoMotos}%` }}
                  className="h-full bg-money-positive rounded-full transition-all duration-300"
                />
              </div>
            </div>

            {/* 2. Disponíveis */}
            <div className="p-3 bg-surface-subtle rounded-xl border border-border-subtle flex flex-col justify-between min-w-0">
              <span className="text-[10px] text-text-muted font-bold uppercase tracking-wider truncate">
                Disponíveis
              </span>
              <div className="text-sm sm:text-base font-bold text-text-primary mt-1 tabular-nums font-mono">
                <AnimatedNumber value={motosDisponiveis} format="number" cacheKey="asset_motos_disponiveis" />
              </div>
              <span className="text-[10px] text-text-muted block mt-1.5 truncate">
                {motosManutencao > 0 ? `${motosManutencao} em oficina` : 'Prontas para locação'}
              </span>
            </div>

            {/* 3. Receita (Mês) */}
            <div className="p-3 bg-surface-subtle rounded-xl border border-border-subtle flex flex-col justify-between min-w-0">
              <span className="text-[10px] text-text-muted font-bold uppercase tracking-wider truncate">
                Receita (Mês)
              </span>
              <div className="text-sm sm:text-base font-bold text-money-positive mt-1 tabular-nums truncate font-mono">
                <AnimatedNumber value={faturamentoMensalMotos} format="currency" cacheKey="asset_motos_fat_mensal" />
              </div>
              <span
                className={`text-[10px] font-semibold block mt-1.5 truncate ${
                  inadimplenciaMotos > 0 ? 'text-money-negative' : 'text-text-muted'
                }`}
              >
                {inadimplenciaMotos > 0
                  ? `${formatCurrency(inadimplenciaMotos)} atraso`
                  : receitaMesAtualMotos > 0
                  ? `Recebido: ${formatCurrency(receitaMesAtualMotos)}`
                  : 'Em dia'}
              </span>
            </div>

            {/* 4. Projeção Anual */}
            <div className="p-3 bg-slate-50/80 dark:bg-surface-base rounded-xl border border-border-subtle flex flex-col justify-between min-w-0">
              <div className="flex items-center gap-1 text-text-muted dark:text-text-secondary">
                <Calendar className="w-3 h-3 text-amber-500 dark:text-amber-400 shrink-0" />
                <span className="text-[10px] font-bold uppercase tracking-wider truncate">
                  Projeção Anual
                </span>
              </div>
              <div className="text-sm sm:text-base font-bold text-amber-600 dark:text-amber-400 mt-1 tabular-nums truncate font-mono">
                <AnimatedNumber value={faturamentoMensalMotos * 12} format="currency" cacheKey="asset_motos_fat_anual" />
              </div>
              <span className="text-[10px] text-text-muted dark:text-text-secondary block mt-1.5 truncate">
                12 meses projetados
              </span>
            </div>
          </div>

          {/* Bottom Footer: Capital Investido & Inadimplência Detalhada */}
          <div className="flex flex-wrap items-center justify-between pt-2.5 border-t border-border-subtle text-xs gap-2">
            <div className="flex items-center gap-1.5 text-text-muted min-w-0">
              <Wallet className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400/90 shrink-0" />
              <span className="text-[11px] text-text-muted">Capital Investido:</span>
              <span className="font-semibold text-text-primary dark:text-text-primary font-mono text-[11px] sm:text-xs">
                {formatCurrency(valorInvestidoMotos)}
              </span>
            </div>

            <div className="flex items-center gap-1.5 text-text-muted shrink-0">
              {inadimplenciaMotos > 0 ? (
                <AlertTriangle className="w-3.5 h-3.5 text-rose-500 dark:text-rose-400 shrink-0" />
              ) : (
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 dark:text-emerald-400 shrink-0" />
              )}
              <span className="text-[11px] text-text-muted">Inadimplência:</span>
              <span
                className={`font-semibold font-mono text-[11px] sm:text-xs ${
                  inadimplenciaMotos > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-600 dark:text-emerald-400'
                }`}
              >
                {formatCurrency(inadimplenciaMotos)} ({inadimplenciaPctMotos.toFixed(1)}%)
              </span>
            </div>
          </div>
        </div>

        {/* ================= CARD 2: IMÓVEIS — KITNETS ================= */}
        <div
          className="gsap-asset-summary-card bg-surface-card rounded-2xl border border-border-subtle p-4 sm:p-5 space-y-3.5 flex flex-col justify-between shadow-xs hover:shadow-md dark:shadow-lg dark:shadow-black/40 hover:border-slate-300 dark:hover:border-border-subtle transition-all"
        >
          {/* Card Header */}
          <div className="flex items-center justify-between pb-3 border-b border-sky-200/60 dark:border-category-kitnets-sky/20">
            <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
              <CategoryStamp category="kitnet" size="md" />
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-sm font-bold text-text-primary dark:text-text-primary">
                    Imóveis — Kitnets
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 dark:bg-category-kitnets-sky/15 text-sky-700 dark:text-category-kitnets-sky border border-sky-200 dark:border-category-kitnets-sky/30">
                    {totalKitnets} {totalKitnets === 1 ? 'unidade' : 'unidades'}
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-50 dark:bg-sky-500/10 text-sky-700 dark:text-sky-400 border border-sky-200 dark:border-sky-500/20 font-mono">
                    {kitnetsAlugadas}/{totalKitnets} Alugadas
                  </span>
                </div>
                <p className="text-xs text-text-muted dark:text-text-secondary truncate mt-0.5">
                  Locações residenciais & taxa de água
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onNavigateTab('kitnets')}
              className="text-xs text-action-primary hover:text-action-light hover:underline font-bold flex items-center gap-1 cursor-pointer whitespace-nowrap active:scale-95 transition-all shrink-0 ml-2"
            >
              Ver Imóveis →
            </button>
          </div>

          {/* Grid of 4 Metrics (2 columns on mobile, 4 columns on large screens) */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 text-xs">
            {/* 1. Alugadas */}
            <div className="p-3 bg-surface-subtle rounded-xl border border-border-subtle flex flex-col justify-between min-w-0">
              <span className="text-[10px] text-text-muted font-bold uppercase tracking-wider truncate">
                Alugadas
              </span>
              <div className="text-sm sm:text-base font-bold text-money-positive mt-1 tabular-nums flex items-baseline gap-1 truncate font-mono">
                <AnimatedNumber value={kitnetsAlugadas} format="number" cacheKey="asset_kitnets_alugadas" />
                <span className="text-xs text-text-muted font-normal">({taxaOcupacaoKitnets}%)</span>
              </div>
              <div className="w-full h-1.5 bg-surface-highlight rounded-full mt-2 overflow-hidden">
                <div
                  style={{ width: `${taxaOcupacaoKitnets}%` }}
                  className="h-full bg-money-positive rounded-full transition-all duration-300"
                />
              </div>
            </div>

            {/* 2. Disponíveis */}
            <div className="p-3 bg-surface-subtle rounded-xl border border-border-subtle flex flex-col justify-between min-w-0">
              <span className="text-[10px] text-text-muted font-bold uppercase tracking-wider truncate">
                Disponíveis
              </span>
              <div className="text-sm sm:text-base font-bold text-text-primary mt-1 tabular-nums font-mono">
                <AnimatedNumber value={kitnetsDisponiveis} format="number" cacheKey="asset_kitnets_disponiveis" />
              </div>
              <span className="text-[10px] text-text-muted block mt-1.5 truncate">
                {kitnetsManutencao > 0 ? `${kitnetsManutencao} em reforma` : 'Prontas para morar'}
              </span>
            </div>

            {/* 3. Receita (Mês) */}
            <div className="p-3 bg-surface-subtle rounded-xl border border-border-subtle flex flex-col justify-between min-w-0">
              <span className="text-[10px] text-text-muted font-bold uppercase tracking-wider truncate">
                Receita (Mês)
              </span>
              <div className="text-sm sm:text-base font-bold text-money-positive mt-1 tabular-nums truncate font-mono">
                <AnimatedNumber value={faturamentoMensalKitnets} format="currency" cacheKey="asset_kitnets_fat_mensal" />
              </div>
              <span
                className={`text-[10px] font-semibold block mt-1.5 truncate ${
                  inadimplenciaKitnets > 0 ? 'text-money-negative' : 'text-text-muted'
                }`}
              >
                {inadimplenciaKitnets > 0
                  ? `${formatCurrency(inadimplenciaKitnets)} atraso`
                  : receitaMesAtualKitnets > 0
                  ? `Recebido: ${formatCurrency(receitaMesAtualKitnets)}`
                  : 'Em dia'}
              </span>
            </div>

            {/* 4. Projeção Anual */}
            <div className="p-3 bg-surface-subtle rounded-xl border border-border-subtle flex flex-col justify-between min-w-0">
              <div className="flex items-center gap-1 text-text-muted">
                <Calendar className="w-3 h-3 text-sky-500 dark:text-sky-400 shrink-0" />
                <span className="text-[10px] font-bold uppercase tracking-wider truncate">
                  Projeção Anual
                </span>
              </div>
              <div className="text-sm sm:text-base font-bold text-sky-600 dark:text-sky-400 mt-1 tabular-nums truncate font-mono">
                <AnimatedNumber value={faturamentoMensalKitnets * 12} format="currency" cacheKey="asset_kitnets_fat_anual" />
              </div>
              <span className="text-[10px] text-text-muted dark:text-text-secondary block mt-1.5 truncate">
                12 meses projetados
              </span>
            </div>
          </div>

          {/* Bottom Footer: Patrimônio Avaliado & Inadimplência Detalhada */}
          <div className="flex flex-wrap items-center justify-between pt-2.5 border-t border-border-subtle text-xs gap-2">
            <div className="flex items-center gap-1.5 text-text-muted min-w-0">
              <Wallet className="w-3.5 h-3.5 text-sky-500 dark:text-sky-400/90 shrink-0" />
              <span className="text-[11px] text-text-muted">Patrimônio Avaliado:</span>
              <span className="font-semibold text-text-primary dark:text-text-primary font-mono text-[11px] sm:text-xs">
                {formatCurrency(valorInvestidoKitnets)}
              </span>
            </div>

            <div className="flex items-center gap-1.5 text-text-muted shrink-0">
              {inadimplenciaKitnets > 0 ? (
                <AlertTriangle className="w-3.5 h-3.5 text-rose-500 dark:text-rose-400 shrink-0" />
              ) : (
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 dark:text-emerald-400 shrink-0" />
              )}
              <span className="text-[11px] text-text-muted">Inadimplência:</span>
              <span
                className={`font-semibold font-mono text-[11px] sm:text-xs ${
                  inadimplenciaKitnets > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-600 dark:text-emerald-400'
                }`}
              >
                {formatCurrency(inadimplenciaKitnets)} ({inadimplenciaPctKitnets.toFixed(1)}%)
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
