import React, { useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Trash2, X } from 'lucide-react';
import { Expense } from '../../types';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { useBodyScrollLock } from '../../hooks/useBodyScrollLock';

interface DeleteExpenseModalProps {
  expense: Expense | null;
  onClose: () => void;
  onConfirmDelete: (expenseId: string) => void;
}

export const DeleteExpenseModal: React.FC<DeleteExpenseModalProps> = ({
  expense,
  onClose,
  onConfirmDelete,
}) => {
  useBodyScrollLock(!!expense);

  useEffect(() => {
    if (!expense) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [expense, onClose]);

  if (!expense || typeof document === 'undefined') return null;

  return createPortal(
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Excluir Despesa"
      className="fixed inset-0 z-[110] flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn font-sans"
    >
      <div className="bg-surface-sidebar border border-border-subtle rounded-2xl sm:rounded-3xl w-full max-w-lg mx-auto overflow-hidden shadow-2xl shadow-black/40 dark:shadow-black/80 my-auto animate-modal-enter">
        <div className="p-4 sm:p-5 border-b border-border-subtle flex items-center justify-between bg-surface-card">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-text-primary">Excluir Despesa</h3>
              <p className="text-xs text-text-muted">Esta ação removerá a conta do histórico</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-text-muted hover:text-text-primary hover:bg-surface-subtle border border-transparent hover:border-border-subtle transition-all cursor-pointer shrink-0 active:scale-95"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-4 bg-surface-card">
          <p className="text-xs sm:text-sm text-text-muted dark:text-text-secondary">
            Tem certeza de que deseja excluir permanentemente a despesa{' '}
            <strong className="text-text-primary font-semibold">"{expense.title}"</strong>?
          </p>

          <div className="p-4 rounded-2xl bg-surface-subtle border border-border-subtle space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-text-muted font-medium">Valor:</span>
              <span className="font-bold text-text-primary tabular-nums">{formatCurrency(expense.amount)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-text-muted font-medium">Vencimento:</span>
              <span className="text-text-primary tabular-nums">{formatDate(expense.dueDate)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-text-muted font-medium">Status:</span>
              <span className="capitalize text-text-primary font-medium">{expense.status}</span>
            </div>
          </div>

          <div className="pt-3 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs sm:text-sm font-semibold text-text-muted hover:text-text-primary dark:hover:text-white rounded-xl hover:bg-surface-subtle transition-colors cursor-pointer active:scale-95"
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={() => onConfirmDelete(expense.id)}
              className="px-5 py-2.5 bg-rose-600 hover:bg-rose-500 active:scale-95 text-white font-bold text-xs sm:text-sm rounded-xl transition-all cursor-pointer flex items-center gap-2 shadow-lg shadow-rose-600/25"
            >
              <Trash2 className="w-4 h-4" />
              <span>Sim, Excluir Despesa</span>
            </button>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
};
