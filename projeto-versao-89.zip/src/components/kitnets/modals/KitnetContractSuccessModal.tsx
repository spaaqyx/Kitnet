import React, { useEffect, useRef } from 'react';
import { useBodyScrollLock } from '../../../hooks/useBodyScrollLock';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import { FileCheck, FileText, X } from 'lucide-react';
import { Kitnet, KitnetContract, KitnetTenant, SystemSettings } from '../../../types';
import { formatCurrency, formatCPF } from '../../../utils/formatters';
import { generateKitnetContractPdfFile } from '../../../utils/pdfGenerator';

interface KitnetContractSuccessModalProps {
  data: {
    kitnet: Kitnet;
    tenant: KitnetTenant;
    contract: KitnetContract;
  } | null;
  settings: SystemSettings;
  onClose: () => void;
}

export const KitnetContractSuccessModal: React.FC<KitnetContractSuccessModalProps> = ({
  data,
  settings,
  onClose,
}) => {
  const isOpen = Boolean(data);
  const shouldReduceMotion = useReducedMotion();

  const lastDataRef = useRef(data);
  if (data) {
    lastDataRef.current = data;
  }
  const currentData = data || lastDataRef.current;

  useBodyScrollLock(isOpen);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (typeof document === 'undefined') return null;

  return createPortal(
    <AnimatePresence>
      {isOpen && currentData && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Sucesso do Contrato"
          className="fixed inset-0 z-[110] flex items-center justify-center p-3 sm:p-4 font-sans"
        >
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: shouldReduceMotion ? 0.05 : 0.2 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
            onClick={onClose}
          />

          {/* Modal Container */}
          <motion.div
            initial={shouldReduceMotion ? { opacity: 0 } : { opacity: 0, scale: 0.95, y: 12 }}
            animate={shouldReduceMotion ? { opacity: 1 } : { opacity: 1, scale: 1, y: 0 }}
            exit={shouldReduceMotion ? { opacity: 0 } : { opacity: 0, scale: 0.95, y: 12 }}
            transition={{
              duration: shouldReduceMotion ? 0.05 : 0.22,
              ease: [0.16, 1, 0.3, 1],
            }}
            className="relative bg-surface-base border border-sky-500/30 rounded-2xl w-full max-w-lg mx-auto p-5 sm:p-6 shadow-2xl space-y-4 my-auto overflow-hidden z-10 animate-modal-enter"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-sky-500/15 border border-sky-500/30 flex items-center justify-center shrink-0 text-sky-400">
                <FileCheck className="w-5 h-5" />
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="text-base font-bold text-white leading-tight">
                  Contrato de Locação Residencial
                </h3>
                <p className="text-xs text-text-muted mt-0.5">
                  Unidade vinculada com sucesso ao inquilino.
                </p>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 rounded-xl text-text-muted hover:text-text-primary hover:bg-surface-hover transition-colors cursor-pointer active:scale-95"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 bg-surface-base border border-border-subtle rounded-xl space-y-2.5 text-xs">
              <div className="flex items-center justify-between text-text-muted">
                <span>Imóvel / Unidade:</span>
                <span className="font-semibold text-white">
                  {currentData.kitnet.name} (Unid. {currentData.kitnet.number})
                </span>
              </div>
              <div className="flex items-center justify-between text-text-muted">
                <span>Locatário(a):</span>
                <span className="font-semibold text-sky-400">
                  {currentData.tenant.fullName}
                </span>
              </div>
              <div className="flex items-center justify-between text-text-muted">
                <span>CPF:</span>
                <span className="font-mono text-white">
                  {formatCPF(currentData.tenant.cpf)}
                </span>
              </div>
              <div className="flex items-center justify-between text-text-muted">
                <span>Aluguel Mensal:</span>
                <span className="font-bold text-emerald-400 font-mono text-sm">
                  {formatCurrency(currentData.contract.rentValue)} / mês
                </span>
              </div>
            </div>

            <div className="space-y-2.5 pt-1">
              <button
                type="button"
                onClick={() => {
                  generateKitnetContractPdfFile({
                    kitnet: currentData.kitnet,
                    contract: currentData.contract,
                    tenant: currentData.tenant,
                    settings,
                    autoDownload: true,
                  });
                }}
                className="w-full py-3 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-sky-500/20 transition-all active:scale-95 cursor-pointer"
              >
                <FileText className="w-4 h-4" />
                <span>Gerar Contrato de Locação (Baixar PDF)</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="w-full py-2.5 bg-surface-subtle hover:bg-surface-hover text-text-secondary hover:text-white font-semibold rounded-xl text-xs transition-colors border border-border-subtle active:scale-95 cursor-pointer"
              >
                Fechar / Visualizar Unidade
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body
  );
};
