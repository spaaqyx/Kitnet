import React, { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import { Trash2, AlertTriangle } from 'lucide-react';
import { Kitnet, KitnetContract } from '../../../types';
import { STANDARD_EASE } from '../../../utils/motion';
import { useBodyScrollLock } from '../../../hooks/useBodyScrollLock';

interface DeleteKitnetModalProps {
  kitnetToDelete: Kitnet | null;
  kitnetContracts: KitnetContract[];
  onClose: () => void;
  onConfirm: () => void;
}

export const DeleteKitnetModal: React.FC<DeleteKitnetModalProps> = ({
  kitnetToDelete,
  kitnetContracts,
  onClose,
  onConfirm,
}) => {
  const isOpen = Boolean(kitnetToDelete);
  const shouldReduceMotion = useReducedMotion();
  const lastKitnetRef = useRef(kitnetToDelete);

  if (kitnetToDelete) {
    lastKitnetRef.current = kitnetToDelete;
  }

  const currentKitnet = kitnetToDelete || lastKitnetRef.current;
  useBodyScrollLock(isOpen);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const hasActiveContract = currentKitnet
    ? kitnetContracts.some((c) => c.kitnetId === currentKitnet.id && c.status === 'ativo')
    : false;

  if (typeof document === 'undefined') return null;

  return createPortal(
    <AnimatePresence>
      {isOpen && currentKitnet && (
        <motion.div
          key="delete-kitnet-backdrop"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          role="dialog"
          aria-modal="true"
          aria-label="Excluir Kitnet"
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md font-sans"
          onClick={onClose}
        >
          <motion.div
            key="delete-kitnet-card"
            initial={{ opacity: 0, scale: shouldReduceMotion ? 1 : 0.96, y: shouldReduceMotion ? 0 : 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: shouldReduceMotion ? 1 : 0.96, y: shouldReduceMotion ? 0 : 8 }}
            transition={{ duration: 0.22, ease: STANDARD_EASE }}
            className="bg-surface-base border border-border-subtle rounded-2xl w-full max-w-lg mx-auto p-6 shadow-2xl space-y-4 my-auto overflow-hidden animate-modal-enter"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-12 rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-base font-bold text-white">Excluir Kitnet Definitivamente?</h3>
              <p className="text-xs text-text-muted">
                Você está prestes a remover <strong className="text-white">{currentKitnet.name} (Unidade {currentKitnet.number})</strong>.
              </p>
            </div>

            {hasActiveContract && (
              <div className="p-3.5 bg-rose-500/10 border border-rose-500/30 rounded-xl flex items-start gap-2.5 text-xs text-rose-300">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-rose-200">Atenção: Locatário Ativo Detectado!</strong>
                  <p className="text-[11px] text-rose-300/90 mt-0.5 leading-relaxed">
                    Esta kitnet possui contrato em vigor. Ao excluí-la, o vínculo de contrato e o histórico desta unidade também serão encerrados.
                  </p>
                </div>
              </div>
            )}

            <p className="text-[11px] text-text-muted text-center">
              Esta ação é permanente e atualizará seu balanço patrimonial.
            </p>

            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-4 py-2.5 bg-surface-subtle hover:bg-surface-hover text-text-secondary hover:text-white font-semibold rounded-xl text-xs border border-border-subtle active:scale-95 transition-colors duration-150 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                id="btn-confirm-delete-kitnet"
                onClick={onConfirm}
                className="flex-1 px-4 py-2.5 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md shadow-rose-500/20 active:scale-95 transition-colors duration-150 cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                <span>Sim, Excluir</span>
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
};
