import React from 'react';
import {
  FileText,
  Calendar,
  Clock,
  TrendingUp,
  History,
  Send,
  UserPlus,
  ShieldCheck,
  Wallet,
  User,
  Sparkles,
} from 'lucide-react';
import { Kitnet, KitnetContract, KitnetTenant } from '../../../types';
import { isInstallmentOverdue } from '../../../utils/formatters';
import { getKitnetMonthlyTotal } from '../../../domain';

interface KitnetDetailContractTabProps {
  kitnet: Kitnet;
  activeContract?: KitnetContract;
  tenant?: KitnetTenant;
  formatCurrency: (value: number) => string;
  formatDate: (dateStr: string) => string;
  handleOpenNewContract: (kitnet: Kitnet) => void;
  setRenewForm: (data: { additionalMonths: number; newRentValue: number; reason: string }) => void;
  setShowRenewModal: (show: boolean) => void;
  setShowAdjustmentModal: (show: boolean) => void;
  setShowPaymentModal: (data: { contractId: string; installment: any }) => void;
  onOpenWhatsApp?: (contractId: string, installmentId?: string) => void;
  handleSendKitnetWhatsApp: () => void;
}

export const KitnetDetailContractTab: React.FC<KitnetDetailContractTabProps> = ({
  kitnet,
  activeContract,
  tenant,
  formatCurrency,
  formatDate,
  handleOpenNewContract,
  setRenewForm,
  setShowRenewModal,
  setShowAdjustmentModal,
  setShowPaymentModal,
  onOpenWhatsApp,
  handleSendKitnetWhatsApp,
}) => {
  return (
    <div className="space-y-4">
      {activeContract ? (
        <>
          {(() => {
            const isRolloverActive = activeContract.installments.length > activeContract.durationMonths;
            const vigenciaCount = Math.ceil(activeContract.installments.length / (activeContract.durationMonths || 12));

            return (
              <>
                <div className="bg-surface-base border border-border-subtle rounded-2xl p-4 sm:p-5 space-y-3.5">
                  {/* Top: Header with Contract Badge, Tenant Name and Active Status */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-3 border-b border-border-subtle">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-[10px] font-semibold bg-category-kitnets-sky/10 text-category-kitnets-sky border border-category-kitnets-sky/20 uppercase tracking-wider">
                          <FileText className="w-3 h-3" />
                          Contrato Residencial • {activeContract.durationMonths} Meses Iniciais
                        </span>
                        {isRolloverActive && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[10px] font-bold bg-money-positive/10 text-money-positive border border-money-positive/20">
                            <Clock className="w-3 h-3" />
                            {vigenciaCount}ª Vigência • Indeterminado (Art. 46)
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <div className="w-7 h-7 rounded-lg bg-surface-subtle border border-border-subtle flex items-center justify-center text-text-secondary shrink-0">
                          <User className="w-4 h-4 text-category-kitnets-sky" />
                        </div>
                        <h3 className="text-base font-bold text-text-primary">
                          {tenant?.fullName || 'Inquilino'}
                        </h3>
                      </div>
                    </div>

                    <div className="self-start sm:self-center">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-money-positive/10 text-money-positive border border-money-positive/25">
                        <span className="w-1.5 h-1.5 rounded-full bg-money-positive animate-pulse" />
                        Contrato Ativo
                      </span>
                    </div>
                  </div>

                  {/* Main Highlight: Valor Mensal Total */}
                  <div className="bg-surface-card border border-border-subtle rounded-xl p-3.5 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="space-y-1">
                      <span className="text-[11px] uppercase tracking-wider font-semibold text-text-secondary flex items-center gap-1.5">
                        <Wallet className="w-3.5 h-3.5 text-money-positive" />
                        Valor Mensal Total
                      </span>
                      <div className="flex items-baseline gap-2">
                        <span className="text-2xl sm:text-3xl font-black text-money-positive tracking-tight tabular-nums">
                          {formatCurrency(getKitnetMonthlyTotal(activeContract))}
                        </span>
                        <span className="text-xs text-text-secondary font-medium">/mês</span>
                      </div>
                    </div>

                    {/* Breakdown Chips */}
                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      <div className="px-2.5 py-1.5 rounded-lg bg-surface-base border border-border-subtle flex items-center gap-1.5 text-text-secondary">
                        <span>Aluguel:</span>
                        <strong className="text-text-primary font-semibold">{formatCurrency(activeContract.rentValue)}</strong>
                      </div>
                      {Boolean(activeContract.waterValue) && (
                        <div className="px-2.5 py-1.5 rounded-lg bg-surface-base border border-border-subtle flex items-center gap-1.5 text-text-secondary">
                          <span>Água:</span>
                          <strong className="text-text-primary font-semibold">+{formatCurrency(activeContract.waterValue || 0)}</strong>
                        </div>
                      )}
                      {Boolean(activeContract.internetValue) && (
                        <div className="px-2.5 py-1.5 rounded-lg bg-surface-base border border-border-subtle flex items-center gap-1.5 text-text-secondary">
                          <span>Internet:</span>
                          <strong className="text-text-primary font-semibold">+{formatCurrency(activeContract.internetValue || 0)}</strong>
                        </div>
                      )}
                      {Boolean(activeContract.otherFees) && (
                        <div className="px-2.5 py-1.5 rounded-lg bg-surface-base border border-border-subtle flex items-center gap-1.5 text-text-secondary">
                          <span>Taxas:</span>
                          <strong className="text-text-primary font-semibold">+{formatCurrency(activeContract.otherFees || 0)}</strong>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* 4-Column Structured KPI Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    <div className="p-3 bg-surface-card/70 border border-border-subtle rounded-xl space-y-1">
                      <div className="flex items-center gap-1.5 text-[11px] text-text-secondary font-medium">
                        <Calendar className="w-3.5 h-3.5 text-category-kitnets-sky" />
                        <span>Início</span>
                      </div>
                      <p className="text-sm font-bold text-text-primary tabular-nums">
                        {formatDate(activeContract.startDate)}
                      </p>
                    </div>

                    <div className="p-3 bg-surface-card/70 border border-border-subtle rounded-xl space-y-1">
                      <div className="flex items-center gap-1.5 text-[11px] text-text-secondary font-medium">
                        <Clock className="w-3.5 h-3.5 text-category-motos-alt" />
                        <span>Vencimento</span>
                      </div>
                      <p className="text-sm font-bold text-text-primary">
                        Dia {activeContract.dueDay}
                      </p>
                    </div>

                    <div className="p-3 bg-surface-card/70 border border-orange-500/20 bg-orange-500/5 rounded-xl space-y-1">
                      <div className="flex items-center gap-1.5 text-[11px] text-orange-400/90 font-medium">
                        <ShieldCheck className="w-3.5 h-3.5 text-orange-400" />
                        <span>Caução</span>
                      </div>
                      <p className="text-sm font-bold text-orange-400 tabular-nums">
                        {formatCurrency(activeContract.deposit || 0)}
                      </p>
                    </div>

                    <div className="p-3 bg-surface-card/70 border border-border-subtle rounded-xl space-y-1">
                      <div className="flex items-center gap-1.5 text-[11px] text-text-secondary font-medium">
                        <Sparkles className="w-3.5 h-3.5 text-action-primary" />
                        <span>Taxa Limpeza</span>
                      </div>
                      <p className="text-sm font-bold text-action-light tabular-nums">
                        {formatCurrency(activeContract.cleaningFee !== undefined ? activeContract.cleaningFee : (kitnet.cleaningFeeBase || 0))}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Banner Informativo de Renovação Legal / Rollover */}
                {isRolloverActive && (
                  <div className="p-3 bg-surface-card border border-border-subtle rounded-xl flex items-start justify-between gap-3 text-xs">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1.5 text-category-kitnets-sky font-semibold">
                        <Clock className="w-3.5 h-3.5" />
                        <span>Prorrogação Automática por Prazo Indeterminado</span>
                      </div>
                      <p className="text-[11px] text-text-secondary leading-relaxed">
                        O prazo de {activeContract.durationMonths} meses foi cumprido com sucesso. A locação segue ativa ininterruptamente nos termos do Art. 46 e 47 da Lei 8.245/91, com todas as cláusulas e garantias preservadas.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setRenewForm({
                          additionalMonths: 12,
                          newRentValue: activeContract.rentValue,
                          reason: `Formalização da ${vigenciaCount + 1}ª Vigência contratual`,
                        });
                        setShowRenewModal(true);
                      }}
                      className="px-2.5 py-1.5 bg-action-primary/15 hover:bg-action-primary/25 text-action-primary border border-action-primary/30 rounded-lg text-xs font-semibold shrink-0 cursor-pointer transition-colors active:scale-95"
                    >
                      + Aditivo / Renovação
                    </button>
                  </div>
                )}
              </>
            );
          })()}

          {/* Header com Ações de Reajuste & Renovação */}
          {(() => {
            const pendingInstallments = activeContract.installments.filter(
              (i) => i.status !== 'pago' && i.status !== 'cancelada'
            );
            const remainingCount = pendingInstallments.length;
            const totalCount = activeContract.installments.length;
            const paidCount = totalCount - remainingCount;
            const progressPercent = totalCount > 0 ? Math.round((paidCount / totalCount) * 100) : 0;

            return (
              <div className="space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-text-secondary">
                      Cronograma de Mensalidades
                    </h4>
                    <span className="text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-money-positive/15 text-money-positive border border-money-positive/30 tabular-nums">
                      {paidCount} de {totalCount} pagas • {remainingCount} restantes
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setRenewForm({
                          additionalMonths: 12,
                          newRentValue: activeContract.rentValue,
                          reason: 'Prorrogação formal com extensão do cronograma de parcelas',
                        });
                        setShowRenewModal(true);
                      }}
                      className="px-2.5 py-1 bg-surface-base hover:bg-surface-elevated text-text-primary border border-border-subtle rounded-lg text-xs font-medium flex items-center gap-1 cursor-pointer transition-colors active:scale-95"
                      title="Gerar novo ciclo de parcelas (+12 ou +24 meses)"
                    >
                      <Calendar className="w-3.5 h-3.5 text-action-primary" />
                      <span>Renovar / Estender</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowAdjustmentModal(true)}
                      className="px-2.5 py-1 bg-surface-base hover:bg-surface-elevated text-action-primary border border-action-primary/30 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors active:scale-95"
                      title="Reajustar valor das próximas mensalidades (IGP-M, IPCA ou Personalizado)"
                    >
                      <TrendingUp className="w-3.5 h-3.5" />
                      <span>Reajustar Aluguel</span>
                    </button>
                  </div>
                </div>

                <div className="w-full bg-surface-card h-1.5 rounded-full overflow-hidden border border-border-subtle">
                  <div
                    className="bg-money-positive h-full transition-all duration-300 rounded-full"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>
            );
          })()}

          {/* Histórico de Reajustes Salvos */}
          {activeContract.adjustments && activeContract.adjustments.length > 0 && (
            <div className="p-3 bg-surface-base border border-border-subtle rounded-xl">
              <h5 className="text-xs font-semibold text-action-primary flex items-center gap-1.5 mb-2">
                <History className="w-3.5 h-3.5" />
                <span>Histórico de Reajustes Anuais ({activeContract.adjustments.length})</span>
              </h5>
              <div className="space-y-1.5 text-xs text-text-secondary">
                {activeContract.adjustments.map((adj) => (
                  <div key={adj.id} className="flex items-center justify-between py-1 border-b border-border-subtle last:border-0">
                    <span>
                      {formatDate(adj.appliedAt)}: de <strong className="text-text-primary">{formatCurrency(adj.previousValue)}</strong> para <strong className="text-money-positive">{formatCurrency(adj.newValue)}</strong>
                      {adj.percentage ? ` (+${adj.percentage}%)` : ''}
                    </span>
                    <span className="text-[11px] text-text-muted italic">{adj.reason}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Installments Table (Desktop) & Stacked Cards (Mobile) */}
          <div className="border border-border-subtle rounded-xl overflow-hidden bg-surface-base max-h-80 overflow-y-auto">
            {/* Mobile View: Stacked Cards */}
            <div className="block sm:hidden divide-y divide-border-subtle p-2 space-y-2">
              {activeContract.installments.map((inst) => (
                <div key={inst.id} className="p-3 bg-surface-card rounded-xl border border-border-subtle space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono font-bold text-xs text-text-primary bg-surface-base px-2 py-0.5 rounded border border-border-subtle">
                        Mês {inst.number}
                      </span>
                      {inst.isPartial && (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-400 border border-amber-500/30">
                          Proporcional {inst.partialDays ? `(${inst.partialDays}d)` : ''}
                        </span>
                      )}
                    </div>
                    <span className="text-sm font-bold text-text-primary tabular-nums">
                      {formatCurrency(inst.amount)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-xs text-text-secondary pt-0.5">
                    <span>Vencimento:</span>
                    <strong className="text-text-primary">{formatDate(inst.dueDate)}</strong>
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-1.5 border-t border-border-subtle">
                    <span
                      className={`px-2.5 py-0.5 rounded-md text-[10px] font-bold border ${
                        inst.status === 'pago'
                          ? 'bg-money-positive/10 text-money-positive border-money-positive/20'
                          : isInstallmentOverdue(inst)
                          ? 'bg-money-negative/10 text-money-negative border-money-negative/20'
                          : 'bg-surface-base text-text-secondary border-border-subtle'
                      }`}
                    >
                      {inst.status === 'pago'
                        ? 'Pago'
                        : isInstallmentOverdue(inst)
                        ? 'Atrasado'
                        : 'Pendente'}
                    </span>

                    {inst.status !== 'pago' ? (
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            if (onOpenWhatsApp) {
                              onOpenWhatsApp(activeContract.id, inst.id);
                            } else {
                              handleSendKitnetWhatsApp();
                            }
                          }}
                          className="px-2.5 py-1 rounded-lg bg-surface-base hover:bg-surface-elevated text-money-positive font-semibold text-xs border border-border-subtle transition-all flex items-center gap-1 cursor-pointer active:scale-95"
                          title="Visualizar Mensagem de Cobrança no WhatsApp"
                        >
                          <Send className="w-3 h-3" />
                          <span>Cobrar</span>
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setShowPaymentModal({
                              contractId: activeContract.id,
                              installment: inst,
                            })
                          }
                          className="px-3 py-1 rounded-lg bg-money-positive hover:bg-money-positive-hover text-white font-bold text-xs transition-all cursor-pointer shadow-sm shadow-money-positive/20 active:scale-95 flex items-center gap-1.5"
                        >
                          <span>Dar Baixa</span>
                          <span className="px-1.5 py-0.5 rounded bg-black/25 text-[10px] font-semibold">
                            {activeContract.installments.filter((i) => i.status !== 'pago' && i.status !== 'cancelada').length} rest.
                          </span>
                        </button>
                      </div>
                    ) : (
                      <span className="text-xs text-money-positive font-bold">Quitado</span>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop View: Horizontal Table */}
            <div className="hidden sm:block overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-surface-card text-text-secondary uppercase text-[10px] font-medium sticky top-0 border-b border-border-subtle">
                  <tr>
                    <th className="p-3">Mês</th>
                    <th className="p-3">Valor Total</th>
                    <th className="p-3">Vencimento</th>
                    <th className="p-3">Status</th>
                    <th className="p-3 text-right">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border-subtle">
                  {activeContract.installments.map((inst) => (
                    <tr key={inst.id} className="hover:bg-surface-card/50 transition-colors">
                      <td className="p-3 font-mono font-medium text-text-primary">
                        <div className="flex items-center gap-1.5">
                          <span>Mês {inst.number}</span>
                          {inst.isPartial && (
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-400 border border-amber-500/30">
                              Proporcional {inst.partialDays ? `(${inst.partialDays}d)` : ''}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="p-3 font-medium text-text-primary">
                        {formatCurrency(inst.amount)}
                      </td>
                      <td className="p-3 text-text-secondary font-medium">
                        {formatDate(inst.dueDate)}
                      </td>
                      <td className="p-3">
                        <span
                          className={`px-2 py-0.5 rounded-md text-[10px] font-semibold border ${
                            inst.status === 'pago'
                              ? 'bg-money-positive/10 text-money-positive border-money-positive/20'
                              : isInstallmentOverdue(inst)
                              ? 'bg-money-negative/10 text-money-negative border-money-negative/20'
                              : 'bg-surface-base text-text-secondary border-border-subtle'
                          }`}
                        >
                          {inst.status === 'pago'
                            ? 'Pago'
                            : isInstallmentOverdue(inst)
                            ? 'Atrasado'
                            : 'Pendente'}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        {inst.status !== 'pago' ? (
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => {
                                if (onOpenWhatsApp) {
                                  onOpenWhatsApp(activeContract.id, inst.id);
                                } else {
                                  handleSendKitnetWhatsApp();
                                }
                              }}
                              className="px-2 py-1 rounded-lg bg-transparent hover:bg-surface-elevated text-money-positive font-medium text-[11px] border border-border-subtle transition-all flex items-center gap-1 cursor-pointer active:scale-95"
                              title="Visualizar Mensagem de Cobrança no WhatsApp"
                            >
                              <Send className="w-3 h-3" />
                              <span>Cobrar</span>
                            </button>
                            <button
                              onClick={() =>
                                setShowPaymentModal({
                                 contractId: activeContract.id,
                                 installment: inst,
                               })
                             }
                             className="px-2.5 py-1 rounded-lg bg-money-positive hover:bg-money-positive-hover text-white font-bold text-[11px] transition-all cursor-pointer shadow-sm shadow-money-positive/20 active:scale-95 flex items-center gap-1"
                            >
                              <span>Dar Baixa</span>
                              <span className="px-1.5 py-0.5 rounded bg-black/25 text-[9px] font-semibold">
                                {activeContract.installments.filter((i) => i.status !== 'pago' && i.status !== 'cancelada').length} rest.
                              </span>
                            </button>
                          </div>
                        ) : (
                          <span className="text-[11px] text-money-positive font-medium">Quitado</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        <div className="py-8 text-center bg-surface-base rounded-xl border border-dashed border-border-subtle space-y-3">
          <FileText className="w-7 h-7 text-text-muted mx-auto" />
          <div>
            <p className="text-sm font-semibold text-text-primary">Nenhum contrato ativo para esta unidade</p>
            <p className="text-xs text-text-secondary mt-0.5">Esta kitnet está disponível para novo inquilino.</p>
          </div>
          <button
            onClick={() => handleOpenNewContract(kitnet)}
            className="px-4 py-2.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs rounded-xl inline-flex items-center gap-2 cursor-pointer shadow-md shadow-sky-500/20 active:scale-95 transition-all"
          >
            <UserPlus className="w-4 h-4" />
            <span>Criar Contrato Agora</span>
          </button>
        </div>
      )}
    </div>
  );
};
