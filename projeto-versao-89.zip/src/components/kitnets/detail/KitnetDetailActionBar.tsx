import React from 'react';
import {
  UserPlus,
  LogOut,
  Layers,
  MessageCircle,
  FileText,
  Copy,
  Edit3,
  Trash2,
} from 'lucide-react';
import { Kitnet, KitnetContract, KitnetTenant } from '../../../types';

interface KitnetDetailActionBarProps {
  kitnet: Kitnet;
  activeContract?: KitnetContract;
  tenant?: KitnetTenant;
  handleOpenNewContract: (kitnet: Kitnet) => void;
  setKitnetToTerminate: (data: { contract: KitnetContract; kitnet: Kitnet }) => void;
  setShowCompareModal: (show: boolean) => void;
  onOpenWhatsApp?: (contractId: string, installmentId?: string) => void;
  handleSendKitnetWhatsApp: () => void;
  onGenerateDocument: (type: 'contrato_kitnet', kitnet: Kitnet, contract?: KitnetContract, tenant?: KitnetTenant) => void;
  duplicateKitnet: (id: string) => void;
  handleOpenEditModal: (kitnet: Kitnet) => void;
  setKitnetToDelete: (kitnet: Kitnet) => void;
}

export const KitnetDetailActionBar: React.FC<KitnetDetailActionBarProps> = ({
  kitnet,
  activeContract,
  tenant,
  handleOpenNewContract,
  setKitnetToTerminate,
  setShowCompareModal,
  onOpenWhatsApp,
  handleSendKitnetWhatsApp,
  onGenerateDocument,
  duplicateKitnet,
  handleOpenEditModal,
  setKitnetToDelete,
}) => {
  return (
    <div className="bg-surface-card rounded-2xl border border-border-subtle p-3 sm:p-4 space-y-3 shadow-xs">
      {/* Row 1: Two primary large action buttons */}
      <div className="grid grid-cols-2 gap-2.5">
        {kitnet.status !== 'alugada' ? (
          <button
            id={`btn-new-contract-kitnet-${kitnet.id}`}
            type="button"
            onClick={() => handleOpenNewContract(kitnet)}
            className="h-12 px-4 rounded-xl bg-surface-subtle hover:bg-surface-hover border border-border-subtle hover:border-border-hover text-text-primary dark:text-white text-xs sm:text-sm font-semibold flex items-center justify-center gap-2.5 transition-all cursor-pointer active:scale-98 shadow-xs"
          >
            <UserPlus className="w-4 h-4 text-sky-500 dark:text-sky-400" />
            <span className="text-text-primary dark:text-white">Criar Contrato</span>
          </button>
        ) : (
          <button
            id={`btn-terminate-contract-${kitnet.id}`}
            type="button"
            onClick={() =>
              activeContract &&
              setKitnetToTerminate({ contract: activeContract, kitnet })
            }
            className="h-12 px-4 rounded-xl bg-surface-subtle hover:bg-surface-hover border border-border-subtle hover:border-border-hover text-text-primary dark:text-white text-xs sm:text-sm font-semibold flex items-center justify-center gap-2.5 transition-all cursor-pointer active:scale-98 shadow-xs"
          >
            <LogOut className="w-4 h-4 text-rose-500 dark:text-rose-400" />
            <span className="text-text-primary dark:text-white">Encerrar Locação</span>
          </button>
        )}

        <button
          type="button"
          onClick={() => setShowCompareModal(true)}
          className="h-12 px-4 rounded-xl bg-surface-subtle hover:bg-surface-hover border border-border-subtle hover:border-border-hover text-text-primary dark:text-white text-xs sm:text-sm font-semibold flex items-center justify-center gap-2.5 transition-all cursor-pointer active:scale-98 shadow-xs"
        >
          <Layers className="w-4 h-4 text-indigo-500 dark:text-indigo-400" />
          <span className="text-text-primary dark:text-white">Vistorias</span>
        </button>
      </div>

      {/* Row 2: Secondary Tools Container */}
      <div className="bg-surface-subtle rounded-xl border border-border-subtle p-2.5 sm:p-3">
        {/* Sub-row 1: 3 quick actions in a row */}
        <div className="grid grid-cols-3 gap-1.5 text-center items-center">
          {/* 1. WhatsApp */}
          <button
            type="button"
            onClick={() => {
              if (activeContract && onOpenWhatsApp) {
                onOpenWhatsApp(activeContract.id);
              } else {
                handleSendKitnetWhatsApp();
              }
            }}
            className="py-1.5 sm:py-2 px-1 rounded-lg hover:bg-surface-hover active:scale-95 text-text-secondary dark:text-white/90 hover:text-slate-900 dark:hover:text-white flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 text-[10px] sm:text-xs font-semibold transition-all cursor-pointer min-w-0"
            title="Enviar mensagem WhatsApp"
            aria-label="Enviar mensagem WhatsApp"
          >
            <MessageCircle className="w-4 h-4 text-emerald-600 dark:text-money-positive-hover shrink-0" />
            <span className="truncate">WhatsApp</span>
          </button>

          {/* 2. PDF */}
          <button
            type="button"
            onClick={() =>
              onGenerateDocument(
                'contrato_kitnet',
                kitnet,
                activeContract,
                tenant
              )
            }
            className="py-1.5 sm:py-2 px-1 rounded-lg hover:bg-surface-hover active:scale-95 text-text-secondary dark:text-white/90 hover:text-slate-900 dark:hover:text-white flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 text-[10px] sm:text-xs font-semibold transition-all cursor-pointer min-w-0"
            title="Gerar contrato em PDF"
            aria-label="Gerar contrato em PDF"
          >
            <FileText className="w-4 h-4 text-rose-500 dark:text-rose-400 shrink-0" />
            <span className="truncate">PDF</span>
          </button>

          {/* 3. Duplicar */}
          <button
            type="button"
            onClick={() => duplicateKitnet(kitnet.id)}
            className="py-1.5 sm:py-2 px-1 rounded-lg hover:bg-surface-hover active:scale-95 text-text-secondary dark:text-white/90 hover:text-slate-900 dark:hover:text-white flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 text-[10px] sm:text-xs font-semibold transition-all cursor-pointer min-w-0"
            title="Duplicar cadastro de kitnet"
            aria-label="Duplicar cadastro de kitnet"
          >
            <Copy className="w-4 h-4 text-teal-600 dark:text-teal-400 shrink-0" />
            <span className="truncate">Duplicar</span>
          </button>
        </div>

        {/* Divider */}
        <div className="border-t border-border-subtle my-2" />

        {/* Sub-row 2: Editar & Apagar with vertical divider */}
        <div className="grid grid-cols-2 items-center divide-x divide-border-subtle">
          {/* Editar */}
          <button
            id={`btn-edit-kitnet-${kitnet.id}`}
            type="button"
            onClick={() => handleOpenEditModal(kitnet)}
            className="py-2 px-2 rounded-lg hover:bg-surface-hover active:scale-95 text-text-secondary dark:text-white hover:text-slate-900 dark:hover:text-white flex items-center justify-center gap-2 text-xs font-semibold transition-all cursor-pointer"
            title="Editar dados da kitnet"
            aria-label="Editar dados da kitnet"
          >
            <Edit3 className="w-4 h-4 text-amber-500 dark:text-amber-400" />
            <span>Editar</span>
          </button>

          {/* Apagar */}
          <button
            id={`btn-delete-kitnet-${kitnet.id}`}
            type="button"
            onClick={() => setKitnetToDelete(kitnet)}
            className="py-2 px-2 rounded-lg hover:bg-red-500/15 active:scale-95 text-rose-600 dark:text-rose-400 hover:text-rose-700 dark:hover:text-rose-300 flex items-center justify-center gap-2 text-xs font-semibold transition-all cursor-pointer"
            title="Apagar kitnet do sistema"
            aria-label="Apagar kitnet do sistema"
          >
            <Trash2 className="w-4 h-4 text-rose-500 dark:text-rose-400" />
            <span>Apagar</span>
          </button>
        </div>
      </div>
    </div>
  );
};
