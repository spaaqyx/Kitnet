import React from 'react';
import { gsap } from 'gsap';
import { COLORS } from '../../styles/colors';
import {
  ChevronDown,
  User,
  Calendar,
  Wrench,
  CheckCircle2,
} from 'lucide-react';
import { Kitnet, KitnetContract, KitnetTenant } from '../../types';
import { formatCurrency, formatDate, formatCPF, formatPhone, isInstallmentOverdue } from '../../utils/formatters';
import { getKitnetMonthlyTotal, getKitnetAssetMonthlyBase } from '../../domain';
import { KitnetIcon } from '../CategoryIcons';
import { KitnetDetailContent } from '../KitnetDetailContent';
import { HighlightMissingText } from '../HighlightMissingText';
import { gsapButtonPress } from '../../utils/gsapAnimations';

interface KitnetCardItemProps {
  kitnet: Kitnet;
  index: number;
  isSelected: boolean;
  isMobileExpanded?: boolean;
  activeContract?: KitnetContract;
  tenant?: KitnetTenant;
  activeSubTab: 'geral' | 'contrato' | 'inquilino' | 'vistoria' | 'fotos';
  setActiveSubTab: (tab: 'geral' | 'contrato' | 'inquilino' | 'vistoria' | 'fotos') => void;
  onToggleSelect: () => void;
  duplicateKitnet: (id: string) => void;
  handleOpenEditModal: (kitnet: Kitnet) => void;
  setKitnetToDelete: (kitnet: Kitnet) => void;
  handleOpenNewContract: (kitnet: Kitnet) => void;
  setKitnetToTerminate: (data: { contract: KitnetContract; kitnet: Kitnet }) => void;
  setShowCompareModal: (val: boolean) => void;
  onOpenWhatsApp?: (contractId: string, installmentId?: string) => void;
  handleSendKitnetWhatsApp: () => void;
  onGenerateDocument: (type: any, kitnet: Kitnet, contract?: KitnetContract, tenant?: KitnetTenant) => void;
  setRenewForm: React.Dispatch<React.SetStateAction<any>>;
  setShowRenewModal: (val: boolean) => void;
  setShowAdjustmentModal: (val: boolean) => void;
  setShowPaymentModal: (val: any) => void;
  setSelectedPhotoPreview?: (photo: { url: string; title: string } | null) => void;
  onOpenClientProfile?: (tenantId: string, type: 'moto' | 'kitnet') => void;
}

export const KitnetCardItem: React.FC<KitnetCardItemProps> = ({
  kitnet,
  index,
  isSelected,
  isMobileExpanded = false,
  activeContract,
  tenant,
  activeSubTab,
  setActiveSubTab,
  onToggleSelect,
  duplicateKitnet,
  handleOpenEditModal,
  setKitnetToDelete,
  handleOpenNewContract,
  setKitnetToTerminate,
  setShowCompareModal,
  onOpenWhatsApp,
  handleSendKitnetWhatsApp,
  onGenerateDocument,
  setRenewForm,
  setShowRenewModal,
  setShowAdjustmentModal,
  setShowPaymentModal,
  setSelectedPhotoPreview,
  onOpenClientProfile,
}) => {
  // Next due date formatted - dynamic based on next pending installment
  const nextDueDate = React.useMemo(() => {
    if (!activeContract || !activeContract.installments || activeContract.installments.length === 0) {
      return null;
    }
    // Filter all installments that are not paid
    const pendingInstallments = activeContract.installments.filter(
      (i) => i.status !== 'pago'
    );

    if (pendingInstallments.length === 0) {
      return 'Quitado';
    }

    // Sort by dueDate ascending, fallback to installment number
    pendingInstallments.sort((a, b) => {
      if (a.dueDate && b.dueDate) {
        return a.dueDate.localeCompare(b.dueDate);
      }
      return a.number - b.number;
    });

    const nextPending = pendingInstallments[0];
    if (nextPending?.dueDate) {
      const parts = nextPending.dueDate.split('T')[0].split('-');
      if (parts.length === 3) {
        return `${parts[2]}/${parts[1]}/${parts[0]}`;
      }
      return formatDate(nextPending.dueDate);
    }

    return null;
  }, [activeContract]);

  // Is expanded (either selected or mobile expanded)
  const isExpanded = isSelected || Boolean(isMobileExpanded);

  const accordionRef = React.useRef<HTMLDivElement>(null);
  const chevronRef = React.useRef<SVGSVGElement>(null);
  const isInitialMount = React.useRef(true);
  const [isMounted, setIsMounted] = React.useState(isExpanded);

  React.useEffect(() => {
    // Sync chevron rotation cleanly with GSAP
    if (chevronRef.current) {
      if (isInitialMount.current) {
        gsap.set(chevronRef.current, { rotation: isExpanded ? 180 : 0 });
      } else {
        gsap.to(chevronRef.current, {
          rotation: isExpanded ? 180 : 0,
          duration: 0.28,
          ease: 'power2.out',
        });
      }
    }

    if (isInitialMount.current) {
      isInitialMount.current = false;
      return;
    }

    if (isExpanded) {
      setIsMounted(true);
      const raf = requestAnimationFrame(() => {
        if (!accordionRef.current) return;
        gsap.killTweensOf(accordionRef.current);
        gsap.fromTo(
          accordionRef.current,
          { height: 0, opacity: 0 },
          {
            height: 'auto',
            opacity: 1,
            duration: 0.32,
            ease: 'power2.out',
            clearProps: 'height',
          }
        );
      });
      return () => cancelAnimationFrame(raf);
    } else {
      if (accordionRef.current) {
        gsap.killTweensOf(accordionRef.current);
        const currentHeight = accordionRef.current.offsetHeight;
        gsap.fromTo(
          accordionRef.current,
          { height: currentHeight, opacity: 1 },
          {
            height: 0,
            opacity: 0,
            duration: 0.24,
            ease: 'power2.inOut',
            onComplete: () => {
              setIsMounted(false);
            },
          }
        );
      } else {
        setIsMounted(false);
      }
    }
  }, [isExpanded]);

  // Clean title formatting (e.g. Kitnet 01 • Jardim Primavera)
  const displayTitle = React.useMemo(() => {
    const raw = kitnet.name?.trim() || (kitnet.number?.trim() ? `Kitnet ${kitnet.number.trim()}` : 'Unidade Residencial');
    return raw.replace('—', '•').replace('-', '•');
  }, [kitnet.name, kitnet.number]);

  // Exact card border styling according to status
  const borderClass = React.useMemo(() => {
    if (isExpanded) {
      return 'border-action-primary ring-1 ring-action-primary/30';
    }
    if (kitnet.status === 'alugada') {
      return 'border-money-positive';
    }
    if (kitnet.status === 'reforma') {
      return 'border-money-warning-hover';
    }
    return 'border-sky-500/40';
  }, [kitnet.status, isExpanded]);

  return (
    <div
      id={`kitnet-card-${kitnet.id}`}
      className={`bg-surface-subtle rounded-2xl border transition-colors duration-200 overflow-hidden shadow-lg shadow-black/30 ${borderClass}`}
    >
      {/* Clickable Header / Main Card Info */}
      <div
        onClick={onToggleSelect}
        className="p-3.5 sm:p-6 cursor-pointer select-none transition-colors hover:bg-surface-hover"
      >
        <div className="flex items-start gap-3 sm:gap-5">
          {/* Square Photo Thumbnail */}
          <div className="w-20 h-20 sm:w-28 sm:h-28 rounded-2xl overflow-hidden relative shrink-0 border border-border-subtle bg-surface-card shadow-md">
            {kitnet.photos?.livingRoom || kitnet.photos?.bedroom ? (
              <img
                src={kitnet.photos.livingRoom || kitnet.photos.bedroom}
                alt={kitnet.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-surface-card">
                <KitnetIcon size={28} color={COLORS.action.primary} />
              </div>
            )}
          </div>

          {/* Right Info Section */}
          <div className="flex-1 min-w-0">
            {/* Row 1: Title & Status Badge */}
            <div className="flex items-center justify-between gap-2 sm:gap-3 flex-wrap">
              <h3 className="text-sm sm:text-lg font-bold text-text-primary tracking-tight truncate">
                {displayTitle}
              </h3>

              {/* Status Badge */}
              {kitnet.status === 'alugada' && (
                <span className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-500/40 text-[10px] sm:text-xs font-bold px-2.5 sm:px-3 py-0.5 sm:py-1 rounded-lg uppercase tracking-wider shrink-0">
                  ALUGADA
                </span>
              )}
              {kitnet.status === 'reforma' && (
                <span className="bg-amber-500/15 text-amber-700 dark:text-amber-400 border border-amber-500/40 text-[10px] sm:text-xs font-bold px-2.5 sm:px-3 py-0.5 sm:py-1 rounded-lg uppercase tracking-wider shrink-0">
                  EM REFORMA
                </span>
              )}
              {kitnet.status === 'disponivel' && (
                <span className="bg-sky-500/15 text-sky-700 dark:text-sky-400 border border-sky-500/40 text-[10px] sm:text-xs font-bold px-2.5 sm:px-3 py-0.5 sm:py-1 rounded-lg uppercase tracking-wider shrink-0">
                  DISPONÍVEL
                </span>
              )}
            </div>

            {/* Row 2: Unit Pill & Address */}
            <div className="flex items-center gap-2 mt-1.5 sm:mt-2 text-xs text-text-secondary flex-wrap">
              <span className="bg-surface-subtle border border-border-subtle text-text-primary font-bold text-xs px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-lg shrink-0">
                Unidade {kitnet.number}
              </span>
              <span className="text-text-muted">•</span>
              <span className="truncate max-w-[200px] sm:max-w-md text-text-secondary">
                <HighlightMissingText text={kitnet.address || 'Endereço não informado'} />
              </span>
            </div>

            {/* Row 3: Tenant Name or Renovation Note or Available Status */}
            <div className="mt-2 sm:mt-2.5">
              {kitnet.status === 'alugada' ? (
                <div className="flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm text-text-primary font-medium truncate">
                  <User className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-sky-500 dark:text-sky-400 shrink-0" />
                  <span className="truncate">
                    <HighlightMissingText
                      text={
                        tenant?.fullName ||
                        (kitnet.statusNote?.startsWith('Locatário:')
                          ? kitnet.statusNote.replace('Locatário:', '').trim()
                          : '') ||
                        '[Locatário não informado]'
                      }
                    />
                  </span>
                </div>
              ) : kitnet.status === 'reforma' ? (
                <div className="flex items-center gap-1.5 sm:gap-2 text-xs text-category-motos-alt font-medium">
                  <Wrench className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-category-motos-alt shrink-0" />
                  <span className="truncate">{kitnet.statusNote || kitnet.notes || 'Em reforma / manutenção'}</span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 sm:gap-2 text-xs text-category-kitnets-cyan font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-category-kitnets-cyan shrink-0" />
                  <span className="truncate">{kitnet.statusNote || kitnet.notes || 'Pronta para locação imediata'}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Values & Due Date Container matching screenshot */}
        <div className="mt-3 sm:mt-4 pt-2.5 sm:pt-3 border-t border-border-subtle flex items-center justify-between gap-2 sm:gap-3 flex-wrap sm:flex-nowrap">
          {/* Left: Valor Mensal */}
          <div className="min-w-0">
            <div className="text-[11px] sm:text-xs text-text-secondary font-medium">Valor Mensal</div>
            <div className="text-sm sm:text-lg font-bold text-money-positive mt-0.5">
              {formatCurrency(
                activeContract
                  ? getKitnetMonthlyTotal(activeContract)
                  : getKitnetAssetMonthlyBase(kitnet)
              )}
              <span className="text-[11px] sm:text-sm font-semibold text-money-positive">/mês</span>
            </div>
          </div>

          {/* Middle: Vencimento */}
          {kitnet.status === 'alugada' && nextDueDate ? (
            <div className="pl-3 sm:pl-4 border-l border-border-subtle min-w-0">
              <div className="text-[11px] sm:text-xs text-text-secondary font-medium">Vencimento</div>
              <div className="text-xs sm:text-sm font-semibold text-text-primary flex items-center gap-1.5 sm:gap-2 mt-0.5 whitespace-nowrap">
                <Calendar className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-text-muted dark:text-white shrink-0" />
                <span className="truncate">{nextDueDate}</span>
              </div>
            </div>
          ) : (
            <div />
          )}

          {/* Right: Circular Chevron Button */}
          <button
            id={`btn-toggle-kitnet-${kitnet.id}`}
            type="button"
            aria-label={isExpanded ? 'Recolher detalhes da kitnet' : 'Expandir detalhes da kitnet'}
            aria-expanded={isExpanded}
            onClick={(e) => {
              e.stopPropagation();
              gsapButtonPress(e.currentTarget);
              onToggleSelect();
            }}
            className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-slate-100 hover:bg-slate-200 dark:bg-surface-subtle dark:hover:bg-surface-card border border-border-subtle text-text-secondary dark:text-white flex items-center justify-center transition-colors duration-150 cursor-pointer active:scale-95 group shrink-0 shadow-xs sm:shadow-md ml-auto focus:outline-none focus:ring-2 focus:ring-action-primary/50"
          >
            <ChevronDown
              ref={chevronRef}
              className="w-4 h-4 sm:w-5 sm:h-5 text-text-secondary dark:text-white"
            />
          </button>
        </div>
      </div>

      {/* Expanded Accordion Body */}
      {isMounted && (
        <div
          ref={accordionRef}
          className="border-t border-border-subtle bg-surface-base overflow-hidden"
        >
          <div className="p-4 sm:p-6 space-y-4">
            <KitnetDetailContent
              kitnet={kitnet}
              activeContract={activeContract}
              tenant={tenant}
              activeSubTab={activeSubTab}
              setActiveSubTab={setActiveSubTab}
              duplicateKitnet={duplicateKitnet}
              handleOpenEditModal={handleOpenEditModal}
              setKitnetToDelete={setKitnetToDelete}
              handleOpenNewContract={handleOpenNewContract}
              setKitnetToTerminate={setKitnetToTerminate}
              setShowCompareModal={setShowCompareModal}
              onOpenWhatsApp={onOpenWhatsApp}
              handleSendKitnetWhatsApp={handleSendKitnetWhatsApp}
              onGenerateDocument={onGenerateDocument}
              setRenewForm={setRenewForm}
              setShowRenewModal={setShowRenewModal}
              setShowAdjustmentModal={setShowAdjustmentModal}
              setShowPaymentModal={setShowPaymentModal}
              setSelectedPhotoPreview={setSelectedPhotoPreview}
              onOpenClientProfile={onOpenClientProfile}
              formatCurrency={formatCurrency}
              formatDate={formatDate}
              formatCPF={formatCPF}
              formatPhone={formatPhone}
            />
          </div>
        </div>
      )}
    </div>
  );
};
