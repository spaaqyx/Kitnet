import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../context/AppContext';
import { formatDate } from '../utils/formatters';
import { useBodyScrollLock } from '../hooks/useBodyScrollLock';
import { useScrollActiveIntoView } from '../hooks/useScrollActiveIntoView';
import { SettingsAccountSection } from './settings/SettingsAccountSection';
import { SettingsSecuritySection } from './settings/SettingsSecuritySection';
import { SettingsLocadorSection } from './settings/SettingsLocadorSection';
import { SettingsBackupSection } from './settings/SettingsBackupSection';
import { SettingsAuditTimelineSection } from './settings/SettingsAuditTimelineSection';
import { SettingsModals } from './settings/SettingsModals';
import { Settings, Shield, Building, Clock, LayoutGrid, Users, Sun, Moon } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { ThemeToggle } from './ui/theme-toggle';
import { gsapButtonPress } from '../utils/gsapAnimations';

interface SettingsAndTimelineViewProps {
  onOpenPwaGuide?: () => void;
}

export const SettingsAndTimelineView: React.FC<SettingsAndTimelineViewProps> = React.memo(({ onOpenPwaGuide }) => {
  const {
    timeline,
    settings,
    updateSettings,
    clearTimeline,
    exportBackup,
    getBackupJsonString,
    importBackup,
    lockApp,
    clearGoogleSession,
    googleSession,
    isDemoMode,
    toggleDemoMode,
    isReadOnlyMode,
    toggleReadOnlyMode,
  } = useApp();
  const { isDark } = useTheme();

  const [activeTab, setActiveTab] = useState<'all' | 'locador' | 'security' | 'timeline'>('all');

  // Modals state
  const [showLogoutModal, setShowLogoutModal] = useState<boolean>(false);
  const [showClearTimelineModal, setShowClearTimelineModal] = useState<boolean>(false);

  useBodyScrollLock(Boolean(showLogoutModal || showClearTimelineModal));

  const sessionStartDate = googleSession?.authenticatedAt
    ? formatDate(googleSession.authenticatedAt)
    : 'Hoje';

  interface SettingsTabItem {
    id: 'all' | 'locador' | 'security' | 'timeline';
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    count?: number;
  }

  const tabs: SettingsTabItem[] = [
    { id: 'all', label: 'Tudo', icon: LayoutGrid },
    { id: 'locador', label: 'Locador & PIX', icon: Building },
    { id: 'security', label: 'Segurança & Backup', icon: Shield },
    { id: 'timeline', label: 'Auditoria', icon: Clock, count: timeline.length },
  ];

  const { containerRef, registerItem, scrollItemIntoView } = useScrollActiveIntoView(activeTab);

  return (
    <div className="space-y-4 sm:space-y-5 font-sans max-w-4xl mx-auto">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-border-subtle">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-violet-600/10 border border-violet-500/20 flex items-center justify-center text-violet-400 shadow-inner shrink-0">
            <Settings className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <h1 className="text-xl font-bold text-text-primary tracking-tight">
              Configurações do Sistema
            </h1>
            <p className="text-xs text-text-muted">
              Gerencie dados cadastrais, segurança, backups e histórico de auditoria
            </p>
          </div>
        </div>

        {/* Tab Filters: container box stays fixed, buttons scroll smoothly and center active tab */}
        <div className="w-full sm:w-auto p-1 bg-surface-subtle border border-border-subtle rounded-xl max-w-full relative">
          <div
            ref={containerRef}
            className="flex items-center gap-1.5 overflow-x-auto no-scrollbar scroll-smooth touch-pan-x"
          >
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <motion.button
                  key={tab.id}
                  ref={registerItem(tab.id)}
                  type="button"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.96 }}
                  onClick={(e) => {
                    gsapButtonPress(e.currentTarget);
                    setActiveTab(tab.id);
                    scrollItemIntoView(tab.id);
                  }}
                  className={`shrink-0 px-3.5 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 whitespace-nowrap transition-all cursor-pointer select-none ${
                    isActive
                      ? 'bg-violet-600 text-white font-bold'
                      : 'text-text-muted hover:text-text-primary hover:bg-surface-hover'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5 shrink-0" />
                  <span className="shrink-0">{tab.label}</span>
                  {tab.count !== undefined && (
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold shrink-0 ${
                        isActive ? 'bg-white/20 text-white' : 'bg-surface-subtle text-text-muted'
                      }`}
                    >
                      {tab.count}
                    </span>
                  )}
                </motion.button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 1. Account Section (Always visible or in 'all' / 'locador') */}
      {(activeTab === 'all' || activeTab === 'locador') && (
        <SettingsAccountSection
          settings={settings}
          googleSession={googleSession}
          sessionStartDate={sessionStartDate}
          onOpenPwaGuide={onOpenPwaGuide}
        />
      )}

      {/* 2. Locador & PIX Section */}
      {(activeTab === 'all' || activeTab === 'locador') && (
        <SettingsLocadorSection
          settings={settings}
          updateSettings={updateSettings}
        />
      )}

      {/* 3. Security Section */}
      {(activeTab === 'all' || activeTab === 'security') && (
        <SettingsSecuritySection
          settings={settings}
          lockApp={lockApp}
          onOpenLogoutModal={() => setShowLogoutModal(true)}
          updateSettings={updateSettings}
          isReadOnlyMode={isReadOnlyMode}
          toggleReadOnlyMode={toggleReadOnlyMode}
        />
      )}

      {/* Modo de Demonstração (Dados de Teste) */}
      {(activeTab === 'all' || activeTab === 'security') && (
        <div className="p-4 sm:p-5 bg-surface-subtle border border-purple-500/25 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-400 shrink-0">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-text-primary">Modo de Demonstração</h3>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                    isDemoMode
                      ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 ring-1 ring-purple-500/20'
                      : 'bg-surface-subtle text-text-muted'
                  }`}
                >
                  {isDemoMode ? 'Ativo' : 'Desativado'}
                </span>
              </div>
              <p className="text-xs text-text-muted mt-1 leading-relaxed">
                Carrega clientes, kitnets e motos fictícias para demonstração e testes do aplicativo.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => toggleDemoMode()}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer select-none active:scale-95 flex items-center justify-center gap-2 shrink-0 ${
              isDemoMode
                ? 'bg-purple-600 hover:bg-purple-500 text-white'
                : 'bg-surface-subtle hover:bg-surface-hover text-text-primary border border-border-subtle'
            }`}
          >
            <span>{isDemoMode ? 'Desligar Modo Demo' : 'Ligar Modo Demo'}</span>
          </button>
        </div>
      )}

      {/* 3.5 Tema Visual (Modo Claro / Modo Escuro) */}
      {(activeTab === 'all' || activeTab === 'security') && (
        <div className="p-4 sm:p-5 bg-surface-card border border-border-subtle rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-violet-500/15 border border-violet-500/30 flex items-center justify-center text-violet-400 shrink-0">
              {isDark ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5 text-amber-500" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-text-primary">Tema Visual</h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider bg-violet-500/20 text-violet-300 border border-violet-500/40">
                  {isDark ? 'Modo Escuro' : 'Modo Claro'}
                </span>
              </div>
              <p className="text-xs text-text-muted mt-1 leading-relaxed">
                Alterne entre o visual escuro imersivo e o visual claro de alto contraste.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0 self-end sm:self-center">
            <span className="text-xs font-medium text-text-muted">
              {isDark ? 'Escuro' : 'Claro'}
            </span>
            <ThemeToggle />
          </div>
        </div>
      )}

      {/* 4. Backup Section */}
      {(activeTab === 'all' || activeTab === 'security') && (
        <SettingsBackupSection
          settings={settings}
          exportBackup={exportBackup}
          importBackup={importBackup}
          getBackupJsonString={getBackupJsonString}
        />
      )}

      {/* 5. Timeline de Auditoria */}
      {(activeTab === 'all' || activeTab === 'timeline') && (
        <SettingsAuditTimelineSection
          timeline={timeline}
          onOpenClearTimelineModal={() => setShowClearTimelineModal(true)}
        />
      )}

      {/* Modais de Confirmação */}
      <SettingsModals
        showLogoutModal={showLogoutModal}
        setShowLogoutModal={setShowLogoutModal}
        onConfirmLogout={clearGoogleSession}
        showClearTimelineModal={showClearTimelineModal}
        setShowClearTimelineModal={setShowClearTimelineModal}
        onConfirmClearTimeline={clearTimeline}
      />
    </div>
  );
});

