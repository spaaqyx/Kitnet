import React from 'react';
import { motion } from 'motion/react';
import { COLORS } from '../styles/colors';
import {
  Plus,
  Search,
  X,
  Motorbike,
  ArrowUpCircle,
  Wrench,
} from 'lucide-react';
import { Moto, MotoContract, MotoTenant } from '../types';
import {
  formatCurrency,
  formatDate,
  formatCPF,
  formatPhone,
  getCNHStatus,
  isPlateCorruptedOrInvalid,
} from '../utils/formatters';
import { WEEKS_PER_MONTH } from '../utils/financialMath';
import { monthlyToWeekly, weeklyToMonthly } from '../domain';
import { MotoMaintenanceModal } from './MotoMaintenanceModal';
import { RentAdjustmentModal } from './RentAdjustmentModal';
import { CentralVistoriasModal } from './vistorias/CentralVistoriasModal';
import { MotoIcon } from './CategoryIcons';
import { EmptyState } from './common/EmptyState';
import { NewMotoWizardModal } from './motos/modals/NewMotoWizardModal';
import { NewContractModal } from './motos/modals/NewContractModal';
import { EditMotoModal } from './motos/modals/EditMotoModal';
import { MotoPaymentModal } from './motos/modals/MotoPaymentModal';
import { MotoNewKmModal } from './motos/modals/MotoNewKmModal';
import { MotoDeliveryModal } from './motos/modals/MotoDeliveryModal';
import {
  DeleteMotoConfirmModal,
  TerminateMotoModal,
  PhotoLightboxModal,
  NewContractSuccessModal,
} from './motos/modals/MotoAuxiliaryModals';
import { MotoCardItem } from './motos/MotoCardItem';
import { MotoSummaryKPIs } from './motos/MotoSummaryKPIs';
import { useMotosViewLogic } from './motos/useMotosViewLogic';
import { useScrollActiveIntoView } from '../hooks/useScrollActiveIntoView';
import { useGsapStagger, gsapButtonPress } from '../utils/gsapAnimations';

interface MotosViewProps {
  onOpenWhatsApp: (contractId: string, installmentId?: string) => void;
  onGenerateDocument: (type: any, moto: Moto, contract?: MotoContract, tenant?: MotoTenant) => void;
  onOpenSimulator?: () => void;
  onOpenClientProfile?: (tenantId: string, type: 'moto' | 'kitnet') => void;
}

export const MotosView: React.FC<MotosViewProps> = React.memo(({
  onOpenWhatsApp,
  onGenerateDocument,
  onOpenSimulator,
  onOpenClientProfile,
}) => {
  const {
    motos,
    motoContracts,
    motoTenants,
    settings,
    filterStatus,
    setFilterStatus,
    searchTerm,
    setSearchTerm,
    selectedMotoId,
    setSelectedMotoId,
    activeSubTab,
    setActiveSubTab,
    showNewMotoModal,
    setShowNewMotoModal,
    motoToEdit,
    setMotoToEdit,
    motoToDelete,
    setMotoToDelete,
    motoToTerminate,
    setMotoToTerminate,
    showNewContractModal,
    setShowNewContractModal,
    showNewKmModal,
    setShowNewKmModal,
    showDeliveryModal,
    setShowDeliveryModal,
    showPaymentModal,
    setShowPaymentModal,
    showCompareModal,
    setShowCompareModal,
    showMaintenanceModal,
    setShowMaintenanceModal,
    showAdjustmentModal,
    setShowAdjustmentModal,
    selectedPhotoPreview,
    setSelectedPhotoPreview,
    newContractSuccessData,
    setNewContractSuccessData,
    galleryFileInputRef,
    newMotoForm,
    setNewMotoForm,
    resetNewMotoForm,
    standaloneContractForm,
    setStandaloneContractForm,
    editMotoForm,
    setEditMotoForm,
    terminateMotoForm,
    setTerminateMotoForm,
    filteredMotos,
    selectedMoto,
    activeContract,
    handleNewMotoTenantPhotoUpload,
    handleEditMotoTenantPhotoUpload,
    handleStandaloneTenantPhotoUpload,
    handleCreateMotoSubmit,
    handleCreateStandaloneContractSubmit,
    handleOpenEditModal,
    handleEditMotoSubmit,
    handleDirectGalleryUpload,
    handleTriggerQuickUpload,
    handleRemovePhotoAngle,
    duplicateMoto,
    deleteMoto,
    deleteMotoMaintenance,
    terminateMotoContract,
    addKmLog,
    recordMotoDelivery,
    payMotoInstallment,
  } = useMotosViewLogic();

  const { containerRef, registerItem, scrollItemIntoView } = useScrollActiveIntoView(filterStatus);
  const motosListContainerRef = useGsapStagger<HTMLDivElement>('.moto-card-anim-item', [
    filterStatus,
    searchTerm,
    filteredMotos.length,
  ]);

  // Metrics for KPIs Header
  const totalMotos = motos.length;
  const occupiedMotos = motos.filter((m) => m.status === 'alugada').length;
  const occupancyPercentage = totalMotos > 0 ? (occupiedMotos / totalMotos) * 100 : 0;
  const availableMotos = motos.filter((m) => m.status === 'disponivel').length;
  const maintenanceMotos = motos.filter((m) => m.status === 'manutencao').length;
  const activeMonthlyRevenue = motoContracts
    .filter((c) => c.status === 'ativo')
    .reduce((sum, c) => {
      if (c.paymentFrequency === 'semanal') {
        return sum + (c.weeklyValue ? c.weeklyValue * WEEKS_PER_MONTH : 0);
      }
      return sum + (c.monthlyValue || 0);
    }, 0);

  const activeWeeklyRevenue = motoContracts
    .filter((c) => c.status === 'ativo' && c.paymentFrequency === 'semanal')
    .reduce((sum, c) => sum + (c.weeklyValue || 0), 0);

  const handleToggleMoto = (motoId: string) => {
    setSelectedMotoId((prev) => (prev === motoId ? null : motoId));
  };

  const maskCPFInput = (v: string) => {
    return v
      .replace(/\D/g, '')
      .slice(0, 11)
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
  };

  const maskPhoneInput = (v: string) => {
    return v
      .replace(/\D/g, '')
      .slice(0, 11)
      .replace(/(\d{2})(\d)/, '($1) $2')
      .replace(/(\d{5})(\d{4})$/, '$1-$2');
  };

  return (
    <div className="space-y-4 font-sans max-w-7xl mx-auto">
      {/* Hidden file input for quick direct uploads */}
      <input
        ref={galleryFileInputRef}
        type="file"
        accept="image/*"
        onChange={handleDirectGalleryUpload}
        className="hidden"
      />

      {/* Top Header & 4 Compact KPI Cards (Standardized with Kitnet design) */}
      <MotoSummaryKPIs
        totalMotos={totalMotos}
        occupancyPercentage={occupancyPercentage}
        occupiedMotos={occupiedMotos}
        activeMonthlyRevenue={activeMonthlyRevenue}
        activeWeeklyRevenue={activeWeeklyRevenue}
        availableMotos={availableMotos}
        maintenanceMotos={maintenanceMotos}
        currentFilter={filterStatus}
        onAddNewMoto={() => setShowNewMotoModal(true)}
        onOpenSimulator={onOpenSimulator}
        onFilterClick={setFilterStatus}
      />

      {/* Filter and Search Bar Container */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* 4 Standard Filter Chips with smooth auto-center */}
          <div
            ref={containerRef}
            className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0 scrollbar-none scroll-smooth touch-pan-x"
          >
            {/* 1. Todas */}
            <motion.button
              ref={registerItem('todos')}
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => {
                setFilterStatus('todos');
                scrollItemIntoView('todos');
              }}
              className={`px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-xl font-semibold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 border ${
                filterStatus === 'todos'
                  ? 'bg-purple-600 text-white border-purple-600 shadow-xs font-bold'
                  : 'bg-surface-card hover:bg-surface-hover text-text-secondary border-border-subtle hover:border-border-hover'
              }`}
            >
              <Motorbike className={`w-4 h-4 ${filterStatus === 'todos' ? 'text-white' : 'text-text-muted'}`} />
              <span className={filterStatus === 'todos' ? 'font-bold' : ''}>Todas</span>
              <span
                className={`text-xs font-bold px-2 py-0.5 rounded-full transition-all ${
                  filterStatus === 'todos'
                    ? 'bg-white/25 text-white font-black'
                    : 'bg-surface-subtle text-text-muted border border-border-subtle'
                }`}
              >
                {motos.length}
              </span>
            </motion.button>

            {/* 2. Disponíveis */}
            <motion.button
              ref={registerItem('disponivel')}
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => {
                setFilterStatus('disponivel');
                scrollItemIntoView('disponivel');
              }}
              className={`px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-xl font-semibold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 border ${
                filterStatus === 'disponivel'
                  ? 'bg-sky-600 text-white border-sky-600 shadow-xs font-bold'
                  : 'bg-surface-card hover:bg-surface-hover text-text-secondary border-border-subtle hover:border-border-hover'
              }`}
            >
              <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${filterStatus === 'disponivel' ? 'bg-white' : 'bg-sky-500'}`} />
              <span className={filterStatus === 'disponivel' ? 'font-bold' : ''}>Disponíveis</span>
              <span
                className={`text-xs font-bold px-2 py-0.5 rounded-full transition-all ${
                  filterStatus === 'disponivel'
                    ? 'bg-white/25 text-white font-black'
                    : 'bg-surface-subtle text-text-muted border border-border-subtle'
                }`}
              >
                {availableMotos}
              </span>
            </motion.button>

            {/* 3. Alugadas */}
            <motion.button
              ref={registerItem('alugada')}
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => {
                setFilterStatus('alugada');
                scrollItemIntoView('alugada');
              }}
              className={`px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-xl font-semibold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 border ${
                filterStatus === 'alugada'
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs font-bold'
                  : 'bg-surface-card hover:bg-surface-hover text-text-secondary border-border-subtle hover:border-border-hover'
              }`}
            >
              <ArrowUpCircle className={`w-4 h-4 shrink-0 ${filterStatus === 'alugada' ? 'text-white' : 'text-text-muted'}`} />
              <span className={filterStatus === 'alugada' ? 'font-bold' : ''}>Alugadas</span>
              <span
                className={`text-xs font-bold px-2 py-0.5 rounded-full transition-all ${
                  filterStatus === 'alugada'
                    ? 'bg-white/25 text-white font-black'
                    : 'bg-surface-subtle text-text-muted border border-border-subtle'
                }`}
              >
                {occupiedMotos}
              </span>
            </motion.button>

            {/* 4. Em Manutenção */}
            <motion.button
              ref={registerItem('manutencao')}
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => {
                setFilterStatus('manutencao');
                scrollItemIntoView('manutencao');
              }}
              className={`px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-xl font-semibold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 border ${
                filterStatus === 'manutencao'
                  ? 'bg-amber-600 text-white border-amber-600 shadow-xs font-bold'
                  : 'bg-surface-card hover:bg-surface-hover text-text-secondary border-border-subtle hover:border-border-hover'
              }`}
            >
              <Wrench className={`w-4 h-4 shrink-0 ${filterStatus === 'manutencao' ? 'text-white' : 'text-text-muted'}`} />
              <span className={filterStatus === 'manutencao' ? 'font-bold' : ''}>Em Manutenção</span>
              <span
                className={`text-xs font-bold px-2 py-0.5 rounded-full transition-all ${
                  filterStatus === 'manutencao'
                    ? 'bg-white/25 text-white font-black'
                    : 'bg-surface-subtle text-text-muted border border-border-subtle'
                }`}
              >
                {maintenanceMotos}
              </span>
            </motion.button>
          </div>

          {/* Search Input */}
          <div className="relative w-full sm:w-72 shrink-0">
            <Search className="w-4 h-4 text-text-secondary absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Buscar por placa, modelo, chassi..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-8 py-2 bg-surface-input hover:bg-surface-card focus:bg-surface-card border border-border-subtle focus:border-action-primary rounded-xl text-xs text-text-primary placeholder:text-text-muted outline-none transition-colors"
            />
            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-text-secondary hover:text-text-primary p-1 cursor-pointer transition-transform active:scale-95"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main List of Motos (Full Width, In-Place Accordion Expansion) */}
      <div ref={motosListContainerRef} className="space-y-4">
        {filteredMotos.length === 0 ? (
          <EmptyState
            icon={<MotoIcon size={32} color={COLORS.category.motos} className="mx-auto" />}
            title="Nenhuma moto encontrada"
            description="Cadastre um novo veículo ou altere os filtros de busca."
            actionLabel="Cadastrar Moto"
            onAction={() => setShowNewMotoModal(true)}
            actionIcon={<Plus className="w-4 h-4" />}
            category="motos"
          />
        ) : (
          filteredMotos.map((moto, index) => {
            const isSelected = selectedMotoId === moto.id;
            const contract =
              motoContracts.find((c) => c.motoId === moto.id && c.status === 'ativo') ||
              motoContracts.find((c) => c.motoId === moto.id);
            const tenant = motoTenants.find((t) => t.id === contract?.tenantId);

            return (
              <div key={moto.id} className="moto-card-anim-item">
                <MotoCardItem
                  moto={moto}
                  index={index}
                  isSelected={isSelected}
                  contract={contract}
                  tenant={tenant}
                  activeSubTab={activeSubTab}
                  onToggleSelect={handleToggleMoto}
                  setActiveSubTab={setActiveSubTab}
                  handleOpenEditModal={handleOpenEditModal}
                  setShowNewContractModal={setShowNewContractModal}
                  onGenerateDocument={onGenerateDocument}
                  onOpenWhatsApp={onOpenWhatsApp}
                  setShowMaintenanceModal={setShowMaintenanceModal}
                  setShowCompareModal={setShowCompareModal}
                  duplicateMoto={duplicateMoto}
                  setTerminateMotoForm={setTerminateMotoForm}
                  setMotoToTerminate={setMotoToTerminate}
                  setMotoToDelete={setMotoToDelete}
                  setShowAdjustmentModal={setShowAdjustmentModal}
                  setShowPaymentModal={setShowPaymentModal}
                  deleteMotoMaintenance={deleteMotoMaintenance}
                  setShowNewKmModal={setShowNewKmModal}
                  setShowDeliveryModal={setShowDeliveryModal}
                  setSelectedPhotoPreview={setSelectedPhotoPreview}
                  handleTriggerQuickUpload={handleTriggerQuickUpload}
                  handleRemovePhotoAngle={handleRemovePhotoAngle}
                  onOpenClientProfile={onOpenClientProfile}
                  formatCurrency={formatCurrency}
                  formatDate={formatDate}
                  formatCPF={formatCPF}
                  formatPhone={formatPhone}
                  getCNHStatus={getCNHStatus}
                  isPlateCorruptedOrInvalid={isPlateCorruptedOrInvalid}
                />
              </div>
            );
          })
        )}
      </div>

      {/* Modals & Wizards */}
      <NewMotoWizardModal
        isOpen={showNewMotoModal}
        onClose={() => {
          setShowNewMotoModal(false);
          resetNewMotoForm();
        }}
        form={newMotoForm}
        setForm={setNewMotoForm}
        onSubmit={handleCreateMotoSubmit}
        handleTenantPhotoUpload={handleNewMotoTenantPhotoUpload}
        maskCPFInput={maskCPFInput}
        maskPhoneInput={maskPhoneInput}
        formatCurrency={formatCurrency}
        formatDate={formatDate}
        existingTenants={motoTenants}
        settings={settings}
      />

      {showNewContractModal && selectedMoto && (
        <NewContractModal
          isOpen={showNewContractModal}
          selectedMoto={selectedMoto}
          onClose={() => setShowNewContractModal(false)}
          form={standaloneContractForm}
          setForm={setStandaloneContractForm}
          onSubmit={handleCreateStandaloneContractSubmit}
          handleStandaloneTenantPhotoUpload={handleStandaloneTenantPhotoUpload}
          maskCPFInput={maskCPFInput}
          maskPhoneInput={maskPhoneInput}
          formatCurrency={formatCurrency}
          formatDate={formatDate}
          existingTenants={motoTenants}
          settings={settings}
        />
      )}

      <EditMotoModal
        isOpen={Boolean(motoToEdit)}
        motoToEdit={motoToEdit}
        onClose={() => setMotoToEdit(null)}
        form={editMotoForm}
        setForm={setEditMotoForm}
        onSubmit={handleEditMotoSubmit}
        handleTenantPhotoUpload={handleEditMotoTenantPhotoUpload}
        maskCPFInput={maskCPFInput}
        maskPhoneInput={maskPhoneInput}
        isPlateCorruptedOrInvalid={isPlateCorruptedOrInvalid}
      />

      <MotoPaymentModal
        paymentData={showPaymentModal}
        onClose={() => setShowPaymentModal(null)}
        onConfirm={(contractId, instId, notes) => {
          payMotoInstallment(contractId, instId, notes);
          setShowPaymentModal(null);
        }}
      />

      {showNewKmModal && selectedMoto && (
        <MotoNewKmModal
          isOpen={showNewKmModal}
          moto={selectedMoto}
          onClose={() => setShowNewKmModal(false)}
          onConfirm={(motoId, km, notes, photoUrl) => {
            addKmLog(motoId, km, notes, photoUrl);
          }}
        />
      )}

      {showDeliveryModal && selectedMoto && (
        <MotoDeliveryModal
          isOpen={showDeliveryModal}
          moto={selectedMoto}
          onClose={() => setShowDeliveryModal(false)}
          onConfirm={(motoId, delivery) => {
            recordMotoDelivery(motoId, delivery);
          }}
        />
      )}

      {showCompareModal && selectedMoto && (
        <CentralVistoriasModal
          isOpen={showCompareModal}
          onClose={() => setShowCompareModal(false)}
          assetType="moto"
          moto={selectedMoto}
        />
      )}

      <DeleteMotoConfirmModal
        moto={motoToDelete}
        onClose={() => setMotoToDelete(null)}
        onConfirm={() => {
          if (motoToDelete) {
            deleteMoto(motoToDelete.id);
            setMotoToDelete(null);
            if (selectedMotoId === motoToDelete.id) {
              setSelectedMotoId(null);
            }
          }
        }}
      />

      <TerminateMotoModal
        data={motoToTerminate}
        form={terminateMotoForm}
        setForm={setTerminateMotoForm}
        onClose={() => setMotoToTerminate(null)}
        onConfirm={() => {
          if (motoToTerminate) {
            terminateMotoContract(
              motoToTerminate.contract.id,
              terminateMotoForm.finalKm,
              terminateMotoForm.notes
            );
            setMotoToTerminate(null);
          }
        }}
        formatCurrency={formatCurrency}
      />

      {selectedPhotoPreview && (
        <PhotoLightboxModal
          photo={selectedPhotoPreview}
          onClose={() => setSelectedPhotoPreview(null)}
        />
      )}

      {newContractSuccessData && (
        <NewContractSuccessModal
          data={newContractSuccessData}
          onClose={() => setNewContractSuccessData(null)}
          settings={settings}
          formatCurrency={formatCurrency}
          formatCPF={formatCPF}
        />
      )}

      {showMaintenanceModal && selectedMoto && (
        <MotoMaintenanceModal
          isOpen={showMaintenanceModal}
          moto={selectedMoto}
          onClose={() => setShowMaintenanceModal(false)}
        />
      )}

      <RentAdjustmentModal
        isOpen={showAdjustmentModal}
        onClose={() => setShowAdjustmentModal(false)}
        type="moto"
        contractId={activeContract?.id}
        currentValue={
          activeContract
            ? activeContract.paymentFrequency === 'semanal'
              ? activeContract.weeklyValue || (activeContract.monthlyValue ? monthlyToWeekly(activeContract.monthlyValue) : (activeContract.installments?.[0]?.amount || 0))
              : activeContract.monthlyValue || (activeContract.weeklyValue ? weeklyToMonthly(activeContract.weeklyValue) : (activeContract.installments?.[0]?.amount || 0))
            : undefined
        }
        clientName={
          activeContract
            ? motoTenants.find((t) => t.id === activeContract.tenantId)?.fullName || 'Locatário'
            : undefined
        }
      />
    </div>
  );
});
