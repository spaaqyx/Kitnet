import React, { useState, useMemo } from 'react';
import { DOCUMENT_TYPES_LIST } from './documentTypesList';
import { Motorbike, Home, ShieldCheck, Scale, Check, ChevronDown } from 'lucide-react';
import { gsapButtonPress } from '../../utils/gsapAnimations';

interface DocumentTypeSelectorProps {
  docType: string;
  onSelectDocType: (id: string) => void;
}

interface CategoryConfig {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  count: number;
  activeTabStyle: string;
  activeIconStyle: string;
  activeBadgeStyle: string;
  hoverTabStyle: string;
  selectedCardStyle: string;
  selectedIconBoxStyle: string;
  selectedCheckStyle: string;
}

export const DocumentTypeSelector: React.FC<DocumentTypeSelectorProps> = ({
  docType,
  onSelectDocType,
}) => {
  // Infer active category from currently selected docType
  const currentDoc = DOCUMENT_TYPES_LIST.find((d) => d.id === docType);
  const initialCategory = currentDoc
    ? currentDoc.category === 'Financeiro' || currentDoc.category === 'Garantia'
      ? 'Garantia'
      : currentDoc.category === 'Encerramento' || currentDoc.category === 'Jurídico'
      ? 'Jurídico'
      : currentDoc.category
    : 'Motos';

  const [activeCategory, setActiveCategory] = useState<string>(initialCategory);

  const categories: CategoryConfig[] = [
    {
      id: 'Motos',
      label: 'Motos',
      icon: Motorbike,
      count: 3,
      activeTabStyle:
        'bg-amber-500/15 border-amber-500/50 text-amber-700 dark:text-amber-300 font-bold',
      activeIconStyle: 'text-amber-600 dark:text-amber-400',
      activeBadgeStyle: 'bg-amber-500/20 text-amber-800 dark:text-amber-300 border border-amber-500/40',
      hoverTabStyle: 'hover:text-amber-700 dark:hover:text-amber-300 hover:bg-amber-500/10 hover:border-amber-500/30',
      selectedCardStyle:
        'bg-amber-500/[0.06] border-amber-500/60 shadow-sm',
      selectedIconBoxStyle: 'bg-amber-500 text-slate-950 shadow-sm',
      selectedCheckStyle: 'bg-amber-500 text-slate-950',
    },
    {
      id: 'Kitnets',
      label: 'Kitnets',
      icon: Home,
      count: 1,
      activeTabStyle:
        'bg-sky-500/15 border-sky-500/50 text-sky-700 dark:text-sky-300 font-bold',
      activeIconStyle: 'text-sky-600 dark:text-sky-400',
      activeBadgeStyle: 'bg-sky-500/20 text-sky-800 dark:text-sky-300 border border-sky-500/40',
      hoverTabStyle: 'hover:text-sky-700 dark:hover:text-sky-300 hover:bg-sky-500/10 hover:border-sky-500/30',
      selectedCardStyle:
        'bg-sky-500/[0.06] border-sky-500/60 shadow-sm',
      selectedIconBoxStyle: 'bg-sky-500 text-white shadow-sm',
      selectedCheckStyle: 'bg-sky-500 text-white',
    },
    {
      id: 'Garantia',
      label: 'Recibos & Caução',
      icon: ShieldCheck,
      count: 2,
      activeTabStyle:
        'bg-emerald-500/15 border-emerald-500/50 text-emerald-700 dark:text-emerald-300 font-bold',
      activeIconStyle: 'text-emerald-600 dark:text-emerald-400',
      activeBadgeStyle: 'bg-emerald-500/20 text-emerald-800 dark:text-emerald-300 border border-emerald-500/40',
      hoverTabStyle: 'hover:text-emerald-700 dark:hover:text-emerald-300 hover:bg-emerald-500/10 hover:border-emerald-500/30',
      selectedCardStyle:
        'bg-emerald-500/[0.06] border-emerald-500/60 shadow-sm',
      selectedIconBoxStyle: 'bg-emerald-600 text-white shadow-sm',
      selectedCheckStyle: 'bg-emerald-600 text-white',
    },
    {
      id: 'Jurídico',
      label: 'Jurídico & Distrato',
      icon: Scale,
      count: 2,
      activeTabStyle:
        'bg-purple-500/15 border-purple-500/50 text-purple-700 dark:text-purple-300 font-bold',
      activeIconStyle: 'text-purple-600 dark:text-purple-400',
      activeBadgeStyle: 'bg-purple-500/20 text-purple-800 dark:text-purple-300 border border-purple-500/40',
      hoverTabStyle: 'hover:text-purple-700 dark:hover:text-purple-300 hover:bg-purple-500/10 hover:border-purple-500/30',
      selectedCardStyle:
        'bg-purple-500/[0.06] border-purple-500/60 shadow-sm',
      selectedIconBoxStyle: 'bg-purple-600 text-white shadow-sm',
      selectedCheckStyle: 'bg-purple-600 text-white',
    },
  ];

  const currentCategoryConfig = categories.find((c) => c.id === activeCategory) || categories[0];

  const filteredDocs = useMemo(() => {
    if (activeCategory === 'Garantia') {
      return DOCUMENT_TYPES_LIST.filter(
        (d) => d.category === 'Garantia' || d.category === 'Financeiro'
      );
    }
    if (activeCategory === 'Jurídico') {
      return DOCUMENT_TYPES_LIST.filter(
        (d) => d.category === 'Jurídico' || d.category === 'Encerramento'
      );
    }
    return DOCUMENT_TYPES_LIST.filter((d) => d.category === activeCategory);
  }, [activeCategory]);

  return (
    <div className="space-y-4">
      {/* Category Tabs: Sophisticated Segmented Control with Category-Specific Accents */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1.5 bg-surface-subtle border border-border-subtle rounded-xl shadow-inner">
        {categories.map((cat) => {
          const Icon = cat.icon;
          const isActive = activeCategory === cat.id;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={(e) => {
                gsapButtonPress(e.currentTarget);
                setActiveCategory(cat.id);
                // If the currently selected doc isn't in this category, select first in category
                const docsInCat =
                  cat.id === 'Garantia'
                    ? DOCUMENT_TYPES_LIST.filter(
                        (d) => d.category === 'Garantia' || d.category === 'Financeiro'
                      )
                    : cat.id === 'Jurídico'
                    ? DOCUMENT_TYPES_LIST.filter(
                        (d) => d.category === 'Jurídico' || d.category === 'Encerramento'
                      )
                    : DOCUMENT_TYPES_LIST.filter((d) => d.category === cat.id);
                if (docsInCat.length > 0 && !docsInCat.some((d) => d.id === docType)) {
                  onSelectDocType(docsInCat[0].id);
                }
              }}
              className={`w-full py-2.5 px-2.5 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 border transition-all duration-150 cursor-pointer select-none active:scale-[0.98] ${
                isActive
                  ? cat.activeTabStyle
                  : `border-transparent text-text-secondary bg-transparent hover:bg-surface-card ${cat.hoverTabStyle}`
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 transition-colors ${isActive ? cat.activeIconStyle : 'text-text-muted'}`} />
              <span className="truncate">{cat.label}</span>
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold shrink-0 transition-colors ${
                  isActive
                    ? cat.activeBadgeStyle
                    : 'bg-surface-card text-text-secondary border border-border-subtle'
                }`}
              >
                {cat.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Document Selection Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {filteredDocs.map((item) => {
          const Icon = item.icon;
          const isSelected = docType === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={(e) => {
                gsapButtonPress(e.currentTarget);
                onSelectDocType(item.id);
              }}
              className={`w-full text-left p-3.5 rounded-xl border transition-all duration-150 cursor-pointer relative flex flex-col justify-between gap-2.5 select-none active:scale-[0.99] ${
                isSelected
                  ? currentCategoryConfig.selectedCardStyle
                  : 'bg-surface-card border-border-subtle hover:bg-surface-hover hover:border-border-default'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className={`p-2 rounded-lg shrink-0 transition-colors ${
                      isSelected
                        ? currentCategoryConfig.selectedIconBoxStyle
                        : 'bg-surface-subtle text-text-secondary border border-border-subtle'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <span
                      className={`font-bold text-xs tracking-tight block truncate ${
                        isSelected ? 'text-text-primary' : 'text-text-secondary'
                      }`}
                    >
                      {item.title}
                    </span>
                    <span
                      className={`text-[10px] block truncate font-medium ${
                        isSelected ? currentCategoryConfig.activeIconStyle : 'text-text-secondary'
                      }`}
                    >
                      {item.badge}
                    </span>
                  </div>
                </div>

                {isSelected && (
                  <div
                    className={`w-4 h-4 rounded-full flex items-center justify-center shrink-0 shadow-xs ${currentCategoryConfig.selectedCheckStyle}`}
                  >
                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                  </div>
                )}
              </div>

              <p className="text-[11px] text-text-secondary line-clamp-2 leading-relaxed pl-0.5">
                {item.desc}
              </p>
            </button>
          );
        })}
      </div>

      {/* Direct Dropdown for Fast Access on Mobile */}
      <div className="sm:hidden pt-1">
        <div className="flex items-center justify-between text-[11px] text-text-secondary mb-1 px-1">
          <span>Ou escolha direto por menu:</span>
          <span className={`font-semibold truncate max-w-[180px] ${currentCategoryConfig.activeIconStyle}`}>
            {currentDoc?.title}
          </span>
        </div>
        <div className="relative">
          <select
            value={docType}
            onChange={(e) => {
              onSelectDocType(e.target.value);
              const found = DOCUMENT_TYPES_LIST.find((d) => d.id === e.target.value);
              if (found) {
                const cat =
                  found.category === 'Financeiro' || found.category === 'Garantia'
                    ? 'Garantia'
                    : found.category === 'Encerramento' || found.category === 'Jurídico'
                    ? 'Jurídico'
                    : found.category;
                setActiveCategory(cat);
              }
            }}
            className="w-full bg-surface-base border border-border-dark rounded-xl px-3.5 py-2.5 text-xs text-text-primary appearance-none focus:outline-none focus:border-category-motos pr-9"
          >
            {DOCUMENT_TYPES_LIST.map((doc) => (
              <option key={doc.id} value={doc.id}>
                [{doc.category}] {doc.title}
              </option>
            ))}
          </select>
          <ChevronDown className="w-4 h-4 text-text-secondary absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>
      </div>
    </div>
  );
};
