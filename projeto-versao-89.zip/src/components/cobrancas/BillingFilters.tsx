import React from 'react';
import { motion } from 'motion/react';
import { Search, Motorbike, Home, AlertCircle, Clock, Calendar, CheckCircle2 } from 'lucide-react';
import { useScrollActiveIntoView } from '../../hooks/useScrollActiveIntoView';

interface BillingFiltersProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  filterType: 'todos' | 'moto' | 'kitnet';
  setFilterType: (type: 'todos' | 'moto' | 'kitnet') => void;
  activeCategory: 'todos' | 'atrasado' | 'vencendo_hoje' | 'proximos_7_dias' | 'em_dia';
  setActiveCategory: (cat: 'todos' | 'atrasado' | 'vencendo_hoje' | 'proximos_7_dias' | 'em_dia') => void;
  motosCount: number;
  kitnetsCount: number;
  atrasadosCount: number;
  vencendoHojeCount: number;
  proximos7DiasCount: number;
  emDiaCount: number;
  totalCount: number;
}

export const BillingFilters: React.FC<BillingFiltersProps> = ({
  searchQuery,
  setSearchQuery,
  filterType,
  setFilterType,
  activeCategory,
  setActiveCategory,
  motosCount,
  kitnetsCount,
  atrasadosCount,
  vencendoHojeCount,
  proximos7DiasCount,
  emDiaCount,
  totalCount,
}) => {
  const { containerRef, registerItem, scrollItemIntoView } = useScrollActiveIntoView(activeCategory);

  const statusCategories = [
    {
      id: 'todos' as const,
      label: 'Todos',
      count: totalCount,
      icon: null,
      activeClass: 'bg-purple-100 dark:bg-purple-500/20 text-purple-900 dark:text-purple-200 border-purple-400 font-bold shadow-xs',
      badgeClass: 'bg-purple-600 text-white font-bold',
      hoverClass: 'hover:border-purple-400 hover:bg-purple-50 dark:hover:bg-purple-500/10 hover:text-purple-800 dark:hover:text-purple-300',
    },
    {
      id: 'atrasado' as const,
      label: 'Atrasados',
      count: atrasadosCount,
      icon: <AlertCircle className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400 shrink-0" />,
      activeClass: 'bg-rose-100 dark:bg-rose-500/20 text-rose-900 dark:text-rose-200 border-rose-400 font-bold shadow-xs',
      badgeClass: 'bg-rose-600 text-white font-bold',
      hoverClass: 'hover:border-rose-400 hover:bg-rose-50 dark:hover:bg-rose-500/10 hover:text-rose-800 dark:hover:text-rose-300',
    },
    {
      id: 'vencendo_hoje' as const,
      label: 'Vencendo Hoje',
      count: vencendoHojeCount,
      icon: <Clock className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />,
      activeClass: 'bg-amber-100 dark:bg-amber-500/20 text-amber-950 dark:text-amber-200 border-amber-400 font-bold shadow-xs',
      badgeClass: 'bg-amber-500 text-slate-950 font-bold',
      hoverClass: 'hover:border-amber-400 hover:bg-amber-50 dark:hover:bg-amber-500/10 hover:text-amber-900 dark:hover:text-amber-300',
    },
    {
      id: 'proximos_7_dias' as const,
      label: 'Próximos 7 Dias',
      count: proximos7DiasCount,
      icon: <Calendar className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400 shrink-0" />,
      activeClass: 'bg-sky-100 dark:bg-sky-500/20 text-sky-900 dark:text-sky-200 border-sky-400 font-bold shadow-xs',
      badgeClass: 'bg-sky-600 text-white font-bold',
      hoverClass: 'hover:border-sky-400 hover:bg-sky-50 dark:hover:bg-sky-500/10 hover:text-sky-800 dark:hover:text-sky-300',
    },
    {
      id: 'em_dia' as const,
      label: 'Em Dia',
      count: emDiaCount,
      icon: <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />,
      activeClass: 'bg-emerald-100 dark:bg-emerald-500/20 text-emerald-900 dark:text-emerald-200 border-emerald-400 font-bold shadow-xs',
      badgeClass: 'bg-emerald-600 text-white font-bold',
      hoverClass: 'hover:border-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-500/10 hover:text-emerald-800 dark:hover:text-emerald-300',
    },
  ];
  return (
    <div className="bg-surface-sidebar border border-border-subtle p-4 rounded-xl space-y-3 shadow-sm">
      {/* Top row: Search and Asset Type */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-text-secondary" />
          <input
            type="text"
            placeholder="Buscar por cliente, placa, CPF ou kitnet..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-surface-subtle hover:bg-surface-card focus:bg-surface-card border border-border-subtle rounded-xl pl-9 pr-4 py-2 text-xs sm:text-sm text-text-primary placeholder-text-secondary/60 focus:outline-none focus:border-action-primary transition-all"
          />
        </div>

        {/* Asset Type Selector */}
        <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0 scrollbar-none no-scrollbar">
          <button
            type="button"
            onClick={() => setFilterType('todos')}
            className={`shrink-0 min-w-max px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer border active:scale-95 ${
              filterType === 'todos'
                ? 'bg-purple-100 dark:bg-purple-500/20 text-purple-900 dark:text-purple-200 border-purple-400 font-bold'
                : 'bg-surface-subtle hover:bg-surface-card text-text-secondary border-border-subtle hover:border-purple-400 hover:text-purple-800 dark:hover:text-purple-300'
            }`}
          >
            Todos os Ativos ({motosCount + kitnetsCount})
          </button>
          <button
            type="button"
            onClick={() => setFilterType('moto')}
            className={`shrink-0 min-w-max px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer border active:scale-95 ${
              filterType === 'moto'
                ? 'bg-amber-100 dark:bg-amber-500/20 text-amber-950 dark:text-amber-200 border-amber-400 font-bold'
                : 'bg-surface-subtle hover:bg-surface-card text-text-secondary border-border-subtle hover:border-amber-400 hover:text-amber-800 dark:hover:text-amber-300'
            }`}
          >
            <Motorbike className={`w-3.5 h-3.5 shrink-0 ${filterType === 'moto' ? 'text-amber-600 dark:text-amber-300' : 'text-text-secondary'}`} />
            <span>Motos ({motosCount})</span>
          </button>
          <button
            type="button"
            onClick={() => setFilterType('kitnet')}
            className={`shrink-0 min-w-max px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer border active:scale-95 ${
              filterType === 'kitnet'
                ? 'bg-sky-100 dark:bg-sky-500/20 text-sky-900 dark:text-sky-200 border-sky-400 font-bold'
                : 'bg-surface-subtle hover:bg-surface-card text-text-secondary border-border-subtle hover:border-sky-400 hover:text-sky-800 dark:hover:text-sky-300'
            }`}
          >
            <Home className={`w-3.5 h-3.5 shrink-0 ${filterType === 'kitnet' ? 'text-sky-600 dark:text-sky-300' : 'text-text-secondary'}`} />
            <span>Kitnets ({kitnetsCount})</span>
          </button>
        </div>
      </div>

      {/* Bottom row: Status Filter Badges with smooth auto-center */}
      <div
        ref={containerRef}
        className="flex items-center gap-2 overflow-x-auto pt-2 border-t border-border-subtle pb-1 scrollbar-none no-scrollbar scroll-smooth touch-pan-x"
      >
        {statusCategories.map((cat) => {
          const isSelected = activeCategory === cat.id;
          return (
            <motion.button
              key={cat.id}
              ref={registerItem(cat.id)}
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => {
                setActiveCategory(cat.id);
                scrollItemIntoView(cat.id);
              }}
              className={`shrink-0 min-w-max px-3.5 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 border select-none ${
                isSelected
                  ? cat.activeClass
                  : `bg-surface-subtle hover:bg-surface-card text-text-secondary border-border-subtle ${cat.hoverClass}`
              }`}
            >
              {cat.icon}
              <span className={`shrink-0 whitespace-nowrap ${isSelected ? 'font-bold' : ''}`}>{cat.label}</span>
              <span
                className={`shrink-0 inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full text-[11px] font-bold tabular-nums transition-all ${
                  isSelected ? cat.badgeClass : 'bg-surface-card text-text-secondary border border-border-subtle'
                }`}
              >
                {cat.count}
              </span>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
};
