import React, { useRef, useEffect } from 'react';
import { Check, ChevronRight } from 'lucide-react';
import { gsapScrollStepper, gsapButtonPress } from '../../utils/gsapAnimations';

export interface WizardStepItem {
  num: number;
  label: string;
  icon?: React.ComponentType<{ className?: string }>;
}

export interface BaseWizardStepperProps {
  steps: WizardStepItem[];
  currentStep: number;
  onStepClick: (stepNum: number) => void;
  accentColor?: string;
}

export const BaseWizardStepper: React.FC<BaseWizardStepperProps> = ({
  steps,
  currentStep,
  onStepClick,
  accentColor = 'emerald',
}) => {
  const stepperRef = useRef<HTMLDivElement>(null);
  const stepButtonRefs = useRef<(HTMLButtonElement | null)[]>([]);

  // Auto-scroll active step into center on mobile using GSAP
  useEffect(() => {
    const activeBtn = stepButtonRefs.current[currentStep];
    const container = stepperRef.current;
    if (activeBtn && container) {
      gsapScrollStepper(container, activeBtn);
    }
  }, [currentStep]);

  return (
    <div className="relative bg-surface-subtle border-b border-border-subtle px-2 sm:px-4 py-2 shrink-0 overflow-hidden">
      {/* Soft fade masks on left and right for seamless scroll indication */}
      <div className="pointer-events-none absolute left-0 top-0 bottom-0 w-4 sm:w-6 bg-gradient-to-r from-surface-subtle to-transparent z-10" />
      <div className="pointer-events-none absolute right-0 top-0 bottom-0 w-4 sm:w-6 bg-gradient-to-l from-surface-subtle to-transparent z-10" />

      <div
        ref={stepperRef}
        className="flex items-center gap-1 sm:gap-2 overflow-x-auto scrollbar-none scroll-smooth py-0.5 px-2"
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        {steps.map((s, idx) => {
          const Icon = s.icon;
          const isCompleted = currentStep > s.num;
          const isCurrent = currentStep === s.num;

          return (
            <React.Fragment key={s.num}>
              <button
                ref={(el) => {
                  stepButtonRefs.current[s.num] = el;
                }}
                type="button"
                onClick={(e) => {
                  gsapButtonPress(e.currentTarget);
                  onStepClick(s.num);
                }}
                className={`group relative flex items-center gap-1.5 sm:gap-2 px-2.5 py-1.5 sm:px-3 sm:py-2 rounded-xl text-xs font-semibold transition-all duration-150 active:scale-95 cursor-pointer shrink-0 whitespace-nowrap border ${
                  isCurrent
                    ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/50 shadow-xs ring-1 ring-emerald-500/30 font-bold'
                    : isCompleted
                    ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/15'
                    : 'bg-surface-card text-text-muted border-border-subtle hover:text-text-primary hover:border-border-hover'
                }`}
              >
                <div
                  className={`w-4.5 h-4.5 sm:w-5 sm:h-5 rounded-full flex items-center justify-center text-[9.5px] sm:text-[10px] font-bold shrink-0 transition-colors ${
                    isCurrent
                      ? 'bg-emerald-500 text-white'
                      : isCompleted
                      ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/40'
                      : 'bg-surface-subtle text-text-muted group-hover:text-text-primary'
                  }`}
                >
                  {isCompleted ? <Check className="w-2.5 h-2.5 sm:w-3 sm:h-3 stroke-[3]" /> : s.num}
                </div>
                {Icon && (
                  <Icon
                    className={`w-3.5 h-3.5 shrink-0 transition-colors ${
                      isCurrent
                        ? 'text-emerald-700 dark:text-emerald-300'
                        : isCompleted
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : 'text-text-muted'
                    }`}
                  />
                )}
                <span className="tracking-tight">{s.label}</span>
              </button>
              {idx < steps.length - 1 && (
                <ChevronRight
                  className={`w-3 h-3 sm:w-3.5 sm:h-3.5 shrink-0 mx-0.5 transition-colors ${
                    currentStep > s.num ? 'text-emerald-500' : 'text-border-subtle'
                  }`}
                />
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
};
