import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Plus,
  Search,
  X,
  Home,
  ArrowUpCircle,
  TrendingUp,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Kitnet, KitnetContract, KitnetTenant, Installment } from '../types';
import { generateKitnetWhatsAppMessage, openWhatsAppLink } from '../utils/whatsappGenerator';
import { isInstallmentOverdue } from '../utils/formatters';
import { getKitnetMonthlyTotal } from '../utils/contractCalculations';
import { ComparadorVistoriaModal } from './ComparadorVistoriaModal';
import { CadastroKitnetWizardModal } from './CadastroKitnetWizardModal';
import { RentAdjustmentModal } from './RentAdjustmentModal';
import { useBodyScrollLock } from '../hooks/useBodyScrollLock';
import { useScrollActiveIntoView } from '../hooks/useScrollActiveIntoView';
import { KitnetIcon } from './CategoryIcons';
import { EmptyState } from './common/EmptyState';

// Subcomponents & Modals
import { KitnetSummaryKPIs } from './kitnets/KitnetSummaryKPIs';
import { KitnetCardItem } from './kitnets/KitnetCardItem';
import { EditKitnetModal } from './kitnets/modals/EditKitnetModal';
import { DeleteKitnetModal } from './kitnets/modals/DeleteKitnetModal';
import { TerminateKitnetModal } from './kitnets/modals/TerminateKitnetModal';
import { NewKitnetContractModal } from './kitnets/modals/NewKitnetContractModal';
import { RenewKitnetContractModal } from './kitnets/modals/RenewKitnetContractModal';
import { KitnetContractSuccessModal } from './kitnets/modals/KitnetContractSuccessModal';
import { KitnetPaymentModal } from './kitnets/modals/KitnetPaymentModal';
import { PhotoZoomPreviewModal } from './kitnets/modals/PhotoZoomPreviewModal';

interface KitnetsViewProps {
  onOpenWhatsApp?: (contractId: string, installmentId?: string) => void;
  onGenerateDocument: (type: any, kitnet: Kitnet, contract?: KitnetContract, tenant?: KitnetTenant) => void;
  onOpenClientProfile?: (tenantId: string, type: 'moto' | 'kitnet') => void;
}

export const KitnetsView: React.FC<KitnetsViewProps> = React.memo(({
  onOpenWhatsApp,
  onGenerateDocument,
  onOpenClientProfile,
}) => {
  const {
    kitnets,
    kitnetContracts,
    kitnetTenants,
    updateKitnet,
    deleteKitnet,
    duplicateKitnet,
    addKitnetTenant,
    createKitnetContract,
    renewKitnetContract,
    payKitnetInstallment,
    terminateKitnetContract,
    saveSignature,
    settings,
  } = useApp();

  const [filterStatus, setFilterStatus] = useState<string>('todos');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedKitnetId, setSelectedKitnetId] = useState<string | null>(null);

  const { containerRef, registerItem, scrollItemIntoView } = useScrollActiveIntoView(filterStatus);
  const [isMobileDetailOpen] = useState<boolean>(false);
  const [activeSubTab, setActiveSubTab] = useState<'geral' | 'contrato' | 'inquilino' | 'vistoria' | 'fotos'>('geral');
  const [selectedPhotoPreview, setSelectedPhotoPreview] = useState<{ url: string; title: string } | null>(null);

  // Modals state
  const [showNewKitnetModal, setShowNewKitnetModal] = useState<boolean>(false);
  const [kitnetToEdit, setKitnetToEdit] = useState<Kitnet | null>(null);
  const [kitnetToDelete, setKitnetToDelete] = useState<Kitnet | null>(null);
  const [kitnetToTerminate, setKitnetToTerminate] = useState<{ contract: KitnetContract; kitnet: Kitnet } | null>(null);
  const [showNewContractModal, setShowNewContractModal] = useState<boolean>(false);
  const [showRenewModal, setShowRenewModal] = useState<boolean>(false);
  const [showPaymentModal, setShowPaymentModal] = useState<{ contractId: string; installment: Installment } | null>(null);
  const [showCompareModal, setShowCompareModal] = useState<boolean>(false);
  const [showAdjustmentModal, setShowAdjustmentModal] = useState<boolean>(false);
  const [newContractSuccessData, setNewContractSuccessData] = useState<{
    kitnet: Kitnet;
    tenant: KitnetTenant;
    contract: KitnetContract;
  } | null>(null);

  const [, setRenewForm] = useState({
    additionalMonths: 12,
    newRentValue: 1560,
    reason: 'Renovação anual com emissão de novo cronograma de pagamentos',
  });

  // Filtered Kitnets
  const filteredKitnets = kitnets.filter((k) => {
    const matchesStatus = filterStatus === 'todos' || k.status === filterStatus;
    const matchesSearch =
      k.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      k.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      k.address.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const isAnyModalOpen = Boolean(
    kitnetToEdit ||
    kitnetToDelete ||
    kitnetToTerminate ||
    showNewContractModal ||
    showRenewModal ||
    showNewKitnetModal ||
    showPaymentModal ||
    showCompareModal ||
    newContractSuccessData
  );

  useBodyScrollLock(isAnyModalOpen);

  const selectedKitnet = kitnets.find((k) => k.id === selectedKitnetId) || filteredKitnets[0] || kitnets[0];
  const activeContract = kitnetContracts.find((c) => c.kitnetId === selectedKitnet?.id && c.status === 'ativo');
  const tenant = kitnetTenants.find((t) => t.id === activeContract?.tenantId);

  const handleRenewContractSubmit = (additionalMonths: number, newRentValue: number, reason: string) => {
    if (!activeContract) return;
    renewKitnetContract(
      activeContract.id,
      additionalMonths,
      newRentValue,
      reason
    );
    setShowRenewModal(false);
  };

  const handleSaveEditKitnet = (kitnetId: string, updatedData: any) => {
    updateKitnet(kitnetId, updatedData);
    setKitnetToEdit(null);
  };

  const handleConfirmDeleteKitnet = () => {
    if (!kitnetToDelete) return;
    const deletedId = kitnetToDelete.id;
    deleteKitnet(deletedId);
    if (selectedKitnetId === deletedId) {
      const remaining = kitnets.filter((k) => k.id !== deletedId);
      setSelectedKitnetId(remaining.length > 0 ? remaining[0].id : null);
    }
    setKitnetToDelete(null);
  };

  const handleConfirmTerminate = (contractId: string, newStatus: 'disponivel' | 'reforma', notes: string) => {
    terminateKitnetContract(contractId, newStatus, notes);
    setKitnetToTerminate(null);
  };

  const handleOpenNewContract = (kitnet: Kitnet) => {
    setSelectedKitnetId(kitnet.id);
    setShowNewContractModal(true);
  };

  const handleCreateContractSubmit = (contractData: any, newTenantData?: any) => {
    if (!selectedKitnet) return;

    let finalTenantId = contractData.tenantId;

    if (newTenantData) {
      finalTenantId = addKitnetTenant(newTenantData);
    }

    if (!finalTenantId) {
      alert('Selecione ou cadastre um inquilino.');
      return;
    }

    const newContractObj: KitnetContract = {
      id: 'temp_contract',
      kitnetId: selectedKitnet.id,
      tenantId: finalTenantId,
      startDate: contractData.startDate,
      durationMonths: contractData.durationMonths,
      rentValue: contractData.rentValue,
      waterValue: contractData.waterValue,
      dueDay: contractData.dueDay,
      deposit: contractData.deposit,
      status: 'ativo',
      installments: [],
    };

    createKitnetContract(newContractObj);

    const activeTenantObj: KitnetTenant = kitnetTenants.find((t) => t.id === finalTenantId) || {
      id: finalTenantId,
      fullName: newTenantData?.fullName || 'Inquilino',
      cpf: newTenantData?.cpf || '000.000.000-00',
      rg: 'Não informado',
      birthDate: '1990-01-01',
      whatsapp: newTenantData?.phone || '',
      phone: newTenantData?.phone || '',
      email: '',
      address: selectedKitnet.address || '',
      maritalStatus: 'solteiro',
      profession: '',
      incomeType: newTenantData?.incomeType || 'CLT',
      documents: {},
    };

    setNewContractSuccessData({
      kitnet: selectedKitnet,
      tenant: activeTenantObj,
      contract: newContractObj,
    });

    setShowNewContractModal(false);
  };

  const handleSendKitnetWhatsApp = () => {
    if (!activeContract || !tenant) return;
    const nextInst =
      activeContract.installments.find((i) => isInstallmentOverdue(i)) ||
      activeContract.installments.find((i) => i.status === 'pendente') ||
      activeContract.installments[0];

    const message = generateKitnetWhatsAppMessage(
      activeContract,
      tenant,
      nextInst,
      settings,
      `${selectedKitnet.name} - Unidade ${selectedKitnet.number}`
    );

    if (tenant.whatsapp || tenant.phone) {
      openWhatsAppLink(tenant.whatsapp || tenant.phone, message);
    } else {
      alert('Inquilino sem telefone cadastrado.');
    }
  };

  const totalUnits = kitnets.length;
  const occupiedUnits = kitnets.filter((k) => k.status === 'alugada').length;
  const availableUnits = kitnets.filter((k) => k.status === 'disponivel').length;
  const inRenovationUnits = kitnets.filter((k) => k.status === 'reforma').length;
  const occupancyPercentage = totalUnits > 0 ? Math.round((occupiedUnits / totalUnits) * 100) : 0;
  const activeMonthlyRevenue = kitnetContracts
    .filter((c) => c.status === 'ativo')
    .reduce((acc, c) => acc + getKitnetMonthlyTotal(c), 0);

  return (
    <div id="kitnets-view-root" className="space-y-4 sm:space-y-5 font-sans">
      {/* Top Header & Executive KPI Summary Grid */}
      <KitnetSummaryKPIs
        totalUnits={totalUnits}
        occupancyPercentage={occupancyPercentage}
        occupiedUnits={occupiedUnits}
        activeMonthlyRevenue={activeMonthlyRevenue}
        availableUnits={availableUnits}
        inRenovationUnits={inRenovationUnits}
        isMobileDetailOpen={isMobileDetailOpen}
        onAddNewKitnet={() => setShowNewKitnetModal(true)}
        onFilterClick={(filter) => setFilterStatus(filter)}
      />

      {/* Filter Pills Bar & Search Bar (Image 2) */}
      <div className={`space-y-3 ${isMobileDetailOpen ? 'hidden lg:block' : 'block'}`}>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* 4 Exact Filter Chips from Image 2 with smooth auto-center */}
          <div
            ref={containerRef}
            className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0 scrollbar-none scroll-smooth touch-pan-x"
          >
            {/* 1. Todas */}
            <motion.button
              ref={registerItem('todos')}
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => {
                setFilterStatus('todos');
                scrollItemIntoView('todos');
              }}
              className={`px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-xl font-semibold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 border ${
                filterStatus === 'todos'
                  ? 'bg-gradient-to-r from-purple-500/25 via-purple-500/15 to-violet-500/20 text-purple-200 border-purple-400/90'
                  : 'bg-[#0E111D] text-slate-400 border-white/[0.08] hover:border-purple-500/50 hover:bg-purple-500/[0.08] hover:text-purple-300'
              }`}
            >
              <Home className={`w-4 h-4 ${filterStatus === 'todos' ? 'text-purple-300' : 'text-slate-400'}`} />
              <span className={filterStatus === 'todos' ? 'font-bold' : ''}>Todas</span>
              <span
                className={`text-xs font-bold px-2 py-0.5 rounded-full transition-all ${
                  filterStatus === 'todos'
                    ? 'bg-purple-500 text-slate-950 font-black'
                    : 'bg-[#161B2B] text-slate-400 border border-white/[0.06]'
                }`}
              >
                {kitnets.length}
              </span>
            </motion.button>

            {/* 2. Disponíveis */}
            <motion.button
              ref={registerItem('disponivel')}
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => {
                setFilterStatus('disponivel');
                scrollItemIntoView('disponivel');
              }}
              className={`px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-xl font-semibold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 border ${
                filterStatus === 'disponivel'
                  ? 'bg-gradient-to-r from-sky-500/25 via-sky-500/15 to-cyan-500/20 text-sky-200 border-sky-400/90'
                  : 'bg-[#0E111D] text-slate-400 border-white/[0.08] hover:border-sky-500/50 hover:bg-sky-500/[0.08] hover:text-sky-300'
              }`}
            >
              <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${filterStatus === 'disponivel' ? 'bg-sky-400' : 'bg-sky-400/60'}`} />
              <span className={filterStatus === 'disponivel' ? 'font-bold' : ''}>Disponíveis</span>
              <span
                className={`text-xs font-bold px-2 py-0.5 rounded-full transition-all ${
                  filterStatus === 'disponivel'
                    ? 'bg-sky-500 text-slate-950 font-black'
                    : 'bg-[#161B2B] text-slate-400 border border-white/[0.06]'
                }`}
              >
                {kitnets.filter((k) => k.status === 'disponivel').length}
              </span>
            </motion.button>

            {/* 3. Alugadas */}
            <motion.button
              ref={registerItem('alugada')}
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => {
                setFilterStatus('alugada');
                scrollItemIntoView('alugada');
              }}
              className={`px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-xl font-semibold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 border ${
                filterStatus === 'alugada'
                  ? 'bg-gradient-to-r from-emerald-500/25 via-emerald-500/15 to-teal-500/20 text-emerald-200 border-emerald-400/90'
                  : 'bg-[#0E111D] text-slate-400 border-white/[0.08] hover:border-emerald-500/50 hover:bg-emerald-500/[0.08] hover:text-emerald-300'
              }`}
            >
              <ArrowUpCircle className={`w-4 h-4 shrink-0 ${filterStatus === 'alugada' ? 'text-emerald-300' : 'text-slate-400'}`} />
              <span className={filterStatus === 'alugada' ? 'font-bold' : ''}>Alugadas</span>
              <span
                className={`text-xs font-bold px-2 py-0.5 rounded-full transition-all ${
                  filterStatus === 'alugada'
                    ? 'bg-emerald-500 text-slate-950 font-black'
                    : 'bg-[#161B2B] text-slate-400 border border-white/[0.06]'
                }`}
              >
                {kitnets.filter((k) => k.status === 'alugada').length}
              </span>
            </motion.button>

            {/* 4. Em Reforma */}
            <motion.button
              ref={registerItem('reforma')}
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => {
                setFilterStatus('reforma');
                scrollItemIntoView('reforma');
              }}
              className={`px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-xl font-semibold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 border ${
                filterStatus === 'reforma'
                  ? 'bg-gradient-to-r from-amber-500/25 via-amber-500/15 to-orange-500/20 text-amber-200 border-amber-400/90'
                  : 'bg-[#0E111D] text-slate-400 border-white/[0.08] hover:border-amber-500/50 hover:bg-amber-500/[0.08] hover:text-amber-300'
              }`}
            >
              <TrendingUp className={`w-4 h-4 shrink-0 ${filterStatus === 'reforma' ? 'text-amber-300' : 'text-slate-400'}`} />
              <span className={filterStatus === 'reforma' ? 'font-bold' : ''}>Em Reforma</span>
              <span
                className={`text-xs font-bold px-2 py-0.5 rounded-full transition-all ${
                  filterStatus === 'reforma'
                    ? 'bg-amber-500 text-slate-950 font-black'
                    : 'bg-[#161B2B] text-slate-400 border border-white/[0.06]'
                }`}
              >
                {kitnets.filter((k) => k.status === 'reforma').length}
              </span>
            </motion.button>
          </div>

          {/* Search Input */}
          <div className="relative w-full sm:w-72 shrink-0">
            <Search className="w-4 h-4 text-[#94A3B8] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Buscar unidade, endereço..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-8 py-2 bg-[#0C0F1D] border border-white/[0.08] focus:border-[#8B5CF6] rounded-xl text-xs text-white placeholder-[#64748B] outline-none transition-colors"
            />
            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#94A3B8] hover:text-white p-1 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Units List matching Image 2 */}
      <div className="space-y-4">
        {filteredKitnets.length === 0 ? (
          <EmptyState
            icon={<KitnetIcon size={32} color="#0EA5E9" className="mx-auto" />}
            title="Nenhuma kitnet encontrada"
            description="Cadastre uma nova unidade ou altere o filtro de busca."
            actionLabel="Adicionar Unidade"
            onAction={() => setShowNewKitnetModal(true)}
            actionIcon={<Plus className="w-4 h-4" />}
            category="kitnets"
          />
        ) : (
          filteredKitnets.map((kitnet, index) => {
            const isSelected = selectedKitnetId === kitnet.id;
            const contract =
              kitnetContracts.find((c) => c.kitnetId === kitnet.id && c.status === 'ativo') ||
              kitnetContracts.find((c) => c.kitnetId === kitnet.id);
            const t = kitnetTenants.find((item) => item.id === contract?.tenantId);

            return (
              <KitnetCardItem
                key={kitnet.id}
                kitnet={kitnet}
                index={index}
                isSelected={isSelected}
                activeContract={contract}
                tenant={t}
                activeSubTab={activeSubTab}
                setActiveSubTab={setActiveSubTab}
                onToggleSelect={() => setSelectedKitnetId(isSelected ? null : kitnet.id)}
                duplicateKitnet={duplicateKitnet}
                handleOpenEditModal={(k) => setKitnetToEdit(k)}
                setKitnetToDelete={(k) => setKitnetToDelete(k)}
                handleOpenNewContract={handleOpenNewContract}
                setKitnetToTerminate={(data) => setKitnetToTerminate(data)}
                setShowCompareModal={setShowCompareModal}
                onOpenWhatsApp={onOpenWhatsApp}
                handleSendKitnetWhatsApp={handleSendKitnetWhatsApp}
                onGenerateDocument={onGenerateDocument}
                setRenewForm={setRenewForm}
                setShowRenewModal={setShowRenewModal}
                setShowAdjustmentModal={setShowAdjustmentModal}
                setShowPaymentModal={setShowPaymentModal}
                setSelectedPhotoPreview={setSelectedPhotoPreview}
                onOpenClientProfile={onOpenClientProfile}
              />
            );
          })
        )}
      </div>

      {/* Modals */}
      <PhotoZoomPreviewModal
        photoPreview={selectedPhotoPreview}
        onClose={() => setSelectedPhotoPreview(null)}
      />

      <EditKitnetModal
        kitnetToEdit={kitnetToEdit}
        kitnetContracts={kitnetContracts}
        kitnetTenants={kitnetTenants}
        onClose={() => setKitnetToEdit(null)}
        onSave={handleSaveEditKitnet}
      />

      <DeleteKitnetModal
        kitnetToDelete={kitnetToDelete}
        kitnetContracts={kitnetContracts}
        onClose={() => setKitnetToDelete(null)}
        onConfirm={handleConfirmDeleteKitnet}
      />

      <TerminateKitnetModal
        kitnetToTerminate={kitnetToTerminate}
        onClose={() => setKitnetToTerminate(null)}
        onConfirm={handleConfirmTerminate}
      />

      <NewKitnetContractModal
        isOpen={showNewContractModal}
        selectedKitnet={selectedKitnet}
        kitnetTenants={kitnetTenants}
        onClose={() => setShowNewContractModal(false)}
        onSubmit={handleCreateContractSubmit}
      />

      <CadastroKitnetWizardModal
        isOpen={showNewKitnetModal}
        onClose={() => setShowNewKitnetModal(false)}
        onSuccess={(newKitnetId, contractDetails) => {
          setSelectedKitnetId(newKitnetId);
          setActiveSubTab('geral');
          if (contractDetails) {
            setNewContractSuccessData(contractDetails);
          }
        }}
      />

      <KitnetPaymentModal
        paymentData={showPaymentModal}
        onClose={() => setShowPaymentModal(null)}
        onConfirm={(contractId, installmentId) => {
          payKitnetInstallment(contractId, installmentId);
          setShowPaymentModal(null);
        }}
      />

      {selectedKitnet && (
        <ComparadorVistoriaModal
          isOpen={showCompareModal}
          onClose={() => setShowCompareModal(false)}
          assetType="kitnet"
          kitnet={selectedKitnet}
        />
      )}

      {showAdjustmentModal && selectedKitnet && activeContract && (
        <RentAdjustmentModal
          isOpen={showAdjustmentModal}
          contractId={activeContract.id}
          currentMonthlyValue={activeContract.rentValue}
          type="kitnet"
          identifier={`${selectedKitnet.name} (Unid. ${selectedKitnet.number})`}
          tenantName={tenant?.fullName || 'Inquilino'}
          onClose={() => setShowAdjustmentModal(false)}
        />
      )}

      <KitnetContractSuccessModal
        data={newContractSuccessData}
        settings={settings}
        onClose={() => setNewContractSuccessData(null)}
      />

      <RenewKitnetContractModal
        isOpen={showRenewModal}
        selectedKitnet={selectedKitnet}
        activeContract={activeContract}
        tenant={tenant}
        onClose={() => setShowRenewModal(false)}
        onConfirm={handleRenewContractSubmit}
      />
    </div>
  );
});
