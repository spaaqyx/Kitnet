import React, { useState, useRef, useEffect } from 'react';
import {
  Calendar,
  Clock,
  Gauge,
  FileText,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Upload,
  Link2,
  Copy,
  Check,
  RotateCcw,
  ShieldCheck,
  ArrowDown,
  ArrowUp,
  Sun,
  Moon,
} from 'lucide-react';
import { NumericInput } from '../../../NumericInput';
import {
  MotoInspectionItemStatus,
  MotoFuelLevel,
  MotoInspectionChecklist,
  MotoDeliveryInspection,
} from '../../../../types';
import { formatDate } from '../../../../utils/formatters';
import {
  IconPneuDianteiro,
  IconPneuTraseiro,
  IconFreioDianteiro,
  IconFreioTraseiro,
  IconFarolLanternas,
  IconSetas,
  IconBuzina,
  IconRetrovisores,
  IconAssentoBanco,
  IconPinturaLataria,
  IconCapacete,
  IconCapaChuva,
  IconSuporteCelular,
  IconBauBauleto,
  IconChaveReserva,
  IconOutros,
  IconCombustivel,
  IconStatusBom,
  IconStatusRegular,
  IconStatusRuim,
  IconMagicWand,
} from './inspectionIcons';

interface NewMotoStepDeliveryInspectionProps {
  form: any;
  setForm: React.Dispatch<React.SetStateAction<any>>;
  selectedMoto: any;
}

interface ChecklistItemMeta {
  key: keyof MotoInspectionChecklist;
  label: string;
  category: string;
  IconComponent: React.FC<{ className?: string }>;
  defaultObsPlaceholder: string;
  quickSuggestions: string[];
}

const CHECKLIST_ITEMS_CONFIG: ChecklistItemMeta[] = [
  {
    key: 'pneuDianteiro',
    label: 'Pneu Dianteiro',
    category: 'Rodagem & Aderência',
    IconComponent: IconPneuDianteiro,
    defaultObsPlaceholder: 'Ex: Novo / 80% vida útil / Calibrado',
    quickSuggestions: ['Novo (100%)', 'Sem avarias', 'Calibrado', 'Desgaste leve'],
  },
  {
    key: 'pneuTraseiro',
    label: 'Pneu Traseiro',
    category: 'Rodagem & Aderência',
    IconComponent: IconPneuTraseiro,
    defaultObsPlaceholder: 'Ex: Bom estado / Ranhuras perfeitas',
    quickSuggestions: ['Novo (100%)', 'Sem avarias', 'Calibrado', 'Desgaste leve'],
  },
  {
    key: 'freioDianteiro',
    label: 'Freio Dianteiro',
    category: 'Sistema de Frenagem',
    IconComponent: IconFreioDianteiro,
    defaultObsPlaceholder: 'Ex: Pastilhas novas / Disco ventilado ok',
    quickSuggestions: ['Pastilhas novas', 'Disco perfeito', 'Revisado', 'Eficiência 100%'],
  },
  {
    key: 'freioTraseiro',
    label: 'Freio Traseiro',
    category: 'Sistema de Frenagem',
    IconComponent: IconFreioTraseiro,
    defaultObsPlaceholder: 'Ex: Lona regulada / Resposta imediata',
    quickSuggestions: ['Lona regulada', 'Sem chiados', 'Revisado', 'Eficiência 100%'],
  },
  {
    key: 'farolLanternas',
    label: 'Farol e Lanternas',
    category: 'Iluminação & Visibilidade',
    IconComponent: IconFarolLanternas,
    defaultObsPlaceholder: 'Ex: Luz alta e baixa operando perfeitamente',
    quickSuggestions: ['Alta e baixa 100%', 'Lente cristalina', 'LED operante'],
  },
  {
    key: 'setas',
    label: 'Setas / Piscas (D / T)',
    category: 'Sinalização Dinâmica',
    IconComponent: IconSetas,
    defaultObsPlaceholder: 'Ex: 4 setas piscando na frequência correta',
    quickSuggestions: ['Todas 4 operantes', 'Lentes intactas', 'Relé calibrado'],
  },
  {
    key: 'buzina',
    label: 'Buzina',
    category: 'Segurança Sonora',
    IconComponent: IconBuzina,
    defaultObsPlaceholder: 'Ex: Som limpo, alto e audível',
    quickSuggestions: ['Som alto e limpo', 'Acionamento macio', 'Operante'],
  },
  {
    key: 'retrovisores',
    label: 'Retrovisores',
    category: 'Campo de Visão',
    IconComponent: IconRetrovisores,
    defaultObsPlaceholder: 'Ex: Par original instalado, sem trincas',
    quickSuggestions: ['Par original sem trincas', 'Ajuste firme', 'Espelhos limpos'],
  },
  {
    key: 'assentoBanco',
    label: 'Assento / Banco',
    category: 'Ergonomia & Conforto',
    IconComponent: IconAssentoBanco,
    defaultObsPlaceholder: 'Ex: Capa original intacta, trava funcionando',
    quickSuggestions: ['Sem rasgos ou furos', 'Trava funcionando', 'Espuma firme'],
  },
  {
    key: 'pinturaLataria',
    label: 'Pintura & Carenagem',
    category: 'Estética & Lataria',
    IconComponent: IconPinturaLataria,
    defaultObsPlaceholder: 'Ex: Polida, sem riscos profundos ou amassados',
    quickSuggestions: ['Polida sem riscos', 'Carenagens firmes', 'Pequeno risco estético'],
  },
];

const FUEL_LEVELS_CONFIG: Array<{
  value: MotoFuelLevel;
  label: string;
  percent: number;
  colorClass: string;
}> = [
  { value: 'reserva', label: 'Reserva', percent: 12, colorClass: 'from-rose-500 to-amber-500' },
  { value: '1/4', label: '1/4', percent: 25, colorClass: 'from-amber-500 to-yellow-500' },
  { value: '1/2', label: '1/2', percent: 50, colorClass: 'from-yellow-500 to-emerald-400' },
  { value: '3/4', label: '3/4', percent: 75, colorClass: 'from-emerald-400 to-emerald-500' },
  { value: 'cheio', label: 'Cheio', percent: 100, colorClass: 'from-emerald-400 to-teal-400' },
];

const ACCESSORIES_CONFIG = [
  { key: 'capacete', label: 'Capacete de Moto', Icon: IconCapacete, desc: 'Com viseira regulamentada' },
  { key: 'capaChuva', label: 'Capa de Chuva', Icon: IconCapaChuva, desc: 'Impermeável completa' },
  { key: 'suporteCelular', label: 'Suporte Celular', Icon: IconSuporteCelular, desc: 'Fixação em guidão' },
  { key: 'bauBauleto', label: 'Baú / Bauleto', Icon: IconBauBauleto, desc: 'Com chave e suporte' },
  { key: 'chaveReserva', label: 'Chave Reserva', Icon: IconChaveReserva, desc: 'Ignição e tanque' },
  { key: 'outros', label: 'Outros Acessórios', Icon: IconOutros, desc: 'Item customizável' },
];

export const NewMotoStepDeliveryInspection: React.FC<NewMotoStepDeliveryInspectionProps> = ({
  form,
  setForm,
  selectedMoto,
}) => {
  const [paperTheme, setPaperTheme] = useState<'paper' | 'dark'>('paper');
  const [copiedNotification, setCopiedNotification] = useState(false);
  const [magicFeedback, setMagicFeedback] = useState(false);

  const checklistRef = useRef<HTMLDivElement>(null);
  const termoRef = useRef<HTMLDivElement>(null);

  // Garante que inspection exista no form com dados canônicos
  const inspection: MotoDeliveryInspection = form.inspection || {
    date: form.startDate || new Date().toISOString().split('T')[0],
    time: '10:00',
    initialKm: Number(form.currentKm || selectedMoto?.currentKm || 0),
    checklist: {
      pneuDianteiro: { checked: true, status: 'bom', notes: '' },
      pneuTraseiro: { checked: true, status: 'bom', notes: '' },
      freioDianteiro: { checked: true, status: 'bom', notes: '' },
      freioTraseiro: { checked: true, status: 'bom', notes: '' },
      farolLanternas: { checked: true, status: 'bom', notes: '' },
      setas: { checked: true, status: 'bom', notes: '' },
      buzina: { checked: true, status: 'bom', notes: '' },
      retrovisores: { checked: true, status: 'bom', notes: '' },
      assentoBanco: { checked: true, status: 'bom', notes: '' },
      pinturaLataria: { checked: true, status: 'bom', notes: '' },
    },
    fuelLevel: 'cheio',
    accessories: {
      capacete: true,
      capaChuva: true,
      suporteCelular: true,
      bauBauleto: false,
      chaveReserva: true,
      outros: false,
      outrosDescricao: '',
    },
    damagesDescription:
      'Nenhuma avaria estrutural identificada na vistoria inicial. Veículo entregue revisado, lavado e em perfeitas condições operacionais.',
    videoType: 'link',
    videoUrl: '',
    videoFileName: '',
  };

  // Garante sincronização bidirecional do inspection no formulário pai para as etapas seguintes
  useEffect(() => {
    setForm((prev: any) => {
      if (prev.inspection) return prev;
      return {
        ...prev,
        inspection,
        inspectionDate: inspection.date,
        inspectionTime: inspection.time,
        currentKm: inspection.initialKm,
      };
    });
  }, [setForm]);

  const updateInspection = (updater: (prev: MotoDeliveryInspection) => MotoDeliveryInspection) => {
    setForm((prev: any) => {
      const current = prev.inspection || inspection;
      const updated = updater(current);
      return {
        ...prev,
        inspection: updated,
        inspectionDate: updated.date,
        inspectionTime: updated.time,
        currentKm: updated.initialKm,
      };
    });
  };

  const handleChecklistToggle = (key: keyof MotoInspectionChecklist) => {
    updateInspection((prev) => ({
      ...prev,
      checklist: {
        ...prev.checklist,
        [key]: {
          ...prev.checklist[key],
          checked: !prev.checklist[key].checked,
        },
      },
    }));
  };

  const handleChecklistStatus = (
    key: keyof MotoInspectionChecklist,
    status: MotoInspectionItemStatus
  ) => {
    updateInspection((prev) => ({
      ...prev,
      checklist: {
        ...prev.checklist,
        [key]: {
          ...prev.checklist[key],
          status,
          checked: true,
        },
      },
    }));
  };

  const handleChecklistObs = (key: keyof MotoInspectionChecklist, notes: string) => {
    updateInspection((prev) => ({
      ...prev,
      checklist: {
        ...prev.checklist,
        [key]: {
          ...prev.checklist[key],
          notes,
        },
      },
    }));
  };

  const handleFuelSelect = (level: MotoFuelLevel) => {
    updateInspection((prev) => ({
      ...prev,
      fuelLevel: level,
    }));
  };

  const handleAccessoryToggle = (key: keyof typeof inspection.accessories) => {
    updateInspection((prev) => ({
      ...prev,
      accessories: {
        ...prev.accessories,
        [key]: !prev.accessories[key as 'capacete'],
      },
    }));
  };

  const handleMarkAllGood = () => {
    updateInspection((prev) => {
      const newChecklist = { ...prev.checklist };
      CHECKLIST_ITEMS_CONFIG.forEach(({ key }) => {
        newChecklist[key] = {
          checked: true,
          status: 'bom',
          notes: prev.checklist[key]?.notes || 'Em perfeito estado de uso',
        };
      });
      return {
        ...prev,
        checklist: newChecklist,
        fuelLevel: 'cheio',
      };
    });
    setMagicFeedback(true);
    setTimeout(() => setMagicFeedback(false), 2000);
  };

  const handleResetChecklist = () => {
    updateInspection((prev) => {
      const newChecklist = { ...prev.checklist };
      CHECKLIST_ITEMS_CONFIG.forEach(({ key }) => {
        newChecklist[key] = {
          checked: true,
          status: 'bom',
          notes: '',
        };
      });
      return {
        ...prev,
        checklist: newChecklist,
      };
    });
  };

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      updateInspection((prev) => ({
        ...prev,
        videoType: 'upload',
        videoUrl: base64,
        videoFileName: file.name,
      }));
    };
    reader.readAsDataURL(file);
  };

  const handleCopyTermSummary = () => {
    const lines: string[] = [
      '--- ANEXO I: TERMO DE VISTORIA E RETIRADA ---',
      `Veículo: ${selectedMoto?.brand || ''} ${selectedMoto?.model || ''} - Placa: ${selectedMoto?.plate || 'SEM PLACA'}`,
      `Data: ${formatDate(inspection.date)} às ${inspection.time || '10:00'} | Km Inicial: ${Number(inspection.initialKm || 0).toLocaleString('pt-BR')} km`,
      `Combustível: ${inspection.fuelLevel.toUpperCase()}`,
      'Itens Vistoriados:',
      ...CHECKLIST_ITEMS_CONFIG.map(({ key, label }) => {
        const item = inspection.checklist[key];
        const status = item.status === 'bom' ? 'BOM' : item.status === 'regular' ? 'REGULAR' : 'RUIM';
        return `- ${label}: [${status}] ${item.notes ? `(${item.notes})` : ''}`;
      }),
      'Acessórios:',
      inspection.accessories.capacete ? '- Capacete: SIM' : '',
      inspection.accessories.capaChuva ? '- Capa de Chuva: SIM' : '',
      inspection.accessories.suporteCelular ? '- Suporte Celular: SIM' : '',
      inspection.accessories.bauBauleto ? '- Baú / Bauleto: SIM' : '',
      inspection.accessories.chaveReserva ? '- Chave Reserva: SIM' : '',
      inspection.accessories.outros ? `- Outros: ${inspection.accessories.outrosDescricao || 'SIM'}` : '',
      `Avarias: ${inspection.damagesDescription || 'Nenhuma avaria'}`,
    ].filter(Boolean);

    navigator.clipboard.writeText(lines.join('\n'));
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 2200);
  };

  const scrollToTermo = () => {
    termoRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const scrollToForm = () => {
    checklistRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  // Contagem de itens
  const verifiedCount = CHECKLIST_ITEMS_CONFIG.filter((c) => inspection.checklist[c.key]?.checked).length;
  const goodCount = CHECKLIST_ITEMS_CONFIG.filter((c) => inspection.checklist[c.key]?.status === 'bom').length;
  const currentFuelConfig = FUEL_LEVELS_CONFIG.find((f) => f.value === inspection.fuelLevel) || FUEL_LEVELS_CONFIG[4];

  return (
    <div className="space-y-4 font-sans text-slate-100" id="moto-delivery-inspection-step" ref={checklistRef}>
      {/* BARRA SUPERIOR: CABEÇALHO UNIFICADO COM INDICADORES */}
      <div className="p-3.5 sm:p-4 rounded-2xl bg-[#090C15] border border-white/[0.08] flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-500 text-slate-950 flex items-center justify-center font-black shrink-0">
            <ShieldCheck className="w-5 h-5 text-slate-950" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-white font-bold text-sm sm:text-base leading-tight">
                Vistoria de Entrega & Retirada (Anexo I)
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                {goodCount === 10 ? '✨ 10/10 100% Apto' : `${verifiedCount}/10 Conferidos`}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Configure o checklist à esquerda e analise o documento oficial em tempo real na mesma tela.
            </p>
          </div>
        </div>

        {/* BOTÕES DE ATALHO RÁPIDO PARA MOBILE E AÇÕES GLOBAIS */}
        <div className="flex items-center gap-2 flex-wrap self-start sm:self-auto">
          {/* Botão Mágico: Marcar Todos como Bom */}
          <button
            type="button"
            onClick={handleMarkAllGood}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all duration-200 cursor-pointer active:scale-95 ${
              magicFeedback
                ? 'bg-emerald-400 text-slate-950 scale-105'
                : 'bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30'
            }`}
            title="Preencher todos os 10 itens como Bom com 1 clique"
          >
            <IconMagicWand className="w-3.5 h-3.5" />
            <span>{magicFeedback ? 'Todos Marcados como Bom!' : 'Tudo 100% Bom'}</span>
          </button>

          {/* Atalho de rolagem para o Termo no mobile */}
          <button
            type="button"
            onClick={scrollToTermo}
            className="lg:hidden px-3 py-1.5 rounded-xl text-xs font-semibold bg-white/[0.08] hover:bg-white/[0.12] text-slate-200 border border-white/[0.1] flex items-center gap-1.5 cursor-pointer active:scale-95 transition-all"
          >
            <FileText className="w-3.5 h-3.5 text-emerald-400" />
            <span>Ver Termo Abaixo</span>
            <ArrowDown className="w-3 h-3 text-slate-400" />
          </button>
        </div>
      </div>

      {/* GRID PRINCIPAL: FORMULÁRIO INTERATIVO À ESQUERDA + TERMO OFICIAL NA MESMA BOX À DIREITA */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* ================= COLUNA ESQUERDA: CONTROLES & CHECKLIST (lg:col-span-7) ================= */}
        <div className="lg:col-span-7 space-y-4">
          {/* BLOCO 1: IDENTIFICAÇÃO BÁSICA OBRIGATÓRIA (DATA, HORA, KM INICIAL) */}
          <div className="p-3.5 sm:p-4 rounded-2xl bg-[#0C0E18] border border-white/[0.08] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                1. Data, Hora & Quilometragem Inicial
              </span>
              <span className="text-[10px] font-mono text-slate-400 bg-white/[0.04] px-2 py-0.5 rounded-md border border-white/[0.06]">
                {selectedMoto?.plate || 'SEM PLACA'} • {selectedMoto?.brand} {selectedMoto?.model}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* DATA */}
              <div className="space-y-1">
                <label className="text-[11px] text-slate-300 font-medium flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-emerald-400" />
                  <span>Data da Vistoria</span>
                  <span className="text-rose-400">*</span>
                </label>
                <input
                  type="date"
                  value={inspection.date}
                  onChange={(e) => updateInspection((prev) => ({ ...prev, date: e.target.value }))}
                  className="w-full h-10 px-3 rounded-xl bg-[#07080E] border border-white/[0.1] text-white text-xs focus:border-emerald-500 focus:outline-none transition-colors"
                  required
                />
              </div>

              {/* HORA */}
              <div className="space-y-1">
                <label className="text-[11px] text-slate-300 font-medium flex items-center gap-1">
                  <Clock className="w-3 h-3 text-emerald-400" />
                  <span>Hora da Retirada</span>
                  <span className="text-rose-400">*</span>
                </label>
                <input
                  type="time"
                  value={inspection.time}
                  onChange={(e) => updateInspection((prev) => ({ ...prev, time: e.target.value }))}
                  className="w-full h-10 px-3 rounded-xl bg-[#07080E] border border-white/[0.1] text-white text-xs focus:border-emerald-500 focus:outline-none transition-colors"
                  required
                />
              </div>

              {/* KM INICIAL */}
              <div className="space-y-1">
                <label className="text-[11px] text-slate-300 font-medium flex items-center gap-1">
                  <Gauge className="w-3 h-3 text-emerald-400" />
                  <span>Km Inicial (Odômetro)</span>
                  <span className="text-rose-400">*</span>
                </label>
                <NumericInput
                  mode="integer"
                  min={0}
                  value={inspection.initialKm || null}
                  onChange={(val) =>
                    updateInspection((prev) => ({ ...prev, initialKm: val }))
                  }
                  placeholder="Ex: 162949"
                  className="w-full h-10 px-3 rounded-xl bg-[#07080E] border border-white/[0.1] text-white text-xs font-mono font-bold focus:border-emerald-500 focus:outline-none transition-colors"
                  required
                />
              </div>
            </div>
          </div>

          {/* BLOCO 2: CHECKLIST DA MOTOCICLETA COM DESIGN REFINADO & BOTÕES ANIMADOS */}
          <div className="p-3.5 sm:p-4 rounded-2xl bg-[#0C0E18] border border-white/[0.08] space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  2. Checklist de Inspeção Física (10 Componentes)
                </span>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Clique no status correspondente e utilize sugestões rápidas para agilizar o preenchimento.
                </p>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={handleResetChecklist}
                  className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-white/[0.05] transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Limpar Obs</span>
                </button>
              </div>
            </div>

            {/* LISTA DE CARDS DE CHECKLIST */}
            <div className="space-y-2.5">
              {CHECKLIST_ITEMS_CONFIG.map(({ key, label, category, IconComponent, defaultObsPlaceholder, quickSuggestions }) => {
                const item = inspection.checklist[key];
                const isBom = item.status === 'bom';
                const isRegular = item.status === 'regular';
                const isRuim = item.status === 'ruim';

                return (
                  <div
                    key={key}
                    className={`p-3 rounded-2xl border transition-all duration-200 ${
                      item.checked
                        ? isBom
                          ? 'bg-[#080B12] border-emerald-500/25 shadow-sm'
                          : isRegular
                          ? 'bg-[#0B090F] border-amber-500/30 shadow-sm'
                          : 'bg-[#0E080B] border-rose-500/30 shadow-sm'
                        : 'bg-[#080910]/60 border-white/[0.04] opacity-80'
                    }`}
                  >
                    <div className="flex flex-col gap-2.5">
                      {/* Linha 1: Ícone SVG + Nome + Botões Animados de Status */}
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        {/* Identificação do Item */}
                        <div className="flex items-center gap-2.5 min-w-[170px]">
                          <button
                            type="button"
                            onClick={() => handleChecklistToggle(key)}
                            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-200 cursor-pointer active:scale-90 ${
                              isBom
                                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 shadow-xs'
                                : isRegular
                                ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30 shadow-xs'
                                : 'bg-rose-500/15 text-rose-400 border border-rose-500/30 shadow-xs'
                            }`}
                            title="Alternar conferência deste item"
                          >
                            <IconComponent className="w-5 h-5" />
                          </button>

                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-bold text-white tracking-wide">
                                {label}
                              </span>
                              <span
                                className={`w-1.5 h-1.5 rounded-full ${
                                  isBom ? 'bg-emerald-400' : isRegular ? 'bg-amber-400' : 'bg-rose-400'
                                }`}
                              />
                            </div>
                            <span className="text-[10px] text-slate-400 block">
                              {category}
                            </span>
                          </div>
                        </div>

                        {/* BOTÕES PRÓPRIOS & ANIMADOS: BOM / REGULAR / RUIM */}
                        <div className="flex items-center gap-1.5 bg-[#05060B] p-1 rounded-xl border border-white/[0.08] shrink-0">
                          {/* Botão BOM */}
                          <button
                            type="button"
                            onClick={() => handleChecklistStatus(key, 'bom')}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all duration-150 cursor-pointer active:scale-90 ${
                              isBom
                                ? 'bg-emerald-500 text-slate-950 scale-[1.02]'
                                : 'text-slate-400 hover:text-emerald-300 hover:bg-emerald-500/10'
                            }`}
                          >
                            <IconStatusBom className={`w-3.5 h-3.5 ${isBom ? 'text-slate-950' : 'text-emerald-400'}`} />
                            <span>Bom</span>
                          </button>

                          {/* Botão REGULAR */}
                          <button
                            type="button"
                            onClick={() => handleChecklistStatus(key, 'regular')}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all duration-150 cursor-pointer active:scale-90 ${
                              isRegular
                                ? 'bg-amber-500 text-slate-950 scale-[1.02]'
                                : 'text-slate-400 hover:text-amber-300 hover:bg-amber-500/10'
                            }`}
                          >
                            <IconStatusRegular className={`w-3.5 h-3.5 ${isRegular ? 'text-slate-950' : 'text-amber-400'}`} />
                            <span>Regular</span>
                          </button>

                          {/* Botão RUIM */}
                          <button
                            type="button"
                            onClick={() => handleChecklistStatus(key, 'ruim')}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all duration-150 cursor-pointer active:scale-90 ${
                              isRuim
                                ? 'bg-rose-500 text-white scale-[1.02]'
                                : 'text-slate-400 hover:text-rose-300 hover:bg-rose-500/10'
                            }`}
                          >
                            <IconStatusRuim className={`w-3.5 h-3.5 ${isRuim ? 'text-white' : 'text-rose-400'}`} />
                            <span>Ruim</span>
                          </button>
                        </div>
                      </div>

                      {/* Linha 2: Campo de Observação e Chips Rápidos de Sugestão */}
                      <div className="space-y-1.5 pt-1 border-t border-white/[0.04]">
                        <input
                          type="text"
                          value={item.notes || ''}
                          onChange={(e) => handleChecklistObs(key, e.target.value)}
                          placeholder={defaultObsPlaceholder}
                          className="w-full h-8 px-3 rounded-xl bg-[#06070D] border border-white/[0.08] text-white text-[11px] placeholder:text-slate-600 focus:border-emerald-500 focus:outline-none transition-colors"
                        />

                        {/* Chips Rápidos de Sugestão (1 clique preenche) */}
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[10px] text-slate-500">Sugestões:</span>
                          {quickSuggestions.map((sug, idx) => (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => handleChecklistObs(key, sug)}
                              className="text-[10px] px-2 py-0.5 rounded-md bg-white/[0.04] hover:bg-emerald-500/15 hover:text-emerald-300 text-slate-400 border border-white/[0.05] transition-all cursor-pointer active:scale-95"
                            >
                              + {sug}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* BLOCO 3: COMBUSTÍVEL ANIMADO & ACESSÓRIOS COM ÍCONES SVG */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* MEDIDOR DE COMBUSTÍVEL COM DESIGN ANIMADO */}
            <div className="p-3.5 sm:p-4 rounded-2xl bg-[#0C0E18] border border-white/[0.08] space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <IconCombustivel className="w-4 h-4 text-emerald-400" />
                  3. Nível de Combustível
                </span>
                <span className="text-[11px] font-bold font-mono text-emerald-300 uppercase">
                  {currentFuelConfig.label} ({currentFuelConfig.percent}%)
                </span>
              </div>

              {/* Barra Animada de Nível de Combustível */}
              <div className="w-full h-3 rounded-full bg-[#05060A] border border-white/[0.08] overflow-hidden p-0.5 relative">
                <div
                  className={`h-full rounded-full bg-gradient-to-r ${currentFuelConfig.colorClass} transition-all duration-300`}
                  style={{ width: `${currentFuelConfig.percent}%` }}
                />
              </div>

              {/* Botoes de Seleção de Combustível */}
              <div className="grid grid-cols-5 gap-1 min-[400px]:gap-1.5">
                {FUEL_LEVELS_CONFIG.map(({ value, label }) => {
                  const isSelected = inspection.fuelLevel === value;
                  return (
                    <button
                      key={value}
                      type="button"
                      onClick={() => handleFuelSelect(value)}
                      className={`h-11 px-0.5 min-[400px]:px-1 rounded-xl text-[10px] min-[400px]:text-xs font-bold transition-all duration-150 flex flex-col items-center justify-center cursor-pointer border active:scale-95 ${
                        isSelected
                          ? 'bg-emerald-500 text-slate-950 border-emerald-400 scale-[1.03]'
                          : 'bg-[#07080E] text-slate-300 border-white/[0.08] hover:bg-[#10131F] hover:text-white'
                      }`}
                    >
                      <span className="text-[10px] font-mono opacity-80 leading-none">
                        {isSelected ? '[ X ]' : '[   ]'}
                      </span>
                      <span className="mt-0.5 leading-none">{label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* ACESSÓRIOS ENTREGUES COM CARDS SVG */}
            <div className="p-3.5 sm:p-4 rounded-2xl bg-[#0C0E18] border border-white/[0.08] space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  4. Acessórios Entregues
                </span>
                <span className="text-[10px] text-emerald-400 font-mono">
                  Sincronizado no Anexo I
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                {ACCESSORIES_CONFIG.map(({ key, label, Icon, desc }) => {
                  const checked = Boolean(inspection.accessories[key as 'capacete']);
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => handleAccessoryToggle(key as any)}
                      className={`p-2 rounded-xl border text-left flex items-center gap-2 transition-all duration-150 cursor-pointer active:scale-95 select-none ${
                        checked
                          ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300 shadow-xs'
                          : 'bg-[#07080E] border-white/[0.06] text-slate-400 hover:text-slate-200 hover:bg-[#0E111C]'
                      }`}
                    >
                      <div
                        className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                          checked ? 'bg-emerald-500 text-slate-950 font-bold' : 'bg-white/[0.05] text-slate-400'
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <span className="text-[11px] font-bold block truncate leading-tight">
                          {label}
                        </span>
                        <span className="text-[9px] text-slate-400 block truncate leading-none">
                          {checked ? 'Entregue [X]' : 'Não entregue'}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Se "outros" estiver marcado */}
              {inspection.accessories.outros && (
                <div className="pt-1 animate-fadeIn">
                  <input
                    type="text"
                    value={inspection.accessories.outrosDescricao || ''}
                    onChange={(e) =>
                      updateInspection((prev) => ({
                        ...prev,
                        accessories: { ...prev.accessories, outrosDescricao: e.target.value },
                      }))
                    }
                    placeholder="Especifique outros itens (Ex: Trava de disco, luvas...)"
                    className="w-full h-8 px-3 rounded-xl bg-[#07080E] border border-emerald-500/40 text-white text-xs focus:border-emerald-500 focus:outline-none transition-colors"
                  />
                </div>
              )}
            </div>
          </div>

          {/* BLOCO 4: AVARIAS EXISTENTES & VÍDEO DA VISTORIA */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* AVARIAS EXISTENTES */}
            <div className="p-3.5 sm:p-4 rounded-2xl bg-[#0C0E18] border border-white/[0.08] space-y-2">
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                5. Descrição de Avarias Existentes
              </span>
              <p className="text-[11px] text-slate-400">
                Garante proteção mútua no ato de devolução ou sinistros futuros:
              </p>

              <textarea
                rows={3}
                value={inspection.damagesDescription}
                onChange={(e) =>
                  updateInspection((prev) => ({ ...prev, damagesDescription: e.target.value }))
                }
                placeholder="Ex: Nenhuma avaria estrutural. Leve arranhão na manopla direita..."
                className="w-full p-2.5 rounded-xl bg-[#07080E] border border-white/[0.1] text-white text-xs focus:border-emerald-500 focus:outline-none transition-colors leading-relaxed resize-none"
              />
            </div>

            {/* VÍDEO 360° */}
            <div className="p-3.5 sm:p-4 rounded-2xl bg-[#0C0E18] border border-white/[0.08] space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Link2 className="w-3.5 h-3.5 text-indigo-400" />
                  6. Vídeo Probatório (360°)
                </span>
                <span className="text-[10px] text-indigo-300 font-mono">Prova jurídica</span>
              </div>

              <div className="grid grid-cols-2 gap-1.5">
                <button
                  type="button"
                  onClick={() => updateInspection((prev) => ({ ...prev, videoType: 'link' }))}
                  className={`py-1.5 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                    inspection.videoType !== 'upload'
                      ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40'
                      : 'bg-[#07080E] text-slate-400 border-white/[0.06]'
                  }`}
                >
                  <Link2 className="w-3 h-3" />
                  <span>Link Nuvem</span>
                </button>
                <button
                  type="button"
                  onClick={() => updateInspection((prev) => ({ ...prev, videoType: 'upload' }))}
                  className={`py-1.5 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                    inspection.videoType === 'upload'
                      ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40'
                      : 'bg-[#07080E] text-slate-400 border-white/[0.06]'
                  }`}
                >
                  <Upload className="w-3 h-3" />
                  <span>Upload de Arquivo</span>
                </button>
              </div>

              {inspection.videoType === 'upload' ? (
                <label className="flex flex-col items-center justify-center p-2.5 rounded-xl border border-dashed border-indigo-500/30 bg-[#070810] hover:bg-[#0C0F1C] cursor-pointer transition-colors">
                  <Upload className="w-4 h-4 text-indigo-400 mb-1" />
                  <span className="text-xs font-semibold text-white truncate max-w-[200px]">
                    {inspection.videoFileName || 'Selecionar vídeo (MP4/MOV)'}
                  </span>
                  <input type="file" accept="video/*" onChange={handleVideoUpload} className="hidden" />
                </label>
              ) : (
                <input
                  type="url"
                  value={inspection.videoUrl || ''}
                  onChange={(e) => updateInspection((prev) => ({ ...prev, videoUrl: e.target.value }))}
                  placeholder="https://drive.google.com/... ou YouTube/WhatsApp"
                  className="w-full h-9 px-3 rounded-xl bg-[#07080E] border border-white/[0.1] text-white text-xs font-mono focus:border-indigo-500 focus:outline-none"
                />
              )}
            </div>
          </div>
        </div>

        {/* ================= COLUNA DIREITA: TERMO OFICIAL NA MESMA BOX (lg:col-span-5) ================= */}
        <div className="lg:col-span-5 space-y-3" id="termo-oficial-box" ref={termoRef}>
          {/* HEADER DA CAIXA DO TERMO */}
          <div className="p-3 rounded-2xl bg-[#0C0E18] border border-white/[0.08] flex items-center justify-between gap-2 shadow-md">
            <div className="flex items-center gap-2 min-w-0">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
              <div className="min-w-0">
                <span className="text-xs font-bold text-white block truncate">
                  Termo de Retirada (Anexo I)
                </span>
                <span className="text-[10px] text-slate-400 block truncate">
                  Atualização instantânea na mesma box
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              {/* Alternar Tema Papel / Noturno */}
              <button
                type="button"
                onClick={() => setPaperTheme(paperTheme === 'paper' ? 'dark' : 'paper')}
                className="p-1.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.1] text-slate-300 transition-colors cursor-pointer"
                title={paperTheme === 'paper' ? 'Ver em Modo Noturno' : 'Ver em Papel A4'}
              >
                {paperTheme === 'paper' ? <Moon className="w-3.5 h-3.5 text-amber-400" /> : <Sun className="w-3.5 h-3.5 text-amber-300" />}
              </button>

              {/* Copiar Resumo */}
              <button
                type="button"
                onClick={handleCopyTermSummary}
                className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 flex items-center gap-1 transition-all cursor-pointer active:scale-95"
                title="Copiar resumo textual para WhatsApp"
              >
                {copiedNotification ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-emerald-400" />}
                <span>{copiedNotification ? 'Copiado!' : 'Copiar'}</span>
              </button>

              {/* Botão de Subir para Checklist (no mobile) */}
              <button
                type="button"
                onClick={scrollToForm}
                className="lg:hidden p-1.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.1] text-slate-300 transition-colors cursor-pointer"
                title="Voltar ao checklist"
              >
                <ArrowUp className="w-3.5 h-3.5 text-emerald-400" />
              </button>
            </div>
          </div>

          {/* DOCUMENTO DO TERMO OFICIAL RENDERIZADO DIRETAMENTE NA MESMA BOX */}
          <div
            className={`rounded-2xl border p-4 sm:p-5 shadow-2xl transition-all duration-200 text-xs font-sans max-h-[640px] overflow-y-auto scrollbar-thin ${
              paperTheme === 'paper'
                ? 'bg-[#FDFBF7] text-slate-900 border-amber-200/60 shadow-black/40'
                : 'bg-[#07090F] text-slate-200 border-white/[0.12] shadow-black/80'
            }`}
          >
            {/* CABEÇALHO DO DOCUMENTO JURÍDICO */}
            <div className={`text-center pb-3 mb-3 border-b ${paperTheme === 'paper' ? 'border-slate-300' : 'border-white/[0.1]'}`}>
              <span className={`text-[9px] font-bold font-mono uppercase tracking-widest block ${paperTheme === 'paper' ? 'text-slate-500' : 'text-emerald-400'}`}>
                REPÚBLICA FEDERATIVA DO BRASIL • LOCAÇÃO DE MOTOS
              </span>
              <h4 className={`text-xs sm:text-sm font-black uppercase tracking-wide mt-1 ${paperTheme === 'paper' ? 'text-slate-950' : 'text-white'}`}>
                ANEXO I – TERMO DE VISTORIA E RETIRADA
              </h4>
              <p className={`text-[10px] italic mt-0.5 ${paperTheme === 'paper' ? 'text-slate-600' : 'text-slate-400'}`}>
                Parte integrante e indissociável do Contrato de Locação.
              </p>
            </div>

            {/* METADADOS DO VEÍCULO E RETIRADA */}
            <div className={`p-2.5 rounded-xl border mb-3 text-[11px] grid grid-cols-2 gap-2 ${paperTheme === 'paper' ? 'bg-slate-100/80 border-slate-300' : 'bg-white/[0.03] border-white/[0.08]'}`}>
              <div>
                <span className={`block text-[9px] uppercase font-bold ${paperTheme === 'paper' ? 'text-slate-500' : 'text-slate-400'}`}>
                  Data da Vistoria:
                </span>
                <strong className={paperTheme === 'paper' ? 'text-slate-900' : 'text-white'}>
                  {formatDate(inspection.date)}
                </strong>
              </div>
              <div>
                <span className={`block text-[9px] uppercase font-bold ${paperTheme === 'paper' ? 'text-slate-500' : 'text-slate-400'}`}>
                  Hora da Retirada:
                </span>
                <strong className={paperTheme === 'paper' ? 'text-slate-900' : 'text-white'}>
                  {inspection.time || '10:00'}
                </strong>
              </div>
              <div>
                <span className={`block text-[9px] uppercase font-bold ${paperTheme === 'paper' ? 'text-slate-500' : 'text-slate-400'}`}>
                  Quilometragem Inicial:
                </span>
                <strong className={paperTheme === 'paper' ? 'text-emerald-700 font-mono font-bold' : 'text-emerald-400 font-mono font-bold'}>
                  {Number(inspection.initialKm || 0).toLocaleString('pt-BR')} km
                </strong>
              </div>
              <div>
                <span className={`block text-[9px] uppercase font-bold ${paperTheme === 'paper' ? 'text-slate-500' : 'text-slate-400'}`}>
                  Veículo / Placa:
                </span>
                <strong className={paperTheme === 'paper' ? 'text-slate-900' : 'text-white'}>
                  {selectedMoto?.plate || 'SEM PLACA'} ({selectedMoto?.model || 'Moto'})
                </strong>
              </div>
            </div>

            {/* TABELA DE CHECKLIST FORMATADA DO TERMO */}
            <div className="space-y-1.5 mb-3">
              <span className={`text-[10px] font-black uppercase tracking-wider block ${paperTheme === 'paper' ? 'text-slate-900' : 'text-white'}`}>
                CONDIÇÕES GERAIS DA MOTOCICLETA:
              </span>
              <div className={`rounded-xl border overflow-hidden divide-y ${paperTheme === 'paper' ? 'border-slate-300 divide-slate-200 bg-white' : 'border-white/[0.08] divide-white/[0.05] bg-[#05060A]'}`}>
                {CHECKLIST_ITEMS_CONFIG.map(({ key, label }) => {
                  const item = inspection.checklist[key];
                  const isBom = item.status === 'bom';
                  const isRegular = item.status === 'regular';
                  const isRuim = item.status === 'ruim';

                  return (
                    <div key={key} className="px-2.5 py-1.5 flex items-center justify-between text-[10.5px] gap-2">
                      <div className="flex items-center gap-1.5 font-mono">
                        <span className={`font-bold ${isBom ? 'text-emerald-600' : isRegular ? 'text-amber-600' : 'text-rose-600'}`}>
                          {item.checked ? '[ X ]' : '[   ]'}
                        </span>
                        <span className={`font-medium font-sans ${paperTheme === 'paper' ? 'text-slate-800' : 'text-slate-200'}`}>
                          {label}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 font-mono text-[10px]">
                        <span className={isBom ? (paperTheme === 'paper' ? 'text-emerald-700 font-bold' : 'text-emerald-400 font-bold') : 'opacity-40'}>
                          ({isBom ? 'X' : ' '}) Bom
                        </span>
                        <span className={isRegular ? (paperTheme === 'paper' ? 'text-amber-700 font-bold' : 'text-amber-400 font-bold') : 'opacity-40'}>
                          ({isRegular ? 'X' : ' '}) Reg
                        </span>
                        <span className={isRuim ? (paperTheme === 'paper' ? 'text-rose-700 font-bold' : 'text-rose-400 font-bold') : 'opacity-40'}>
                          ({isRuim ? 'X' : ' '}) Ruim
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* COMBUSTÍVEL NO TERMO */}
            <div className={`p-2.5 rounded-xl border mb-3 ${paperTheme === 'paper' ? 'bg-slate-100/60 border-slate-300' : 'bg-white/[0.02] border-white/[0.06]'}`}>
              <span className={`text-[10px] font-black uppercase tracking-wider block mb-1 ${paperTheme === 'paper' ? 'text-slate-900' : 'text-white'}`}>
                NÍVEL DE COMBUSTÍVEL NA RETIRADA:
              </span>
              <div className="flex flex-wrap items-center gap-2.5 text-[10px] font-mono">
                {FUEL_LEVELS_CONFIG.map(({ value, label }) => {
                  const isSelected = inspection.fuelLevel === value;
                  return (
                    <span
                      key={value}
                      className={
                        isSelected
                          ? paperTheme === 'paper'
                            ? 'text-emerald-800 font-bold bg-emerald-100 px-1.5 py-0.5 rounded'
                            : 'text-emerald-400 font-bold bg-emerald-500/20 px-1.5 py-0.5 rounded'
                          : 'opacity-50'
                      }
                    >
                      [{isSelected ? ' X ' : '   '}] {label}
                    </span>
                  );
                })}
              </div>
            </div>

            {/* ACESSÓRIOS NO TERMO */}
            <div className={`p-2.5 rounded-xl border mb-3 ${paperTheme === 'paper' ? 'bg-slate-100/60 border-slate-300' : 'bg-white/[0.02] border-white/[0.06]'}`}>
              <span className={`text-[10px] font-black uppercase tracking-wider block mb-1 ${paperTheme === 'paper' ? 'text-slate-900' : 'text-white'}`}>
                ACESSÓRIOS ENTREGUES:
              </span>
              <div className="flex flex-wrap items-center gap-1.5 text-[10px] font-mono">
                {inspection.accessories.capacete && (
                  <span className={`px-1.5 py-0.5 rounded border ${paperTheme === 'paper' ? 'bg-emerald-100 text-emerald-800 border-emerald-300' : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20'}`}>
                    [ X ] Capacete
                  </span>
                )}
                {inspection.accessories.capaChuva && (
                  <span className={`px-1.5 py-0.5 rounded border ${paperTheme === 'paper' ? 'bg-emerald-100 text-emerald-800 border-emerald-300' : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20'}`}>
                    [ X ] Capa Chuva
                  </span>
                )}
                {inspection.accessories.suporteCelular && (
                  <span className={`px-1.5 py-0.5 rounded border ${paperTheme === 'paper' ? 'bg-emerald-100 text-emerald-800 border-emerald-300' : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20'}`}>
                    [ X ] Suporte Celular
                  </span>
                )}
                {inspection.accessories.bauBauleto && (
                  <span className={`px-1.5 py-0.5 rounded border ${paperTheme === 'paper' ? 'bg-emerald-100 text-emerald-800 border-emerald-300' : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20'}`}>
                    [ X ] Baú / Bauleto
                  </span>
                )}
                {inspection.accessories.chaveReserva && (
                  <span className={`px-1.5 py-0.5 rounded border ${paperTheme === 'paper' ? 'bg-emerald-100 text-emerald-800 border-emerald-300' : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20'}`}>
                    [ X ] Chave Reserva
                  </span>
                )}
                {inspection.accessories.outros && (
                  <span className={`px-1.5 py-0.5 rounded border ${paperTheme === 'paper' ? 'bg-emerald-100 text-emerald-800 border-emerald-300' : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20'}`}>
                    [ X ] {inspection.accessories.outrosDescricao || 'Outros'}
                  </span>
                )}
                {!Object.values(inspection.accessories).some(Boolean) && (
                  <span className="italic opacity-60 text-[10px]">Nenhum acessório adicional.</span>
                )}
              </div>
            </div>

            {/* AVARIAS NO TERMO */}
            <div className={`p-2.5 rounded-xl border mb-3 ${paperTheme === 'paper' ? 'bg-slate-100/60 border-slate-300' : 'bg-white/[0.02] border-white/[0.06]'}`}>
              <span className={`text-[10px] font-black uppercase tracking-wider block mb-1 ${paperTheme === 'paper' ? 'text-slate-900' : 'text-white'}`}>
                DESCRIÇÃO DE AVARIAS EXISTENTES:
              </span>
              <p className={`text-[10.5px] leading-relaxed italic ${paperTheme === 'paper' ? 'text-slate-700' : 'text-slate-300'}`}>
                {inspection.damagesDescription || 'Nenhuma avaria estrutural identificada na entrega.'}
              </p>
            </div>

            {/* VÍDEO 360 */}
            <div className={`p-2 rounded-xl border mb-3 text-[10px] ${paperTheme === 'paper' ? 'bg-indigo-50/80 border-indigo-200 text-indigo-950' : 'bg-indigo-500/10 border-indigo-500/20 text-indigo-200'}`}>
              <strong>Nota Probatória:</strong> Além deste termo, foi registrado vídeo de vistoria em 360° no ato da entrega.
              {inspection.videoUrl && (
                <span className="block mt-0.5 font-mono truncate">
                  Ref: {inspection.videoType === 'upload' ? inspection.videoFileName : inspection.videoUrl}
                </span>
              )}
            </div>

            {/* DECLARAÇÃO E ASSINATURAS */}
            <div className="pt-2 space-y-4">
              <p className={`text-[10px] leading-relaxed italic ${paperTheme === 'paper' ? 'text-slate-600' : 'text-slate-400'}`}>
                O LOCATÁRIO declara que vistoriou a motocicleta, recebeu os acessórios e concorda que o veículo está em perfeitas condições de uso, obrigando-se a devolvê-lo nas mesmas condições.
              </p>

              <div className="grid grid-cols-2 gap-4 pt-4 text-center">
                <div className={`border-t pt-1 ${paperTheme === 'paper' ? 'border-slate-400 text-slate-800' : 'border-white/30 text-white'}`}>
                  <span className="text-[10px] font-bold block">Assinatura do LOCADOR</span>
                </div>
                <div className={`border-t pt-1 ${paperTheme === 'paper' ? 'border-slate-400 text-slate-800' : 'border-white/30 text-white'}`}>
                  <span className="text-[10px] font-bold block">Assinatura do LOCATÁRIO</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
