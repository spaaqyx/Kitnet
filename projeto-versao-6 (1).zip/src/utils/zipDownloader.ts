import JSZip from 'jszip';
import type { ProjectVersionInfo, AppVersionItem } from '../types';
import { today, nowDateTime, getBrazilParts } from './dateUtils';

export const DEFAULT_VERSION_INFO: ProjectVersionInfo = {
  lastGenerated: '2026-09-05T14:36:20-03:00',
  updatedAt: '2026-09-05T14:36:20-03:00',
  formattedTime: '14:36:20',
  formattedDate: '05/09/2026',
  formattedDateTime: '05/09/2026 às 14:36:20',
  currentVersion: {
    num: 6,
    version: 'Versão 6',
    displayName: 'Projeto Versão 6',
    filename: 'projeto-versao-6.zip',
    downloadUrl: '/versions/projeto-versao-6.zip',
    sizeBytes: 648295,
    sizeFormatted: '633.1 KB',
    updatedAt: '2026-09-05T14:36:20-03:00',
    formattedDateTime: '05/09/2026 às 14:36:20',
    formattedTime: '14:36:20',
    formattedDate: '05/09/2026',
    isLatest: true,
  },
  previousVersion: {
    num: 5,
    version: 'Versão 5',
    displayName: 'Projeto Versão 5',
    filename: 'projeto-versao-5.zip',
    downloadUrl: '/versions/projeto-versao-5.zip',
    sizeBytes: 648255,
    sizeFormatted: '633.1 KB',
    updatedAt: '2026-09-05T14:32:31-03:00',
    formattedDateTime: '05/09/2026 às 14:32:31',
    formattedTime: '14:32:31',
    formattedDate: '05/09/2026',
    isLatest: false,
  },
  comparison: {
    hasPrevious: true,
    oldSizeFormatted: '633.1 KB',
    oldSizeBytes: 648255,
    newSizeFormatted: '633.1 KB',
    newSizeBytes: 648295,
    diffBytes: 40,
    diffFormatted: '+0.0 KB',
    diffPercent: '+0.0%',
    isIncrease: true,
  },
  allVersions: [
    {
      num: 6,
      version: 'Versão 6',
      displayName: 'Projeto Versão 6',
      filename: 'projeto-versao-6.zip',
      downloadUrl: '/versions/projeto-versao-6.zip',
      sizeBytes: 648295,
      sizeFormatted: '633.1 KB',
      updatedAt: '2026-09-05T14:36:20-03:00',
      formattedDateTime: '05/09/2026 às 14:36:20',
      formattedTime: '14:36:20',
      formattedDate: '05/09/2026',
      isLatest: true,
    },
    {
      num: 5,
      version: 'Versão 5',
      displayName: 'Projeto Versão 5',
      filename: 'projeto-versao-5.zip',
      downloadUrl: '/versions/projeto-versao-5.zip',
      sizeBytes: 648255,
      sizeFormatted: '633.1 KB',
      updatedAt: '2026-09-05T14:32:31-03:00',
      formattedDateTime: '05/09/2026 às 14:32:31',
      formattedTime: '14:32:31',
      formattedDate: '05/09/2026',
      isLatest: false,
    },
    {
      num: 4,
      version: 'Versão 4',
      displayName: 'Projeto Versão 4',
      filename: 'projeto-versao-4.zip',
      downloadUrl: '/versions/projeto-versao-4.zip',
      sizeBytes: 647485,
      sizeFormatted: '632.3 KB',
      updatedAt: '2026-09-05T14:25:26-03:00',
      formattedDateTime: '05/09/2026 às 14:25:26',
      formattedTime: '14:25:26',
      formattedDate: '05/09/2026',
      isLatest: false,
    },
    {
      num: 3,
      version: 'Versão 3',
      displayName: 'Projeto Versão 3',
      filename: 'projeto-versao-3.zip',
      downloadUrl: '/versions/projeto-versao-3.zip',
      sizeBytes: 644272,
      sizeFormatted: '629.2 KB',
      updatedAt: '2026-09-05T11:58:37-03:00',
      formattedDateTime: '05/09/2026 às 11:58:37',
      formattedTime: '11:58:37',
      formattedDate: '05/09/2026',
      isLatest: false,
    },
    {
      num: 2,
      version: 'Versão 2',
      displayName: 'Projeto Versão 2',
      filename: 'projeto-versao-2.zip',
      downloadUrl: '/versions/projeto-versao-2.zip',
      sizeBytes: 646913,
      sizeFormatted: '631.8 KB',
      updatedAt: '2026-09-05T11:46:31-03:00',
      formattedDateTime: '05/09/2026 às 11:46:31',
      formattedTime: '11:46:31',
      formattedDate: '05/09/2026',
      isLatest: false,
    },
    {
      num: 1,
      version: 'Projeto Versão 1',
      displayName: 'Projeto Versão 1',
      filename: 'projeto-versao-1.zip',
      downloadUrl: '/versions/projeto-versao-1.zip',
      sizeBytes: 640788,
      sizeFormatted: '625.8 KB',
      updatedAt: '2026-09-05T11:29:37-03:00',
      formattedDateTime: '05/09/2026 às 11:29:37',
      formattedTime: '11:29:37',
      formattedDate: '05/09/2026',
      isLatest: false,
    },
  ],
};

/**
 * Loads the latest version-info.json generated during build or update
 * and cross-verifies exact real binary size via HEAD request when possible.
 */
export async function fetchProjectVersionInfo(): Promise<ProjectVersionInfo> {
  try {
    const res = await fetch(`/version-info.json?t=${Date.now()}`);
    if (res.ok) {
      const data = (await res.json()) as ProjectVersionInfo;

      // Real-time Content-Length verification of the actual zip binary
      try {
        const headRes = await fetch(`/projeto-completo.zip?t=${Date.now()}`, { method: 'HEAD' });
        const cl = headRes.headers.get('content-length');
        if (cl) {
          const bytes = parseInt(cl, 10);
          if (!isNaN(bytes) && bytes > 0) {
            const formatted =
              bytes >= 1024 * 1024
                ? `${(bytes / (1024 * 1024)).toFixed(1)} MB`
                : `${(bytes / 1024).toFixed(1)} KB`;

            if (data.currentVersion) {
              data.currentVersion.sizeBytes = bytes;
              data.currentVersion.sizeFormatted = formatted;
            }
            if (data.comparison) {
              data.comparison.newSizeBytes = bytes;
              data.comparison.newSizeFormatted = formatted;
              if (data.previousVersion) {
                const diff = bytes - data.previousVersion.sizeBytes;
                const sign = diff > 0 ? '+' : (diff === 0 ? '' : '-');
                const diffKb = Math.abs(diff / 1024).toFixed(1);
                data.comparison.diffBytes = diff;
                data.comparison.diffFormatted = diff === 0 ? '0 KB' : `${sign}${diffKb} KB`;
                const pct =
                  data.previousVersion.sizeBytes > 0
                    ? Math.abs((diff / data.previousVersion.sizeBytes) * 100).toFixed(1)
                    : '0';
                data.comparison.diffPercent = diff === 0 ? '0%' : `${sign}${pct}%`;
                data.comparison.isIncrease = diff > 0;
              }
            }
          }
        }
      } catch {
        // Optional validation
      }

      return data;
    }
  } catch (err) {
    console.warn('Erro ao carregar version-info.json, usando fallback padrão:', err);
  }
  return DEFAULT_VERSION_INFO;
}

/**
 * Downloads a specific version archive by URL and filename
 */
export async function downloadSpecificVersion(downloadUrl: string, filename: string): Promise<void> {
  try {
    const cleanUrl = `${downloadUrl}?t=${Date.now()}`;
    const res = await fetch(cleanUrl);
    const contentType = res.headers.get('content-type') || '';
    if (res.ok && !contentType.includes('text/html')) {
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      return;
    }
  } catch (err) {
    console.warn('Download de versão específica falhou, tentando fallback:', err);
  }

  // Fallback to /projeto-completo.zip if this is the latest version
  try {
    const res = await fetch(`/projeto-completo.zip?t=${Date.now()}`);
    const contentType = res.headers.get('content-type') || '';
    if (res.ok && !contentType.includes('text/html')) {
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      return;
    }
  } catch {
    // ignore
  }

  // Fallback: direct anchor link
  const a = document.createElement('a');
  a.href = downloadUrl;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

/**
 * Downloads the latest complete project ZIP file
 */
export async function downloadLatestProjectZip(customFilename?: string): Promise<void> {
  let zipName = customFilename;
  if (!zipName) {
    try {
      const vInfo = await fetchProjectVersionInfo();
      zipName = vInfo.currentVersion?.filename || `projeto-versao-${vInfo.currentVersion?.num || 5}.zip`;
    } catch {
      zipName = DEFAULT_VERSION_INFO.currentVersion?.filename || 'projeto-versao-5.zip';
    }
  }

  // Try downloading the specific version zip first
  try {
    const specificUrl = `/versions/${zipName}?t=${Date.now()}`;
    const res = await fetch(specificUrl);
    const contentType = res.headers.get('content-type') || '';
    if (res.ok && !contentType.includes('text/html')) {
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = zipName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      return;
    }
  } catch (err) {
    console.warn('Specific version file fetch failed, falling back to /projeto-completo.zip:', err);
  }

  // Fallback to /projeto-completo.zip (always contains the newest full build)
  try {
    const res = await fetch(`/projeto-completo.zip?t=${Date.now()}`);
    const contentType = res.headers.get('content-type') || '';
    if (res.ok && !contentType.includes('text/html')) {
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = zipName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      return;
    }
  } catch (err) {
    console.warn('Pre-bundled zip fetch failed, falling back to dynamic generator', err);
  }

  // Fallback: create zip dynamically using JSZip
  const zip = new JSZip();
  zip.file('README.txt', `${zipName} - Gestão Patrimonial gerado em ` + nowDateTime(true));
  const content = await zip.generateAsync({ type: 'blob' });
  const url = window.URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = url;
  a.download = zipName;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(url);
  document.body.removeChild(a);
}
