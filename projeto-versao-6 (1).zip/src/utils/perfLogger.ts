import { useEffect, useRef } from 'react';

/**
 * Performance Tracking Hook & Logger
 * Identifies component re-render frequency, renders per second, and potential infinite loops.
 */
interface RenderStats {
  count: number;
  lastRenderTime: number;
  rendersInLastSecond: number;
  secondStartTime: number;
}

const renderStatsMap = new Map<string, RenderStats>();

export function useRenderTracker(componentName: string, trackedProps?: Record<string, any>) {
  const renderCount = useRef(0);
  const prevProps = useRef(trackedProps);
  renderCount.current += 1;

  useEffect(() => {
    const now = performance.now();
    let stats = renderStatsMap.get(componentName);

    if (!stats) {
      stats = {
        count: 0,
        lastRenderTime: now,
        rendersInLastSecond: 0,
        secondStartTime: now,
      };
      renderStatsMap.set(componentName, stats);
    }

    stats.count += 1;

    // Calculate frequency in the last 1 second
    if (now - stats.secondStartTime > 1000) {
      stats.secondStartTime = now;
      stats.rendersInLastSecond = 1;
    } else {
      stats.rendersInLastSecond += 1;
    }

    stats.lastRenderTime = now;

    // Detect high frequency / potential loop
    if (stats.rendersInLastSecond > 8) {
      console.warn(
        `%c[PERF ALERT] ⚠️ <${componentName} /> rendered ${stats.rendersInLastSecond} times in <1s! (Total: ${stats.count})`,
        'color: #f59e0b; font-weight: bold; background: #78350f20; padding: 2px 6px; border-radius: 4px;'
      );
    } else if (process.env.NODE_ENV !== 'production') {
      console.debug(
        `%c[RenderTrack] 🔄 <${componentName} /> (#${renderCount.current})`,
        'color: #a78bfa; font-size: 11px;'
      );
    }

    // Check changed props if provided
    if (trackedProps && prevProps.current) {
      const changedKeys: string[] = [];
      Object.keys(trackedProps).forEach((key) => {
        if (trackedProps[key] !== prevProps.current?.[key]) {
          changedKeys.push(key);
        }
      });
      if (changedKeys.length > 0 && process.env.NODE_ENV !== 'production') {
        console.debug(`  ↳ Props changed for <${componentName} />:`, changedKeys);
      }
    }
    prevProps.current = trackedProps;
  });
}

/**
 * Diagnostic Lifecycle Logger
 * Identifies mounts, unmounts, renders, and effects for debugging render anomalies.
 */
export function useLifecycleLogger(componentName: string, details?: any) {
  const renderCount = useRef(0);
  renderCount.current += 1;
  const currentRender = renderCount.current;

  // Log render
  console.log(
    `%c[LIFECYCLE] 🔄 RENDER #${currentRender}: <${componentName} />`,
    'color: #38bdf8; font-weight: 500;',
    details ?? ''
  );

  useEffect(() => {
    console.log(
      `%c[LIFECYCLE] 🟢 MOUNT: <${componentName} /> (Initial Render #${currentRender})`,
      'color: #4ade80; font-weight: bold; background: #064e3b33; padding: 2px 4px; border-radius: 4px;'
    );
    return () => {
      console.log(
        `%c[LIFECYCLE] 🔴 UNMOUNT: <${componentName} /> (Last Render #${renderCount.current})`,
        'color: #f87171; font-weight: bold; background: #7f1d1d33; padding: 2px 4px; border-radius: 4px;'
      );
    };
  }, []);

  useEffect(() => {
    console.log(
      `%c[LIFECYCLE] ⚡ EFFECT executed: <${componentName} /> (Render #${currentRender})`,
      'color: #fbbf24;'
    );
  });
}
