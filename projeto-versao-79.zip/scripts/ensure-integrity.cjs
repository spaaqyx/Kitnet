const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const rootDir = path.resolve(__dirname, '..');

const REQUIRED_FILES = [
  'src/context/index.ts',
  'src/context/AppContext.tsx',
  'src/styles/colors.ts',
  'src/types/index.ts',
  'src/hooks/index.ts',
  'src/utils/formatters.ts',
  'src/components/DashboardView.tsx',
  'src/components/Navigation.tsx',
  'src/domain/index.ts',
  'src/services/DashboardService.ts',
  'src/App.tsx',
  'src/main.tsx',
  'src/index.css'
];

function checkIntegrity() {
  const missing = REQUIRED_FILES.filter(relPath => {
    const fullPath = path.join(rootDir, relPath);
    try {
      const stat = fs.statSync(fullPath);
      return stat.size === 0;
    } catch {
      return true;
    }
  });

  if (missing.length === 0) {
    return true;
  }

  console.warn(`[Integrity] Missing or empty files detected: ${missing.join(', ')}`);
  console.log('[Integrity] Restoring project files from verified archive...');

  const backupCandidates = [
    path.join(rootDir, '.project-backup.zip'),
    path.join(rootDir, 'public/projeto-completo.zip'),
    path.join(rootDir, 'dist/projeto-completo.zip')
  ];

  // Dynamically add all available numbered versions, newest first
  const versionsDir = path.join(rootDir, 'public/versions');
  if (fs.existsSync(versionsDir)) {
    try {
      const versionFiles = fs.readdirSync(versionsDir)
        .filter(f => /^projeto-versao-\d+\.zip$/.test(f))
        .sort((a, b) => {
          const numA = parseInt(a.match(/\d+/)[0], 10);
          const numB = parseInt(b.match(/\d+/)[0], 10);
          return numB - numA;
        })
        .map(f => path.join(versionsDir, f));
      backupCandidates.splice(1, 0, ...versionFiles);
    } catch {
      // ignore
    }
  }

  let restored = false;
  for (const candidate of backupCandidates) {
    if (fs.existsSync(candidate) && fs.statSync(candidate).size > 10000) {
      try {
        console.log(`[Integrity] Extracting from ${candidate}...`);
        execSync(`unzip -o -q "${candidate}"`, { cwd: rootDir, stdio: 'inherit' });
        restored = true;
        break;
      } catch (err) {
        console.error(`[Integrity] Failed to extract from ${candidate}:`, err.message);
      }
    }
  }

  if (!restored) {
    console.error('[Integrity Error] Could not find a valid archive to restore missing files.');
    return false;
  }

  // Verify again
  const stillMissing = REQUIRED_FILES.filter(relPath => {
    const fullPath = path.join(rootDir, relPath);
    return !fs.existsSync(fullPath);
  });

  if (stillMissing.length > 0) {
    console.error(`[Integrity Error] The following files could not be restored: ${stillMissing.join(', ')}`);
    return false;
  }

  console.log('[Integrity] All project files successfully restored and verified.');
  return true;
}

if (require.main === module) {
  const ok = checkIntegrity();
  if (!ok) {
    process.exit(1);
  }
}

module.exports = { checkIntegrity, REQUIRED_FILES };
