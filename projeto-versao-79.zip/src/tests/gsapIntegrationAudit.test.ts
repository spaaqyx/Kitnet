/**
 * src/tests/gsapIntegrationAudit.test.ts
 *
 * Trava de regressão e auditoria completa da biblioteca GSAP:
 * 1. Verifica se a biblioteca 'gsap' é carregada corretamente sem falhas de ESM.
 * 2. Verifica a existência de todos os métodos de núcleo do GSAP (to, from, fromTo, set, timeline, context, killTweensOf, config).
 * 3. Verifica se src/utils/gsapAnimations.ts exporta a instância central configurada e todos os helpers necessários.
 * 4. Varre todos os arquivos de src/ garantindo que nenhum use importação padrão de gsap,
 *    padronizando para importações nomeadas ({ gsap }) para prevenir conflitos de bundling.
 * 5. Garante que o vite.config.ts tenha gsap em optimizeDeps.include para pré-empacotamento sem erros.
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { gsap } from 'gsap';
import * as gsapUtils from '../utils/gsapAnimations';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '../..');

console.log('====================================================');
console.log('   AUDITORIA INTEGRAL DA BIBLIOTECA GSAP (VISTORIA)  ');
console.log('====================================================\n');

let passedChecks = 0;
const errors: string[] = [];

// 1. Verificação da biblioteca base GSAP
try {
  if (typeof gsap !== 'function' && typeof gsap !== 'object') {
    errors.push('GSAP importado não é uma função/objeto válido.');
  } else {
    passedChecks++;
    console.log(`✅ [1/5] GSAP core carregado com sucesso (versão: ${gsap.version}).`);
  }
} catch (err: any) {
  errors.push(`Falha ao verificar GSAP core: ${err.message}`);
}

// 2. Verificação dos métodos de animação e utilitários de ciclo de vida
const requiredGsapMethods = [
  'to',
  'from',
  'fromTo',
  'set',
  'timeline',
  'context',
  'killTweensOf',
  'config',
  'getTweensOf',
];

const missingMethods = requiredGsapMethods.filter((method) => typeof (gsap as any)[method] !== 'function');
if (missingMethods.length > 0) {
  errors.push(`Métodos essenciais do GSAP ausentes: ${missingMethods.join(', ')}`);
} else {
  passedChecks++;
  console.log(`✅ [2/5] Todos os métodos essenciais do GSAP (${requiredGsapMethods.length}) estão presentes e ativos.`);
}

// 3. Verificação do módulo central src/utils/gsapAnimations.ts
const requiredUtilsHelpers = [
  'gsap',
  'gsapScrollTo',
  'gsapButtonPress',
  'gsapCardHoverEnter',
  'gsapCardHoverLeave',
  'gsapFillProgressBar',
  'gsapAnimateSparkline',
  'animateModalEnter',
  'gsapModalOpen',
  'gsapModalClose',
  'useGsapStagger',
  'useGsapModal',
  'gsapScrollStepper',
  'gsapAnimateTabChange',
];

const missingHelpers = requiredUtilsHelpers.filter((helper) => !(helper in gsapUtils));
if (missingHelpers.length > 0) {
  errors.push(`Módulo src/utils/gsapAnimations.ts não exporta: ${missingHelpers.join(', ')}`);
} else {
  passedChecks++;
  console.log(`✅ [3/5] Módulo central src/utils/gsapAnimations exporta com sucesso todos os ${requiredUtilsHelpers.length} helpers.`);
}

// 4. Varredura no código fonte para proibir default imports ("import gsap from 'gsap'")
function walkDir(dir: string): string[] {
  let results: string[] = [];
  if (!fs.existsSync(dir)) return results;
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results = results.concat(walkDir(fullPath));
    } else if (/\.(tsx|ts)$/.test(entry.name)) {
      results.push(fullPath);
    }
  }
  return results;
}

const allSourceFiles = walkDir(path.join(rootDir, 'src'));
const defaultImportViolations: string[] = [];

for (const file of allSourceFiles) {
  if (path.resolve(file) === path.resolve(__filename)) continue;
  const content = fs.readFileSync(file, 'utf8');
  // Procura por "import gsap from 'gsap'" ou "import gsap from "gsap""
  if (/import\s+gsap\s+from\s+['"]gsap['"]/.test(content)) {
    defaultImportViolations.push(path.relative(rootDir, file));
  }
}

if (defaultImportViolations.length > 0) {
  errors.push(
    `Arquivos com default import de gsap: ${defaultImportViolations.join(', ')}. Use named import com chaves.`
  );
} else {
  passedChecks++;
  console.log(`✅ [4/5] Todos os ${allSourceFiles.length} arquivos fonte usam named imports padronizados para GSAP.`);
}

// 5. Verificação da configuração do vite.config.ts
const viteConfigPath = path.join(rootDir, 'vite.config.ts');
if (fs.existsSync(viteConfigPath)) {
  const viteContent = fs.readFileSync(viteConfigPath, 'utf8');
  if (!viteContent.includes("include: ['gsap']") && !viteContent.includes('include: ["gsap"]')) {
    errors.push('vite.config.ts não inclui "gsap" em optimizeDeps.include.');
  } else {
    passedChecks++;
    console.log('✅ [5/5] vite.config.ts otimiza e pré-empacota "gsap" corretamente via optimizeDeps.');
  }
} else {
  errors.push('vite.config.ts não encontrado.');
}

console.log('\n----------------------------------------------------');
if (errors.length > 0) {
  console.error(`❌ [FAIL] Foram encontrados ${errors.length} erro(s) na auditoria do GSAP:`);
  for (const err of errors) {
    console.error(` - ${err}`);
  }
  process.exit(1);
} else {
  console.log(`🎉 [SUCCESS] Todas as ${passedChecks} verificações do GSAP passaram com louvor!`);
  console.log('A biblioteca GSAP está puxando perfeitamente e 100% à prova de falhas futuras.');
  process.exit(0);
}
