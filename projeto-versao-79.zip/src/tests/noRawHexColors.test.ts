/**
 * src/tests/noRawHexColors.test.ts
 *
 * Trava de regressão de cores:
 * Garante que nenhuma cor hex direta (#[0-9A-Fa-f]{6}) seja escrita em arquivos
 * .tsx/.ts dentro de src/components, src/context e src/utils.
 * Todas as cores devem vir exclusivamente de src/styles/colors.ts.
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '../..');

function walkDir(dir: string): string[] {
  let results: string[] = [];
  if (!fs.existsSync(dir)) return results;
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results = results.concat(walkDir(fullPath));
    } else if (/\.(tsx|ts)$/.test(entry.name)) {
      results.push(fullPath);
    }
  }
  return results;
}

const targetDirs = [
  path.join(rootDir, 'src'),
];

const ignoredFiles = new Set([
  path.resolve(rootDir, 'src/styles/colors.ts'),
]);

const hexRegex = /#[0-9A-Fa-f]{6}\b/g;

interface Violation {
  file: string;
  line: number;
  snippet: string;
  hex: string;
}

const violations: Violation[] = [];

for (const targetDir of targetDirs) {
  const files = walkDir(targetDir);
  for (const file of files) {
    const resolvedPath = path.resolve(file);
    if (ignoredFiles.has(resolvedPath) || resolvedPath.includes('/tests/')) {
      continue;
    }

    const content = fs.readFileSync(file, 'utf8');
    const lines = content.split('\n');

    lines.forEach((lineText, index) => {
      const matches = lineText.match(hexRegex);
      if (matches) {
        for (const m of matches) {
          violations.push({
            file: path.relative(rootDir, file),
            line: index + 1,
            snippet: lineText.trim(),
            hex: m,
          });
        }
      }
    });
  }
}

console.log('--- AUDITORIA DE PADRONIZAÇÃO DE CORES (TRAVA CONTRA REGRESSÃO) ---');

if (violations.length > 0) {
  console.error(`❌ [FAIL] Encontradas ${violations.length} ocorrências de cores hex brutas fora de src/styles/colors.ts:\n`);
  
  // Agrupa por arquivo para exibição limpa
  const grouped: Record<string, Violation[]> = {};
  for (const v of violations) {
    if (!grouped[v.file]) grouped[v.file] = [];
    grouped[v.file].push(v);
  }

  for (const [file, items] of Object.entries(grouped)) {
    console.error(`📄 ${file} (${items.length} ocorrência(s)):`);
    for (const item of items.slice(0, 5)) {
      console.error(`   Linha ${item.line}: ${item.snippet} [${item.hex}]`);
    }
    if (items.length > 5) {
      console.error(`   ... e mais ${items.length - 5} ocorrências neste arquivo.`);
    }
    console.error('');
  }

  console.error(`\n🚨 O teste falhou. Todas as cores hex devem ser substituídas pelas referências de COLORS em src/styles/colors.ts.`);
  process.exit(1);
} else {
  console.log('✅ [PASS] Zero cores hex soltas encontradas! 100% dos arquivos do projeto em src/ estão rigorosamente padronizados com COLORS.');
  process.exit(0);
}
