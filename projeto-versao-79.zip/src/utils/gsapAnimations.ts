import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

/**
 * GSAP Central Configuration & Helper Module for the entire app.
 * Configured safely for React 19, strict mode, zero memory leaks, GPU accelerated.
 */

// Central GSAP configuration to suppress false-positive null warnings during rapid React unmounts
gsap.config({
  nullTargetWarn: false,
  autoSleep: 60,
});

// Re-export the unified GSAP singleton
export { gsap };
export default gsap;

// Smooth scroll a container to a target position using GSAP
export function gsapScrollTo(container: HTMLElement | null, targetLeft: number, duration = 0.35) {
  if (!container) return;
  gsap.to(container, {
    scrollLeft: targetLeft,
    duration,
    ease: 'power2.out',
    overwrite: 'auto',
  });
}

// Button click/tap ripple and scale bounce effect - zero delay and zero fighting with CSS transitions
export function gsapButtonPress(element: HTMLElement | null, callback?: () => void) {
  // CRITICAL: Call the action callback immediately with ZERO delay
  if (callback) {
    try {
      callback();
    } catch (err) {
      console.error('Error executing button callback:', err);
    }
  }

  if (!element) return;

  // Non-blocking snappy GSAP bounce
  gsap.killTweensOf(element);
  gsap.fromTo(
    element,
    { scale: 0.93 },
    {
      scale: 1,
      duration: 0.18,
      ease: 'back.out(2)',
      clearProps: 'transform',
      overwrite: 'auto',
    }
  );
}

// Card hover micro-interaction (lift, scale, glow)
export function gsapCardHoverEnter(element: HTMLElement | null, liftY = -4, scaleVal = 1.01) {
  if (!element) return;
  gsap.to(element, {
    y: liftY,
    scale: scaleVal,
    duration: 0.24,
    ease: 'power2.out',
    overwrite: 'auto',
  });
}

export function gsapCardHoverLeave(element: HTMLElement | null) {
  if (!element) return;
  gsap.to(element, {
    y: 0,
    scale: 1,
    duration: 0.28,
    ease: 'power2.out',
    overwrite: 'auto',
    clearProps: 'transform',
  });
}

// Smooth animated fill for progress bars
export function gsapFillProgressBar(element: HTMLElement | null, targetWidthPercent: number, duration = 0.6) {
  if (!element) return;
  gsap.fromTo(
    element,
    { width: '0%' },
    {
      width: `${Math.min(100, Math.max(0, targetWidthPercent))}%`,
      duration,
      ease: 'power2.out',
      overwrite: 'auto',
    }
  );
}

// Smooth animated stroke for SVG sparklines
export function gsapAnimateSparkline(pathElement: SVGPathElement | null, duration = 0.8) {
  if (!pathElement) return;
  try {
    const length = pathElement.getTotalLength();
    gsap.fromTo(
      pathElement,
      { strokeDasharray: length, strokeDashoffset: length },
      {
        strokeDashoffset: 0,
        duration,
        ease: 'power2.out',
        overwrite: 'auto',
      }
    );
  } catch {
    // Fallback if getTotalLength is unavailable in test environment
  }
}

// Modal/Dialog enter animation
export function animateModalEnter(container: HTMLElement | null, onComplete?: () => void) {
  if (!container) return;
  gsap.fromTo(
    container,
    { scale: 0.94, y: 16, opacity: 0 },
    { scale: 1, y: 0, opacity: 1, duration: 0.3, ease: 'power3.out', onComplete }
  );
}

// Full modal open orchestration: backdrop fade + dialog spring in
export function gsapModalOpen(
  backdropEl: HTMLElement | null,
  dialogEl: HTMLElement | null,
  options?: { onComplete?: () => void; duration?: number }
) {
  if (backdropEl) {
    gsap.killTweensOf(backdropEl);
    gsap.fromTo(
      backdropEl,
      { opacity: 0 },
      { opacity: 1, duration: options?.duration || 0.26, ease: 'power2.out', overwrite: 'auto' }
    );
  }
  if (dialogEl) {
    gsap.killTweensOf(dialogEl);
    gsap.fromTo(
      dialogEl,
      { opacity: 0, scale: 0.93, y: 22 },
      {
        opacity: 1,
        scale: 1,
        y: 0,
        duration: 0.35,
        ease: 'back.out(1.25)',
        overwrite: 'auto',
        onComplete: options?.onComplete,
      }
    );
  }
}

// Full modal close orchestration: dialog sink/shrink + backdrop fade out before calling unmount callback
export function gsapModalClose(
  backdropEl: HTMLElement | null,
  dialogEl: HTMLElement | null,
  onComplete: () => void
) {
  let finished = false;
  const finish = () => {
    if (!finished) {
      finished = true;
      onComplete();
    }
  };

  if (!backdropEl && !dialogEl) {
    finish();
    return;
  }

  if (backdropEl) {
    gsap.killTweensOf(backdropEl);
    gsap.to(backdropEl, {
      opacity: 0,
      duration: 0.22,
      ease: 'power2.in',
      overwrite: 'auto',
    });
  }

  if (dialogEl) {
    gsap.killTweensOf(dialogEl);
    gsap.to(dialogEl, {
      opacity: 0,
      scale: 0.94,
      y: 16,
      duration: 0.22,
      ease: 'power2.in',
      overwrite: 'auto',
      onComplete: finish,
    });
  } else {
    setTimeout(finish, 220);
  }
}

// Stagger cards in a grid/list
export function animateStaggerCards(selectorOrElements: string | HTMLElement[], parent?: HTMLElement) {
  return gsap.from(selectorOrElements, {
    y: 18,
    opacity: 0,
    duration: 0.35,
    stagger: 0.04,
    ease: 'power3.out',
    clearProps: 'transform,opacity',
  });
}

// Hook for automatic GSAP container animation
export function useGsapStagger<T extends HTMLElement>(
  targetSelector: string,
  deps: React.DependencyList = []
) {
  const containerRef = useRef<T>(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      gsap.from(targetSelector, {
        y: 16,
        opacity: 0,
        duration: 0.38,
        stagger: 0.04,
        ease: 'power3.out',
        clearProps: 'transform,opacity',
      });
    }, el);

    return () => ctx.revert();
  }, deps);

  return containerRef;
}

// Hook for GSAP Modal presentation
export function useGsapModal<T extends HTMLElement>(isOpen: boolean) {
  const modalBoxRef = useRef<T>(null);

  useEffect(() => {
    const el = modalBoxRef.current;
    if (!isOpen || !el) return;
    const ctx = gsap.context(() => {
      gsap.fromTo(
        el,
        { scale: 0.92, y: 18, opacity: 0 },
        { scale: 1, y: 0, opacity: 1, duration: 0.32, ease: 'back.out(1.4)', clearProps: 'transform,opacity' }
      );
    }, el);

    return () => ctx.revert();
  }, [isOpen]);

  return modalBoxRef;
}

// Helper to center and animate stepper buttons
export function gsapScrollStepper(
  container: HTMLElement | null,
  activeItem: HTMLElement | null,
  duration = 0.35
) {
  if (!container || !activeItem) return;

  const containerRect = container.getBoundingClientRect();
  const elRect = activeItem.getBoundingClientRect();
  const currentScroll = container.scrollLeft;
  const relativeLeft = elRect.left - containerRect.left;
  const targetScroll = currentScroll + relativeLeft - (container.clientWidth / 2) + (elRect.width / 2);

  gsap.to(container, {
    scrollLeft: Math.max(0, targetScroll),
    duration,
    ease: 'power2.out',
    overwrite: 'auto',
  });

  // Micro bounce on the step pill
  gsap.fromTo(
    activeItem,
    { scale: 0.94 },
    { scale: 1, duration: 0.24, ease: 'back.out(2)' }
  );
}

// Fade and slide in content when tabs switch
export function gsapAnimateTabChange(target: HTMLElement | null) {
  if (!target) return;
  gsap.fromTo(
    target,
    { opacity: 0, y: 10 },
    { opacity: 1, y: 0, duration: 0.25, ease: 'power2.out', clearProps: 'all' }
  );
}

