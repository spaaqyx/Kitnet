import type { Options } from 'canvas-confetti';

/**
 * Lazy confetti trigger to prevent canvas-confetti from inflating initial app bundle
 */
export const triggerConfetti = async (options?: Options): Promise<void> => {
  try {
    const confettiModule = await import('canvas-confetti');
    const confettiFn: (opts?: Options) => Promise<null> | null =
      (confettiModule as any).default || confettiModule;
    confettiFn({
      particleCount: 80,
      spread: 60,
      origin: { y: 0.7 },
      ...options,
    });
  } catch {
    // Fallback gracefully on low-memory/unsupported environments
  }
};
