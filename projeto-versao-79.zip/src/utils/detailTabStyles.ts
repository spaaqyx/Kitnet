/**
 * src/utils/detailTabStyles.ts
 * 
 * Configuração padronizada de estilos luminosos e cores semânticas por função
 * para as abas de Detalhes de Motos e Kitnets.
 * 
 * Cada função possui uma identidade visual única e iluminada (neon glow):
 * - Geral / Dados: Roxo / Violeta
 * - Contrato & Parcelas: Verde Esmeralda
 * - Locatário / Inquilino: Azul Celeste (Sky)
 * - Vistoria: Verde Menta (Teal)
 * - Fotos: Rosa Choque (Pink)
 * - Manutenções: Âmbar / Laranja
 * - Quilometragem: Índigo / Azul Real
 * - Documentos: Rose / Coral
 */

export interface TabThemeConfig {
  activeBtn: string;
  activeIcon: string;
  activeBadge: string;
  hoverBtn: string;
}

export const DETAIL_TAB_THEMES: Record<string, TabThemeConfig> = {
  geral: {
    activeBtn:
      'bg-purple-600 text-white border-purple-600 shadow-xs dark:bg-purple-500/25 dark:text-purple-200 dark:border-purple-500/80 font-bold',
    activeIcon: 'text-white dark:text-purple-300',
    activeBadge: 'bg-white/25 text-white dark:bg-purple-500 dark:text-slate-950 font-black',
    hoverBtn: 'hover:border-purple-500/50 hover:bg-purple-500/[0.08] hover:text-purple-700 dark:hover:text-purple-300',
  },
  contrato: {
    activeBtn:
      'bg-emerald-600 text-white border-emerald-600 shadow-xs dark:bg-emerald-500/25 dark:text-emerald-200 dark:border-emerald-500/80 font-bold',
    activeIcon: 'text-white dark:text-emerald-300',
    activeBadge: 'bg-white/25 text-white dark:bg-emerald-500 dark:text-slate-950 font-black',
    hoverBtn: 'hover:border-emerald-500/50 hover:bg-emerald-500/[0.08] hover:text-emerald-700 dark:hover:text-emerald-300',
  },
  locatario: {
    activeBtn:
      'bg-sky-600 text-white border-sky-600 shadow-xs dark:bg-sky-500/25 dark:text-sky-200 dark:border-sky-500/80 font-bold',
    activeIcon: 'text-white dark:text-sky-300',
    activeBadge: 'bg-white/25 text-white dark:bg-sky-600 dark:text-slate-950 font-black',
    hoverBtn: 'hover:border-sky-500/50 hover:bg-sky-500/[0.08] hover:text-sky-700 dark:hover:text-sky-300',
  },
  inquilino: {
    activeBtn:
      'bg-sky-600 text-white border-sky-600 shadow-xs dark:bg-sky-500/25 dark:text-sky-200 dark:border-sky-500/80 font-bold',
    activeIcon: 'text-white dark:text-sky-300',
    activeBadge: 'bg-white/25 text-white dark:bg-sky-600 dark:text-slate-950 font-black',
    hoverBtn: 'hover:border-sky-500/50 hover:bg-sky-500/[0.08] hover:text-sky-700 dark:hover:text-sky-300',
  },
  manutencoes: {
    activeBtn:
      'bg-amber-600 text-white border-amber-600 shadow-xs dark:bg-amber-500/25 dark:text-amber-200 dark:border-amber-500/80 font-bold',
    activeIcon: 'text-white dark:text-amber-300',
    activeBadge: 'bg-white/25 text-white dark:bg-amber-600 dark:text-slate-950 font-black',
    hoverBtn: 'hover:border-amber-500/50 hover:bg-amber-500/[0.08] hover:text-amber-700 dark:hover:text-amber-300',
  },
  km: {
    activeBtn:
      'bg-indigo-600 text-white border-indigo-600 shadow-xs dark:bg-indigo-500/25 dark:text-indigo-200 dark:border-indigo-500/80 font-bold',
    activeIcon: 'text-white dark:text-indigo-300',
    activeBadge: 'bg-white/25 text-white dark:bg-indigo-600 dark:text-slate-950 font-black',
    hoverBtn: 'hover:border-indigo-500/50 hover:bg-indigo-500/[0.08] hover:text-indigo-700 dark:hover:text-indigo-300',
  },
  vistoria: {
    activeBtn:
      'bg-teal-600 text-white border-teal-600 shadow-xs dark:bg-teal-500/25 dark:text-teal-200 dark:border-teal-500/80 font-bold',
    activeIcon: 'text-white dark:text-teal-300',
    activeBadge: 'bg-white/25 text-white dark:bg-teal-600 dark:text-slate-950 font-black',
    hoverBtn: 'hover:border-teal-500/50 hover:bg-teal-500/[0.08] hover:text-teal-700 dark:hover:text-teal-300',
  },
  fotos: {
    activeBtn:
      'bg-pink-600 text-white border-pink-600 shadow-xs dark:bg-pink-500/25 dark:text-pink-200 dark:border-pink-500/80 font-bold',
    activeIcon: 'text-white dark:text-pink-300',
    activeBadge: 'bg-white/25 text-white dark:bg-pink-600 dark:text-slate-950 font-black',
    hoverBtn: 'hover:border-pink-500/50 hover:bg-pink-500/[0.08] hover:text-pink-700 dark:hover:text-pink-300',
  },
  documentos: {
    activeBtn:
      'bg-rose-600 text-white border-rose-600 shadow-xs dark:bg-rose-500/25 dark:text-rose-200 dark:border-rose-500/80 font-bold',
    activeIcon: 'text-white dark:text-rose-300',
    activeBadge: 'bg-white/25 text-white dark:bg-rose-600 dark:text-slate-950 font-black',
    hoverBtn: 'hover:border-rose-500/50 hover:bg-rose-500/[0.08] hover:text-rose-700 dark:hover:text-rose-300',
  },
};

const DEFAULT_THEME: TabThemeConfig = DETAIL_TAB_THEMES.geral;

export function getDetailTabTheme(tabId: string): TabThemeConfig {
  return DETAIL_TAB_THEMES[tabId] || DEFAULT_THEME;
}
