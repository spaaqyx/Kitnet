import React from 'react';
import { Moto, MotoContract, MotoTenant } from '../../../types';
import {
  UserPlus,
  LogOut,
  Layers,
  Wrench,
  MessageCircle,
  FileText,
  Copy,
  Edit3,
  Trash2,
} from 'lucide-react';

interface MotoDetailActionBarProps {
  moto: Moto;
  activeContract?: MotoContract;
  tenant?: MotoTenant;
  setShowNewContractModal: (show: boolean) => void;
  setTerminateMotoForm: (data: { finalKm: number; notes: string }) => void;
  setMotoToTerminate: (data: { contract: MotoContract; moto: Moto }) => void;
  onGenerateDocument: (type: any, moto: Moto, contract?: MotoContract, tenant?: MotoTenant) => void;
  onOpenWhatsApp: (contractId: string, installmentId?: string) => void;
  setShowMaintenanceModal: (show: boolean) => void;
  setShowCompareModal: (show: boolean) => void;
  duplicateMoto: (id: string) => void;
  handleOpenEditModal: (moto: Moto) => void;
  setMotoToDelete: (moto: Moto) => void;
}

export const MotoDetailActionBar: React.FC<MotoDetailActionBarProps> = ({
  moto,
  activeContract,
  tenant,
  setShowNewContractModal,
  setTerminateMotoForm,
  setMotoToTerminate,
  onGenerateDocument,
  onOpenWhatsApp,
  setShowMaintenanceModal,
  setShowCompareModal,
  duplicateMoto,
  handleOpenEditModal,
  setMotoToDelete,
}) => {
  return (
    <div className="bg-surface-card rounded-2xl border border-border-subtle p-3 sm:p-4 space-y-3 shadow-xs">
      {/* Row 1: Two primary large action buttons */}
      <div className="grid grid-cols-2 gap-2.5">
        {moto.status !== 'alugada' ? (
          <button
            id={`btn-new-contract-moto-${moto.id}`}
            type="button"
            onClick={() => setShowNewContractModal(true)}
            className="h-12 px-4 rounded-xl bg-surface-subtle hover:bg-surface-hover border border-border-subtle hover:border-border-hover text-slate-800 dark:text-white text-xs sm:text-sm font-semibold flex items-center justify-center gap-2.5 transition-all cursor-pointer active:scale-98 shadow-xs"
            title="Iniciar contrato de locação com intenção de compra"
          >
            <UserPlus className="w-4 h-4 text-sky-500 dark:text-sky-400" />
            <span className="text-slate-800 dark:text-white">Criar Contrato</span>
          </button>
        ) : (
          activeContract && (
            <button
              id={`btn-terminate-contract-moto-${moto.id}`}
              type="button"
              onClick={() => {
                setTerminateMotoForm({
                  finalKm: moto.currentKm,
                  notes: 'Locação finalizada e moto devolvida em boas condições.',
                });
                setMotoToTerminate({ contract: activeContract, moto });
              }}
              className="h-12 px-4 rounded-xl bg-surface-subtle hover:bg-surface-hover border border-border-subtle hover:border-border-hover text-slate-800 dark:text-white text-xs sm:text-sm font-semibold flex items-center justify-center gap-2.5 transition-all cursor-pointer active:scale-98 shadow-xs"
              title="Encerrar contrato de locação e devolver caução"
            >
              <LogOut className="w-4 h-4 text-rose-500 dark:text-money-negative-light" />
              <span className="text-slate-800 dark:text-white">Encerrar Locação</span>
            </button>
          )
        )}

        <button
          type="button"
          onClick={() => setShowCompareModal(true)}
          className="h-12 px-4 rounded-xl bg-surface-subtle hover:bg-surface-hover border border-border-subtle hover:border-border-hover text-slate-800 dark:text-white text-xs sm:text-sm font-semibold flex items-center justify-center gap-2.5 transition-all cursor-pointer active:scale-98 shadow-xs"
          title="Comparar fotos de entrega vs estado atual"
        >
          <Layers className="w-4 h-4 text-indigo-500 dark:text-indigo-400" />
          <span className="text-slate-800 dark:text-white">Vistorias</span>
        </button>
      </div>

      {/* Row 2: Secondary Tools Container */}
      <div className="bg-surface-subtle rounded-xl border border-border-subtle p-2.5 sm:p-3">
        {/* Sub-row 1: 4 quick actions in responsive grid */}
        <div className="grid grid-cols-2 min-[380px]:grid-cols-4 gap-1.5 text-center items-center">
          {/* 1. Manutenção */}
          <button
            type="button"
            onClick={() => setShowMaintenanceModal(true)}
            className="py-1.5 sm:py-2 px-1 rounded-lg hover:bg-slate-200/70 dark:hover:bg-white/[0.06] active:scale-95 text-slate-700 dark:text-white/90 hover:text-slate-900 dark:hover:text-white flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 text-[10px] sm:text-xs font-semibold transition-all cursor-pointer min-w-0"
            title="Registrar manutenção"
            aria-label="Registrar manutenção"
          >
            <Wrench className="w-4 h-4 text-amber-500 dark:text-amber-400 shrink-0" />
            <span className="truncate">Manutenção</span>
          </button>

          {/* 2. WhatsApp */}
          <button
            type="button"
            onClick={() => {
              if (activeContract) {
                onOpenWhatsApp(activeContract.id);
              }
            }}
            disabled={!activeContract}
            className={`py-1.5 sm:py-2 px-1 rounded-lg flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 text-[10px] sm:text-xs font-semibold transition-all min-w-0 ${
              activeContract
                ? 'hover:bg-slate-200/70 dark:hover:bg-white/[0.06] active:scale-95 text-slate-700 dark:text-white/90 hover:text-slate-900 dark:hover:text-white cursor-pointer'
                : 'text-slate-400 dark:text-white/30 cursor-not-allowed'
            }`}
            title="Enviar notificação via WhatsApp"
            aria-label="Enviar WhatsApp"
          >
            <MessageCircle className={`w-4 h-4 shrink-0 ${activeContract ? 'text-emerald-600 dark:text-money-positive-hover' : 'text-slate-400 dark:text-white/30'}`} />
            <span className="truncate">WhatsApp</span>
          </button>

          {/* 3. PDF */}
          <button
            type="button"
            onClick={() =>
              onGenerateDocument('contrato_locacao', moto, activeContract, tenant)
            }
            className="py-1.5 sm:py-2 px-1 rounded-lg hover:bg-slate-200/70 dark:hover:bg-white/[0.06] active:scale-95 text-slate-700 dark:text-white/90 hover:text-slate-900 dark:hover:text-white flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 text-[10px] sm:text-xs font-semibold transition-all cursor-pointer min-w-0"
            title="Gerar contrato em PDF"
            aria-label="Gerar contrato em PDF"
          >
            <FileText className="w-4 h-4 text-rose-500 dark:text-rose-400 shrink-0" />
            <span className="truncate">PDF</span>
          </button>

          {/* 4. Duplicar */}
          <button
            type="button"
            onClick={() => duplicateMoto(moto.id)}
            className="py-1.5 sm:py-2 px-1 rounded-lg hover:bg-slate-200/70 dark:hover:bg-white/[0.06] active:scale-95 text-slate-700 dark:text-white/90 hover:text-slate-900 dark:hover:text-white flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 text-[10px] sm:text-xs font-semibold transition-all cursor-pointer min-w-0"
            title="Duplicar cadastro da moto"
            aria-label="Duplicar cadastro da moto"
          >
            <Copy className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
            <span className="truncate">Duplicar</span>
          </button>
        </div>

        {/* Divider */}
        <div className="border-t border-border-subtle my-2" />

        {/* Sub-row 2: Editar & Apagar with vertical divider */}
        <div className="grid grid-cols-2 items-center divide-x divide-border-subtle">
          {/* Editar */}
          <button
            id={`btn-edit-moto-${moto.id}`}
            type="button"
            onClick={() => handleOpenEditModal(moto)}
            className="py-2 px-2 rounded-lg hover:bg-slate-200/70 dark:hover:bg-white/[0.06] active:scale-95 text-slate-700 dark:text-white hover:text-slate-900 dark:hover:text-white flex items-center justify-center gap-2 text-xs font-semibold transition-all cursor-pointer"
            title="Editar dados da moto"
          >
            <Edit3 className="w-4 h-4 text-amber-500 dark:text-amber-400" />
            <span>Editar</span>
          </button>

          {/* Apagar */}
          <button
            id={`btn-delete-moto-${moto.id}`}
            type="button"
            onClick={() => setMotoToDelete(moto)}
            className="py-2 px-2 rounded-lg hover:bg-red-500/15 active:scale-95 text-rose-600 dark:text-money-negative-light hover:text-rose-700 dark:hover:text-red-400 flex items-center justify-center gap-2 text-xs font-semibold transition-all cursor-pointer"
            title="Apagar moto do sistema"
          >
            <Trash2 className="w-4 h-4 text-rose-500 dark:text-money-negative-light" />
            <span>Apagar</span>
          </button>
        </div>
      </div>
    </div>
  );
};
