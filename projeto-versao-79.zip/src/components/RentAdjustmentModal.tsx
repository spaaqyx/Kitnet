import React, { useState, useMemo, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  TrendingUp,
  History,
  CheckCircle2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatCurrency, formatDate, isInstallmentOverdue, today } from '../utils/formatters';
import { RentAdjustment } from '../types';
import { useBodyScrollLock } from '../hooks/useBodyScrollLock';
import { CurrencyInput } from './NumericInput';

interface RentAdjustmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'moto' | 'kitnet';
  contractId?: string;
  currentValue?: number;
  currentMonthlyValue?: number;
  contractTitle?: string;
  identifier?: string;
  clientName?: string;
  tenantName?: string;
  adjustments?: RentAdjustment[];
  pendingInstallments?: { number: number; dueDate: string; amount: number }[];
}

export const RentAdjustmentModal: React.FC<RentAdjustmentModalProps> = ({
  isOpen,
  onClose,
  type,
  contractId = '',
  currentValue: propCurrentValue,
  currentMonthlyValue,
  contractTitle: propContractTitle,
  identifier,
  clientName: propClientName,
  tenantName,
  adjustments: propAdjustments,
  pendingInstallments: propPendingInstallments,
}) => {
  const {
    adjustMotoContractRent,
    adjustKitnetContractRent,
    motoContracts,
    kitnetContracts,
    isReadOnlyMode,
  } = useApp();

  useBodyScrollLock(isOpen);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Derive contract details from context if needed
  const activeContract = useMemo(() => {
    if (!contractId) return undefined;
    if (type === 'moto') {
      return motoContracts.find((c) => c.id === contractId);
    }
    return kitnetContracts.find((c) => c.id === contractId);
  }, [type, contractId, motoContracts, kitnetContracts]);

  const rawCurrentValue =
    propCurrentValue ??
    currentMonthlyValue ??
    (type === 'moto'
      ? (activeContract as any)?.monthlyValue || 0
      : (activeContract as any)?.rentValue || 0);

  const rawContractTitle =
    propContractTitle || identifier || (contractId ? `Contrato #${contractId.slice(-6)}` : 'Contrato');

  const rawClientName = propClientName || tenantName || 'Locatário';

  const rawAdjustments =
    propAdjustments || activeContract?.rentAdjustments || [];

  const rawPendingInstallments = useMemo(() => {
    if (propPendingInstallments && propPendingInstallments.length > 0) {
      return propPendingInstallments;
    }
    if (activeContract?.installments) {
      return activeContract.installments
        .filter((i) => i.status === 'pendente' || isInstallmentOverdue(i))
        .map((i) => ({ number: i.number, dueDate: i.dueDate, amount: i.amount }));
    }
    return [{ number: 1, dueDate: today(), amount: rawCurrentValue }];
  }, [propPendingInstallments, activeContract, rawCurrentValue]);

  // Cache last active data for seamless AnimatePresence exit animations
  const lastActiveRef = useRef<{
    type: 'moto' | 'kitnet';
    contractId: string;
    effectiveCurrentValue: number;
    effectiveContractTitle: string;
    effectiveClientName: string;
    effectiveAdjustments: RentAdjustment[];
    effectivePendingInstallments: { number: number; dueDate: string; amount: number }[];
  } | null>(null);

  if (isOpen && (contractId || propCurrentValue !== undefined || currentMonthlyValue !== undefined)) {
    lastActiveRef.current = {
      type,
      contractId,
      effectiveCurrentValue: rawCurrentValue,
      effectiveContractTitle: rawContractTitle,
      effectiveClientName: rawClientName,
      effectiveAdjustments: rawAdjustments,
      effectivePendingInstallments: rawPendingInstallments,
    };
  }

  const effectiveCurrentValue = lastActiveRef.current?.effectiveCurrentValue ?? rawCurrentValue;
  const effectiveContractTitle = lastActiveRef.current?.effectiveContractTitle ?? rawContractTitle;
  const effectiveClientName = lastActiveRef.current?.effectiveClientName ?? rawClientName;
  const effectiveAdjustments = lastActiveRef.current?.effectiveAdjustments ?? rawAdjustments;
  const effectivePendingInstallments = lastActiveRef.current?.effectivePendingInstallments ?? rawPendingInstallments;
  const activeContractId = lastActiveRef.current?.contractId || contractId;
  const activeType = lastActiveRef.current?.type || type;

  const [newValue, setNewValue] = useState<number>(effectiveCurrentValue);
  const [reason, setReason] = useState<string>('Reajuste anual padrão');
  const [effectiveFrom, setEffectiveFrom] = useState<number>(
    effectivePendingInstallments.length > 0 ? effectivePendingInstallments[0].number : 1
  );
  const [isSuccess, setIsSuccess] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setNewValue(effectiveCurrentValue);
      setReason('Reajuste anual padrão');
      setEffectiveFrom(effectivePendingInstallments.length > 0 ? effectivePendingInstallments[0].number : 1);
      setIsSuccess(false);
    }
  }, [isOpen, effectiveCurrentValue, effectivePendingInstallments]);

  if (typeof document === 'undefined') return null;

  const diff = newValue - effectiveCurrentValue;
  const percentChange =
    effectiveCurrentValue > 0 ? (diff / effectiveCurrentValue) * 100 : 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isReadOnlyMode) return;
    if (newValue <= 0 || !reason.trim() || !activeContractId) return;

    if (activeType === 'moto') {
      adjustMotoContractRent(activeContractId, newValue, reason.trim(), effectiveFrom);
    } else {
      adjustKitnetContractRent(activeContractId, newValue, reason.trim(), effectiveFrom);
    }

    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 1200);
  };

  return typeof document !== 'undefined'
    ? createPortal(
        <AnimatePresence>
          {isOpen && (
            <motion.div
              key="adjustment-modal-root"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.18 }}
              className="fixed inset-0 z-[100] flex items-center justify-center p-2.5 sm:p-4 font-sans"
              role="dialog"
              aria-modal="true"
              aria-label="Reajuste de Aluguel"
            >
              {/* Backdrop */}
              <motion.div
                key="adjustment-backdrop"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="fixed inset-0 bg-black/85 backdrop-blur-md"
                onClick={onClose}
              />

              {/* Dialog Card */}
              <motion.div
                key="adjustment-card"
                initial={{ opacity: 0, scale: 0.94, y: 14 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 14 }}
                transition={{ type: 'spring', damping: 28, stiffness: 350 }}
                className="relative bg-surface-card border border-border-dark rounded-2xl w-full max-w-lg mx-auto max-h-[92dvh] sm:max-h-[85vh] overflow-hidden flex flex-col shadow-2xl my-auto z-10 animate-modal-enter"
                onClick={(e) => e.stopPropagation()}
              >
        {/* Header */}
        <div className="px-5 py-4 border-b border-border-dark bg-surface-base flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-action-primary/10 text-action-primary border border-action-primary/25 shrink-0">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-text-primary">
                Reajustar Valor do Contrato
              </h3>
              <p className="text-xs text-text-secondary truncate max-w-[260px] sm:max-w-xs">
                {effectiveContractTitle} • {effectiveClientName}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-text-secondary hover:text-text-primary hover:bg-border-dark transition-all active:scale-95 cursor-pointer border border-transparent hover:border-border-dark"
            title="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4 overflow-y-auto modal-scroll-container overscroll-contain flex-1">
          {isSuccess && (
            <div className="p-3.5 rounded-xl bg-money-positive/15 border border-money-positive/30 text-money-positive text-xs font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 shrink-0" />
              <span>Reajuste aplicado com sucesso! As parcelas futuras foram recalculadas.</span>
            </div>
          )}

          {/* Current vs New comparison */}
          <div className="grid grid-cols-2 gap-3 p-3.5 rounded-xl bg-surface-base border border-border-dark">
            <div>
              <span className="text-[10px] font-semibold uppercase text-text-secondary block mb-0.5">
                Valor Atual
              </span>
              <span className="text-sm sm:text-base font-bold text-text-primary font-mono">
                {formatCurrency(effectiveCurrentValue)}
              </span>
            </div>

            <div>
              <span className="text-[10px] font-semibold uppercase text-text-secondary block mb-0.5">
                Novo Valor
              </span>
              <span className="text-sm sm:text-base font-bold text-action-primary font-mono">
                {formatCurrency(newValue)}
              </span>
              {diff !== 0 && (
                <span className={`text-[10px] block font-bold mt-0.5 ${diff > 0 ? 'text-money-positive' : 'text-money-negative'}`}>
                  {diff > 0 ? `+${formatCurrency(diff)}` : formatCurrency(diff)} ({percentChange > 0 ? `+${percentChange.toFixed(1)}` : percentChange.toFixed(1)}%)
                </span>
              )}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-text-secondary mb-1.5">
              Novo Valor da Parcela / Aluguel (R$)
            </label>
            <CurrencyInput
              value={newValue}
              onChange={(val) => setNewValue(val)}
              disabled={isReadOnlyMode}
              className="w-full px-3.5 py-2.5 rounded-xl border border-border-dark bg-surface-base text-sm font-bold text-text-primary focus:outline-none focus:border-action-primary"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-text-secondary mb-1.5">
              A partir de qual parcela aplicar?
            </label>
            <select
              value={effectiveFrom}
              onChange={(e) => setEffectiveFrom(Number(e.target.value))}
              disabled={isReadOnlyMode}
              className="w-full px-3.5 py-2.5 rounded-xl border border-border-dark bg-surface-base text-xs font-semibold text-text-primary focus:outline-none focus:border-action-primary"
            >
              {effectivePendingInstallments.map((inst) => (
                <option key={inst.number} value={inst.number}>
                  Parcela nº {inst.number} (Vence em {formatDate(inst.dueDate)})
                </option>
              ))}
            </select>
            <p className="text-[11px] text-text-secondary mt-1">
              As parcelas anteriores e já liquidadas permanecerão inalteradas.
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-text-secondary mb-1.5">
              Motivo do Reajuste / Observações
            </label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              disabled={isReadOnlyMode}
              placeholder="Ex: Reajuste anual IPCA/IGPM, Acordo de renovação, etc."
              className="w-full px-3.5 py-2.5 rounded-xl border border-border-dark bg-surface-base text-xs font-medium text-text-primary focus:outline-none focus:border-action-primary"
              required
            />
          </div>

          {/* Adjustments History */}
          {effectiveAdjustments.length > 0 && (
            <div className="pt-2 border-t border-border-dark space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-text-secondary flex items-center gap-1.5">
                <History className="w-3.5 h-3.5 text-action-primary" />
                Histórico de Reajustes Anteriores ({effectiveAdjustments.length})
              </h4>
              <div className="space-y-1.5 max-h-32 overflow-y-auto">
                {effectiveAdjustments.map((adj) => (
                  <div
                    key={adj.id}
                    className="p-2.5 rounded-lg bg-surface-base border border-border-dark text-xs flex items-center justify-between"
                  >
                    <div>
                      <div className="font-semibold text-text-primary">
                        {formatCurrency(adj.previousValue)} → {formatCurrency(adj.newValue)}
                      </div>
                      <div className="text-[10px] text-text-secondary mt-0.5">
                        {adj.reason} • {formatDate(adj.date)}
                        {adj.effectiveFromInstallment ? ` (a partir da parcela ${adj.effectiveFromInstallment})` : ''}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Footer Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-border-dark">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-border-dark text-xs font-semibold text-text-secondary hover:text-text-primary hover:bg-surface-base transition-all active:scale-95 cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isReadOnlyMode || newValue <= 0}
              className="px-5 py-2.5 rounded-xl bg-action-primary hover:bg-action-hover disabled:opacity-50 text-white text-xs font-bold transition-all active:scale-95 shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <TrendingUp className="w-4 h-4" />
              Confirmar Reajuste
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  )}
</AnimatePresence>,
document.body
) : null;
};
