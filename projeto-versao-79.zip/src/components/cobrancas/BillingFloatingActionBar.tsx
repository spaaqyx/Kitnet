import React from 'react';
import { createPortal } from 'react-dom';
import { Send, CheckCheck, X } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';
import { BillingItem } from './types';

interface BillingFloatingActionBarProps {
  selectedItems: BillingItem[];
  onOpenBatchModal: () => void;
  onOpenBatchPayModal: () => void;
  onClearSelection: () => void;
}

export const BillingFloatingActionBar: React.FC<BillingFloatingActionBarProps> = ({
  selectedItems,
  onOpenBatchModal,
  onOpenBatchPayModal,
  onClearSelection,
}) => {
  if (typeof document === 'undefined' || selectedItems.length === 0) return null;

  const totalAmount = selectedItems.reduce((acc, i) => acc + i.amount, 0);

  return createPortal(
    <div className="fixed bottom-20 sm:bottom-6 left-1/2 -translate-x-1/2 z-[90] w-full max-w-2xl px-3 sm:px-4 animate-slideUp">
      <div className="bg-surface-card/95 backdrop-blur-md border border-action-primary/60 rounded-2xl p-3 sm:p-3.5 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-2.5 sm:gap-3 font-sans">
        <div className="flex items-center gap-2.5 text-xs text-text-primary w-full sm:w-auto">
          <div className="w-7 h-7 rounded-lg bg-action-primary text-white flex items-center justify-center font-bold text-xs shrink-0">
            {selectedItems.length}
          </div>
          <div className="min-w-0">
            <span className="font-bold block truncate">
              {selectedItems.length}{' '}
              {selectedItems.length === 1 ? 'parcela selecionada' : 'parcelas selecionadas'}
            </span>
            <span className="text-action-primary font-bold tabular-nums">
              Total: {formatCurrency(totalAmount)}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end shrink-0">
          {/* Encaminhar Mensagens WhatsApp */}
          <button
            onClick={onOpenBatchModal}
            className="btn-primary flex-1 sm:flex-none px-3 sm:px-3.5 py-2 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap active:scale-95 transition-transform"
          >
            <Send className="w-4 h-4 stroke-[2.5]" />
            <span className="truncate">Encaminhar</span>
          </button>

          {/* Baixa em Lote */}
          <button
            onClick={onOpenBatchPayModal}
            className="px-3 py-2 bg-emerald-600/15 hover:bg-emerald-600/25 text-emerald-600 dark:text-emerald-400 font-semibold text-xs rounded-xl border border-emerald-500/30 hover:border-emerald-500/50 flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95"
            title="Quitar parcelas selecionadas"
          >
            <CheckCheck className="w-4 h-4" />
            <span className="hidden sm:inline">Baixa em Lote</span>
          </button>

          {/* Limpar */}
          <button
            onClick={onClearSelection}
            className="p-2 text-text-secondary hover:text-text-primary hover:bg-surface-subtle rounded-xl border border-transparent hover:border-border-subtle transition-colors cursor-pointer active:scale-95"
            title="Limpar seleção"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>,
    document.body
  );
};
