import React, { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import { useBodyScrollLock } from '../../../hooks/useBodyScrollLock';
import { CheckCheck, X } from 'lucide-react';
import { BillingItem } from '../types';
import { formatCurrency } from '../../../utils/formatters';

interface BatchPaymentModalProps {
  items: BillingItem[] | null;
  isOpen?: boolean;
  onClose: () => void;
  onConfirm: (items: BillingItem[]) => void;
}

export const BatchPaymentModal: React.FC<BatchPaymentModalProps> = ({
  items,
  isOpen: propIsOpen,
  onClose,
  onConfirm,
}) => {
  const isOpen = propIsOpen !== undefined ? propIsOpen : Boolean(items && items.length > 0);
  const prefersReducedMotion = useReducedMotion();
  const lastItemsRef = useRef<BillingItem[]>([]);

  if (items && items.length > 0) {
    lastItemsRef.current = items;
  }
  const currentItems = (items && items.length > 0) ? items : lastItemsRef.current;

  useBodyScrollLock(isOpen);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (typeof document === 'undefined') return null;

  const totalAmount = currentItems.reduce((acc, i) => acc + i.amount, 0);

  return createPortal(
    <AnimatePresence>
      {isOpen && currentItems.length > 0 && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Baixa em Lote"
          className="fixed inset-0 z-[100] flex items-center justify-center p-2.5 sm:p-4 overflow-y-auto overflow-x-hidden font-sans touch-pan-y w-full max-w-full"
          style={{ overflowX: 'hidden', touchAction: 'pan-y' }}
        >
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: prefersReducedMotion ? 0.05 : 0.2 }}
            className="fixed inset-0 bg-black/85 backdrop-blur-md"
            onClick={onClose}
          />

          {/* Modal Container */}
          <motion.div
            initial={prefersReducedMotion ? { opacity: 0 } : { opacity: 0, scale: 0.95, y: 10 }}
            animate={prefersReducedMotion ? { opacity: 1 } : { opacity: 1, scale: 1, y: 0 }}
            exit={prefersReducedMotion ? { opacity: 0 } : { opacity: 0, scale: 0.95, y: 10 }}
            transition={{
              duration: prefersReducedMotion ? 0.05 : 0.22,
              ease: [0.16, 1, 0.3, 1],
            }}
            className="relative bg-surface-card border border-border-subtle rounded-2xl sm:rounded-3xl w-full max-w-lg mx-auto min-w-0 overflow-hidden flex flex-col my-auto shadow-2xl z-10 animate-modal-enter"
          >
            <div className="p-4 sm:p-5 border-b border-border-subtle flex items-center justify-between bg-surface-header gap-2 shrink-0">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
                  <CheckCheck className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-sm sm:text-base font-bold text-text-primary truncate">Baixa em Lote</h3>
                  <p className="text-[11px] sm:text-xs text-text-secondary truncate">
                    Quitar {currentItems.length} parcelas selecionadas simultaneamente
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="w-9 h-9 rounded-xl text-text-muted hover:text-text-primary hover:bg-surface-hover border border-transparent hover:border-border-subtle transition-colors flex items-center justify-center cursor-pointer shrink-0 active:scale-90"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            <div className="p-4 sm:p-5 space-y-4 overflow-y-auto overflow-x-hidden modal-scroll-container">
              <div className="bg-surface-subtle border border-border-subtle p-4 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-xs text-text-secondary">Total a ser quitado:</span>
                  <div className="text-xl font-bold text-money-positive tabular-nums">
                    {formatCurrency(totalAmount)}
                  </div>
                </div>
                <span className="px-3 py-1 bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 rounded-lg text-xs font-bold">
                  {currentItems.length} parcelas
                </span>
              </div>

              <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                <span className="text-xs font-semibold text-text-secondary uppercase tracking-wider">
                  Parcelas a quitar:
                </span>
                {currentItems.map((item) => (
                  <div
                    key={item.id}
                    className="p-2.5 bg-surface-subtle rounded-xl border border-border-subtle flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-bold text-text-primary block">{item.clientName}</span>
                      <span className="text-text-secondary text-[11px]">
                        {item.assetName} • Parcela {item.installmentNumber}
                      </span>
                    </div>
                    <span className="font-bold text-money-positive tabular-nums">{formatCurrency(item.amount)}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-4 sm:p-5 border-t border-border-subtle flex items-center justify-end gap-2.5 bg-surface-header shrink-0">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs sm:text-sm font-semibold text-text-muted hover:text-text-primary hover:bg-surface-hover rounded-xl border border-transparent hover:border-border-subtle transition-colors cursor-pointer active:scale-95"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => onConfirm(currentItems)}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer active:scale-95 shadow-sm"
              >
                <CheckCheck className="w-4 h-4 stroke-[2.5]" />
                Confirmar Baixa de Todas
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body
  );
};
