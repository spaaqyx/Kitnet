import React from 'react';

// FormField Wrapper
export interface FormFieldProps {
  label?: string;
  error?: string;
  required?: boolean;
  hint?: string;
  children: React.ReactNode;
  className?: string;
}

export const FormField: React.FC<FormFieldProps> = ({
  label,
  error,
  required,
  hint,
  children,
  className = '',
}) => {
  return (
    <div className={`space-y-1.5 ${className}`}>
      {label && (
        <div className="flex items-center justify-between">
          <label className="text-xs font-semibold text-text-secondary tracking-tight">
            {label} {required && <span className="text-rose-500">*</span>}
          </label>
          {hint && <span className="text-[11px] text-text-dim">{hint}</span>}
        </div>
      )}
      {children}
      {error && (
        <p className="text-xs text-rose-500 font-medium tracking-tight animate-fadeIn">
          {error}
        </p>
      )}
    </div>
  );
};

// UI Input
export interface FormInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  hasError?: boolean;
}

export const FormInput = React.forwardRef<HTMLInputElement, FormInputProps>(
  ({ className = '', leftIcon, rightIcon, hasError, ...props }, ref) => {
    return (
      <div className="relative flex items-center">
        {leftIcon && (
          <div className="absolute left-3 flex items-center justify-center pointer-events-none text-text-muted">
            {leftIcon}
          </div>
        )}
        <input
          ref={ref}
          className={`w-full rounded-xl bg-surface-input border text-text-primary placeholder:text-text-dim text-xs sm:text-sm py-2 sm:py-2.5 transition-all duration-150 outline-none ${
            leftIcon ? 'pl-9 sm:pl-10' : 'pl-3 sm:pl-3.5'
          } ${rightIcon ? 'pr-9 sm:pr-10' : 'pr-3 sm:pr-3.5'} ${
            hasError
              ? 'border-rose-500 focus:border-rose-500 focus:ring-1 focus:ring-rose-500'
              : 'border-border-subtle hover:border-border-hover focus:border-action-primary focus:ring-1 focus:ring-action-primary'
          } ${className}`}
          {...props}
        />
        {rightIcon && (
          <div className="absolute right-3 flex items-center justify-center pointer-events-none text-text-muted">
            {rightIcon}
          </div>
        )}
      </div>
    );
  }
);
FormInput.displayName = 'FormInput';

// UI Select
export interface FormSelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  hasError?: boolean;
}

export const FormSelect = React.forwardRef<HTMLSelectElement, FormSelectProps>(
  ({ className = '', hasError, children, ...props }, ref) => {
    return (
      <div className="relative">
        <select
          ref={ref}
          className={`w-full appearance-none rounded-xl bg-surface-input border text-text-primary text-xs sm:text-sm py-2 sm:py-2.5 pl-3 sm:pl-3.5 pr-8 transition-all duration-150 outline-none cursor-pointer ${
            hasError
              ? 'border-rose-500 focus:border-rose-500 focus:ring-1 focus:ring-rose-500'
              : 'border-border-subtle hover:border-border-hover focus:border-action-primary focus:ring-1 focus:ring-action-primary'
          } ${className}`}
          {...props}
        >
          {children}
        </select>
        <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-text-muted">
          <svg className="w-4 h-4 fill-current" viewBox="0 0 20 20">
            <path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" />
          </svg>
        </div>
      </div>
    );
  }
);
FormSelect.displayName = 'FormSelect';

// Status Badge
export type BadgeVariant = 'success' | 'warning' | 'danger' | 'info' | 'neutral' | 'purple' | 'amber' | 'sky';

export interface StatusBadgeProps {
  variant?: BadgeVariant;
  children: React.ReactNode;
  icon?: React.ReactNode;
  className?: string;
  dot?: boolean;
}

const BADGE_VARIANTS: Record<BadgeVariant, string> = {
  success: 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30',
  warning: 'bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/30',
  danger: 'bg-rose-500/15 text-rose-700 dark:text-rose-300 border-rose-500/30',
  info: 'bg-sky-500/15 text-sky-700 dark:text-sky-300 border-sky-500/30',
  neutral: 'bg-surface-elevated text-text-secondary border-border-subtle',
  purple: 'bg-purple-500/15 text-purple-700 dark:text-purple-300 border-purple-500/30',
  amber: 'bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/30',
  sky: 'bg-sky-500/15 text-sky-700 dark:text-sky-300 border-sky-500/30',
};

const DOT_COLORS: Record<BadgeVariant, string> = {
  success: 'bg-emerald-500',
  warning: 'bg-amber-500',
  danger: 'bg-rose-500',
  info: 'bg-sky-500',
  neutral: 'bg-text-muted',
  purple: 'bg-purple-500',
  amber: 'bg-amber-500',
  sky: 'bg-sky-400',
};

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  variant = 'neutral',
  children,
  icon,
  className = '',
  dot = false,
}) => {
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold border tracking-tight shrink-0 select-none ${BADGE_VARIANTS[variant]} ${className}`}
    >
      {dot && <span className={`w-1.5 h-1.5 rounded-full ${DOT_COLORS[variant]} shrink-0`} />}
      {icon}
      <span>{children}</span>
    </span>
  );
};
