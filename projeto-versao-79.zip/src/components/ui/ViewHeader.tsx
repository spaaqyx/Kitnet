import React from 'react';

export interface ViewHeaderProps {
  title: string;
  subtitle?: string;
  badge?: React.ReactNode;
  icon?: React.ReactNode;
  actions?: React.ReactNode;
  className?: string;
}

export const ViewHeader: React.FC<ViewHeaderProps> = ({
  title,
  subtitle,
  badge,
  icon,
  actions,
  className = '',
}) => {
  return (
    <div
      className={`p-4 sm:p-5 bg-surface-sidebar border border-border-subtle rounded-2xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3.5 ${className}`}
    >
      <div className="flex items-center gap-3 min-w-0">
        {icon && (
          <div className="w-10 h-10 rounded-xl bg-surface-subtle border border-border-subtle text-action-primary flex items-center justify-center shrink-0 shadow-xs">
            {icon}
          </div>
        )}
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl sm:text-2xl font-bold text-text-primary tracking-tight truncate">
              {title}
            </h1>
            {badge}
          </div>
          {subtitle && (
            <p className="text-xs sm:text-sm text-text-secondary mt-0.5 truncate">
              {subtitle}
            </p>
          )}
        </div>
      </div>

      {actions && (
        <div className="flex items-center gap-2 shrink-0 self-start sm:self-auto flex-wrap sm:flex-nowrap">
          {actions}
        </div>
      )}
    </div>
  );
};
