import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { CreditCard, X, Smartphone, DollarSign, Check } from 'lucide-react';
import { Expense } from '../../types';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { useBodyScrollLock } from '../../hooks/useBodyScrollLock';
import { getCategoryLabel } from './financeiroHelpers';

interface PayExpenseModalProps {
  expense: Expense | null;
  onClose: () => void;
  onConfirm: (expenseId: string, paymentMethod: string, paymentNote: string) => void;
}

export const PayExpenseModal: React.FC<PayExpenseModalProps> = ({
  expense,
  onClose,
  onConfirm,
}) => {
  const [paymentMethod, setPaymentMethod] = useState<'PIX' | 'Dinheiro' | 'Transferência' | 'Cartão'>('PIX');
  const [paymentNote, setPaymentNote] = useState<string>('');

  useBodyScrollLock(!!expense);

  useEffect(() => {
    if (!expense) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [expense, onClose]);

  if (!expense || typeof document === 'undefined') return null;

  const handleConfirm = () => {
    onConfirm(expense.id, paymentMethod, paymentNote);
  };

  return createPortal(
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Confirmar Pagamento de Despesa"
      className="fixed inset-0 z-[100] flex items-center justify-center p-2.5 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn font-sans"
    >
      <div className="bg-surface-sidebar border border-border-subtle rounded-2xl sm:rounded-3xl w-full max-w-lg mx-auto max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl shadow-black/40 dark:shadow-black/80 my-auto animate-modal-enter min-w-0">
        <div className="p-4 sm:p-5 border-b border-border-subtle flex items-center justify-between bg-surface-card shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">Confirmar Pagamento</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Dar baixa e quitar despesa</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-surface-subtle border border-transparent hover:border-border-subtle transition-all cursor-pointer shrink-0 active:scale-95"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto min-h-0 p-4 sm:p-5 space-y-4 custom-scrollbar bg-surface-card">
          {/* Summary Card */}
          <div className="p-4 rounded-2xl bg-surface-subtle border border-border-subtle space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Despesa:</span>
              <span className="text-xs font-bold text-slate-900 dark:text-white">{expense.title}</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500 dark:text-slate-400 font-medium">Categoria:</span>
              <span className="text-slate-900 dark:text-white font-medium capitalize">{getCategoryLabel(expense.category)}</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500 dark:text-slate-400 font-medium">Vencimento:</span>
              <span className="text-slate-900 dark:text-white font-medium">{formatDate(expense.dueDate)}</span>
            </div>
            <div className="pt-2 border-t border-border-subtle flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Valor a Pagar:</span>
              <span className="text-lg font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                {formatCurrency(expense.amount)}
              </span>
            </div>
          </div>

          {/* Payment Method Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Forma de Pagamento
            </label>
            <div className="grid grid-cols-2 gap-2">
              {(['PIX', 'Dinheiro', 'Transferência', 'Cartão'] as const).map((method) => (
                <button
                  key={method}
                  type="button"
                  onClick={() => setPaymentMethod(method)}
                  className={`px-3 py-2.5 rounded-xl text-xs font-bold transition-all border flex items-center justify-center gap-1.5 cursor-pointer uppercase active:scale-95 ${
                    paymentMethod === method
                      ? 'bg-emerald-600 text-white border-emerald-500 shadow-md shadow-emerald-600/25'
                      : 'bg-surface-subtle text-slate-600 dark:text-slate-400 border-border-subtle hover:border-border-highlight hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {method === 'PIX' && <Smartphone className="w-3.5 h-3.5" />}
                  {method === 'Dinheiro' && <DollarSign className="w-3.5 h-3.5" />}
                  {method === 'Transferência' && <CreditCard className="w-3.5 h-3.5" />}
                  {method === 'Cartão' && <CreditCard className="w-3.5 h-3.5" />}
                  <span>{method}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Payment Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Observações (Opcional)
            </label>
            <input
              type="text"
              placeholder="Ex: Pago com chave PIX da conta bancária..."
              value={paymentNote}
              onChange={(e) => setPaymentNote(e.target.value)}
              className="w-full bg-surface-subtle border border-border-subtle hover:border-border-highlight focus:bg-surface-card rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/25 transition-all"
            />
          </div>
        </div>

        {/* Action Buttons Footer */}
        <div className="p-3.5 sm:p-4 border-t border-border-subtle flex items-center justify-end gap-2.5 bg-surface-card shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-surface-subtle transition-all cursor-pointer active:scale-95"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleConfirm}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-xs sm:text-sm rounded-xl flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-emerald-600/25"
          >
            <Check className="w-4 h-4 stroke-[3]" />
            <span>Confirmar Pagamento</span>
          </button>
        </div>
      </div>
    </div>,
    document.body
  );
};
