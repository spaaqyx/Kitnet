import React, { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import {
  X,
  User,
  Shield,
  FileText,
  DollarSign,
  AlertTriangle,
  Send,
  Camera,
  Trash2,
  ZoomIn,
  RefreshCw,
} from 'lucide-react';
import { MotoTenant, KitnetTenant, ClientScore } from '../types';
import { useApp } from '../context/AppContext';
import { formatCurrency, formatDate, formatCPF, formatPhone, getDaysUntil } from '../utils/formatters';
import { calculateClientScore } from '../utils/scoreCalculator';
import { ScrollableChips } from './ScrollableChips';
import { useBodyScrollLock } from '../hooks/useBodyScrollLock';
import { ClientDetailProfileTab } from './clients/detail/ClientDetailProfileTab';
import { ClientDetailScoreTab } from './clients/detail/ClientDetailScoreTab';
import { ClientDetailContractsTab } from './clients/detail/ClientDetailContractsTab';
import { ClientDetailOccurrencesTab } from './clients/detail/ClientDetailOccurrencesTab';
import { ClientDetailDocumentsTab } from './clients/detail/ClientDetailDocumentsTab';
import { compressImage } from '../utils/imageUtils';
import { PhotoZoomModal } from './common/PhotoZoomModal';
import { getWhatsAppUrl } from '../utils/whatsappGenerator';

export interface ClientDetailDrawerProps {
  isOpen?: boolean;
  tenantId: string | null;
  tenantType: 'moto' | 'kitnet';
  onClose: () => void;
  onOpenWhatsApp?: (contractId?: string, installmentId?: string) => void;
}

export const ClientDetailDrawer: React.FC<ClientDetailDrawerProps> = ({
  isOpen = true,
  tenantId,
  tenantType,
  onClose,
  onOpenWhatsApp,
}) => {
  const {
    motoTenants,
    kitnetTenants,
    motoContracts,
    kitnetContracts,
    motos,
    kitnets,
    updateMotoTenant,
    updateKitnetTenant,
    addTimelineEvent,
  } = useApp();

  const [activeTab, setActiveTab] = useState<
    'perfil' | 'contratos' | 'score' | 'ocorrencias' | 'documentos'
  >('perfil');

  // Photo management state
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [photoError, setPhotoError] = useState<string | null>(null);
  const [photoPreviewModal, setPhotoPreviewModal] = useState<{ url: string; title: string } | null>(null);

  const shouldReduceMotion = useReducedMotion();
  const [isMobile, setIsMobile] = useState<boolean>(() =>
    typeof window !== 'undefined' ? window.innerWidth < 640 : false
  );

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 640);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useBodyScrollLock(isOpen);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (photoPreviewModal) {
          setPhotoPreviewModal(null);
        } else {
          onClose();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, photoPreviewModal, onClose]);

  // Defensive early check: if not open or no tenantId, return early from render
  // Find tenant by ID based on type
  const tenant: MotoTenant | KitnetTenant | undefined = !tenantId
    ? undefined
    : tenantType === 'moto'
      ? motoTenants.find((t) => t.id === tenantId)
      : kitnetTenants.find((t) => t.id === tenantId);

  // Find related contracts
  const userContracts = !tenantId
    ? []
    : tenantType === 'moto'
      ? motoContracts.filter((c) => c.tenantId === tenantId)
      : kitnetContracts.filter((c) => c.tenantId === tenantId);

  // Calculate score dynamically
  const defaultScore: ClientScore = {
    score: 0,
    classification: 'medio',
    factors: { punctuality: 0, longevity: 0, documentation: 0, occurrencesPenalty: 0 },
    summary: 'Aguardando dados',
  };
  const clientScore: ClientScore = tenant ? calculateClientScore(tenant, userContracts) : defaultScore;

  // CNH Expiration status check
  const getCNHStatus = (expirationDate: string) => {
    const diffDays = getDaysUntil(expirationDate);

    if (diffDays < 0) {
      return { label: 'CNH VENCIDA', badgeClass: 'bg-money-negative/20 text-money-negative border-money-negative/40' };
    }
    if (diffDays <= 30) {
      return { label: `VENCE EM ${diffDays} DIAS`, badgeClass: 'bg-action-primary/20 text-action-primary border-action-primary/40' };
    }
    return { label: 'CNH REGULAR', badgeClass: 'bg-money-positive/20 text-money-positive border-money-positive/40' };
  };

  const scoreBadgeColors = {
    excelente: 'bg-money-positive/15 text-money-positive border-money-positive/30',
    medio: 'bg-action-primary/15 text-action-primary border-action-primary/30',
    risco: 'bg-money-negative/15 text-money-negative border-money-negative/30',
  };

  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !tenant) return;

    try {
      setIsUploadingPhoto(true);
      setPhotoError(null);
      const base64Data = await compressImage(file, 800, 800, 0.70);
      if (tenantType === 'moto') {
        updateMotoTenant(tenant.id, {
          photoUrl: base64Data,
          documents: {
            ...tenant.documents,
            photo: base64Data,
          },
        });
      } else {
        updateKitnetTenant(tenant.id, {
          photoUrl: base64Data,
          documents: {
            ...tenant.documents,
            photo: base64Data,
          },
        });
      }

      addTimelineEvent({
        type: 'ocorrencia_cliente',
        title: `Foto do cliente atualizada`,
        description: `Foto de perfil atualizada para ${tenant.fullName}`,
        entityType: 'cliente',
        entityId: tenant.id,
      });
    } catch {
      setPhotoError('Erro ao carregar ou comprimir a imagem. Tente novamente.');
      setTimeout(() => setPhotoError(null), 4000);
    } finally {
      setIsUploadingPhoto(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleRemovePhoto = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!tenant) return;
    if (tenantType === 'moto') {
      updateMotoTenant(tenant.id, {
        photoUrl: undefined,
        documents: {
          ...tenant.documents,
          photo: undefined,
        },
      });
    } else {
      updateKitnetTenant(tenant.id, {
        photoUrl: undefined,
        documents: {
          ...tenant.documents,
          photo: undefined,
        },
      });
    }
  };

  return typeof document !== 'undefined'
    ? createPortal(
        <AnimatePresence>
          {isOpen && tenant && (
            <motion.div
              key="client-drawer-root"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 z-50 overflow-hidden flex items-end sm:items-stretch justify-center sm:justify-end font-sans"
              role="dialog"
              aria-modal="true"
              aria-label="Detalhes do Cliente"
            >
              {/* Backdrop */}
              <motion.div
                key="client-drawer-backdrop"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="fixed inset-0 bg-black/70 backdrop-blur-xs"
                onClick={onClose}
              />

              {/* Modal de visualização de foto ampliada */}
              <PhotoZoomModal
                photo={photoPreviewModal}
                onClose={() => setPhotoPreviewModal(null)}
              />

              <motion.div
                key="client-drawer-body"
                initial={{
                  x: shouldReduceMotion ? 0 : (isMobile ? 0 : '100%'),
                  y: shouldReduceMotion ? 0 : (isMobile ? '100%' : 0),
                  opacity: shouldReduceMotion ? 0 : 1,
                }}
                animate={{
                  x: 0,
                  y: 0,
                  opacity: 1,
                }}
                exit={{
                  x: shouldReduceMotion ? 0 : (isMobile ? 0 : '100%'),
                  y: shouldReduceMotion ? 0 : (isMobile ? '100%' : 0),
                  opacity: shouldReduceMotion ? 0 : 1,
                  transition: { duration: 0.2, ease: [0.16, 1, 0.3, 1] },
                }}
                transition={{ type: 'spring', damping: 28, stiffness: 320 }}
                className="relative z-10 w-full max-w-2xl bg-surface-card border-t sm:border-t-0 sm:border-l border-border-dark rounded-t-3xl sm:rounded-none h-[90vh] sm:h-full flex flex-col shadow-2xl overflow-hidden"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Mobile Drag Indicator Bar */}
                <div className="w-10 h-1 bg-white/20 rounded-full mx-auto my-2.5 sm:hidden shrink-0" />
            {/* Drawer Header */}
            <div className="p-4 sm:p-5 border-b border-white/[0.08] flex items-center justify-between bg-surface-subtle shrink-0 gap-3">
              <div className="flex items-center gap-3 min-w-0">
                {/* Client Avatar with Upload/Zoom Capabilities */}
                <div className="relative group w-11 h-11 sm:w-12 sm:h-12 rounded-2xl overflow-hidden bg-surface-card border border-white/[0.12] flex items-center justify-center shrink-0 shadow-sm">
                  {tenant.photoUrl || tenant.documents?.photo ? (
                    <>
                      <img
                        src={tenant.photoUrl || tenant.documents?.photo}
                        alt={tenant.fullName}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1.5">
                        <button
                          type="button"
                          onClick={() =>
                            setPhotoPreviewModal({
                              url: tenant.photoUrl || tenant.documents?.photo || '',
                              title: `Foto: ${tenant.fullName}`,
                            })
                          }
                          className="p-1.5 bg-black/80 hover:bg-black text-white rounded-lg cursor-pointer transition-all active:scale-90"
                          title="Ampliar foto"
                          aria-label="Ampliar foto do cliente"
                        >
                          <ZoomIn className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={handleRemovePhoto}
                          className="p-1.5 bg-red-600 hover:bg-red-500 text-white rounded-lg cursor-pointer transition-all active:scale-90"
                          title="Remover foto"
                          aria-label="Remover foto do cliente"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </>
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-violet-300 font-bold text-lg bg-gradient-to-br from-violet-500/20 to-purple-600/30">
                      {tenant.fullName.charAt(0).toUpperCase()}
                    </div>
                  )}
                </div>

                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="text-sm sm:text-base font-bold text-text-primary tracking-tight truncate">{tenant.fullName}</h2>
                    <span
                      className={`px-2 py-0.5 rounded-lg text-[10px] font-bold uppercase tracking-wider shrink-0 border ${
                        tenantType === 'moto'
                          ? 'bg-orange-500/10 text-orange-600 dark:text-orange-400 border-orange-500/25'
                          : 'bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-500/25'
                      }`}
                    >
                      {tenantType === 'moto' ? 'Locatário Moto' : 'Inquilino Kitnet'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-text-muted font-mono mt-0.5 flex-wrap">
                    <span className="whitespace-nowrap">CPF: {formatCPF(tenant.cpf)}</span>
                    <span className="text-text-muted hidden sm:inline">•</span>
                    <span className="whitespace-nowrap text-text-secondary">{formatPhone(tenant.whatsapp || tenant.phone)}</span>
                  </div>
                  {photoError && (
                    <p className="text-[11px] text-rose-500 dark:text-rose-400 mt-1 font-medium bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20 animate-fadeIn">
                      {photoError}
                    </p>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  onChange={handlePhotoSelect}
                  className="hidden"
                  id={`drawer-photo-upload-${tenant.id}`}
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploadingPhoto}
                  className="p-2 sm:p-2.5 rounded-xl bg-surface-card hover:bg-surface-elevated text-text-secondary hover:text-text-primary border border-border-subtle hover:border-violet-500/30 transition-all cursor-pointer active:scale-90 shadow-xs"
                  title="Alterar foto do cliente"
                  aria-label="Alterar foto do cliente"
                >
                  {isUploadingPhoto ? <RefreshCw className="w-4 h-4 animate-spin text-violet-400" /> : <Camera className="w-4 h-4" />}
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="p-2 sm:p-2.5 rounded-xl bg-surface-card hover:bg-rose-500/15 text-text-secondary hover:text-rose-500 dark:hover:text-rose-400 border border-border-subtle hover:border-rose-500/30 transition-all cursor-pointer active:scale-90 shadow-xs"
                  title="Fechar"
                  aria-label="Fechar painel do cliente"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Navigation Tabs */}
            <div className="border-b border-white/[0.08] px-3 sm:px-4 py-2.5 bg-surface-subtle shrink-0">
              <ScrollableChips
                items={[
                  { id: 'perfil', label: 'Perfil', icon: User },
                  { id: 'score', label: 'Score', count: clientScore.score, icon: Shield },
                  { id: 'contratos', label: 'Contratos & Pagamentos', count: userContracts.length, icon: DollarSign },
                  { id: 'ocorrencias', label: 'Ocorrências', count: (tenant.occurrences || []).length, icon: AlertTriangle },
                  { id: 'documentos', label: 'Documentos', count: Object.values(tenant.documents || {}).filter(Boolean).length, icon: FileText },
                ]}
                activeId={activeTab}
                onSelect={(id) => setActiveTab(id as any)}
                variant={tenantType === 'moto' ? 'moto' : 'kitnet'}
                size="sm"
              />
            </div>

            {/* Drawer Body with smooth crossfade */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-surface-base no-scrollbar">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 10, scale: 0.99 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -8, scale: 0.99 }}
                  transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
                  className="space-y-4"
                >
                  {activeTab === 'perfil' && (
                    <ClientDetailProfileTab
                      tenant={tenant}
                      tenantType={tenantType}
                      clientScore={clientScore}
                      scoreBadgeColors={scoreBadgeColors}
                      setActiveTab={setActiveTab}
                      formatCPF={formatCPF}
                      formatDate={formatDate}
                      formatPhone={formatPhone}
                      formatCurrency={formatCurrency}
                      getCNHStatus={getCNHStatus}
                    />
                  )}

                  {activeTab === 'score' && (
                    <ClientDetailScoreTab
                      clientScore={clientScore}
                      scoreBadgeColors={scoreBadgeColors}
                    />
                  )}

                  {activeTab === 'contratos' && (
                    <ClientDetailContractsTab
                      userContracts={userContracts}
                      tenantType={tenantType}
                      motos={motos}
                      kitnets={kitnets}
                      formatCurrency={formatCurrency}
                      formatDate={formatDate}
                    />
                  )}

                  {activeTab === 'ocorrencias' && (
                    <ClientDetailOccurrencesTab
                      tenant={tenant}
                      tenantType={tenantType}
                      formatDate={formatDate}
                    />
                  )}

                  {activeTab === 'documentos' && (
                    <ClientDetailDocumentsTab tenant={tenant} />
                  )}
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Drawer Bottom Actions */}
            <div className="p-3.5 sm:p-4 border-t border-white/[0.08] bg-surface-subtle flex items-center justify-between gap-2 sm:gap-3 shrink-0">
              <a
                href={getWhatsAppUrl(tenant.whatsapp || tenant.phone)}
                target="_blank"
                rel="noreferrer"
                className="flex-1 h-10 px-3 sm:px-4 rounded-xl bg-social-whatsapp hover:bg-money-positive-hover active:scale-95 text-slate-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 cursor-pointer transition-all duration-150 shadow-sm shadow-social-whatsapp/20 truncate"
              >
                <Send className="w-3.5 h-3.5 shrink-0" />
                <span>Conversar</span>
                <span className="hidden sm:inline">no WhatsApp</span>
              </a>
              {userContracts.length > 0 && onOpenWhatsApp && (
                <button
                  type="button"
                  onClick={() => onOpenWhatsApp(userContracts[0].id)}
                  className={`h-10 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-1.5 cursor-pointer transition-all duration-150 active:scale-95 shrink-0 border ${
                    tenantType === 'moto'
                      ? 'bg-orange-500/10 hover:bg-orange-500/20 text-orange-400 hover:text-orange-300 border-orange-500/30 hover:border-orange-500/50'
                      : 'bg-sky-500/10 hover:bg-sky-500/20 text-sky-400 hover:text-sky-300 border-sky-500/30 hover:border-sky-500/50'
                  }`}
                >
                  <Send className="w-3.5 h-3.5 shrink-0" />
                  <span>Cobrança</span>
                </button>
              )}
              <button
                onClick={onClose}
                className="h-10 px-3.5 sm:px-4 rounded-xl bg-surface-card hover:bg-surface-elevated text-text-secondary hover:text-text-primary border border-border-subtle hover:border-border-hover text-xs sm:text-sm font-semibold cursor-pointer transition-all duration-150 active:scale-95 shrink-0"
              >
                Fechar
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  )
: null;
};
