import React from 'react';

interface HighlightMissingTextProps {
  text: string;
  className?: string;
}

/**
 * Componente unificado para destacar campos não preenchidos na cor vermelha (text-rose-400),
 * mantendo exatamente o mesmo tamanho da fonte do texto ao redor (inline).
 * Padronizado para Contratos de Moto e Kitnet.
 */
export const HighlightMissingText: React.FC<HighlightMissingTextProps> = ({
  text,
  className = '',
}) => {
  if (!text) return null;

  // Detecta qualquer placeholder entre colchetes ou termos indicativos de não preenchimento
  const regex = /(\[[^\]]*(?:não informad|obrigat|pendente)[^\]]*\]|\[[^\]]+\]|\(Modelo não informado\)|Modelo não informado|Placa não informada|Endereço não informado|Cor não informada|Ano não informado|Telefone não informado|E-mail não informado|Chassi não informado|RENAVAM não informado|CNH não informada|Profissão não informada|Nome não informado|CPF não informado|Não informado|Não informada)/gi;

  const parts = text.split(regex);
  if (parts.length <= 1) {
    return <span className={className}>{text}</span>;
  }

  return (
    <span className={className}>
      {parts.map((part, index) => {
        if (regex.test(part)) {
          return (
            <span
              key={index}
              className="text-rose-400 font-bold inline"
              title="Campo não preenchido"
            >
              {part}
            </span>
          );
        }
        return <React.Fragment key={index}>{part}</React.Fragment>;
      })}
    </span>
  );
};
