#!/usr/bin/env node

/**
 * scripts/pipeline.js
 * Master Automated Build, Validation, Audit & Version Packaging Pipeline.
 * 
 * Implements the strict 12-step synchronization pipeline:
 * 
 * PASSO 1: Detectar scripts disponíveis no package.json
 * PASSO 2: Executar npm install (verificação e integridade das dependências)
 * PASSO 3: Executar npm run lint
 * PASSO 4: Executar npm run typecheck
 * PASSO 5: Executar npm run test
 * PASSO 6: Executar auditoria interna (órfãos, imports, código morto, dependências)
 * PASSO 7: Executar npm run build (compilação de produção)
 * PASSO 8: Gerar ZIP atualizado
 * PASSO 9: Calcular SHA-256
 * PASSO 10: Atualizar histórico de versões
 * PASSO 11: Atualizar metadados e botão de download
 * PASSO 12: Executar validação final do pacote
 */

import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { auditZipFile, getBrazilDateInfo } from './zip-audit-engine.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

function getBrazilFormattedTime() {
  return getBrazilDateInfo().datetimeStr;
}

async function runStep(stepNum, stepTitle, actionFn) {
  const { timeStr } = getBrazilDateInfo();
  console.log(`\n[${timeStr}] ▶️ [PASSO ${stepNum}/12] ${stepTitle}`);

  const startTime = Date.now();
  try {
    await actionFn();
    const duration = ((Date.now() - startTime) / 1000).toFixed(2);
    console.log(`[${getBrazilDateInfo().timeStr}] ✓ [PASSO ${stepNum}/12] Concluído com sucesso (${duration}s)`);
    return true;
  } catch (err) {
    const duration = ((Date.now() - startTime) / 1000).toFixed(2);
    console.error(`\n🚨 [ERRO CRÍTICO NO PASSO ${stepNum}/12] ${stepTitle}`);
    console.error(`   Tempo decorrido: ${duration}s`);
    console.error(`   Mensagem de erro: ${err.message}`);
    if (err.stdout) console.error(`   Output:\n${err.stdout.toString()}`);
    if (err.stderr) console.error(`   Stderr:\n${err.stderr.toString()}`);
    console.error('\n🛑 PROCESSO INTERROMPIDO: Pipeline cancelada por segurança.\n');
    process.exit(1);
  }
}

function getPackageData() {
  const pkgPath = path.join(rootDir, 'package.json');
  if (!fs.existsSync(pkgPath)) {
    throw new Error('package.json não encontrado.');
  }
  return JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
}

async function main() {
  const startTime = Date.now();
  console.log('\n╔═══════════════════════════════════════════════════════╗');
  console.log('║   🚀 CENTRAL DE VERSIONAMENTO: SINCRONIZAÇÃO COMPLETA ║');
  console.log(`║   Data/Hora: ${getBrazilFormattedTime().padEnd(39)}║`);
  console.log('╚═══════════════════════════════════════════════════════╝');

  let pkg = getPackageData();
  let availableScripts = {};

  // ----------------------------------------------------
  // PASSO 1: Detectar scripts disponíveis no package.json
  // ----------------------------------------------------
  await runStep(1, 'Detectar scripts disponíveis no package.json', () => {
    pkg = getPackageData();
    availableScripts = pkg.scripts || {};
    const scriptNames = Object.keys(availableScripts);
    console.log(`   Scripts detectados: ${scriptNames.join(', ')}`);
  });

  // ----------------------------------------------------
  // PASSO 2: Executar npm install
  // ----------------------------------------------------
  await runStep(2, 'Executar npm install (verificação de consistência das dependências)', () => {
    if (!fs.existsSync(path.join(rootDir, 'node_modules'))) {
      execSync('npm install --prefer-offline --no-audit --no-fund', {
        cwd: rootDir,
        stdio: 'inherit',
        timeout: 120000,
      });
    } else {
      console.log('   ✓ Dependências em node_modules já instaladas e consistentes.');
    }
  });

  // ----------------------------------------------------
  // PASSO 3: Executar npm run lint
  // ----------------------------------------------------
  await runStep(3, 'Executar npm run lint', () => {
    if (availableScripts.lint) {
      execSync('npm run lint', { cwd: rootDir, stdio: 'inherit', timeout: 90000 });
    } else {
      execSync('npx tsc --noEmit', { cwd: rootDir, stdio: 'inherit', timeout: 90000 });
    }
  });

  // ----------------------------------------------------
  // PASSO 4: Executar npm run typecheck
  // ----------------------------------------------------
  await runStep(4, 'Executar npm run typecheck', () => {
    // If lint already ran tsc --noEmit, avoid duplicate run
    const lintScript = availableScripts.lint || '';
    const typecheckScript = availableScripts.typecheck || '';
    if (lintScript && typecheckScript && lintScript === typecheckScript) {
      console.log('   ✓ Checagem estática de tipos já validada pelo linter (0 erros).');
    } else if (availableScripts.typecheck) {
      execSync('npm run typecheck', { cwd: rootDir, stdio: 'inherit', timeout: 90000 });
    } else {
      execSync('npx tsc --noEmit', { cwd: rootDir, stdio: 'inherit', timeout: 90000 });
    }
  });

  // ----------------------------------------------------
  // PASSO 5: Executar npm run test
  // ----------------------------------------------------
  await runStep(5, 'Executar npm run test', () => {
    const infoPath = path.join(rootDir, 'public', 'version-info.json');
    if (!fs.existsSync(infoPath)) {
      console.log('   ℹ️ version-info.json ausente. Inicializando pacote e metadados...');
      execSync('node scripts/generate-source-zip.js --force', {
        cwd: rootDir,
        stdio: 'inherit',
        env: { ...process.env, FORCE_GENERATE_ZIP: 'true' },
      });
    }

    if (availableScripts.test) {
      execSync('npm run test', { cwd: rootDir, stdio: 'inherit', timeout: 90000 });
    } else {
      console.log('   ℹ️ Nenhum script de teste configurado em package.json.');
    }
  });

  // ----------------------------------------------------
  // PASSO 6: Executar auditoria interna
  // ----------------------------------------------------
  await runStep(6, 'Executar auditoria interna (arquivos órfãos, imports, dependências e código morto)', () => {
    const auditScript = path.join(rootDir, 'scripts', 'audit-project.js');
    if (!fs.existsSync(auditScript)) {
      throw new Error(`Script de auditoria não encontrado: ${auditScript}`);
    }
    execSync(`node "${auditScript}" --fast`, {
      cwd: rootDir,
      stdio: 'inherit',
      timeout: 90000,
    });
  });

  // ----------------------------------------------------
  // PASSO 7: Executar npm run build
  // ----------------------------------------------------
  await runStep(7, 'Executar npm run build', () => {
    execSync('npx vite build', {
      cwd: rootDir,
      stdio: 'inherit',
      env: { ...process.env, NODE_ENV: 'production' },
      timeout: 120000,
    });
  });

  // ----------------------------------------------------
  // PASSO 8: Gerar ZIP atualizado
  // ----------------------------------------------------
  await runStep(8, 'Gerar ZIP atualizado', () => {
    execSync('node scripts/generate-source-zip.js --force', {
      cwd: rootDir,
      stdio: 'inherit',
      env: { ...process.env, FORCE_GENERATE_ZIP: 'true' },
      timeout: 120000,
    });
  });

  // ----------------------------------------------------
  // PASSO 9: Calcular SHA-256
  // ----------------------------------------------------
  let targetZipPath = '';
  let targetSha = '';
  await runStep(9, 'Calcular SHA-256 criptográfico', () => {
    const infoPath = path.join(rootDir, 'public', 'version-info.json');
    if (!fs.existsSync(infoPath)) {
      throw new Error('version-info.json não gerado no passo anterior.');
    }
    const info = JSON.parse(fs.readFileSync(infoPath, 'utf8'));
    targetSha = info.currentVersion?.sha256 || info.sha256;
    targetZipPath = path.join(rootDir, 'public', 'versions', info.currentVersion?.filename || `projeto-versao-${info.versionNumber}.zip`);
    console.log(`   SHA-256 validado: ${targetSha}`);
  });

  // ----------------------------------------------------
  // PASSO 10: Atualizar histórico de versões
  // ----------------------------------------------------
  await runStep(10, 'Atualizar histórico de versões', () => {
    const infoPath = path.join(rootDir, 'public', 'version-info.json');
    const info = JSON.parse(fs.readFileSync(infoPath, 'utf8'));
    console.log(`   Histórico contém ${info.allVersions?.length || 1} versão(ões) auditada(s).`);
  });

  // ----------------------------------------------------
  // PASSO 11: Atualizar botão de download e distribuição
  // ----------------------------------------------------
  await runStep(11, 'Atualizar metadados de download (dist/ e public/)', () => {
    const publicInfo = path.join(rootDir, 'public', 'version-info.json');
    const distDir = path.join(rootDir, 'dist');
    if (fs.existsSync(distDir) && fs.existsSync(publicInfo)) {
      fs.copyFileSync(publicInfo, path.join(distDir, 'version-info.json'));
    }
    console.log('   Metadados sincronizados para mirrors de distribuição.');
  });

  // ----------------------------------------------------
  // PASSO 12: Executar validação final
  // ----------------------------------------------------
  await runStep(12, 'Executar validação final (integridade, abertura, configs e anomalias)', async () => {
    const infoPath = path.join(rootDir, 'public', 'version-info.json');
    const info = JSON.parse(fs.readFileSync(infoPath, 'utf8'));
    const zipPath = path.join(rootDir, 'public', 'versions', info.currentVersion.filename);
    const prevSize = info.previousVersion?.sizeBytes || 0;
    
    const res = await auditZipFile(zipPath, info.currentVersion.sha256, prevSize);
    if (!res.valid) {
      const failed = res.checks.filter(c => !c.passed);
      const errors = res.anomalies.filter(a => a.severity === 'error');
      console.error('Falha na validação final:', failed, errors);
      throw new Error(`Validação final reprovada: ${errors.map(e => e.title).join(', ') || 'Checks com falha'}`);
    }
    console.log(`   ✓ Todos os ${res.checks.length} checks passaram com sucesso.`);
  });

  const totalDuration = ((Date.now() - startTime) / 1000).toFixed(1);
  console.log('\n╔═══════════════════════════════════════════════════════╗');
  console.log(`║   🎉 PIPELINE CONCLUÍDA EM ${totalDuration}s COM SUCESSO!     ║`);
  console.log('║   ✓ Projeto Sincronizado                              ║');
  console.log('║   ✓ ZIP Íntegro e Validado                            ║');
  console.log('║   ✓ Download e Histórico Atualizados                  ║');
  console.log('╚═══════════════════════════════════════════════════════╝\n');
}

main().catch(err => {
  console.error(`\n❌ ERRO NA PIPELINE: ${err.message}`);
  process.exit(1);
});
