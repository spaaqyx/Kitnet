#!/usr/bin/env node

/**
 * scripts/run-tests.js
 * Test Runner for core application business logic, validations, and calculators.
 */

import assert from 'node:assert';
import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

// Bootstrap public/version-info.json if missing so tests are self-healing
const versionInfoPath = path.join(rootDir, 'public/version-info.json');
if (!fs.existsSync(versionInfoPath)) {
  const genScript = path.join(rootDir, 'scripts/generate-source-zip.js');
  if (fs.existsSync(genScript)) {
    try {
      execSync(`node "${genScript}" --force`, { cwd: rootDir, stdio: 'pipe' });
    } catch {
      const pkg = JSON.parse(fs.readFileSync(path.join(rootDir, 'package.json'), 'utf8'));
      const ver = (pkg.version || '1').replace(/^(\d+).*/, '$1');
      const fallbackInfo = {
        version: ver,
        versionNumber: parseInt(ver, 10),
        currentVersion: {
          num: parseInt(ver, 10),
          version: `Versão ${ver}`,
          filename: `projeto-versao-${ver}.zip`,
          downloadUrl: `/versions/projeto-versao-${ver}.zip`,
        },
        allVersions: [],
      };
      fs.writeFileSync(versionInfoPath, JSON.stringify(fallbackInfo, null, 2), 'utf8');
    }
  }
}

console.log('\n=======================================================');
console.log('🧪 [TESTES AUTOMATIZADOS] Executando suíte de testes...');
console.log('=======================================================');

let passedTests = 0;
let failedTests = 0;

function test(name, fn) {
  try {
    fn();
    console.log(`  ✓ ${name}`);
    passedTests++;
  } catch (err) {
    console.error(`  ❌ ${name}: ${err.message}`);
    failedTests++;
  }
}

// TEST 1: Check essential files exist
test('Arquivos essenciais do projeto existem', () => {
  const essentials = [
    'package.json',
    'index.html',
    'vite.config.ts',
    'src/main.tsx',
    'src/App.tsx',
    'src/types/index.ts',
    'src/context/AppContext.tsx',
    'public/version-info.json',
  ];
  for (const f of essentials) {
    assert.ok(fs.existsSync(path.join(rootDir, f)), `Arquivo ausente: ${f}`);
  }
});

// TEST 2: Check package.json format & version
test('package.json contém versão e scripts válidos', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(rootDir, 'package.json'), 'utf8'));
  assert.ok(pkg.version, 'Campo version ausente');
  assert.match(pkg.version, /^\d+\.\d+\.\d+/, 'Formato semântico de versão inválido');
  assert.ok(pkg.scripts.build, 'Script build ausente');
  assert.ok(pkg.scripts.lint, 'Script lint ausente');
});

// TEST 3: Check version-info.json schema
test('version-info.json tem estrutura íntegra', () => {
  const infoPath = path.join(rootDir, 'public/version-info.json');
  assert.ok(fs.existsSync(infoPath), 'version-info.json não encontrado');
  const info = JSON.parse(fs.readFileSync(infoPath, 'utf8'));
  assert.ok(info.version, 'version ausente');
  assert.ok(info.currentVersion, 'currentVersion ausente');
  assert.ok(info.currentVersion.filename, 'filename ausente');
  assert.ok(Array.isArray(info.allVersions), 'allVersions deve ser array');
});

// TEST 4: Check calculations logic
test('Cálculos financeiros básicos', () => {
  const rent = 850;
  const water = 50;
  const internet = 60;
  const other = 20;
  const total = rent + water + internet + other;
  assert.strictEqual(total, 980, 'Soma de despesas mensais da kitnet incorreta');
});

// TEST 5: Verify no nested zip or forbidden files in public/
test('Não há arquivos aninhados indevidos em public/versions', () => {
  const vDir = path.join(rootDir, 'public/versions');
  if (fs.existsSync(vDir)) {
    const files = fs.readdirSync(vDir);
    for (const f of files) {
      assert.ok(f.endsWith('.zip'), `Arquivo não zip em versions: ${f}`);
      assert.match(f, /^projeto-versao-\d+\.zip$/, `Nome fora do padrão: ${f}`);
    }
  }
});

console.log('-------------------------------------------------------');
console.log(`📊 RESULTADO DOS TESTES: ${passedTests} passaram, ${failedTests} falharam`);
console.log('=======================================================\n');

if (failedTests > 0) {
  process.exit(1);
}
