/**
 * src/utils/detailTabStyles.ts
 * 
 * Configuração padronizada de estilos luminosos e cores semânticas por função
 * para as abas de Detalhes de Motos e Kitnets.
 * 
 * Cada função possui uma identidade visual única e iluminada (neon glow):
 * - Geral / Dados: Roxo / Violeta
 * - Contrato & Parcelas: Verde Esmeralda
 * - Locatário / Inquilino: Azul Celeste (Sky)
 * - Vistoria: Verde Menta (Teal)
 * - Fotos: Rosa Choque (Pink)
 * - Manutenções: Âmbar / Laranja
 * - Quilometragem: Índigo / Azul Real
 * - Documentos: Rose / Coral
 */

export interface TabThemeConfig {
  activeBtn: string;
  activeIcon: string;
  activeBadge: string;
  hoverBtn: string;
}

export const DETAIL_TAB_THEMES: Record<string, TabThemeConfig> = {
  geral: {
    activeBtn:
      'bg-gradient-to-r from-purple-500/25 via-purple-500/15 to-violet-500/20 text-purple-200 border-purple-400/90 shadow-lg shadow-purple-500/25 ring-1 ring-purple-400/40',
    activeIcon: 'text-purple-300 drop-shadow-[0_0_8px_rgba(192,132,252,0.8)]',
    activeBadge: 'bg-purple-500 text-slate-950 font-black shadow-md shadow-purple-500/50',
    hoverBtn: 'hover:border-purple-500/50 hover:bg-purple-500/[0.08] hover:text-purple-300',
  },
  contrato: {
    activeBtn:
      'bg-gradient-to-r from-emerald-500/25 via-emerald-500/15 to-teal-500/20 text-emerald-200 border-emerald-400/90 shadow-lg shadow-emerald-500/25 ring-1 ring-emerald-400/40',
    activeIcon: 'text-emerald-300 drop-shadow-[0_0_8px_rgba(52,211,153,0.8)]',
    activeBadge: 'bg-emerald-500 text-slate-950 font-black shadow-md shadow-emerald-500/50',
    hoverBtn: 'hover:border-emerald-500/50 hover:bg-emerald-500/[0.08] hover:text-emerald-300',
  },
  locatario: {
    activeBtn:
      'bg-gradient-to-r from-sky-500/25 via-sky-500/15 to-cyan-500/20 text-sky-200 border-sky-400/90 shadow-lg shadow-sky-500/25 ring-1 ring-sky-400/40',
    activeIcon: 'text-sky-300 drop-shadow-[0_0_8px_rgba(56,189,248,0.8)]',
    activeBadge: 'bg-sky-500 text-slate-950 font-black shadow-md shadow-sky-500/50',
    hoverBtn: 'hover:border-sky-500/50 hover:bg-sky-500/[0.08] hover:text-sky-300',
  },
  inquilino: {
    activeBtn:
      'bg-gradient-to-r from-sky-500/25 via-sky-500/15 to-cyan-500/20 text-sky-200 border-sky-400/90 shadow-lg shadow-sky-500/25 ring-1 ring-sky-400/40',
    activeIcon: 'text-sky-300 drop-shadow-[0_0_8px_rgba(56,189,248,0.8)]',
    activeBadge: 'bg-sky-500 text-slate-950 font-black shadow-md shadow-sky-500/50',
    hoverBtn: 'hover:border-sky-500/50 hover:bg-sky-500/[0.08] hover:text-sky-300',
  },
  manutencoes: {
    activeBtn:
      'bg-gradient-to-r from-amber-500/25 via-amber-500/15 to-orange-500/20 text-amber-200 border-amber-400/90 shadow-lg shadow-amber-500/25 ring-1 ring-amber-400/40',
    activeIcon: 'text-amber-300 drop-shadow-[0_0_8px_rgba(251,191,36,0.8)]',
    activeBadge: 'bg-amber-500 text-slate-950 font-black shadow-md shadow-amber-500/50',
    hoverBtn: 'hover:border-amber-500/50 hover:bg-amber-500/[0.08] hover:text-amber-300',
  },
  km: {
    activeBtn:
      'bg-gradient-to-r from-indigo-500/25 via-indigo-500/15 to-blue-500/20 text-indigo-200 border-indigo-400/90 shadow-lg shadow-indigo-500/25 ring-1 ring-indigo-400/40',
    activeIcon: 'text-indigo-300 drop-shadow-[0_0_8px_rgba(129,140,248,0.8)]',
    activeBadge: 'bg-indigo-500 text-slate-950 font-black shadow-md shadow-indigo-500/50',
    hoverBtn: 'hover:border-indigo-500/50 hover:bg-indigo-500/[0.08] hover:text-indigo-300',
  },
  vistoria: {
    activeBtn:
      'bg-gradient-to-r from-teal-500/25 via-teal-500/15 to-emerald-500/20 text-teal-200 border-teal-400/90 shadow-lg shadow-teal-500/25 ring-1 ring-teal-400/40',
    activeIcon: 'text-teal-300 drop-shadow-[0_0_8px_rgba(45,212,191,0.8)]',
    activeBadge: 'bg-teal-500 text-slate-950 font-black shadow-md shadow-teal-500/50',
    hoverBtn: 'hover:border-teal-500/50 hover:bg-teal-500/[0.08] hover:text-teal-300',
  },
  fotos: {
    activeBtn:
      'bg-gradient-to-r from-pink-500/25 via-pink-500/15 to-fuchsia-500/20 text-pink-200 border-pink-400/90 shadow-lg shadow-pink-500/25 ring-1 ring-pink-400/40',
    activeIcon: 'text-pink-300 drop-shadow-[0_0_8px_rgba(244,114,182,0.8)]',
    activeBadge: 'bg-pink-500 text-slate-950 font-black shadow-md shadow-pink-500/50',
    hoverBtn: 'hover:border-pink-500/50 hover:bg-pink-500/[0.08] hover:text-pink-300',
  },
  documentos: {
    activeBtn:
      'bg-gradient-to-r from-rose-500/25 via-rose-500/15 to-red-500/20 text-rose-200 border-rose-400/90 shadow-lg shadow-rose-500/25 ring-1 ring-rose-400/40',
    activeIcon: 'text-rose-300 drop-shadow-[0_0_8px_rgba(251,113,133,0.8)]',
    activeBadge: 'bg-rose-500 text-slate-950 font-black shadow-md shadow-rose-500/50',
    hoverBtn: 'hover:border-rose-500/50 hover:bg-rose-500/[0.08] hover:text-rose-300',
  },
};

const DEFAULT_THEME: TabThemeConfig = DETAIL_TAB_THEMES.geral;

export function getDetailTabTheme(tabId: string): TabThemeConfig {
  return DETAIL_TAB_THEMES[tabId] || DEFAULT_THEME;
}
