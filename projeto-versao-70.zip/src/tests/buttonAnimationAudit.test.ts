/**
 * src/tests/buttonAnimationAudit.test.ts
 *
 * Trava de regressão de animação de botões:
 * Garante que todo arquivo em src/components contendo elementos <button>
 * aplique active:scale (resposta tátil visual ao toque/clique).
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '../..');

function walkDir(dir: string): string[] {
  let results: string[] = [];
  if (!fs.existsSync(dir)) return results;
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results = results.concat(walkDir(fullPath));
    } else if (/\.(tsx|ts)$/.test(entry.name)) {
      results.push(fullPath);
    }
  }
  return results;
}

const targetDir = path.join(rootDir, 'src/components');
const files = walkDir(targetDir);

interface Violation {
  file: string;
  reason: string;
}

const violations: Violation[] = [];
let auditedFilesWithButtons = 0;

for (const file of files) {
  const content = fs.readFileSync(file, 'utf8');
  if (/<button\b/.test(content)) {
    auditedFilesWithButtons++;
    if (!content.includes('active:scale')) {
      violations.push({
        file: path.relative(rootDir, file),
        reason: 'Arquivo possui <button> mas nenhuma ocorrência de active:scale',
      });
    }
  }
}

console.log('--- AUDITORIA DE ANIMAÇÃO DE BOTÕES (TRAVA CONTRA REGRESSÃO) ---');
console.log(`Audited ${auditedFilesWithButtons} files containing <button> in src/components.`);

if (violations.length > 0) {
  console.error(`❌ [FAIL] Encontrados ${violations.length} arquivo(s) com <button> sem active:scale:\n`);
  for (const v of violations) {
    console.error(`  📄 ${v.file}: ${v.reason}`);
  }
  process.exit(1);
} else {
  console.log(`✅ [PASS] 100% dos ${auditedFilesWithButtons} arquivos com botão possuem active:scale padronizado.`);
}
