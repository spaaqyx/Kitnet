/**
 * src/tests/modalAnimationAudit.test.ts
 *
 * Trava de regressão de animação de entrada de modais:
 * Garante que todo arquivo em src/components cujo nome contenha "Modal"
 * aplique a classe animate-modal-enter no seu container principal.
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '../..');

function walkDir(dir: string): string[] {
  let results: string[] = [];
  if (!fs.existsSync(dir)) return results;
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results = results.concat(walkDir(fullPath));
    } else if (/\.(tsx|ts)$/.test(entry.name)) {
      results.push(fullPath);
    }
  }
  return results;
}

const targetDir = path.join(rootDir, 'src/components');
const files = walkDir(targetDir);

interface Violation {
  file: string;
  reason: string;
}

const violations: Violation[] = [];
let auditedModalFiles = 0;

for (const file of files) {
  const fileName = path.basename(file);
  if (fileName.includes('Modal') && fileName.endsWith('.tsx')) {
    auditedModalFiles++;
    const content = fs.readFileSync(file, 'utf8');
    if (!content.includes('animate-modal-enter')) {
      violations.push({
        file: path.relative(rootDir, file),
        reason: 'Arquivo de modal não possui a classe animate-modal-enter',
      });
    }
  }
}

console.log('--- AUDITORIA DE ENTRADA DE MODAIS (TRAVA CONTRA REGRESSÃO) ---');
console.log(`Audited ${auditedModalFiles} modal files in src/components.`);

if (violations.length > 0) {
  console.error(`❌ [FAIL] Encontrados ${violations.length} modal(is) sem animate-modal-enter:\n`);
  for (const v of violations) {
    console.error(`  📄 ${v.file}: ${v.reason}`);
  }
  process.exit(1);
} else {
  console.log(`✅ [PASS] 100% dos ${auditedModalFiles} modais possuem animate-modal-enter.`);
}
