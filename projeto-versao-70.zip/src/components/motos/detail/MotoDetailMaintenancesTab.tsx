import React from 'react';
import { Moto } from '../../../types';
import { Wrench, Plus, Trash2 } from 'lucide-react';

interface MotoDetailMaintenancesTabProps {
  moto: Moto;
  formatCurrency: (value: number) => string;
  formatDate: (dateStr: string) => string;
  setShowMaintenanceModal: (show: boolean) => void;
  deleteMotoMaintenance: (motoId: string, maintenanceId: string) => void;
}

export const MotoDetailMaintenancesTab: React.FC<MotoDetailMaintenancesTabProps> = ({
  moto,
  formatCurrency,
  formatDate,
  setShowMaintenanceModal,
  deleteMotoMaintenance,
}) => {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 bg-surface-base border border-white/[0.08] rounded-xl">
        <div>
          <h3 className="text-sm font-bold text-text-primary flex items-center gap-2">
            <Wrench className="w-4 h-4 text-category-motos" />
            <span>Histórico de Manutenções & Serviços Técnicos</span>
          </h3>
          <p className="text-xs text-text-secondary mt-0.5">
            Controle de trocas de óleo, pneus, relação, pastilhas e revisões preventivas.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setShowMaintenanceModal(true)}
          className="px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer active:scale-95 transition-all"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>Nova Manutenção</span>
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-3.5 bg-surface-base border border-white/[0.08] rounded-xl">
          <span className="text-[10px] text-text-secondary uppercase font-semibold">Total em Manutenções</span>
          <p className="text-base font-bold text-money-negative mt-1">
            {formatCurrency(
              (moto.maintenances || []).reduce((acc, m) => acc + (m.cost || 0), 0)
            )}
          </p>
          <span className="text-[10px] text-text-muted">{moto.maintenances?.length || 0} registros</span>
        </div>

        <div className="p-3.5 bg-surface-base border border-white/[0.08] rounded-xl">
          <span className="text-[10px] text-text-secondary uppercase font-semibold">Última Troca de Óleo</span>
          <p className="text-sm font-bold text-text-primary mt-1">
            {(() => {
              const oleos = (moto.maintenances || []).filter((m) => m.serviceType === 'troca_oleo');
              if (oleos.length === 0) return 'Nenhuma registrada';
              const last = oleos[oleos.length - 1];
              return `${formatDate(last.date)} (${last.km.toLocaleString('pt-BR')} km)`;
            })()}
          </p>
        </div>

        <div className="p-3.5 bg-surface-base border border-white/[0.08] rounded-xl">
          <span className="text-[10px] text-text-secondary uppercase font-semibold">KM Atual do Odômetro</span>
          <p className="text-base font-bold text-category-motos mt-1">
            {moto.currentKm.toLocaleString('pt-BR')} km
          </p>
        </div>
      </div>

      {/* Maintenances List */}
      {!moto.maintenances || moto.maintenances.length === 0 ? (
        <div className="py-8 text-center bg-surface-base rounded-xl border border-dashed border-white/[0.08]">
          <Wrench className="w-8 h-8 text-text-muted mx-auto mb-2" />
          <h4 className="text-sm font-semibold text-text-primary">Nenhuma manutenção registrada</h4>
          <p className="text-xs text-text-secondary mt-1 max-w-sm mx-auto">
            Registre revisões e trocas de peças para ter controle total da moto.
          </p>
        </div>
      ) : (
        <div className="border border-white/[0.08] rounded-xl overflow-hidden bg-surface-base">
          <div className="block sm:hidden divide-y divide-white/[0.08] p-2 space-y-2">
            {moto.maintenances.map((m) => (
              <div key={m.id} className="p-3 bg-surface-card rounded-xl border border-white/[0.08] space-y-2.5">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="font-bold text-xs text-text-primary capitalize block">
                      {m.serviceType.replace('_', ' ')}
                    </span>
                    <span className="text-[11px] text-text-secondary">{m.description}</span>
                  </div>
                  <span className="text-sm font-bold text-money-negative tabular-nums shrink-0">
                    {formatCurrency(m.cost)}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs text-text-secondary pt-0.5">
                  <div>
                    <span>Data:</span> <strong className="text-text-primary block">{formatDate(m.date)}</strong>
                  </div>
                  <div>
                    <span>Odômetro:</span> <strong className="text-category-motos font-mono block">{m.km.toLocaleString('pt-BR')} km</strong>
                  </div>
                </div>

                {m.mechanicOrShop && (
                  <div className="text-xs text-text-secondary">
                    <span>Oficina/Mecânico:</span> <strong className="text-text-primary">{m.mechanicOrShop}</strong>
                  </div>
                )}

                <div className="flex items-center justify-end pt-1.5 border-t border-white/[0.08]">
                  <button
                    type="button"
                    onClick={() => deleteMotoMaintenance(moto.id, m.id)}
                    className="px-3 py-1 rounded-lg bg-surface-base hover:bg-money-negative/20 text-text-secondary hover:text-money-negative border border-white/[0.08] cursor-pointer transition-colors text-xs font-medium flex items-center gap-1.5 active:scale-95"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Excluir</span>
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="hidden sm:block overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-surface-card text-text-secondary uppercase text-[10px] font-medium border-b border-white/[0.08]">
                <tr>
                  <th className="p-3">Data</th>
                  <th className="p-3">Tipo de Serviço</th>
                  <th className="p-3">KM</th>
                  <th className="p-3">Oficina / Mecânico</th>
                  <th className="p-3">Custo</th>
                  <th className="p-3 text-right">Ação</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.08]">
                {moto.maintenances.map((m) => (
                  <tr key={m.id} className="hover:bg-surface-card/50 transition-colors">
                    <td className="p-3 font-medium text-text-primary whitespace-nowrap">
                      {formatDate(m.date)}
                    </td>
                    <td className="p-3">
                      <span className="font-semibold text-text-primary capitalize block">
                        {m.serviceType.replace('_', ' ')}
                      </span>
                      <span className="text-[11px] text-text-secondary">{m.description}</span>
                    </td>
                    <td className="p-3 text-category-motos font-mono whitespace-nowrap">
                      {m.km.toLocaleString('pt-BR')} km
                    </td>
                    <td className="p-3 text-text-secondary">
                      {m.mechanicOrShop || 'Não informado'}
                    </td>
                    <td className="p-3 font-bold text-money-negative whitespace-nowrap">
                      {formatCurrency(m.cost)}
                    </td>
                    <td className="p-3 text-right">
                      <button
                        type="button"
                        onClick={() => deleteMotoMaintenance(moto.id, m.id)}
                        className="p-1.5 rounded-lg bg-surface-card hover:bg-money-negative/20 text-text-secondary hover:text-money-negative border border-white/[0.08] cursor-pointer transition-colors active:scale-95"
                        title="Remover registro de manutenção"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
