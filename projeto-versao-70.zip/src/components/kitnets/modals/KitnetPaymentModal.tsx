import React, { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import { CheckCircle } from 'lucide-react';
import { Installment } from '../../../types';
import { formatCurrency } from '../../../utils/formatters';
import { STANDARD_EASE } from '../../../utils/motion';
import { useBodyScrollLock } from '../../../hooks/useBodyScrollLock';

interface KitnetPaymentModalProps {
  paymentData: { contractId: string; installment: Installment } | null;
  onClose: () => void;
  onConfirm: (contractId: string, installmentId: string) => void;
}

export const KitnetPaymentModal: React.FC<KitnetPaymentModalProps> = ({
  paymentData,
  onClose,
  onConfirm,
}) => {
  const isOpen = Boolean(paymentData);
  const shouldReduceMotion = useReducedMotion();
  const lastPaymentDataRef = useRef(paymentData);

  if (paymentData) {
    lastPaymentDataRef.current = paymentData;
  }

  const currentData = paymentData || lastPaymentDataRef.current;
  useBodyScrollLock(isOpen);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (typeof document === 'undefined') return null;

  return createPortal(
    <AnimatePresence>
      {isOpen && currentData && (
        <motion.div
          key="kitnet-payment-backdrop"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          role="dialog"
          aria-modal="true"
          aria-label="Confirmar Pagamento"
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md font-sans"
          onClick={onClose}
        >
          <motion.div
            key="kitnet-payment-card"
            initial={{ opacity: 0, scale: shouldReduceMotion ? 1 : 0.96, y: shouldReduceMotion ? 0 : 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: shouldReduceMotion ? 1 : 0.96, y: shouldReduceMotion ? 0 : 8 }}
            transition={{ duration: 0.22, ease: STANDARD_EASE }}
            className="bg-surface-base border border-white/[0.12] rounded-2xl w-full max-w-sm p-6 shadow-2xl space-y-4 my-auto animate-modal-enter"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2.5 text-white font-bold text-base">
              <div className="p-2 rounded-xl bg-sky-500/15 border border-sky-500/30 text-sky-400">
                <CheckCircle className="w-5 h-5" />
              </div>
              <span>Confirmar Recebimento</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Confirmar o pagamento da parcela <strong className="text-white">#{currentData.installment.number}</strong> no valor de <strong className="text-sky-400 font-mono font-bold text-sm">{formatCurrency(currentData.installment.amount)}</strong>?
            </p>
            <div className="flex justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 bg-white/[0.06] hover:bg-white/[0.10] text-slate-300 hover:text-white rounded-xl text-xs font-semibold border border-white/[0.10] active:scale-95 transition-colors duration-150 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => onConfirm(currentData.contractId, currentData.installment.id)}
                className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs shadow-md shadow-emerald-500/20 active:scale-95 transition-colors duration-150 cursor-pointer"
              >
                Confirmar Pagamento
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
};
