import React from 'react';
import { PhotoZoomModal } from '../../common/PhotoZoomModal';

interface PhotoZoomPreviewModalProps {
  photoPreview: { url: string; title: string } | null;
  onClose: () => void;
}

export const PhotoZoomPreviewModal: React.FC<PhotoZoomPreviewModalProps> = ({
  photoPreview,
  onClose,
}) => {
  // Padronização global: utiliza animate-modal-enter encapsulado em PhotoZoomModal
  return <PhotoZoomModal photoPreview={photoPreview} onClose={onClose} />;
};
