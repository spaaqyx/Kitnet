import React from 'react';
import { Edit } from 'lucide-react';
import { Kitnet, KitnetTenant } from '../../../types';
import { getKitnetAssetMonthlyBase } from '../../../domain';

interface KitnetDetailGeneralTabProps {
  kitnet: Kitnet;
  tenant?: KitnetTenant;
  formatCurrency: (value: number) => string;
  formatCPF: (cpf: string) => string;
  setActiveSubTab: (tab: 'geral' | 'contrato' | 'inquilino' | 'vistoria' | 'fotos') => void;
  handleOpenEditModal: (kitnet: Kitnet) => void;
}

export const KitnetDetailGeneralTab: React.FC<KitnetDetailGeneralTabProps> = ({
  kitnet,
  tenant,
  formatCurrency,
  formatCPF,
  setActiveSubTab,
  handleOpenEditModal,
}) => {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 min-w-0">
        <div className="p-3.5 bg-surface-base rounded-xl border border-white/[0.08] min-w-0">
          <span className="text-[11px] text-text-secondary uppercase font-medium">Aluguel Base</span>
          <p className="text-base font-bold text-text-primary mt-1 truncate">
            {formatCurrency(kitnet.monthlyRentBase)}
          </p>
          <span className="text-[11px] text-text-muted truncate block">Valor líquido mensal</span>
        </div>

        <div className="p-3.5 bg-surface-base rounded-xl border border-white/[0.08] min-w-0">
          <span className="text-[11px] text-text-secondary uppercase font-medium">Taxa Fixa de Água</span>
          <p className="text-base font-bold text-text-primary mt-1 truncate">
            {formatCurrency(kitnet.monthlyWaterBase)}
          </p>
          <span className="text-[11px] text-text-muted truncate block">Rateio de fornecimento</span>
        </div>

        <div className="p-3.5 bg-surface-base rounded-xl border border-white/[0.08] min-w-0">
          <span className="text-[11px] text-text-secondary uppercase font-medium">Total Mensal</span>
          <p className="text-base font-bold text-money-positive mt-1 truncate">
            {formatCurrency(getKitnetAssetMonthlyBase(kitnet))}
          </p>
          <span className="text-[11px] text-text-muted truncate block">Base Total</span>
        </div>
      </div>

      {/* Quick Inquilino Summary */}
      {tenant && (
        <div className="p-3.5 bg-surface-card rounded-xl border border-category-kitnets-sky/20 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="relative w-11 h-11 rounded-xl overflow-hidden bg-surface-base border border-white/[0.08] flex items-center justify-center shrink-0">
              {tenant.photoUrl || tenant.documents?.photo ? (
                <img
                  src={tenant.photoUrl || tenant.documents?.photo}
                  alt={tenant.fullName}
                  className="w-full h-full object-cover"
                />
              ) : (
                <span className="text-category-kitnets-sky font-bold text-base">{tenant.fullName.charAt(0)}</span>
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-category-kitnets-sky">
                  Inquilino Atual
                </span>
                <span className="text-[10px] text-text-secondary">CPF: {formatCPF(tenant.cpf)}</span>
              </div>
              <h4 className="text-sm font-bold text-text-primary">{tenant.fullName}</h4>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setActiveSubTab('inquilino')}
            className="px-3 py-1.5 bg-surface-base hover:bg-surface-elevated text-category-kitnets-sky border border-category-kitnets-sky/30 rounded-lg text-xs font-semibold transition-colors cursor-pointer active:scale-95"
          >
            Ver Inquilino
          </button>
        </div>
      )}

      <div className="p-4 bg-surface-base rounded-xl border border-white/[0.08] space-y-2 text-xs">
        <div className="flex items-center justify-between">
          <strong className="text-text-primary font-semibold">Informações & Observações da Unidade:</strong>
          <button
            onClick={() => handleOpenEditModal(kitnet)}
            className="text-action-primary hover:text-action-hover font-medium flex items-center gap-1 cursor-pointer active:scale-95 transition-transform"
          >
            <Edit className="w-3 h-3" />
            <span>Editar</span>
          </button>
        </div>
        <p className="text-text-secondary leading-relaxed">
          {kitnet.notes?.trim() ? kitnet.notes : 'Nenhuma observação cadastrada.'}
        </p>
        <div className="pt-2 flex items-center gap-4 text-text-muted text-[11px]">
          <span>Endereço: <strong className="text-text-secondary">{kitnet.address}</strong></span>
        </div>
      </div>
    </div>
  );
};
