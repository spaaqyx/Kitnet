import React from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import { X, ZoomIn } from 'lucide-react';
import { STANDARD_EASE } from '../../utils/motion';

export interface PhotoZoomModalProps {
  photoPreview?: { url: string; title?: string } | null;
  photo?: string | { url: string; title?: string } | null;
  photoUrl?: string | null;
  title?: string;
  onClose: () => void;
}

export const PhotoZoomModal: React.FC<PhotoZoomModalProps> = ({
  photoPreview,
  photo,
  photoUrl,
  title,
  onClose,
}) => {
  const shouldReduceMotion = useReducedMotion();

  let displayUrl = '';
  let displayTitle = title || 'Visualização da Foto';

  if (photoPreview?.url) {
    displayUrl = photoPreview.url;
    if (photoPreview.title) displayTitle = photoPreview.title;
  } else if (typeof photo === 'string') {
    displayUrl = photo;
  } else if (photo && typeof photo === 'object' && photo.url) {
    displayUrl = photo.url;
    if (photo.title) displayTitle = photo.title;
  } else if (photoUrl) {
    displayUrl = photoUrl;
  }

  const isOpen = Boolean(displayUrl);
  const lastDataRef = React.useRef({ url: displayUrl, title: displayTitle });
  if (displayUrl) {
    lastDataRef.current = { url: displayUrl, title: displayTitle };
  }
  const effectiveUrl = displayUrl || lastDataRef.current.url;
  const effectiveTitle = displayUrl ? displayTitle : lastDataRef.current.title;

  if (typeof document === 'undefined') return null;

  return createPortal(
    <AnimatePresence>
      {isOpen && effectiveUrl && (
        <motion.div
          key="photo-zoom-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          role="dialog"
          aria-modal="true"
          aria-label={effectiveTitle}
          className="fixed inset-0 z-[150] flex items-center justify-center bg-black/90 backdrop-blur-md p-4"
          onClick={onClose}
        >
          <motion.div
            key="photo-zoom-content"
            initial={{ opacity: 0, scale: shouldReduceMotion ? 1 : 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: shouldReduceMotion ? 1 : 0.95 }}
            transition={{ duration: 0.22, ease: STANDARD_EASE }}
            className="relative max-w-4xl max-h-[90vh] w-full flex flex-col items-center animate-modal-enter"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-full flex items-center justify-between pb-3 text-white border-b border-white/[0.1] mb-3">
              <div className="flex items-center gap-2 min-w-0">
                <ZoomIn className="w-4 h-4 text-violet-400 shrink-0" />
                <span className="text-sm font-semibold truncate">{effectiveTitle}</span>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="Fechar visualização"
                className="w-8 h-8 rounded-full bg-white/[0.1] hover:bg-white/[0.2] text-white flex items-center justify-center transition-all cursor-pointer shrink-0 active:scale-95"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="relative max-h-[80vh] overflow-hidden rounded-xl border border-white/[0.1] bg-black/40 flex items-center justify-center">
              <img
                src={effectiveUrl}
                alt={effectiveTitle}
                className="max-h-[78vh] w-auto object-contain rounded-lg shadow-2xl"
              />
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
};
