import React, { useState } from 'react';
import { formatCPF, formatCurrency, formatDate, formatPhone } from '../../utils/formatters';
import { SystemSettings } from '../../types';
import { UnifiedClient } from './types';
import { ShieldCheck, UserCheck, Home, Motorbike, Calendar, Scale, Phone, MapPin, ChevronDown, ChevronUp } from 'lucide-react';

interface DocumentSummaryBoxProps {
  settings: SystemSettings;
  activeTenantName: string;
  activeTenantCpf: string;
  activeTenantPhone?: string;
  activeTenantAddress?: string;
  activeAssetLabel?: string;
  selectedClient?: UnifiedClient;
  docTitle?: string;
  depositAmount?: number;
  periodicAmount?: number;
  startDate?: string;
  durationMonths?: number;
}

export const DocumentSummaryBox: React.FC<DocumentSummaryBoxProps> = ({
  settings,
  activeTenantName,
  activeTenantCpf,
  activeTenantPhone,
  activeTenantAddress,
  activeAssetLabel,
  selectedClient,
  depositAmount,
  startDate,
  durationMonths,
}) => {
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);

  const deposit = depositAmount ?? selectedClient?.deposit ?? 0;
  const asset = activeAssetLabel || selectedClient?.assetLabel || 'Não preenchido';
  const tenantName = activeTenantName || selectedClient?.fullName || 'Não preenchido';
  const tenantCpf = activeTenantCpf || (selectedClient?.cpf ? formatCPF(selectedClient.cpf) : 'Não preenchido');
  const duration = durationMonths ?? selectedClient?.durationMonths ?? 0;
  const tenantPhone = activeTenantPhone || (selectedClient?.phone ? formatPhone(selectedClient.phone) : 'Não preenchido');
  const tenantAddress = activeTenantAddress || selectedClient?.address || 'Não preenchido';

  const isMoto =
    selectedClient?.type === 'moto' ||
    (activeAssetLabel && (
      activeAssetLabel.toLowerCase().includes('moto') ||
      activeAssetLabel.toLowerCase().includes('honda') ||
      activeAssetLabel.toLowerCase().includes('yamaha') ||
      activeAssetLabel.toLowerCase().includes('fan') ||
      activeAssetLabel.toLowerCase().includes('titan') ||
      activeAssetLabel.toLowerCase().includes('placa')
    ));

  const AssetIcon = isMoto ? Motorbike : Home;
  const assetTypeLabel = isMoto ? 'Motocicleta' : 'Kitnet Residencial';

  return (
    <div className="space-y-3 pt-2">
      {/* 4 Essential Highlight Summary Badges */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {/* 1. Nome do Locatário */}
        <div className="bg-surface-base p-2.5 rounded-xl border border-border-dark flex flex-col justify-between">
          <div className="flex items-center gap-1.5 text-[10px] uppercase font-bold text-action-light tracking-wider">
            <UserCheck className="w-3.5 h-3.5 text-action-primary" />
            <span>Locatário</span>
          </div>
          <div className="mt-1">
            <div className="text-xs font-bold text-text-primary truncate" title={tenantName}>
              {tenantName}
            </div>
            <div className="text-[10px] text-text-secondary font-mono mt-0.5 truncate">{tenantCpf}</div>
          </div>
        </div>

        {/* 2. Imóvel / Moto Locada */}
        <div className="bg-surface-base p-2.5 rounded-xl border border-border-dark flex flex-col justify-between">
          <div className={`flex items-center gap-1.5 text-[10px] uppercase font-bold tracking-wider ${isMoto ? 'text-action-light' : 'text-category-kitnets-cyan'}`}>
            <AssetIcon className={`w-3.5 h-3.5 ${isMoto ? 'text-action-light' : 'text-category-kitnets-cyan'}`} />
            <span>{isMoto ? 'Veículo' : 'Imóvel'}</span>
          </div>
          <div className="mt-1">
            <div className="text-xs font-bold text-text-primary truncate" title={asset}>
              {asset}
            </div>
            <div className="text-[10px] text-text-secondary truncate mt-0.5">
              {assetTypeLabel}
            </div>
          </div>
        </div>

        {/* 3. Valor da Caução */}
        <div className="bg-surface-base p-2.5 rounded-xl border border-orange-500/30 bg-orange-500/10 flex flex-col justify-between">
          <div className="flex items-center gap-1.5 text-[10px] uppercase font-bold text-orange-400 tracking-wider">
            <ShieldCheck className="w-3.5 h-3.5 text-orange-400" />
            <span>Caução</span>
          </div>
          <div className="mt-1">
            <div className="text-xs font-extrabold text-orange-400 font-mono">
              {formatCurrency(deposit)}
            </div>
            <div className="text-[9px] text-orange-400/80 font-medium mt-0.5">
              Garantia
            </div>
          </div>
        </div>

        {/* 4. Prazo & Vigência */}
        <div className="bg-surface-base p-2.5 rounded-xl border border-border-dark flex flex-col justify-between">
          <div className="flex items-center gap-1.5 text-[10px] uppercase font-bold text-category-motos-alt tracking-wider">
            <Calendar className="w-3.5 h-3.5 text-money-warning-hover" />
            <span>Vigência</span>
          </div>
          <div className="mt-1">
            <div className="text-xs font-bold text-text-primary">
              {duration} Meses
            </div>
            <div className="text-[10px] text-text-secondary mt-0.5 truncate">
              {startDate ? formatDate(startDate) : 'Início imediato'}
            </div>
          </div>
        </div>
      </div>

      {/* Bilateral Qualification Accordion (Clean & Compact) */}
      <div className="bg-surface-base rounded-xl border border-border-dark overflow-hidden text-xs">
        <button
          type="button"
          onClick={() => setIsDetailsOpen(!isDetailsOpen)}
          className="w-full px-3 py-2 flex items-center justify-between hover:bg-surface-card transition-colors cursor-pointer active:scale-95"
        >
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-text-primary">
            <Scale className="w-3.5 h-3.5 text-action-primary" />
            <span>Qualificação das Partes (Locador & Locatário)</span>
          </div>
          <div className="flex items-center gap-1 text-[10px] text-text-secondary">
            <span>{isDetailsOpen ? 'Ocultar' : 'Ver Detalhes'}</span>
            {isDetailsOpen ? (
              <ChevronUp className="w-3.5 h-3.5" />
            ) : (
              <ChevronDown className="w-3.5 h-3.5" />
            )}
          </div>
        </button>

        {isDetailsOpen && (
          <div className="p-3 border-t border-border-dark grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-[11px] bg-surface-base/60">
            {/* Locador */}
            <div className="bg-surface-card p-2.5 rounded-lg border border-white/[0.04] space-y-1">
              <div className="text-action-light font-bold text-[10px] uppercase tracking-wider">
                Locador / Proprietário
              </div>
              <p className="font-semibold text-text-primary">{settings.adminName || 'Locador Cadastrado'}</p>
              <p className="text-text-secondary">CPF: <span className="text-text-primary font-mono">{formatCPF(settings.adminCpf || '')}</span></p>
              <p className="text-text-secondary truncate">PIX: <span className="text-action-primary font-mono">{settings.adminPixKey || settings.adminEmail}</span></p>
              <p className="text-text-secondary">Comarca: <span className="text-text-secondary">{settings.cityState || 'Barra Velha - SC'}</span></p>
            </div>

            {/* Locatário */}
            <div className="bg-surface-card p-2.5 rounded-lg border border-white/[0.04] space-y-1">
              <div className="text-category-kitnets-cyan font-bold text-[10px] uppercase tracking-wider">
                Locatário / Inquilino
              </div>
              <p className="font-semibold text-text-primary truncate">{tenantName}</p>
              <p className="text-text-secondary">CPF: <span className="text-text-primary font-mono">{tenantCpf}</span></p>
              <p className="text-text-secondary flex items-center gap-1">
                <Phone className="w-3 h-3 text-category-kitnets-cyan" />
                <span className="text-text-secondary">{tenantPhone}</span>
              </p>
              <p className="text-text-secondary flex items-center gap-1 truncate">
                <MapPin className="w-3 h-3 text-category-motos-alt shrink-0" />
                <span className="text-text-secondary truncate" title={tenantAddress}>{tenantAddress}</span>
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
