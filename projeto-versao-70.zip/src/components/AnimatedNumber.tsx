import React, { useEffect, useState, useRef, memo } from 'react';
import { gsap } from 'gsap';
import { formatCurrency } from '../utils/formatters';

interface AnimatedNumberProps {
  value: number;
  format?: 'currency' | 'number' | 'percent';
  duration?: number;
  className?: string;
  prefix?: string;
  suffix?: string;
  animateOnMount?: boolean;
  cacheKey?: string;
}

// Global cache of previous values to prevent jarring restarts from 0 when returning to tabs
const previousValuesMap = new Map<string, number>();

export const AnimatedNumberComponent: React.FC<AnimatedNumberProps> = ({
  value,
  format = 'number',
  duration = 600,
  className = '',
  prefix = '',
  suffix = '',
  animateOnMount = true,
  cacheKey,
}) => {
  const resolvedKey = cacheKey || `${format}_${prefix}_${suffix}_${className.slice(0, 24)}`;
  const cachedValue = previousValuesMap.get(resolvedKey);

  // If already displayed in this session, start from previous value rather than 0!
  const [displayValue, setDisplayValue] = useState<number>(() => {
    if (cachedValue !== undefined) {
      return cachedValue;
    }
    return animateOnMount && value !== 0 ? 0 : value;
  });

  const prevValueRef = useRef<number>(
    cachedValue !== undefined ? cachedValue : (animateOnMount && value !== 0 ? 0 : value)
  );
  const isFirstMount = useRef<boolean>(true);

  useEffect(() => {
    const startValue = isFirstMount.current
      ? (cachedValue !== undefined ? cachedValue : (animateOnMount ? 0 : value))
      : prevValueRef.current;
    
    isFirstMount.current = false;
    const endValue = value;

    // Cache the latest value for this key
    previousValuesMap.set(resolvedKey, endValue);

    if (startValue === endValue) {
      setDisplayValue(endValue);
      prevValueRef.current = endValue;
      return;
    }

    const state = { val: startValue };
    const tweenDuration = Math.min(Math.max(duration / 1000, 0.3), 0.7);

    const tween = gsap.to(state, {
      val: endValue,
      duration: tweenDuration,
      ease: 'power3.out',
      onUpdate: () => {
        setDisplayValue(state.val);
      },
      onComplete: () => {
        setDisplayValue(endValue);
        prevValueRef.current = endValue;
      },
    });

    return () => {
      tween.kill();
      prevValueRef.current = state.val;
    };
  }, [value, duration, animateOnMount, resolvedKey, cachedValue]);

  let formattedText = '';
  if (format === 'currency') {
    formattedText = formatCurrency(displayValue);
  } else if (format === 'percent') {
    formattedText = `${Math.round(displayValue)}%`;
  } else {
    formattedText = Math.round(displayValue).toLocaleString('pt-BR');
  }

  return (
    <span className={className}>
      {prefix}
      {formattedText}
      {suffix}
    </span>
  );
};

export const AnimatedNumber = memo(AnimatedNumberComponent);


