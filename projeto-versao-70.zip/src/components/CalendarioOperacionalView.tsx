import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  MessageCircle,
  Motorbike,
  Home,
  Shield,
  FileText,
  DollarSign,
  CalendarDays,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatCurrency, formatDate, getTodayLocalDateString, isInstallmentOverdue, getBrazilNow } from '../utils/formatters';
import { safeAdd, safeSub, roundCurrency } from '../utils/financialMath';
import { BrazilTimeBadge } from './BrazilTimeBadge';
import { useScrollActiveIntoView } from '../hooks/useScrollActiveIntoView';

export interface OperationalEvent {
  id: string;
  date: string;
  type: 'parcela_moto' | 'aluguel_kitnet' | 'contrato_vencendo' | 'cnh_vencendo' | 'conta_pagar';
  title: string;
  subtitle: string;
  amount?: number;
  status: 'pago' | 'pendente' | 'atrasado' | 'aviso';
  phone?: string;
  contractId?: string;
  installmentId?: string;
}

export interface EventVisualConfig {
  icon: React.ComponentType<{ className?: string }>;
  colorText: string;
  dotColor: string;
  borderBadge: string;
  bgBadge: string;
  glowColor: string;
  label: string;
}

/**
 * Configuração visual centralizada e consistente para cada tipo de evento operacional.
 */
export function getEventVisualConfig(ev: OperationalEvent): EventVisualConfig {
  switch (ev.type) {
    case 'parcela_moto':
      return {
        icon: Motorbike,
        colorText: 'text-category-motos',
        dotColor: 'bg-category-motos',
        borderBadge: 'border-category-motos/35',
        bgBadge: 'bg-category-motos/10',
        glowColor: 'shadow-category-motos/20',
        label: 'Parcela Moto',
      };
    case 'aluguel_kitnet':
      return {
        icon: Home,
        colorText: 'text-category-kitnets-sky',
        dotColor: 'bg-category-kitnets-sky',
        borderBadge: 'border-category-kitnets-sky/35',
        bgBadge: 'bg-category-kitnets-sky/10',
        glowColor: 'shadow-category-kitnets-sky/20',
        label: 'Aluguel Kitnet',
      };
    case 'contrato_vencendo':
      return {
        icon: FileText,
        colorText: 'text-action-primary',
        dotColor: 'bg-action-primary',
        borderBadge: 'border-action-primary/35',
        bgBadge: 'bg-action-primary/10',
        glowColor: 'shadow-action-primary/20',
        label: 'Término de Contrato',
      };
    case 'cnh_vencendo':
      return {
        icon: Shield,
        colorText: 'text-amber-400',
        dotColor: 'bg-amber-400',
        borderBadge: 'border-amber-500/35',
        bgBadge: 'bg-amber-500/10',
        glowColor: 'shadow-amber-500/20',
        label: 'Validade CNH',
      };
    case 'conta_pagar':
      if (ev.status === 'pago') {
        return {
          icon: DollarSign,
          colorText: 'text-money-positive',
          dotColor: 'bg-money-positive',
          borderBadge: 'border-money-positive/35',
          bgBadge: 'bg-money-positive/10',
          glowColor: 'shadow-money-positive/20',
          label: 'Conta Paga',
        };
      }
      if (ev.status === 'atrasado') {
        return {
          icon: DollarSign,
          colorText: 'text-money-negative',
          dotColor: 'bg-money-negative',
          borderBadge: 'border-money-negative/35',
          bgBadge: 'bg-money-negative/10',
          glowColor: 'shadow-money-negative/20',
          label: 'Conta Atrasada',
        };
      }
      return {
        icon: DollarSign,
        colorText: 'text-text-secondary',
        dotColor: 'bg-text-secondary',
        borderBadge: 'border-white/10',
        bgBadge: 'bg-white/[0.04]',
        glowColor: 'shadow-white/5',
        label: 'Conta a Pagar',
      };
    default:
      return {
        icon: FileText,
        colorText: 'text-action-primary',
        dotColor: 'bg-action-primary',
        borderBadge: 'border-action-primary/35',
        bgBadge: 'bg-action-primary/10',
        glowColor: 'shadow-action-primary/20',
        label: 'Compromisso',
      };
  }
}

interface CalendarioOperacionalViewProps {
  onOpenWhatsApp?: (contractId: string, installmentId?: string) => void;
}

export const CalendarioOperacionalView: React.FC<CalendarioOperacionalViewProps> = ({
  onOpenWhatsApp,
}) => {
  const { motos, kitnets, motoContracts, kitnetContracts, motoTenants, kitnetTenants, expenses } = useApp();

  const [currentDate, setCurrentDate] = useState<Date>(() => getBrazilNow());
  const [viewMode, setViewMode] = useState<'mensal' | 'lista'>('mensal');
  const [selectedEventType, setSelectedEventType] = useState<string>('todos');
  const [selectedDay, setSelectedDay] = useState<string>(getTodayLocalDateString());

  const { containerRef, registerItem, scrollItemIntoView } = useScrollActiveIntoView(selectedEventType);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const isCurrentMonthAndYear = useMemo(() => {
    const b = getBrazilNow();
    return month === b.getMonth() && year === b.getFullYear();
  }, [month, year]);

  // Compila todos os Eventos Operacionais (Mensais e Semanais)
  const events: OperationalEvent[] = useMemo(() => {
    const list: OperationalEvent[] = [];
    const today = getTodayLocalDateString();

    // 1. Parcelas de Motos (Mensais e Semanais)
    motoContracts.forEach((contract) => {
      const moto = motos.find((m) => m.id === contract.motoId);
      const tenant = motoTenants.find((t) => t.id === contract.tenantId);
      const isWeekly = contract.paymentFrequency === 'semanal';
      const installments = contract.installments || [];
      const totalCount = installments.length || contract.durationMonths;

      installments.forEach((inst) => {
        const total = inst.totalInstallments || totalCount;
        list.push({
          id: `inst-m-${contract.id}-${inst.id}`,
          date: inst.dueDate,
          type: 'parcela_moto',
          title: `Moto: ${tenant?.fullName || 'Locatário'} (${inst.number}/${total})`,
          subtitle: moto
            ? `${moto.brand} ${moto.model} [${moto.plate}] • ${isWeekly ? 'Semanal' : 'Mensal'}`
            : `Motocicleta • ${isWeekly ? 'Semanal' : 'Mensal'}`,
          amount: inst.amount,
          status: inst.status === 'pago' ? 'pago' : isInstallmentOverdue(inst) ? 'atrasado' : 'pendente',
          phone: tenant?.whatsapp || tenant?.phone,
          contractId: contract.id,
          installmentId: inst.id,
        });
      });

      // Contrato vencendo
      const lastInst = installments[installments.length - 1];
      if (lastInst) {
        list.push({
          id: `end-m-${contract.id}`,
          date: lastInst.dueDate,
          type: 'contrato_vencendo',
          title: `Término de Contrato (Moto) — ${tenant?.fullName || 'Locatário'}`,
          subtitle: `Transferência de DUT/CRLV prevista para ${moto?.model || 'veículo'}`,
          status: 'aviso',
          phone: tenant?.whatsapp || tenant?.phone,
          contractId: contract.id,
        });
      }
    });

    // 2. Aluguéis de Kitnets
    kitnetContracts.forEach((contract) => {
      const kitnet = kitnets.find((k) => k.id === contract.kitnetId);
      const tenant = kitnetTenants.find((t) => t.id === contract.tenantId);
      const installments = contract.installments || [];
      const totalCount = installments.length || contract.durationMonths;

      installments.forEach((inst) => {
        const total = inst.totalInstallments || totalCount;
        list.push({
          id: `inst-k-${contract.id}-${inst.id}`,
          date: inst.dueDate,
          type: 'aluguel_kitnet',
          title: `Kitnet: ${tenant?.fullName || 'Locatário'} (${inst.number}/${total})`,
          subtitle: kitnet ? `${kitnet.name} - Nº ${kitnet.number}` : 'Kitnet',
          amount: inst.amount,
          status: inst.status === 'pago' ? 'pago' : isInstallmentOverdue(inst) ? 'atrasado' : 'pendente',
          phone: tenant?.whatsapp || tenant?.phone,
          contractId: contract.id,
          installmentId: inst.id,
        });
      });

      // Contrato vencendo
      const lastInst = installments[installments.length - 1];
      if (lastInst) {
        list.push({
          id: `end-k-${contract.id}`,
          date: lastInst.dueDate,
          type: 'contrato_vencendo',
          title: `Renovação de Contrato (Kitnet) — ${tenant?.fullName || 'Locatário'}`,
          subtitle: kitnet ? `Kitnet ${kitnet.number}` : 'Imóvel',
          status: 'aviso',
          phone: tenant?.whatsapp || tenant?.phone,
          contractId: contract.id,
        });
      }
    });

    // 3. CNHs Vencendo (somente para locatários com contratos ativos de moto)
    const activeMotoTenantIds = new Set(
      motoContracts.filter((c) => c.status === 'ativo').map((c) => c.tenantId)
    );

    motoTenants.forEach((tenant) => {
      if (activeMotoTenantIds.has(tenant.id) && tenant.cnh?.expirationDate) {
        list.push({
          id: `cnh-${tenant.id}`,
          date: tenant.cnh.expirationDate,
          type: 'cnh_vencendo',
          title: `Validade de CNH: ${tenant.fullName}`,
          subtitle: `CNH Cat. ${tenant.cnh.category} vence nesta data`,
          status: 'aviso',
          phone: tenant.whatsapp || tenant.phone,
        });
      }
    });

    // 4. Contas a Pagar (Despesas) com reflexo fiel do status (pago, atrasado ou pendente)
    expenses.forEach((expense) => {
      const expDate = expense.dueDate || expense.date || expense.paidDate || '';
      if (!expDate) return;
      const isOverdue = expense.status === 'atrasado' || (expense.status === 'pendente' && expDate < today);
      const effectiveStatus = expense.status === 'pago' ? 'pago' : isOverdue ? 'atrasado' : 'pendente';
      list.push({
        id: `exp-${expense.id}`,
        date: expDate,
        type: 'conta_pagar',
        title: `Conta: ${expense.title}`,
        subtitle: `Categoria: ${expense.category.toUpperCase()} (${expense.targetType})`,
        amount: expense.amount,
        status: effectiveStatus,
      });
    });

    return list.sort((a, b) => a.date.localeCompare(b.date));
  }, [motos, kitnets, motoContracts, kitnetContracts, motoTenants, kitnetTenants, expenses]);

  // Contagens para os filtros
  const eventCounts = useMemo(() => {
    return {
      todos: events.length,
      parcela_moto: events.filter((e) => e.type === 'parcela_moto').length,
      aluguel_kitnet: events.filter((e) => e.type === 'aluguel_kitnet').length,
      conta_pagar: events.filter((e) => e.type === 'conta_pagar').length,
      contrato_vencendo: events.filter((e) => e.type === 'contrato_vencendo').length,
      cnh_vencendo: events.filter((e) => e.type === 'cnh_vencendo').length,
    };
  }, [events]);

  // Filtered Events
  const filteredEvents = useMemo(() => {
    if (selectedEventType === 'todos') return events;
    return events.filter((e) => e.type === selectedEventType);
  }, [events, selectedEventType]);

  // Days in month calculation
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayOfWeek = new Date(year, month, 1).getDay(); // 0 = Sun, 1 = Mon...

  const monthNames = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  const handlePrevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const handleToday = () => {
    const now = getBrazilNow();
    setCurrentDate(now);
    setSelectedDay(getTodayLocalDateString());
  };

  const selectedDayEvents = useMemo(() => {
    return filteredEvents.filter((e) => e.date === selectedDay);
  }, [filteredEvents, selectedDay]);

  // Métricas financeiras e operacionais auditadas do mês visível
  const monthMetrics = useMemo(() => {
    const monthPrefix = `${year}-${String(month + 1).padStart(2, '0')}`;
    const thisMonthEvents = events.filter((e) => e.date.startsWith(monthPrefix));

    // Cobranças do mês (Motos e Kitnets)
    const receitasDoMes = thisMonthEvents.filter(
      (e) => (e.type === 'parcela_moto' || e.type === 'aluguel_kitnet') && e.amount
    );

    let totalPrevisto = 0;
    let totalJaRecebido = 0;
    let totalAReceber = 0;
    let parcelasMotos = 0;
    let parcelasKitnets = 0;

    receitasDoMes.forEach((e) => {
      const valor = e.amount || 0;
      totalPrevisto = safeAdd(totalPrevisto, valor);
      if (e.type === 'parcela_moto') {
        parcelasMotos = safeAdd(parcelasMotos, valor);
      } else if (e.type === 'aluguel_kitnet') {
        parcelasKitnets = safeAdd(parcelasKitnets, valor);
      }

      if (e.status === 'pago') {
        totalJaRecebido = safeAdd(totalJaRecebido, valor);
      } else {
        totalAReceber = safeAdd(totalAReceber, valor);
      }
    });

    // Despesas e Contas do mês
    const despesasDoMes = thisMonthEvents.filter((e) => e.type === 'conta_pagar' && e.amount);
    let totalDespesas = 0;
    let totalDespesasPagas = 0;
    let totalDespesasPendentes = 0;

    despesasDoMes.forEach((e) => {
      const valor = e.amount || 0;
      totalDespesas = safeAdd(totalDespesas, valor);
      if (e.status === 'pago') {
        totalDespesasPagas = safeAdd(totalDespesasPagas, valor);
      } else {
        totalDespesasPendentes = safeAdd(totalDespesasPendentes, valor);
      }
    });

    // Balanço líquido projetado do mês
    const saldoOperacional = safeSub(totalPrevisto, totalDespesas);

    // Contadores de status de cobranças
    const totalAtrasados = thisMonthEvents.filter((e) => e.status === 'atrasado').length;
    const totalPendentes = thisMonthEvents.filter((e) => e.status === 'pendente').length;
    const totalPagos = thisMonthEvents.filter((e) => e.status === 'pago').length;

    return {
      count: thisMonthEvents.length,
      totalPrevisto,
      totalJaRecebido,
      totalAReceber,
      parcelasMotos,
      parcelasKitnets,
      totalDespesas,
      totalDespesasPagas,
      totalDespesasPendentes,
      saldoOperacional,
      totalAtrasados,
      totalPendentes,
      totalPagos,
      totalCobancasCount: receitasDoMes.length,
      totalContasCount: despesasDoMes.length,
    };
  }, [events, year, month]);

  const filterOptions = [
    {
      id: 'todos',
      label: 'Todos os Eventos',
      count: eventCounts.todos,
      activeBg: 'bg-action-primary',
      activeText: 'text-white',
      badgeActive: 'bg-white/20 text-white',
      icon: Sparkles,
    },
    {
      id: 'parcela_moto',
      label: 'Parcelas Motos',
      count: eventCounts.parcela_moto,
      activeBg: 'bg-category-motos',
      activeText: 'text-white',
      badgeActive: 'bg-black/25 text-white',
      icon: Motorbike,
    },
    {
      id: 'aluguel_kitnet',
      label: 'Aluguéis Kitnets',
      count: eventCounts.aluguel_kitnet,
      activeBg: 'bg-category-kitnets-sky',
      activeText: 'text-white',
      badgeActive: 'bg-black/25 text-white',
      icon: Home,
    },
    {
      id: 'conta_pagar',
      label: 'Contas a Pagar',
      count: eventCounts.conta_pagar,
      activeBg: 'bg-money-positive',
      activeText: 'text-white',
      badgeActive: 'bg-black/25 text-white',
      icon: DollarSign,
    },
    {
      id: 'contrato_vencendo',
      label: 'Contratos Vencendo',
      count: eventCounts.contrato_vencendo,
      activeBg: 'bg-action-primary',
      activeText: 'text-white',
      badgeActive: 'bg-white/20 text-white',
      icon: FileText,
    },
    {
      id: 'cnh_vencendo',
      label: 'CNHs Vencendo',
      count: eventCounts.cnh_vencendo,
      activeBg: 'bg-amber-500',
      activeText: 'text-white',
      badgeActive: 'bg-black/25 text-white',
      icon: Shield,
    },
  ];

  return (
    <div className="space-y-4 sm:space-y-5 font-sans pb-2 sm:pb-4">
      {/* Top Header Card */}
      <div className="relative overflow-hidden bg-surface-sidebar p-4 sm:p-5 rounded-2xl border border-white/[0.08] shadow-lg shadow-black/40">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="flex items-start sm:items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-action-primary/15 border border-action-primary/30 flex items-center justify-center text-action-light shrink-0">
              <CalendarIcon className="w-5 h-5" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                  Calendário Operacional
                </h1>
                <BrazilTimeBadge variant="pill" showSeconds={false} showDate={true} />
              </div>
              <p className="text-xs text-text-secondary mt-1 max-w-xl">
                Vencimentos de parcelas (semanais/mensais), aluguéis, CNHs, termos de contrato e despesas fixas.
              </p>
            </div>
          </div>

          {/* View Switcher Segmented Control & Hoje Action */}
          <div className="flex items-center gap-2.5 flex-wrap">
            {/* Segmented Control with animated sliding pill */}
            <div className="relative flex items-center p-1 rounded-xl bg-surface-subtle border border-white/[0.08]">
              <button
                type="button"
                onClick={() => setViewMode('mensal')}
                className={`relative z-10 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer inline-flex items-center gap-1.5 active:scale-95 ${
                  viewMode === 'mensal' ? 'text-white' : 'text-text-secondary hover:text-text-primary'
                }`}
              >
                <CalendarDays className="w-3.5 h-3.5" />
                <span>Visão Mensal</span>
                {viewMode === 'mensal' && (
                  <motion.div
                    layoutId="activeViewTab"
                    className="absolute inset-0 bg-action-primary rounded-lg -z-10"
                    transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                  />
                )}
              </button>

              <button
                type="button"
                onClick={() => setViewMode('lista')}
                className={`relative z-10 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer inline-flex items-center gap-1.5 active:scale-95 ${
                  viewMode === 'lista' ? 'text-white' : 'text-text-secondary hover:text-text-primary'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Lista Cronológica</span>
                {viewMode === 'lista' && (
                  <motion.div
                    layoutId="activeViewTab"
                    className="absolute inset-0 bg-action-primary rounded-lg -z-10"
                    transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                  />
                )}
              </button>
            </div>

            {/* Quick Action: "Hoje" */}
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={handleToday}
              className="h-8.5 sm:h-9 px-3.5 rounded-xl bg-surface-subtle hover:bg-surface-card border border-action-primary/40 hover:border-action-primary text-white text-xs font-semibold transition-all cursor-pointer inline-flex items-center gap-1.5 shadow-xs active:scale-95"
              title="Ir para o dia de hoje"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Hoje</span>
            </motion.button>
          </div>
        </div>

        {/* Mini stats summary bar auditada */}
        <div className="mt-5 pt-4 border-t border-white/[0.06] grid grid-cols-2 lg:grid-cols-5 gap-2.5 text-xs">
          <div className="bg-white/[0.025] p-2.5 rounded-xl border border-white/[0.05]">
            <span className="text-text-secondary text-[11px] block">Mês Selecionado</span>
            <div className="flex items-center gap-1.5 mt-0.5">
              <strong className="text-white font-semibold text-xs sm:text-sm">{monthNames[month]} / {year}</strong>
              {isCurrentMonthAndYear && (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" title="Mês Atual" />
              )}
            </div>
            <span className="text-[10px] text-slate-400 block mt-0.5">
              {monthMetrics.count} {monthMetrics.count === 1 ? 'evento' : 'eventos'} no mês
            </span>
          </div>

          <div className="bg-white/[0.025] p-2.5 rounded-xl border border-white/[0.05]">
            <span className="text-text-secondary text-[11px] block">Receita Prevista</span>
            <strong className="text-money-positive font-mono text-xs sm:text-sm block mt-0.5">
              {formatCurrency(monthMetrics.totalPrevisto)}
            </strong>
            <span className="text-[10px] text-emerald-400/80 block mt-0.5 truncate">
              {monthMetrics.totalJaRecebido > 0 ? `Recebido: ${formatCurrency(monthMetrics.totalJaRecebido)}` : `${monthMetrics.totalCobancasCount} cobranças`}
            </span>
          </div>

          <div className="bg-white/[0.025] p-2.5 rounded-xl border border-white/[0.05]">
            <span className="text-text-secondary text-[11px] block">Saldo a Receber</span>
            <strong className="text-category-kitnets-cyan font-mono text-xs sm:text-sm block mt-0.5">
              {formatCurrency(monthMetrics.totalAReceber)}
            </strong>
            <span className="text-[10px] text-sky-400/80 block mt-0.5">
              {monthMetrics.totalAReceber === 0 ? '100% liquidado' : `${monthMetrics.totalPendentes} pendentes`}
            </span>
          </div>

          <div className="bg-white/[0.025] p-2.5 rounded-xl border border-white/[0.05]">
            <span className="text-text-secondary text-[11px] block">Contas & Despesas</span>
            <strong className="text-amber-300 font-mono text-xs sm:text-sm block mt-0.5">
              {formatCurrency(monthMetrics.totalDespesas)}
            </strong>
            <span className="text-[10px] text-amber-400/80 block mt-0.5">
              {monthMetrics.totalContasCount} {monthMetrics.totalContasCount === 1 ? 'conta programada' : 'contas programadas'}
            </span>
          </div>

          <div className="bg-white/[0.025] p-2.5 rounded-xl border border-white/[0.05] col-span-2 lg:col-span-1">
            <span className="text-text-secondary text-[11px] block">Resultado Operacional</span>
            <strong className={`font-mono text-xs sm:text-sm block mt-0.5 ${monthMetrics.saldoOperacional >= 0 ? 'text-white' : 'text-money-negative'}`}>
              {formatCurrency(monthMetrics.saldoOperacional)}
            </strong>
            <span className="text-[10px] block mt-0.5">
              {monthMetrics.totalAtrasados > 0 ? (
                <span className="text-money-negative font-bold flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3 shrink-0" />
                  {monthMetrics.totalAtrasados} em atraso
                </span>
              ) : (
                <span className="text-emerald-400 font-medium flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 shrink-0" />
                  Em dia
                </span>
              )}
            </span>
          </div>
        </div>
      </div>

      {/* Filter Chips Carousel with smooth auto-scroll to center */}
      <div className="relative">
        <div
          ref={containerRef}
          className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1 px-0.5 scroll-smooth select-none [-webkit-overflow-scrolling:touch] touch-pan-x"
        >
          {filterOptions.map((f) => {
            const isSelected = selectedEventType === f.id;
            const Icon = f.icon;

            return (
              <motion.button
                key={f.id}
                ref={registerItem(f.id)}
                whileHover={{ y: -1 }}
                whileTap={{ scale: 0.96 }}
                onClick={() => {
                  setSelectedEventType(f.id);
                  scrollItemIntoView(f.id);
                }}
                className={`relative px-3.5 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all cursor-pointer inline-flex items-center gap-2 shrink-0 border ${
                  isSelected
                    ? `${f.activeBg} ${f.activeText} border-transparent font-semibold`
                    : 'bg-surface-subtle border-white/[0.08] text-text-secondary hover:text-text-primary hover:bg-surface-card hover:border-white/[0.14]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-current' : 'text-slate-400'}`} />
                <span>{f.label}</span>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-bold tabular-nums min-w-[20px] text-center ${
                    isSelected ? f.badgeActive : 'bg-white/[0.06] text-text-secondary'
                  }`}
                >
                  {f.count}
                </span>
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Main Content Area: Monthly Grid vs Chronological List */}
      <AnimatePresence mode="wait">
        {viewMode === 'mensal' ? (
          <motion.div
            key="view-mensal"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="grid grid-cols-1 lg:grid-cols-3 gap-5"
          >
            {/* Month Grid (2 Columns on Large Screens) */}
            <div className="lg:col-span-2 bg-surface-subtle border border-white/[0.08] rounded-2xl p-5 sm:p-6 shadow-lg flex flex-col justify-between">
              <div>
                {/* Month Navigation Bar */}
                <div className="flex items-center justify-between mb-5">
                  <div className="flex items-center gap-2.5">
                    <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
                      {monthNames[month]} <span className="text-action-primary font-mono">{year}</span>
                    </h2>
                    {isCurrentMonthAndYear && (
                      <span className="px-2 py-0.5 rounded-md bg-action-primary/15 text-action-light text-[10px] font-bold border border-action-primary/30">
                        Mês Atual
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 p-1 rounded-xl bg-surface-sidebar border border-white/[0.08]">
                    <motion.button
                      whileTap={{ scale: 0.9 }}
                      onClick={handlePrevMonth}
                      className="p-1.5 rounded-lg text-text-secondary hover:text-white hover:bg-white/[0.08] transition-colors cursor-pointer"
                      title="Mês Anterior"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </motion.button>

                    <button
                      onClick={handleToday}
                      className="px-2.5 py-1 text-[11px] font-medium text-text-secondary hover:text-white transition-colors cursor-pointer active:scale-95"
                    >
                      Hoje
                    </button>

                    <motion.button
                      whileTap={{ scale: 0.9 }}
                      onClick={handleNextMonth}
                      className="p-1.5 rounded-lg text-text-secondary hover:text-white hover:bg-white/[0.08] transition-colors cursor-pointer"
                      title="Próximo Mês"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </motion.button>
                  </div>
                </div>

                {/* Days of Week Header */}
                <div className="grid grid-cols-7 gap-1 sm:gap-1.5 text-center text-[10px] sm:text-xs font-semibold text-text-muted py-2 border-b border-white/[0.06] mb-2">
                  <span><span className="sm:hidden">D</span><span className="hidden sm:inline">Dom</span></span>
                  <span><span className="sm:hidden">S</span><span className="hidden sm:inline">Seg</span></span>
                  <span><span className="sm:hidden">T</span><span className="hidden sm:inline">Ter</span></span>
                  <span><span className="sm:hidden">Q</span><span className="hidden sm:inline">Qua</span></span>
                  <span><span className="sm:hidden">Q</span><span className="hidden sm:inline">Qui</span></span>
                  <span><span className="sm:hidden">S</span><span className="hidden sm:inline">Sex</span></span>
                  <span><span className="sm:hidden">S</span><span className="hidden sm:inline">Sáb</span></span>
                </div>

                {/* Days Grid */}
                <div className="grid grid-cols-7 gap-1 sm:gap-1.5">
                  {/* Empty leading days */}
                  {Array.from({ length: firstDayOfWeek }).map((_, i) => (
                    <div
                      key={`empty-${i}`}
                      className="min-h-[56px] sm:min-h-[92px] p-1 sm:p-1.5 rounded-lg sm:rounded-xl bg-white/[0.015] border border-white/[0.02] opacity-30"
                    />
                  ))}

                  {/* Month Days */}
                  {Array.from({ length: daysInMonth }).map((_, i) => {
                    const dayNum = i + 1;
                    const formattedDayStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
                    const isSelected = selectedDay === formattedDayStr;
                    const isToday = formattedDayStr === getTodayLocalDateString();

                    const dayEvents = filteredEvents.filter((e) => e.date === formattedDayStr);

                    return (
                      <motion.div
                        key={`day-${dayNum}`}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.97 }}
                        onClick={() => setSelectedDay(formattedDayStr)}
                        className={`min-h-[56px] sm:min-h-[92px] p-1 sm:p-2 rounded-lg sm:rounded-xl border transition-all cursor-pointer flex flex-col justify-between relative group select-none ${
                          isSelected
                            ? 'bg-action-primary/15 border-action-primary ring-1 ring-action-primary'
                            : isToday
                            ? 'bg-surface-subtle border-action-primary/60'
                            : 'bg-surface-base border-white/[0.05] hover:border-white/[0.18] hover:bg-surface-subtle'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span
                            className={`text-xs font-semibold font-mono px-1.5 py-0.5 rounded-md ${
                              isToday
                                ? 'bg-action-primary text-white font-bold shadow-xs'
                                : isSelected
                                ? 'text-action-light font-bold'
                                : 'text-text-secondary'
                            }`}
                          >
                            {dayNum}
                          </span>
                          {dayEvents.length > 0 && (
                            <span className="flex h-2 w-2 relative">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-action-primary opacity-60" />
                              <span className="relative inline-flex rounded-full h-2 w-2 bg-action-primary" />
                            </span>
                          )}
                        </div>

                        {/* Event micro indicators */}
                        <div className="space-y-1 mt-1 overflow-hidden">
                          {dayEvents.slice(0, 2).map((ev) => {
                            const config = getEventVisualConfig(ev);
                            return (
                              <div
                                key={ev.id}
                                className="text-[10px] truncate px-1.5 py-0.5 rounded-md bg-surface-subtle text-text-secondary border border-white/[0.06] flex items-center gap-1.5"
                              >
                                <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${config.dotColor}`} />
                                <span className="truncate text-white font-medium">{ev.title}</span>
                              </div>
                            );
                          })}
                          {dayEvents.length > 2 && (
                            <div className="text-[9px] text-action-primary font-bold text-right tracking-tight">
                              +{dayEvents.length - 2} mais
                            </div>
                          )}
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              {/* Legend Footer */}
              <div className="mt-6 pt-4 border-t border-white/[0.06] flex items-center justify-between flex-wrap gap-3 text-[11px] text-text-secondary">
                <div className="flex items-center gap-4 flex-wrap">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-category-motos" />
                    <span>Motos</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-category-kitnets-sky" />
                    <span>Kitnets</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-money-positive" />
                    <span>Pago</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-money-negative" />
                    <span>Atrasado</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                    <span>CNH</span>
                  </div>
                </div>
                <div className="text-text-muted text-[10px]">
                  Clique em um dia para ver os detalhes
                </div>
              </div>
            </div>

            {/* Selected Day Agenda Drawer (1 Column) */}
            <div className="bg-surface-subtle border border-white/[0.08] rounded-2xl p-5 sm:p-6 shadow-lg flex flex-col justify-between">
              <div>
                <div className="pb-4 border-b border-white/[0.08] flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-bold text-action-primary uppercase tracking-wider block">
                      Agenda Detalhada
                    </span>
                    <h3 className="text-base font-bold text-white mt-0.5">
                      {formatDate(selectedDay)}
                    </h3>
                  </div>
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-action-primary/15 text-action-light border border-action-primary/30">
                    {selectedDayEvents.length} {selectedDayEvents.length === 1 ? 'item' : 'itens'}
                  </span>
                </div>

                {/* Event Cards on Selected Day */}
                <div className="space-y-3 mt-4 max-h-[500px] overflow-y-auto pr-1">
                  {selectedDayEvents.length === 0 ? (
                    <div className="text-center py-16 px-4 text-text-muted text-xs flex flex-col items-center gap-2">
                      <div className="w-10 h-10 rounded-full bg-white/[0.04] flex items-center justify-center text-slate-500">
                        <CheckCircle2 className="w-5 h-5" />
                      </div>
                      <p className="text-slate-400 font-medium">Nenhum compromisso para este dia.</p>
                      <p className="text-[11px] text-slate-500">Selecione outro dia no calendário para inspecionar parcelas e vencimentos.</p>
                    </div>
                  ) : (
                    selectedDayEvents.map((ev) => {
                      const config = getEventVisualConfig(ev);
                      const Icon = config.icon;

                      return (
                        <motion.div
                          key={ev.id}
                          initial={{ opacity: 0, y: 6 }}
                          animate={{ opacity: 1, y: 0 }}
                          className={`p-3.5 rounded-xl border ${config.bgBadge} ${config.borderBadge} space-y-2 relative group hover:border-opacity-60 transition-all`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-center gap-2.5">
                              <div className={`p-1.5 rounded-lg bg-black/30 ${config.colorText}`}>
                                <Icon className="w-4 h-4" />
                              </div>
                              <div>
                                <strong className="text-xs text-white block leading-snug">{ev.title}</strong>
                                <p className="text-[11px] text-text-secondary mt-0.5">{ev.subtitle}</p>
                              </div>
                            </div>
                            {ev.amount && (
                              <span className="text-xs font-mono font-bold text-money-positive bg-money-positive/10 px-2 py-0.5 rounded-md border border-money-positive/25 shrink-0">
                                {formatCurrency(ev.amount)}
                              </span>
                            )}
                          </div>

                          <div className="flex items-center justify-between pt-2 border-t border-white/[0.06] text-[10px]">
                            <span
                              className={`px-2.5 py-0.5 rounded-md font-bold uppercase tracking-wider ${
                                ev.status === 'pago'
                                  ? 'bg-money-positive/20 text-money-positive border border-money-positive/35'
                                  : ev.status === 'atrasado'
                                  ? 'bg-money-negative/20 text-money-negative-light border border-money-negative/35'
                                  : ev.type === 'cnh_vencendo'
                                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/35'
                                  : 'bg-action-primary/20 text-action-light border border-action-primary/35'
                              }`}
                            >
                              {ev.status}
                            </span>

                            {ev.contractId && onOpenWhatsApp && (
                              <button
                                type="button"
                                onClick={() => onOpenWhatsApp(ev.contractId!, ev.installmentId)}
                                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[11px] font-semibold transition-colors cursor-pointer active:scale-95"
                                aria-label="Enviar lembrete de cobrança no WhatsApp"
                              >
                                <MessageCircle className="w-3 h-3" />
                                <span>Lembrete WhatsApp</span>
                              </button>
                            )}
                          </div>
                        </motion.div>
                      );
                    })
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        ) : (
          /* Chronological List Mode */
          <motion.div
            key="view-lista"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="bg-surface-subtle border border-white/[0.08] rounded-2xl p-5 sm:p-6 shadow-lg space-y-4"
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/[0.08]">
              <div>
                <h3 className="text-base font-bold text-white tracking-tight">
                  Lista Cronológica de Vencimentos & Compromissos
                </h3>
                <p className="text-xs text-text-secondary mt-0.5">
                  Exibindo {filteredEvents.length} eventos ordenados por data de vencimento.
                </p>
              </div>
            </div>

            <div className="space-y-2.5">
              {filteredEvents.length === 0 ? (
                <div className="text-center py-16 text-text-muted text-xs">
                  Nenhum evento encontrado para o filtro selecionado.
                </div>
              ) : (
                filteredEvents.map((ev) => {
                  const config = getEventVisualConfig(ev);
                  const Icon = config.icon;

                  return (
                    <motion.div
                      key={ev.id}
                      initial={{ opacity: 0, y: 4 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-3.5 bg-surface-base hover:bg-surface-subtle rounded-xl border border-white/[0.06] hover:border-white/[0.15] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs transition-all"
                    >
                      <div className="flex items-center gap-3">
                        <div className={`p-2.5 rounded-xl border ${config.bgBadge} ${config.borderBadge} shrink-0`}>
                          <Icon className={`w-4 h-4 ${config.colorText}`} />
                        </div>
                        <div>
                          <span className="font-bold text-white block text-sm">{ev.title}</span>
                          <span className="text-text-secondary text-xs">{ev.subtitle}</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between sm:justify-end gap-3.5">
                        <div className="text-right">
                          <span className="font-mono text-xs text-text-secondary block">{formatDate(ev.date)}</span>
                          {ev.amount && (
                            <span className="font-mono font-bold text-money-positive text-sm block">
                              {formatCurrency(ev.amount)}
                            </span>
                          )}
                        </div>

                        <span
                          className={`px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider ${
                            ev.status === 'pago'
                              ? 'bg-money-positive/20 text-money-positive border border-money-positive/35'
                              : ev.status === 'atrasado'
                              ? 'bg-money-negative/20 text-money-negative-light border border-money-negative/35'
                              : ev.type === 'cnh_vencendo'
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/35'
                              : 'bg-action-primary/20 text-action-light border border-action-primary/35'
                          }`}
                        >
                          {ev.status}
                        </span>

                        {ev.contractId && onOpenWhatsApp && (
                          <button
                            type="button"
                            onClick={() => onOpenWhatsApp(ev.contractId!, ev.installmentId)}
                            className="p-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 transition-colors cursor-pointer active:scale-95"
                            title="Enviar Lembrete WhatsApp"
                            aria-label="Enviar Lembrete de Cobrança no WhatsApp"
                          >
                            <MessageCircle className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </motion.div>
                  );
                })
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};


