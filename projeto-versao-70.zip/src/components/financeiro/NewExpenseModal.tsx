import React, { useState } from 'react';
import { createPortal } from 'react-dom';
import { Plus, X, Receipt } from 'lucide-react';
import { Moto, Kitnet, ExpenseCategory, ExpenseRecurrence } from '../../types';
import { getTodayLocalDateString } from '../../utils/formatters';
import { CurrencyInput } from '../NumericInput';

interface NewExpenseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (expenseData: {
    title: string;
    subtitle: string;
    category: ExpenseCategory;
    targetType: 'geral' | 'moto' | 'kitnet';
    targetId: string;
    amount: number;
    dueDate: string;
    recurrence: ExpenseRecurrence;
    notes: string;
  }) => void;
  motos: Moto[];
  kitnets: Kitnet[];
}

export const NewExpenseModal: React.FC<NewExpenseModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  motos,
  kitnets,
}) => {
  const [form, setForm] = useState({
    title: '',
    subtitle: '',
    category: 'internet' as ExpenseCategory,
    targetType: 'kitnet' as 'geral' | 'moto' | 'kitnet',
    targetId: '',
    amount: 129.9,
    dueDate: getTodayLocalDateString(),
    recurrence: 'mensal' as ExpenseRecurrence,
    notes: '',
  });

  if (!isOpen || typeof document === 'undefined') return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) return;
    onSubmit(form);
    // Reset form
    setForm({
      title: '',
      subtitle: '',
      category: 'internet',
      targetType: 'kitnet',
      targetId: '',
      amount: 129.9,
      dueDate: getTodayLocalDateString(),
      recurrence: 'mensal',
      notes: '',
    });
  };

  return createPortal(
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Cadastrar Nova Despesa"
      className="fixed inset-0 z-[100] flex items-center justify-center p-2.5 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn font-sans"
    >
      <div className="bg-surface-base border border-white/[0.10] rounded-2xl sm:rounded-3xl w-full max-w-lg max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl shadow-black/80 my-auto animate-modal-enter min-w-0">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-white/[0.08] flex items-center justify-between bg-surface-base shrink-0 gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl border border-action-primary/30 bg-action-primary/15 text-action-light flex items-center justify-center shrink-0">
              <Receipt className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm sm:text-base font-bold text-text-primary tracking-tight truncate">
                Cadastrar Nova Despesa
              </h3>
              <p className="text-xs text-text-secondary truncate">
                Lançamento de custo operacional, manutenção ou taxa
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-text-secondary hover:text-text-primary hover:bg-white/[0.08] border border-transparent hover:border-white/[0.10] transition-all cursor-pointer shrink-0 active:scale-95"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form & Scrollable Fields Container */}
        <form onSubmit={handleSubmit} className="flex flex-col flex-1 min-h-0 overflow-hidden bg-surface-base">
          <div className="flex-1 overflow-y-auto min-h-0 p-4 sm:p-5 space-y-3.5 custom-scrollbar">
            <div>
              <label className="block text-xs font-semibold text-text-secondary mb-1.5">
                Título da Despesa
              </label>
              <input
                type="text"
                required
                placeholder="Ex: Internet Fibra 600MB"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                className="w-full bg-surface-sidebar border border-white/[0.12] hover:border-white/[0.20] hover:bg-surface-base focus:bg-surface-base rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-text-primary focus:outline-none focus:border-action-primary focus:ring-2 focus:ring-action-primary/25 transition-all placeholder:text-text-muted"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-text-secondary mb-1.5">
                Subtítulo / Local / Bloco
              </label>
              <input
                type="text"
                placeholder="Ex: Bloco Kitnets, Iluminação Externa, Geral"
                value={form.subtitle}
                onChange={(e) => setForm({ ...form, subtitle: e.target.value })}
                className="w-full bg-surface-sidebar border border-white/[0.12] hover:border-white/[0.20] hover:bg-surface-base focus:bg-surface-base rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-text-primary focus:outline-none focus:border-action-primary focus:ring-2 focus:ring-action-primary/25 transition-all placeholder:text-text-muted"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-3.5">
              <div>
                <label className="block text-xs font-semibold text-text-secondary mb-1.5">
                  Categoria
                </label>
                <select
                  value={form.category}
                  onChange={(e) => {
                    const cat = e.target.value as ExpenseCategory;
                    let newTarget = form.targetType;
                    let newSub = form.subtitle;
                    if (cat === 'manutencao_moto') {
                      newTarget = 'moto';
                      newSub = 'Frota de Motos';
                    } else if (cat === 'iptu' || cat === 'reparo' || cat === 'reforma' || cat === 'agua' || cat === 'energia' || cat === 'internet') {
                      newTarget = 'kitnet';
                      newSub = 'Geral Kitnets';
                    }
                    setForm({ ...form, category: cat, targetType: newTarget, subtitle: newSub });
                  }}
                  className="w-full bg-surface-sidebar border border-white/[0.12] hover:border-white/[0.20] hover:bg-surface-base focus:bg-surface-base rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-text-primary focus:outline-none focus:border-action-primary focus:ring-2 focus:ring-action-primary/25 transition-all cursor-pointer"
                >
                  <option value="manutencao_moto" className="bg-surface-base text-text-primary">🏍️ Manutenção de Moto</option>
                  <option value="internet" className="bg-surface-base text-text-primary">📶 Internet</option>
                  <option value="agua" className="bg-surface-base text-text-primary">💧 Água</option>
                  <option value="energia" className="bg-surface-base text-text-primary">⚡ Energia</option>
                  <option value="iptu" className="bg-surface-base text-text-primary">🏛️ IPTU</option>
                  <option value="seguro" className="bg-surface-base text-text-primary">🛡️ Seguro</option>
                  <option value="reparo" className="bg-surface-base text-text-primary">🔧 Reparo Kitnet</option>
                  <option value="reforma" className="bg-surface-base text-text-primary">🔨 Reforma</option>
                  <option value="outros" className="bg-surface-base text-text-primary">🧾 Outros / Serviços</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-text-secondary mb-1.5">
                  Vínculo do Patrimônio
                </label>
                <select
                  value={form.targetType}
                  onChange={(e) => {
                    const tType = e.target.value as 'kitnet' | 'moto' | 'geral';
                    let sub = form.subtitle;
                    if (tType === 'moto' && (!sub || sub === 'Geral Kitnets')) sub = 'Frota de Motos';
                    if (tType === 'kitnet' && (!sub || sub === 'Frota de Motos')) sub = 'Geral Kitnets';
                    setForm({ ...form, targetType: tType, subtitle: sub });
                  }}
                  className="w-full bg-surface-sidebar border border-white/[0.12] hover:border-white/[0.20] hover:bg-surface-base focus:bg-surface-base rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-text-primary focus:outline-none focus:border-action-primary focus:ring-2 focus:ring-action-primary/25 transition-all cursor-pointer"
                >
                  <option value="moto" className="bg-surface-base text-text-primary">🏍️ Frota de Motos</option>
                  <option value="kitnet" className="bg-surface-base text-text-primary">🏢 Kitnets (Imóveis)</option>
                  <option value="geral" className="bg-surface-base text-text-primary">💼 Geral / Administrativo</option>
                </select>
              </div>
            </div>

            {form.targetType === 'moto' && motos.length > 0 && (
              <div>
                <label className="block text-xs font-semibold text-text-secondary mb-1.5">
                  Moto Específica (Opcional)
                </label>
                <select
                  value={form.targetId || ''}
                  onChange={(e) => {
                    const selId = e.target.value;
                    const selMoto = motos.find((m) => m.id === selId);
                    setForm({
                      ...form,
                      targetId: selId,
                      subtitle: selMoto ? `${selMoto.brand} ${selMoto.model} (${selMoto.plate})` : 'Frota de Motos',
                    });
                  }}
                  className="w-full bg-surface-sidebar border border-white/[0.12] hover:border-white/[0.20] hover:bg-surface-base focus:bg-surface-base rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-text-primary focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/25 transition-all cursor-pointer"
                >
                  <option value="" className="bg-surface-base text-text-primary">Todas / Frota Geral de Motos</option>
                  {motos.map((m) => (
                    <option key={m.id} value={m.id} className="bg-surface-base text-text-primary">
                      {m.brand} {m.model} — {m.plate} ({m.color})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {form.targetType === 'kitnet' && kitnets.length > 0 && (
              <div>
                <label className="block text-xs font-semibold text-text-secondary mb-1.5">
                  Kitnet Específica (Opcional)
                </label>
                <select
                  value={form.targetId || ''}
                  onChange={(e) => {
                    const selId = e.target.value;
                    const selKitnet = kitnets.find((k) => k.id === selId);
                    setForm({
                      ...form,
                      targetId: selId,
                      subtitle: selKitnet ? selKitnet.name : 'Geral Kitnets',
                    });
                  }}
                  className="w-full bg-surface-sidebar border border-white/[0.12] hover:border-white/[0.20] hover:bg-surface-base focus:bg-surface-base rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-text-primary focus:outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-500/25 transition-all cursor-pointer"
                >
                  <option value="" className="bg-surface-base text-text-primary">Todas / Geral Kitnets</option>
                  {kitnets.map((k) => (
                    <option key={k.id} value={k.id} className="bg-surface-base text-text-primary">
                      {k.name} ({k.address || `Nº ${k.number}`})
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-text-secondary mb-1.5">
                Valor (R$)
              </label>
              <CurrencyInput
                value={form.amount}
                onChange={(val) => setForm({ ...form, amount: val })}
                className="h-10 sm:h-11 text-xs sm:text-sm"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-3.5">
              <div>
                <label className="block text-xs font-semibold text-text-secondary mb-1.5">
                  Data de Vencimento
                </label>
                <input
                  type="date"
                  required
                  value={form.dueDate}
                  onChange={(e) => setForm({ ...form, dueDate: e.target.value })}
                  className="h-10 sm:h-11 w-full flex items-center bg-surface-sidebar border border-white/[0.12] hover:border-white/[0.20] hover:bg-surface-base focus:bg-surface-base rounded-xl px-3.5 text-xs sm:text-sm text-text-primary focus:outline-none focus:border-action-primary focus:ring-2 focus:ring-action-primary/25 transition-all leading-normal [color-scheme:dark]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-text-secondary mb-1.5">
                  Recorrência
                </label>
                <select
                  value={form.recurrence}
                  onChange={(e) => setForm({ ...form, recurrence: e.target.value as any })}
                  className="h-10 sm:h-11 w-full bg-surface-sidebar border border-white/[0.12] hover:border-white/[0.20] hover:bg-surface-base focus:bg-surface-base rounded-xl px-3.5 text-xs sm:text-sm text-text-primary focus:outline-none focus:border-action-primary focus:ring-2 focus:ring-action-primary/25 transition-all cursor-pointer"
                >
                  <option value="mensal" className="bg-surface-base text-text-primary">Mensal</option>
                  <option value="anual" className="bg-surface-base text-text-primary">Anual</option>
                  <option value="trimestral" className="bg-surface-base text-text-primary">Trimestral</option>
                  <option value="semestral" className="bg-surface-base text-text-primary">Semestral</option>
                  <option value="nenhuma" className="bg-surface-base text-text-primary">Eventual / Única</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-text-secondary mb-1.5">
                Observações (Opcional)
              </label>
              <input
                type="text"
                placeholder="Ex: Código do boleto, operadora, etc."
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                className="w-full bg-surface-sidebar border border-white/[0.12] hover:border-white/[0.20] hover:bg-surface-base focus:bg-surface-base rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-text-primary focus:outline-none focus:border-action-primary focus:ring-2 focus:ring-action-primary/25 transition-all placeholder:text-text-muted"
              />
            </div>
          </div>

          {/* Bottom Actions Footer */}
          <div className="p-3.5 sm:p-4 border-t border-white/[0.08] flex items-center justify-end gap-2.5 bg-surface-base shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold text-text-secondary hover:text-text-primary hover:bg-white/[0.08] transition-all cursor-pointer active:scale-95"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-action-primary hover:bg-action-hover active:scale-95 text-white font-bold text-xs sm:text-sm rounded-xl transition-all cursor-pointer flex items-center gap-2 shadow-lg shadow-action-primary/25"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>Salvar Despesa</span>
            </button>
          </div>
        </form>
      </div>
    </div>,
    document.body
  );
};
