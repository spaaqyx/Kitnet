import React from 'react';
import { createPortal } from 'react-dom';
import { Trash2, X } from 'lucide-react';
import { Expense } from '../../types';
import { formatCurrency, formatDate } from '../../utils/formatters';

interface DeleteExpenseModalProps {
  expense: Expense | null;
  onClose: () => void;
  onConfirmDelete: (expenseId: string) => void;
}

export const DeleteExpenseModal: React.FC<DeleteExpenseModalProps> = ({
  expense,
  onClose,
  onConfirmDelete,
}) => {
  if (!expense || typeof document === 'undefined') return null;

  return createPortal(
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Excluir Despesa"
      className="fixed inset-0 z-[110] flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn font-sans"
    >
      <div className="bg-surface-base border border-white/[0.10] rounded-2xl sm:rounded-3xl w-full max-w-md overflow-hidden shadow-2xl shadow-black/80 my-auto animate-modal-enter">
        <div className="p-4 sm:p-5 border-b border-white/[0.08] flex items-center justify-between bg-surface-base">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-money-negative/15 border border-money-negative/30 text-money-negative flex items-center justify-center shrink-0">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-text-primary">Excluir Despesa</h3>
              <p className="text-xs text-text-secondary">Esta ação removerá a conta do histórico</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-text-secondary hover:text-text-primary hover:bg-white/[0.08] border border-transparent hover:border-white/[0.10] transition-all cursor-pointer shrink-0 active:scale-95"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-4 bg-surface-base">
          <p className="text-xs sm:text-sm text-text-secondary">
            Tem certeza de que deseja excluir permanentemente a despesa{' '}
            <strong className="text-text-primary font-semibold">"{expense.title}"</strong>?
          </p>

          <div className="p-4 rounded-2xl bg-surface-sidebar border border-white/[0.08] space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-text-secondary font-medium">Valor:</span>
              <span className="font-bold text-text-primary tabular-nums">{formatCurrency(expense.amount)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-text-secondary font-medium">Vencimento:</span>
              <span className="text-text-primary tabular-nums">{formatDate(expense.dueDate)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-text-secondary font-medium">Status:</span>
              <span className="capitalize text-text-primary font-medium">{expense.status}</span>
            </div>
          </div>

          <div className="pt-3 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs sm:text-sm font-semibold text-text-secondary hover:text-text-primary rounded-xl hover:bg-white/[0.08] transition-colors cursor-pointer active:scale-95"
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={() => onConfirmDelete(expense.id)}
              className="px-5 py-2.5 bg-money-negative hover:bg-money-negative-light active:scale-95 text-white font-bold text-xs sm:text-sm rounded-xl transition-all cursor-pointer flex items-center gap-2 shadow-lg shadow-money-negative/25"
            >
              <Trash2 className="w-4 h-4" />
              <span>Sim, Excluir Despesa</span>
            </button>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
};
