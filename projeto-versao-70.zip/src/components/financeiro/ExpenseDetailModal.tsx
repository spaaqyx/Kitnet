import React from 'react';
import { createPortal } from 'react-dom';
import { X, Trash2, CreditCard } from 'lucide-react';
import { Expense } from '../../types';
import { formatCurrency, formatDate } from '../../utils/formatters';
import {
  getCategoryCircleIcon,
  getCategoryLabel,
  getRecurrenceLabel,
  getExpenseStatus,
} from './financeiroHelpers';

interface ExpenseDetailModalProps {
  expense: Expense | null;
  onClose: () => void;
  onDelete: (expense: Expense) => void;
  onPay: (expense: Expense) => void;
}

export const ExpenseDetailModal: React.FC<ExpenseDetailModalProps> = ({
  expense,
  onClose,
  onDelete,
  onPay,
}) => {
  if (!expense || typeof document === 'undefined') return null;

  return createPortal(
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Detalhes da Despesa"
      className="fixed inset-0 z-[100] flex items-center justify-center p-2.5 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn font-sans"
    >
      <div className="bg-surface-base border border-white/[0.10] rounded-2xl sm:rounded-3xl w-full max-w-md max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl shadow-black/80 my-auto animate-modal-enter min-w-0">
        <div className="p-4 sm:p-5 border-b border-white/[0.08] flex items-center justify-between bg-surface-base shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-action-primary/15 border border-action-primary/30 text-action-light flex items-center justify-center shrink-0">
              {getCategoryCircleIcon(expense.category)}
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-text-primary">Detalhes da Despesa</h3>
              <p className="text-xs text-text-secondary capitalize">{getCategoryLabel(expense.category)}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-text-secondary hover:text-text-primary hover:bg-white/[0.08] border border-transparent hover:border-white/[0.10] transition-all cursor-pointer shrink-0 active:scale-95"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto min-h-0 p-4 sm:p-5 space-y-4 text-xs custom-scrollbar bg-surface-base">
          <div className="space-y-2.5 p-4 bg-surface-sidebar rounded-2xl border border-white/[0.08]">
            <div className="flex justify-between">
              <span className="text-text-secondary font-medium">Título Completo:</span>
              <span className="font-bold text-text-primary text-right">{expense.title}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-text-secondary font-medium">Recorrência:</span>
              <span className="font-medium text-text-primary capitalize">{getRecurrenceLabel(expense.recurrence)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-text-secondary font-medium">Vencimento:</span>
              <span className="font-medium text-text-primary">{formatDate(expense.dueDate)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-text-secondary font-medium">Situação:</span>
              <span className="font-bold capitalize text-text-primary">
                {getExpenseStatus(expense)}
              </span>
            </div>
            {expense.paidDate && (
              <div className="flex justify-between">
                <span className="text-text-secondary font-medium">Data de Quitação:</span>
                <span className="font-bold text-money-positive">{formatDate(expense.paidDate)}</span>
              </div>
            )}
            {expense.notes && (
              <div className="pt-2 border-t border-white/[0.06]">
                <span className="text-text-secondary block mb-1 font-medium">Observações:</span>
                <p className="text-text-primary bg-surface-base border border-white/[0.06] p-2.5 rounded-xl">{expense.notes}</p>
              </div>
            )}
            <div className="pt-2.5 border-t border-white/[0.06] flex justify-between items-center">
              <span className="text-text-secondary font-bold">Valor Total:</span>
              <span className="text-base font-bold text-money-positive tabular-nums">
                {formatCurrency(expense.amount)}
              </span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-3.5 sm:p-4 border-t border-white/[0.08] flex items-center justify-between gap-2 bg-surface-base shrink-0">
          <button
            type="button"
            onClick={() => onDelete(expense)}
            className="px-3.5 py-2 text-xs font-semibold text-money-negative hover:text-money-negative-light rounded-xl hover:bg-money-negative/10 transition-colors cursor-pointer flex items-center gap-1.5 active:scale-95"
          >
            <Trash2 className="w-4 h-4" />
            <span>Excluir</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-text-secondary hover:text-text-primary hover:bg-white/[0.08] rounded-xl transition-colors cursor-pointer active:scale-95"
            >
              Fechar
            </button>
            {expense.status !== 'pago' && (
              <button
                type="button"
                onClick={() => onPay(expense)}
                className="px-4.5 py-2 bg-money-positive hover:bg-money-positive-hover text-surface-base font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-lg shadow-money-positive/20 active:scale-95 transition-all"
              >
                <CreditCard className="w-4 h-4" />
                <span>Pagar Agora</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
};
