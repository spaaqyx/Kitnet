import { useRef, useEffect, useCallback } from 'react';
import { gsap } from 'gsap';

interface UseScrollActiveIntoViewOptions {
  inline?: ScrollLogicalPosition;
  block?: ScrollLogicalPosition;
  delayMs?: number;
  duration?: number;
}

/**
 * Hook para centralizar automaticamente e com aceleração GSAP os botões de abas/filtros
 * na barra horizontal conforme o usuário clica ou a etapa ativa avança,
 * com física suave e micro-interação tátil de clique.
 */
export function useScrollActiveIntoView<T extends HTMLElement = HTMLButtonElement>(
  activeKey: string | number | undefined | null,
  options: UseScrollActiveIntoViewOptions = {}
) {
  const { inline = 'center', block = 'nearest', delayMs = 35, duration = 0.38 } = options;
  const containerRef = useRef<HTMLDivElement | null>(null);
  const itemsMapRef = useRef<Map<string | number, T>>(new Map());

  const registerItem = useCallback(
    (key: string | number) => (node: T | null) => {
      if (node) {
        itemsMapRef.current.set(key, node);
      } else {
        itemsMapRef.current.delete(key);
      }
    },
    []
  );

  const scrollItemIntoView = useCallback(
    (key: string | number, customInline?: ScrollLogicalPosition) => {
      const el = itemsMapRef.current.get(key);
      if (!el) return;

      // GSAP tactile micro-bounce on the active item
      gsap.timeline()
        .to(el, { scale: 0.95, duration: 0.08, ease: 'power1.out' })
        .to(el, { scale: 1, duration: 0.22, ease: 'back.out(2)' });

      const container = containerRef.current;
      if (container) {
        // Rola APENAS o container horizontal interno com GSAP de forma ultra-suave
        const containerRect = container.getBoundingClientRect();
        const elRect = el.getBoundingClientRect();
        const currentScroll = container.scrollLeft;
        const relativeLeft = elRect.left - containerRect.left;
        const targetScroll = currentScroll + relativeLeft - (container.clientWidth / 2) + (elRect.width / 2);

        gsap.to(container, {
          scrollLeft: Math.max(0, targetScroll),
          duration,
          ease: 'power2.out',
          overwrite: 'auto',
        });
      } else {
        el.scrollIntoView({
          behavior: 'smooth',
          inline: customInline || inline,
          block,
        });
      }
    },
    [inline, block, duration]
  );

  const isFirstMountRef = useRef(true);

  useEffect(() => {
    if (activeKey === undefined || activeKey === null) return;

    // Evita disparo na montagem inicial para itens padrão (ex: 'geral', 'todos'),
    // prevenindo conflitos enquanto o acordeão ainda está expandindo sua altura
    if (isFirstMountRef.current) {
      isFirstMountRef.current = false;
      if (activeKey === 'geral' || activeKey === 'todos' || activeKey === 1 || activeKey === 'todas') {
        return;
      }
    }

    const timer = setTimeout(() => {
      scrollItemIntoView(activeKey);
    }, delayMs);

    return () => clearTimeout(timer);
  }, [activeKey, delayMs, scrollItemIntoView]);

  return {
    containerRef,
    registerItem,
    scrollItemIntoView,
  };
}
