import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

/**
 * GSAP Animation Helpers & Micro-interactions for the entire app.
 * Safe for React 19, zero dispatcher conflicts, GPU accelerated.
 */

// Smooth scroll a container to a target position using GSAP
export function gsapScrollTo(container: HTMLElement | null, targetLeft: number, duration = 0.35) {
  if (!container) return;
  gsap.to(container, {
    scrollLeft: targetLeft,
    duration,
    ease: 'power2.out',
    overwrite: 'auto',
  });
}

// Button click/tap ripple and scale bounce effect
export function gsapButtonPress(element: HTMLElement | null, callback?: () => void) {
  if (!element) {
    callback?.();
    return;
  }
  gsap.timeline()
    .to(element, { scale: 0.94, duration: 0.09, ease: 'power1.out' })
    .to(element, { 
      scale: 1, 
      duration: 0.22, 
      ease: 'back.out(2.5)',
      onComplete: callback,
    });
}

// Modal/Dialog enter animation
export function animateModalEnter(container: HTMLElement | null, onComplete?: () => void) {
  if (!container) return;
  gsap.fromTo(
    container,
    { scale: 0.94, y: 16, opacity: 0 },
    { scale: 1, y: 0, opacity: 1, duration: 0.3, ease: 'power3.out', onComplete }
  );
}

// Stagger cards in a grid/list
export function animateStaggerCards(selectorOrElements: string | HTMLElement[], parent?: HTMLElement) {
  return gsap.from(selectorOrElements, {
    y: 18,
    opacity: 0,
    duration: 0.35,
    stagger: 0.04,
    ease: 'power3.out',
    clearProps: 'transform,opacity',
  });
}

// Hook for automatic GSAP container animation
export function useGsapStagger<T extends HTMLElement>(
  targetSelector: string,
  deps: React.DependencyList = []
) {
  const containerRef = useRef<T>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    const ctx = gsap.context(() => {
      gsap.from(targetSelector, {
        y: 16,
        opacity: 0,
        duration: 0.38,
        stagger: 0.04,
        ease: 'power3.out',
        clearProps: 'transform,opacity',
      });
    }, containerRef);

    return () => ctx.revert();
  }, deps);

  return containerRef;
}

// Hook for GSAP Modal presentation
export function useGsapModal<T extends HTMLElement>(isOpen: boolean) {
  const modalBoxRef = useRef<T>(null);

  useEffect(() => {
    if (!isOpen || !modalBoxRef.current) return;
    const ctx = gsap.context(() => {
      gsap.fromTo(
        modalBoxRef.current,
        { scale: 0.92, y: 18, opacity: 0 },
        { scale: 1, y: 0, opacity: 1, duration: 0.32, ease: 'back.out(1.4)', clearProps: 'transform,opacity' }
      );
    });

    return () => ctx.revert();
  }, [isOpen]);

  return modalBoxRef;
}

// Helper to center and animate stepper buttons
export function gsapScrollStepper(
  container: HTMLElement | null,
  activeItem: HTMLElement | null,
  duration = 0.35
) {
  if (!container || !activeItem) return;

  const containerRect = container.getBoundingClientRect();
  const elRect = activeItem.getBoundingClientRect();
  const currentScroll = container.scrollLeft;
  const relativeLeft = elRect.left - containerRect.left;
  const targetScroll = currentScroll + relativeLeft - (container.clientWidth / 2) + (elRect.width / 2);

  gsap.to(container, {
    scrollLeft: Math.max(0, targetScroll),
    duration,
    ease: 'power2.out',
    overwrite: 'auto',
  });

  // Micro bounce on the step pill
  gsap.fromTo(
    activeItem,
    { scale: 0.94 },
    { scale: 1, duration: 0.24, ease: 'back.out(2)' }
  );
}

// Fade and slide in content when tabs switch
export function gsapAnimateTabChange(target: HTMLElement | null) {
  if (!target) return;
  gsap.fromTo(
    target,
    { opacity: 0, y: 10 },
    { opacity: 1, y: 0, duration: 0.25, ease: 'power2.out', clearProps: 'all' }
  );
}

