import React, { useState, useEffect, useMemo, useRef, memo } from 'react';
import { gsap } from 'gsap';
import {
  LayoutDashboard,
  LayoutGrid,
  Wallet,
  FileText,
  Settings,
  Lock,
  Bell,
  BadgeAlert,
  Layers,
  Users,
  Calendar,
  FileSpreadsheet,
  Bot,
  Search,
  Phone,
  ShieldAlert,
  MoreHorizontal,
  User,
  Eye,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useApp } from '../context/AppContext';
import { getCNHStatus, getDaysUntil, isInstallmentOverdue } from '../utils/formatters';
import { Logo } from './Logo';
import { MotoIcon, KitnetIcon } from './CategoryIcons';
import { MoreMenuDrawer } from './MoreMenuDrawer';
import { useRenderTracker } from '../utils/perfLogger';
import { COLORS } from '../styles/colors';
import { gsapButtonPress } from '../utils/gsapAnimations';

export type TabType =
  | 'dashboard'
  | 'cobrancas'
  | 'motos'
  | 'kitnets'
  | 'clientes'
  | 'calendario'
  | 'financeiro'
  | 'relatorios'
  | 'documentos'
  | 'configuracoes';

interface NavigationProps {
  activeTab?: TabType;
  currentTab?: TabType;
  onTabChange?: (tab: TabType) => void;
  onSelectTab?: (tab: TabType) => void;
  onOpenSettings?: () => void;
  onOpenNotifications: () => void;
  onOpenSearch?: () => void;
  onOpenContacts?: () => void;
  onOpenSimulator?: () => void;
  onOpenPwaGuide?: () => void;
}

export const NavigationComponent: React.FC<NavigationProps> = ({
  activeTab,
  currentTab,
  onTabChange,
  onSelectTab,
  onOpenSettings,
  onOpenNotifications,
  onOpenSearch,
  onOpenContacts,
  onOpenSimulator,
  onOpenPwaGuide,
}) => {
  useRenderTracker('Navigation');
  const current = activeTab || currentTab || 'dashboard';
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);

  // Dynamic Scroll Overlay & Header Glow
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    let ticking = false;

    const updateScroll = () => {
      const scrollY =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop ||
        window.scrollY ||
        (document.getElementById('root')?.scrollTop || 0);
      const nextScrolled = scrollY > 10;
      setIsScrolled((prev) => (prev !== nextScrolled ? nextScrolled : prev));
      ticking = false;
    };

    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(updateScroll);
        ticking = true;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true, capture: true });
    document.addEventListener('scroll', handleScroll, { passive: true, capture: true });
    updateScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll, true);
      document.removeEventListener('scroll', handleScroll, true);
    };
  }, []);

  const handleSelect = (tab: TabType) => {
    if (isReadOnlyMode && tab !== 'dashboard') {
      return;
    }
    if (onTabChange) onTabChange(tab);
    else if (onSelectTab) onSelectTab(tab);
  };
  const handleSettings = () => {
    if (isReadOnlyMode) return;
    if (onOpenSettings) onOpenSettings();
    else handleSelect('configuracoes');
  };

  const handleLogoClick = () => {
    handleSelect('dashboard');
  };

  const {
    lockApp,
    motos,
    kitnets,
    motoTenants,
    motoContracts,
    kitnetContracts,
    expenses,
    isReadOnlyMode,
    toggleReadOnlyMode,
    isDemoMode,
    toggleDemoMode,
  } = useApp();

  // Automatically close more menu drawer if read-only mode becomes active
  useEffect(() => {
    if (isReadOnlyMode && isMoreMenuOpen) {
      setIsMoreMenuOpen(false);
    }
  }, [isReadOnlyMode, isMoreMenuOpen]);

  // Overdue and active alerts count for badge (memoized)
  const { overdueCount, alertCount } = useMemo(() => {
    let overdue = 0;
    let upcomingRentals = 0;

    motoContracts.forEach((c) => {
      c.installments.forEach((i) => {
        if (i.status === 'pago') return;
        if (isInstallmentOverdue(i)) {
          overdue++;
        } else {
          const days = getDaysUntil(i.dueDate);
          if (days <= 3) upcomingRentals++;
        }
      });
    });

    kitnetContracts.forEach((c) => {
      c.installments.forEach((i) => {
        if (i.status === 'pago') return;
        if (isInstallmentOverdue(i)) {
          overdue++;
        } else {
          const days = getDaysUntil(i.dueDate);
          if (days <= 3) upcomingRentals++;
        }
      });
    });

    let alerts = overdue + upcomingRentals;
    const activeMotoTenantIds = new Set(
      motoContracts.filter((c) => c.status === 'ativo').map((c) => c.tenantId)
    );

    motoTenants.forEach((t) => {
      if (activeMotoTenantIds.has(t.id) && t.cnh?.expirationDate) {
        const cnh = getCNHStatus(t.cnh.expirationDate);
        if (cnh.status === 'vencendo' || cnh.status === 'vencida') alerts++;
      }
    });

    motos.forEach((m) => {
      if (m.ipvaDueDate) {
        const days = getDaysUntil(m.ipvaDueDate);
        if (days >= 0 && days <= 15) alerts++;
      }
    });

    expenses.forEach((e) => {
      if (e.status === 'pendente') {
        const days = getDaysUntil(e.dueDate);
        if (days <= 3) alerts++;
      }
    });

    return { overdueCount: overdue, alertCount: alerts };
  }, [motoContracts, kitnetContracts, motoTenants, motos, expenses]);

  // Centralized theme colors for tabs and indicators
  const TAB_THEMES: Record<string, {
    activeText: string;
    activeGlow: string;
    activeBg: string;
    activeBorder: string;
    activeColor: string;
  }> = {
    dashboard: {
      activeText: 'text-action-primary',
      activeGlow: 'bg-action-primary',
      activeBg: 'bg-action-primary/15',
      activeBorder: 'border-action-primary/30',
      activeColor: COLORS.action.primary,
    },
    motos: {
      activeText: 'text-category-motos',
      activeGlow: 'bg-category-motos',
      activeBg: 'bg-category-motos/15',
      activeBorder: 'border-category-motos/30',
      activeColor: COLORS.category.motos,
    },
    kitnets: {
      activeText: 'text-category-kitnets-sky',
      activeGlow: 'bg-category-kitnets-sky',
      activeBg: 'bg-category-kitnets-sky/15',
      activeBorder: 'border-category-kitnets-sky/30',
      activeColor: COLORS.category.kitnetsSky,
    },
    financeiro: {
      activeText: 'text-money-positive',
      activeGlow: 'bg-money-positive',
      activeBg: 'bg-money-positive/15',
      activeBorder: 'border-money-positive/30',
      activeColor: COLORS.money.positive,
    },
    cobrancas: {
      activeText: 'text-money-negative',
      activeGlow: 'bg-money-negative',
      activeBg: 'bg-money-negative/15',
      activeBorder: 'border-money-negative/30',
      activeColor: COLORS.money.negative,
    },
    clientes: {
      activeText: 'text-action-primary',
      activeGlow: 'bg-action-primary',
      activeBg: 'bg-action-primary/15',
      activeBorder: 'border-action-primary/30',
      activeColor: COLORS.action.primary,
    },
    calendario: {
      activeText: 'text-category-motos-alt',
      activeGlow: 'bg-category-motos-alt',
      activeBg: 'bg-category-motos-alt/15',
      activeBorder: 'border-category-motos-alt/30',
      activeColor: COLORS.money.warning,
    },
    relatorios: {
      activeText: 'text-money-positive',
      activeGlow: 'bg-money-positive',
      activeBg: 'bg-money-positive/15',
      activeBorder: 'border-money-positive/30',
      activeColor: COLORS.money.positive,
    },
    ia: {
      activeText: 'text-action-light',
      activeGlow: 'bg-action-primary',
      activeBg: 'bg-action-primary/15',
      activeBorder: 'border-action-primary/30',
      activeColor: COLORS.action.primary,
    },
    documentos: {
      activeText: 'text-category-kitnets-cyan',
      activeGlow: 'bg-category-kitnets-cyan',
      activeBg: 'bg-category-kitnets-cyan/15',
      activeBorder: 'border-category-kitnets-cyan/30',
      activeColor: COLORS.category.kitnetsCyan,
    },
    configuracoes: {
      activeText: 'text-text-primary',
      activeGlow: 'bg-white',
      activeBg: 'bg-white/10',
      activeBorder: 'border-white/20',
      activeColor: COLORS.text.white,
    },
    mais: {
      activeText: 'text-action-primary',
      activeGlow: 'bg-action-primary',
      activeBg: 'bg-action-primary/15',
      activeBorder: 'border-action-primary/30',
      activeColor: COLORS.action.primary,
    },
  };

  // Desktop Navigation Items
  const desktopNavItems: Array<{
    id: TabType;
    label: string;
    icon: React.ComponentType<{ className?: string; size?: number; color?: string }>;
    badge?: number;
    badgeColor?: string;
  }> = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    {
      id: 'cobrancas',
      label: 'Cobranças',
      icon: BadgeAlert,
      badge: overdueCount > 0 ? overdueCount : undefined,
      badgeColor: 'bg-money-negative text-white',
    },
    {
      id: 'motos',
      label: 'Motos',
      icon: (props) => <MotoIcon {...props} size={15} color={COLORS.category.motos} />,
      badge: motos.length,
      badgeColor: 'bg-category-motos/20 text-category-motos border border-category-motos/30',
    },
    {
      id: 'kitnets',
      label: 'Kitnets',
      icon: (props) => <KitnetIcon {...props} size={15} color={COLORS.category.kitnetsSky} />,
      badge: kitnets.length,
      badgeColor: 'bg-category-kitnets-sky/20 text-category-kitnets-sky border border-category-kitnets-sky/30',
    },
    { id: 'clientes', label: 'Clientes & Score', icon: Users },
    { id: 'calendario', label: 'Calendário', icon: Calendar },
    { id: 'financeiro', label: 'Financeiro', icon: Wallet },
    { id: 'relatorios', label: 'Relatórios', icon: FileSpreadsheet },
    { id: 'documentos', label: 'Documentos', icon: FileText },
  ];

  // Mobile bottom items matching exact 5 icons from IMG_0939
  const mobileBottomItems = [
    { id: 'dashboard' as TabType, label: 'Dashboard', icon: LayoutGrid },
    {
      id: 'motos' as TabType,
      label: 'Motos',
      icon: (props: any) => <MotoIcon {...props} size={24} color={COLORS.category.motos} />,
      badge: motos.filter((m) => m.status === 'alugada').length,
    },
    {
      id: 'kitnets' as TabType,
      label: 'Kitnets',
      icon: (props: any) => <KitnetIcon {...props} size={24} color={COLORS.category.kitnetsSky} />,
      badge: kitnets.filter((k) => k.status === 'alugada').length,
    },
    { id: 'financeiro' as TabType, label: 'Financeiro', icon: Wallet },
    { id: 'mais' as any, label: 'Configurações & Mais', icon: Settings },
  ];

  // Limelight spotlights tracking
  const mobileTabRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const spotlightRef = useRef<HTMLDivElement>(null);
  const [mobileLimelight, setMobileLimelight] = useState<{ left: number; isReady: boolean }>({
    left: -999,
    isReady: false,
  });

  const activeMobileIndex = useMemo(() => {
    if (current === 'dashboard') return 0;
    if (current === 'motos') return 1;
    if (current === 'kitnets') return 2;
    if (current === 'financeiro') return 3;
    // Any secondary module or configuration tab ('configuracoes', 'clientes', 'cobrancas', etc.) maps to the 5th icon
    return 4;
  }, [current]);

  useEffect(() => {
    const updateMobileLimelight = () => {
      const activeEl = mobileTabRefs.current[activeMobileIndex];
      if (activeEl) {
        // Spotlight width is 48px (w-12), so center offset is 24px
        const left = activeEl.offsetLeft + activeEl.offsetWidth / 2 - 24;
        setMobileLimelight({
          left,
          isReady: true,
        });

        if (spotlightRef.current) {
          gsap.to(spotlightRef.current, {
            left,
            duration: 0.38,
            ease: 'power2.out',
            opacity: 1,
            overwrite: 'auto',
          });
        }
      }
    };

    updateMobileLimelight();
    const t = setTimeout(updateMobileLimelight, 50);
    window.addEventListener('resize', updateMobileLimelight);
    return () => {
      clearTimeout(t);
      window.removeEventListener('resize', updateMobileLimelight);
    };
  }, [activeMobileIndex]);

  const currentTheme = TAB_THEMES[current] || TAB_THEMES.dashboard;
  const currentActiveColor = currentTheme.activeColor || '#8B5CF6';

  return (
    <>
      {/* Top Navbar: Permanently fixed at top-0 with floating card and safe-area support */}
      <header className="fixed top-0 left-0 right-0 z-40 w-full px-2 sm:px-4 lg:px-6 pt-safe-header pb-2 sm:py-2.5 pointer-events-none">
        {/* Elegant Clean Card Container wrapping around the header */}
        <div
          className={`relative max-w-7xl mx-auto rounded-2xl pointer-events-auto transition-all duration-300 ease-in-out ${
            isScrolled
              ? 'header-box-scrolled'
              : 'header-box'
          }`}
        >
          <div className="relative z-20 px-3.5 sm:px-6 lg:px-7 flex items-center justify-between gap-2 sm:gap-4 h-15 sm:h-16">
            {/* Main Logo & Brand */}
            <div
              className="cursor-pointer shrink-0 transition-transform active:scale-95 flex items-center gap-2.5 group relative"
              onClick={handleLogoClick}
              title="Ir para o Dashboard"
            >
              <Logo
                variant="main"
                size="md"
                showSubtitle={true}
                animated={true}
              />
            </div>

            {/* Desktop Nav Links - Hidden completely during Read-Only Mode */}
            {!isReadOnlyMode && (
              <nav className="relative hidden xl:flex items-center gap-1 overflow-x-auto py-1">
                {desktopNavItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = current === item.id;
                  const theme = TAB_THEMES[item.id] || TAB_THEMES.dashboard;

                  const activeClass = `${theme.activeBg} ${theme.activeText} border ${theme.activeBorder} shadow-xs`;
                  const iconActiveClass = theme.activeText;

                  return (
                    <button
                      type="button"
                      key={item.id}
                      id={`nav-link-${item.id}`}
                      onClick={() => handleSelect(item.id)}
                      className={`relative px-3 py-1.5 rounded-xl text-xs font-semibold transition-all duration-150 flex items-center gap-1.5 whitespace-nowrap cursor-pointer active:scale-95 ${
                        isActive
                          ? activeClass
                          : 'text-text-secondary hover:text-text-primary hover:bg-white/[0.05]'
                      }`}
                    >
                      <Icon
                        className={`w-3.5 h-3.5 ${isActive ? iconActiveClass : ''}`}
                        color={
                          item.id === 'motos'
                            ? COLORS.category.motos
                            : item.id === 'kitnets'
                            ? COLORS.category.kitnetsSky
                            : isActive
                            ? theme.activeColor
                            : undefined
                        }
                      />
                      <span className="shrink-0">{item.label}</span>
                      {item.badge !== undefined && (
                        <span
                          className={`min-w-[16px] h-4 px-1 rounded-full text-[9px] font-bold inline-flex items-center justify-center shrink-0 leading-none ${
                            item.badgeColor || 'bg-white/10 text-text-secondary'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </nav>
            )}

            {/* Right Action Buttons */}
            <div className="relative flex items-center gap-1.5 sm:gap-2 shrink-0">
              {/* Dedicated Modo Leitura Squircle Button */}
              <button
                type="button"
                id="header-btn-readonly-toggle"
                onClick={() => toggleReadOnlyMode()}
                className={`w-10 h-10 sm:w-11 sm:h-11 min-w-[40px] min-h-[40px] rounded-2xl flex items-center justify-center transition-all cursor-pointer active:scale-95 shadow-xs touch-manipulation select-none ${
                  isReadOnlyMode
                    ? 'bg-violet-600/30 border border-violet-400/50 text-white shadow-violet-600/20'
                    : 'bg-[#131725]/90 hover:bg-[#1C2234] border border-white/[0.08] text-violet-400 hover:text-violet-300'
                }`}
                title={isReadOnlyMode ? 'Modo Leitura Ativo (Clique para Desligar)' : 'Ligar Modo Leitura'}
                aria-label="Modo Leitura"
              >
                <Eye className={`w-4.5 sm:w-5 h-4.5 sm:h-5 ${isReadOnlyMode ? 'animate-pulse text-white' : 'text-violet-400'}`} />
              </button>

              {/* Search Squircle Button */}
              {onOpenSearch && (
                <button
                  type="button"
                  id="header-btn-search"
                  onClick={(e) => {
                    gsapButtonPress(e.currentTarget, onOpenSearch);
                  }}
                  className="w-10 h-10 sm:w-11 sm:h-11 min-w-[40px] min-h-[40px] rounded-2xl bg-[#131725]/90 hover:bg-[#1C2234] border border-white/[0.08] text-white/90 hover:text-white flex items-center justify-center transition-all cursor-pointer active:scale-95 shadow-xs touch-manipulation"
                  title="Busca Unificada (Ctrl+K)"
                  aria-label="Buscar"
                >
                  <Search className="w-4.5 sm:w-5 h-4.5 sm:h-5 text-white/90" />
                </button>
              )}

              {/* Notifications Squircle Button with Badge */}
              <button
                type="button"
                id="header-btn-notifications"
                onClick={(e) => {
                  gsapButtonPress(e.currentTarget, onOpenNotifications);
                }}
                className="w-10 h-10 sm:w-11 sm:h-11 min-w-[40px] min-h-[40px] relative rounded-2xl bg-[#131725]/90 hover:bg-[#1C2234] border border-white/[0.08] text-white/90 hover:text-white flex items-center justify-center transition-all cursor-pointer active:scale-95 shadow-xs touch-manipulation"
                title="Alertas e Notificações"
                aria-label="Alertas e Notificações"
              >
                <Bell className="w-4.5 sm:w-5 h-4.5 sm:h-5 text-white/90" />
                {alertCount > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center ring-2 ring-[#0c0d14] shadow-sm animate-pulse">
                    {alertCount}
                  </span>
                )}
              </button>

              {/* User Profile / Settings Squircle Button */}
              <button
                type="button"
                id="header-btn-user"
                onClick={(e) => {
                  gsapButtonPress(e.currentTarget, handleSettings);
                }}
                className={`w-10 h-10 sm:w-11 sm:h-11 min-w-[40px] min-h-[40px] rounded-2xl border flex items-center justify-center transition-all cursor-pointer active:scale-95 shadow-xs touch-manipulation ${
                  current === 'configuracoes'
                    ? 'bg-purple-600/25 border-purple-500/50 text-purple-300 shadow-purple-600/20'
                    : 'bg-[#131725]/90 hover:bg-[#1C2234] border-white/[0.08] text-white/90 hover:text-white'
                }`}
                title="Perfil & Configurações"
                aria-label="Perfil & Configurações"
              >
                <User className="w-4.5 sm:w-5 h-4.5 sm:h-5 text-white/90" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Structural layout spacer ensuring page content starts cleanly below the fixed header */}
      <div
        className="w-full shrink-0 pointer-events-none spacer-safe-header"
        aria-hidden="true"
      />

      {/* Mobile Sticky Bottom Floating Dock - Matching IMG_0939 */}
      {isReadOnlyMode ? null : (
        <div className="lg:hidden fixed bottom-3 left-3 right-3 max-w-md mx-auto z-40 pointer-events-none pb-safe">
          <nav
            aria-label="Menu Principal"
            className="pointer-events-auto relative flex items-center justify-between h-16 rounded-2xl sm:rounded-3xl bg-[#0f111a]/95 border border-white/[0.12] backdrop-blur-xl px-1.5 shadow-[0_12px_36px_rgba(0,0,0,0.7)] overflow-hidden"
          >
            {/* Limelight sliding spotlight for mobile bottom navigation with GSAP physics */}
            <div
              ref={spotlightRef}
              className="absolute top-0 z-10 w-12 h-[3.5px] rounded-full pointer-events-none"
              style={{
                left: `${mobileLimelight.left}px`,
                backgroundColor: '#ffffff',
                boxShadow: '0 0 12px rgba(255, 255, 255, 0.95), 0 2px 8px rgba(255, 255, 255, 0.6)',
                opacity: mobileLimelight.isReady && mobileLimelight.left >= 0 ? 1 : 0,
              }}
            >
              {/* Downward Spotlight Cone matching IMG_0939 */}
              <div
                className="absolute left-[-26%] top-[3.5px] w-[152%] h-14 [clip-path:polygon(8%_100%,22%_0,78%_0,92%_100%)] pointer-events-none"
                style={{
                  background: 'linear-gradient(to bottom, rgba(255, 255, 255, 0.32) 0%, rgba(255, 255, 255, 0.10) 60%, transparent 100%)',
                }}
              />
              {/* Ambient light pool at bottom matching IMG_0939 */}
              <div
                className="absolute top-11 left-[-15%] w-[130%] h-3.5 rounded-full bg-white/20 blur-[6px] pointer-events-none"
              />
            </div>

            {mobileBottomItems.map((item, index) => {
              const Icon = item.icon;
              const isMais = item.id === 'mais';
              const isTabActive = isMais
                ? !['dashboard', 'motos', 'kitnets', 'financeiro'].includes(current)
                : current === item.id;

              return (
                <button
                  ref={(el) => {
                    mobileTabRefs.current[index] = el;
                  }}
                  type="button"
                  key={item.id}
                  id={`mobile-tab-${item.id}`}
                  aria-label={item.label}
                  title={item.label}
                  onClick={(e) => {
                    gsapButtonPress(e.currentTarget);
                    if (isMais) {
                      setIsMoreMenuOpen(true);
                    } else {
                      handleSelect(item.id);
                    }
                  }}
                  className="relative z-20 flex-1 min-w-0 h-full flex items-center justify-center cursor-pointer touch-manipulation active:scale-95 transition-all select-none"
                >
                  <div className="relative flex items-center justify-center">
                    <Icon
                      className={`w-6 h-6 sm:w-6.5 sm:h-6.5 transition-all duration-200 ease-out ${
                        isTabActive
                          ? 'text-white opacity-100 scale-105 filter drop-shadow-[0_0_8px_rgba(255,255,255,0.45)]'
                          : 'text-slate-400 opacity-40 hover:opacity-75'
                      }`}
                    />
                    {item.badge !== undefined && item.badge > 0 && (
                      <span
                        className={`absolute -top-1 -right-1.5 w-2 h-2 rounded-full ring-2 ring-[#0f111a] ${
                          item.id === 'motos'
                            ? 'bg-category-motos'
                            : item.id === 'kitnets'
                            ? 'bg-category-kitnets-sky'
                            : 'bg-rose-500'
                        }`}
                      />
                    )}
                  </div>
                </button>
              );
            })}
          </nav>
        </div>
      )}

      {/* Drawer Menu for "Mais" */}
      <MoreMenuDrawer
        isOpen={isMoreMenuOpen}
        onClose={() => setIsMoreMenuOpen(false)}
        onSelectTab={handleSelect}
        onOpenSimulator={() => {
          if (onOpenSimulator) onOpenSimulator();
        }}
        onOpenContacts={() => {
          if (onOpenContacts) onOpenContacts();
        }}
        onOpenPwaGuide={() => {
          if (onOpenPwaGuide) onOpenPwaGuide();
        }}
        overdueCount={overdueCount}
      />
    </>
  );
};

export const Navigation = memo(NavigationComponent);


