import React, { useState, useMemo, useEffect } from 'react';
import {
  Wallet,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle2,
  Clock,
  Filter,
  Droplets,
  Zap,
  Wifi,
  Shield,
  Wrench,
  Trash2,
  Search,
  SlidersHorizontal,
  Calendar,
  CreditCard,
  ChevronRight,
  Building2,
  Receipt,
  Info,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Expense } from '../types';
import { formatCurrency, formatDate, getDaysUntil, getTodayLocalDateString } from '../utils/formatters';
import { safeAdd, safeSub } from '../utils/financialMath';
import { AnimatedNumber } from './AnimatedNumber';
import { useBodyScrollLock } from '../hooks/useBodyScrollLock';
import { motion } from 'motion/react';
import { useScrollActiveIntoView } from '../hooks/useScrollActiveIntoView';
import {
  getCategoryCircleIcon,
  getCategoryBulletColor,
  getCategoryLabel,
  getRecurrenceLabel,
  getExpenseStatus,
} from './financeiro/financeiroHelpers';
import { PayExpenseModal } from './financeiro/PayExpenseModal';
import { ExpenseDetailModal } from './financeiro/ExpenseDetailModal';
import { NewExpenseModal } from './financeiro/NewExpenseModal';
import { DeleteExpenseModal } from './financeiro/DeleteExpenseModal';

export const FinanceiroView: React.FC = React.memo(() => {
  const {
    expenses,
    motoContracts,
    kitnetContracts,
    motos,
    kitnets,
    motoTenants,
    kitnetTenants,
    addExpense,
    payExpense,
    deleteExpense,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'despesas' | 'recorrentes' | 'lancamentos'>('despesas');
  const [filterCategory, setFilterCategory] = useState<string>('todas');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'todos' | 'vencido' | 'pendente' | 'pago'>('todos');
  const [showFilterMenu, setShowFilterMenu] = useState<boolean>(false);
  const [showNewExpenseModal, setShowNewExpenseModal] = useState<boolean>(false);
  const [selectedExpenseForDetail, setSelectedExpenseForDetail] = useState<Expense | null>(null);
  const [expenseToPay, setExpenseToPay] = useState<Expense | null>(null);
  const [expenseToDelete, setExpenseToDelete] = useState<Expense | null>(null);

  const modeScroll = useScrollActiveIntoView(activeTab);
  const categoryScroll = useScrollActiveIntoView(filterCategory);

  useBodyScrollLock(showNewExpenseModal || !!selectedExpenseForDetail || !!expenseToPay || !!expenseToDelete);

  // Keyboard shortcut listener to close any open modal on Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (expenseToDelete) setExpenseToDelete(null);
        else if (expenseToPay) setExpenseToPay(null);
        else if (selectedExpenseForDetail) setSelectedExpenseForDetail(null);
        else if (showNewExpenseModal) setShowNewExpenseModal(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [expenseToDelete, expenseToPay, selectedExpenseForDetail, showNewExpenseModal]);

  // Calculate financial totals
  const totalDespesas = useMemo(() => expenses.reduce((acc, e) => safeAdd(acc, e.amount || 0), 0), [expenses]);
  const despesasPagas = useMemo(
    () => expenses.filter((e) => e.status === 'pago').reduce((acc, e) => safeAdd(acc, e.amount || 0), 0),
    [expenses]
  );
  const despesasPendentes = useMemo(
    () => expenses.filter((e) => e.status === 'pendente').reduce((acc, e) => safeAdd(acc, e.amount || 0), 0),
    [expenses]
  );

  // Calculate revenues
  const { totalReceitasPagasMotos, paidMotosList, totalReceitasPagasKitnets, paidKitnetsList } = useMemo(() => {
    let motoTotal = 0;
    const motosList: Array<{
      id: string;
      title: string;
      date: string;
      amount: number;
      type: 'moto';
      category: 'parcela' | 'caucao';
    }> = [];

    motoContracts.forEach((c) => {
      const moto = motos.find((m) => m.id === c.motoId);
      const tenant = motoTenants.find((t) => t.id === c.tenantId);

      // Caução recebida no cadastro
      if (c.deposit && c.deposit > 0 && c.depositStatus !== 'devolvida') {
        motoTotal = safeAdd(motoTotal, c.deposit);
        motosList.push({
          id: `caucao-${c.id}`,
          title: `Caução de Entrada (${moto?.brand || ''} ${moto?.model || ''}${moto?.plate ? ` • ${moto.plate}` : ''}) — ${tenant?.fullName || 'Locatário'}`,
          date: c.startDate || getTodayLocalDateString(),
          amount: c.deposit,
          type: 'moto',
          category: 'caucao',
        });
      }

      c.installments.forEach((i) => {
        if (i.status === 'pago') {
          motoTotal = safeAdd(motoTotal, i.amount);
          motosList.push({
            id: i.id,
            title: `Parcela ${i.number}/${i.totalInstallments} (${moto?.brand || ''} ${moto?.model || ''}${moto?.plate ? ` • ${moto.plate}` : ''}) — ${tenant?.fullName || 'Locatário'}`,
            date: i.paidDate || i.dueDate,
            amount: i.amount,
            type: 'moto',
            category: 'parcela',
          });
        }
      });
    });

    let kitnetTotal = 0;
    const kitnetsList: Array<{
      id: string;
      title: string;
      date: string;
      amount: number;
      type: 'kitnet';
      category: 'parcela' | 'caucao';
    }> = [];

    kitnetContracts.forEach((c) => {
      const kitnet = kitnets.find((k) => k.id === c.kitnetId);
      const tenant = kitnetTenants.find((t) => t.id === c.tenantId);

      // Caução recebida no cadastro
      if (c.deposit && c.deposit > 0 && (c as any).depositStatus !== 'devolvida') {
        kitnetTotal = safeAdd(kitnetTotal, c.deposit);
        kitnetsList.push({
          id: `caucao-k-${c.id}`,
          title: `Caução de Entrada (${kitnet?.name || 'Kitnet'}) — ${tenant?.fullName || 'Inquilino'}`,
          date: c.startDate || getTodayLocalDateString(),
          amount: c.deposit,
          type: 'kitnet',
          category: 'caucao',
        });
      }

      c.installments.forEach((i) => {
        if (i.status === 'pago') {
          kitnetTotal = safeAdd(kitnetTotal, i.amount);
          kitnetsList.push({
            id: i.id,
            title: `Aluguel Mês ${i.number}/${i.totalInstallments} (${kitnet?.name || 'Kitnet'}) — ${tenant?.fullName || 'Inquilino'}`,
            date: i.paidDate || i.dueDate,
            amount: i.amount,
            type: 'kitnet',
            category: 'parcela',
          });
        }
      });
    });

    return {
      totalReceitasPagasMotos: motoTotal,
      paidMotosList: motosList,
      totalReceitasPagasKitnets: kitnetTotal,
      paidKitnetsList: kitnetsList,
    };
  }, [motoContracts, kitnetContracts, motos, kitnets, motoTenants, kitnetTenants]);

  const totalReceitasPagas = safeAdd(totalReceitasPagasMotos, totalReceitasPagasKitnets);
  const lucroLiquidoReal = safeSub(totalReceitasPagas, despesasPagas);

  const totalCaucoesRecebidas = useMemo(() => {
    return [...paidMotosList, ...paidKitnetsList]
      .filter((item) => item.category === 'caucao')
      .reduce((acc, item) => safeAdd(acc, item.amount), 0);
  }, [paidMotosList, paidKitnetsList]);

  const allInflows = useMemo(
    () => [...paidMotosList, ...paidKitnetsList].sort((a, b) => b.date.localeCompare(a.date)),
    [paidMotosList, paidKitnetsList]
  );

  // Extract title and subtitle
  const parseExpenseInfo = (exp: Expense) => {
    let mainTitle = exp.title;
    let subtitle = '';

    if (exp.title.includes(' — ')) {
      const parts = exp.title.split(' — ');
      mainTitle = parts[0];
      subtitle = parts.slice(1).join(' — ');
    } else if (exp.title.includes(' - ')) {
      const parts = exp.title.split(' - ');
      mainTitle = parts[0];
      subtitle = parts.slice(1).join(' - ');
    } else if (exp.notes) {
      subtitle = exp.notes;
    } else if (
      exp.targetType === 'moto' ||
      exp.category === 'manutencao_moto' ||
      exp.category === 'seguro' ||
      exp.title.toLowerCase().includes('moto')
    ) {
      const moto = motos.find((m) => m.id === exp.targetId);
      subtitle = moto ? `${moto.brand} ${moto.model} (${moto.plate})` : 'Frota de Motos';
    } else if (
      exp.targetType === 'kitnet' ||
      exp.category === 'iptu' ||
      exp.category === 'reparo' ||
      exp.category === 'reforma' ||
      exp.category === 'agua' ||
      exp.category === 'energia' ||
      exp.category === 'internet' ||
      exp.title.toLowerCase().includes('kitnet')
    ) {
      const kitnet = kitnets.find((k) => k.id === exp.targetId);
      subtitle = kitnet ? kitnet.name : 'Geral Kitnets';
    } else {
      subtitle = 'Operacional';
    }

    return { mainTitle, subtitle };
  };

  // Filtered Expenses (com faturas vencidas priorizadas no topo)
  const filteredExpenses = useMemo(() => {
    return expenses
      .filter((e) => {
        // Tab filter
        if (activeTab === 'recorrentes' && e.recurrence === 'nenhuma') return false;

        // Category chip filter
        if (filterCategory !== 'todas') {
          if (filterCategory === 'servicos') {
            if (!['outros', 'reparo', 'reforma'].includes(e.category)) {
              return false;
            }
          } else if (e.category !== filterCategory) {
            return false;
          }
        }

        // Status filter
        const currentStatus = getExpenseStatus(e);
        if (statusFilter !== 'todos' && currentStatus !== statusFilter) {
          return false;
        }

        // Search Query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchesTitle = e.title.toLowerCase().includes(q);
          const matchesCategory = e.category.toLowerCase().includes(q);
          const matchesNotes = (e.notes || '').toLowerCase().includes(q);
          if (!matchesTitle && !matchesCategory && !matchesNotes) return false;
        }

        return true;
      })
      .sort((a, b) => {
        // 1º Vencidas ('vencido') -> jogadas para cima das quitadas e pendentes
        // 2º Pendentes ('pendente')
        // 3º Quitadas ('pago')
        const statusA = getExpenseStatus(a);
        const statusB = getExpenseStatus(b);
        const priorityOrder: Record<string, number> = {
          vencido: 0,
          pendente: 1,
          pago: 2,
        };
        const orderA = priorityOrder[statusA] ?? 3;
        const orderB = priorityOrder[statusB] ?? 3;
        if (orderA !== orderB) {
          return orderA - orderB;
        }
        // Desempate de vencidas: as mais atrasadas primeiro
        if (statusA === 'vencido') {
          return a.dueDate.localeCompare(b.dueDate);
        }
        // Desempate de pendentes: as que vencem logo primeiro
        if (statusA === 'pendente') {
          return a.dueDate.localeCompare(b.dueDate);
        }
        // Desempate de pagas: as quitadas mais recentes primeiro
        return b.dueDate.localeCompare(a.dueDate);
      });
  }, [expenses, activeTab, filterCategory, statusFilter, searchQuery]);

  const categoryChips = [
    {
      id: 'todas',
      label: 'Todas',
      icon: Receipt,
      activeClass: 'bg-purple-500/20 text-purple-200 border-purple-400/90 ring-1 ring-purple-400/40 font-bold',
      activeText: 'text-purple-200',
      hoverBorder: 'hover:border-purple-500/50 hover:bg-purple-500/[0.08] hover:text-purple-300',
    },
    {
      id: 'internet',
      label: 'Internet',
      icon: Wifi,
      activeClass: 'bg-violet-500/20 text-violet-200 border-violet-400/90 ring-1 ring-violet-400/40 font-bold',
      activeText: 'text-violet-200',
      hoverBorder: 'hover:border-violet-500/50 hover:bg-violet-500/[0.08] hover:text-violet-300',
    },
    {
      id: 'agua',
      label: 'Água',
      icon: Droplets,
      activeClass: 'bg-sky-500/20 text-sky-200 border-sky-400/90 ring-1 ring-sky-400/40 font-bold',
      activeText: 'text-sky-200',
      hoverBorder: 'hover:border-sky-500/50 hover:bg-sky-500/[0.08] hover:text-sky-300',
    },
    {
      id: 'energia',
      label: 'Energia',
      icon: Zap,
      activeClass: 'bg-amber-500/20 text-amber-200 border-amber-400/90 ring-1 ring-amber-400/40 font-bold',
      activeText: 'text-amber-200',
      hoverBorder: 'hover:border-amber-500/50 hover:bg-amber-500/[0.08] hover:text-amber-300',
    },
    {
      id: 'iptu',
      label: 'IPTU',
      icon: Building2,
      activeClass: 'bg-emerald-500/20 text-emerald-200 border-emerald-400/90 ring-1 ring-emerald-400/40 font-bold',
      activeText: 'text-emerald-200',
      hoverBorder: 'hover:border-emerald-500/50 hover:bg-emerald-500/[0.08] hover:text-emerald-300',
    },
    {
      id: 'servicos',
      label: 'Serviços',
      icon: Sparkles,
      activeClass: 'bg-indigo-500/20 text-indigo-200 border-indigo-400/90 ring-1 ring-indigo-400/40 font-bold',
      activeText: 'text-indigo-200',
      hoverBorder: 'hover:border-indigo-500/50 hover:bg-indigo-500/[0.08] hover:text-indigo-300',
    },
    {
      id: 'seguro',
      label: 'Seguro',
      icon: Shield,
      activeClass: 'bg-blue-500/20 text-blue-200 border-blue-400/90 ring-1 ring-blue-400/40 font-bold',
      activeText: 'text-blue-200',
      hoverBorder: 'hover:border-blue-500/50 hover:bg-blue-500/[0.08] hover:text-blue-300',
    },
    {
      id: 'manutencao_moto',
      label: 'Manutenção',
      icon: Wrench,
      activeClass: 'bg-orange-500/20 text-orange-200 border-orange-400/90 ring-1 ring-orange-400/40 font-bold',
      activeText: 'text-orange-200',
      hoverBorder: 'hover:border-orange-500/50 hover:bg-orange-500/[0.08] hover:text-orange-300',
    },
  ];

  return (
    <div className="space-y-4 sm:space-y-5 font-sans text-slate-100 max-w-7xl mx-auto pb-2">
      {/* Top Header Card */}
      <div className="p-4 sm:p-6 bg-[#121420] border border-white/[0.08] rounded-2xl shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3.5">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">Financeiro</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Receitas de parcelas e aluguéis, despesas operacionais e fluxo de caixa
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowNewExpenseModal(true)}
          className="px-4 py-2.5 bg-[#6D28D9] hover:bg-[#5B21B6] active:scale-95 text-white text-xs sm:text-sm font-bold rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-[#6D28D9]/25 transition-all whitespace-nowrap self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>Cadastrar Nova Despesa</span>
        </button>
      </div>

      {/* KPI Cards Overview - Compact & Elegant (2x2 Grid on Mobile, 4 Cols on Desktop) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3.5">
        {/* Card 1: Total Receitas Recebidas */}
        <div className="p-3.5 sm:p-4 rounded-2xl bg-[#121420] border border-white/[0.08] flex flex-col justify-between shadow-md hover:border-white/[0.14] transition-all min-h-[142px]">
          <div>
            <div className="flex items-center justify-between gap-1.5">
              <span className="text-[11px] sm:text-xs text-slate-400 font-medium truncate">Receitas Recebidas</span>
              <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center shrink-0">
                <ArrowUpRight className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-base sm:text-xl font-bold text-[#10B981] tabular-nums tracking-tight mt-2 whitespace-nowrap truncate">
              <AnimatedNumber value={totalReceitasPagas} format="currency" />
            </div>
            <div className="text-[10px] sm:text-xs text-slate-400 mt-1 truncate">
              M: {formatCurrency(totalReceitasPagasMotos)} • K: {formatCurrency(totalReceitasPagasKitnets)}
            </div>
          </div>
          <div className="mt-2 pt-1.5 border-t border-white/[0.06] flex flex-wrap items-center justify-between gap-1 text-[10px] sm:text-xs">
            <span className="text-orange-400 font-semibold flex items-center gap-1 shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-orange-500 shrink-0"></span>
              Caução:
            </span>
            <span className="text-orange-400 font-bold tabular-nums ml-auto">
              {formatCurrency(totalCaucoesRecebidas)}
            </span>
          </div>
        </div>

        {/* Card 2: Despesas Pagas */}
        <div className="p-3.5 sm:p-4 rounded-2xl bg-[#121420] border border-white/[0.08] flex flex-col justify-between shadow-md hover:border-white/[0.14] transition-all min-h-[142px]">
          <div>
            <div className="flex items-center justify-between gap-1.5">
              <span className="text-[11px] sm:text-xs text-slate-400 font-medium truncate">Despesas Pagas</span>
              <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-lg bg-slate-800 text-slate-300 border border-white/[0.08] flex items-center justify-center shrink-0">
                <ArrowDownRight className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-base sm:text-xl font-bold text-slate-100 tabular-nums tracking-tight mt-2 whitespace-nowrap truncate">
              <AnimatedNumber value={despesasPagas} format="currency" />
            </div>
            <p className="text-[10px] sm:text-xs text-slate-400 mt-1 truncate">
              Contas quitadas no período
            </p>
          </div>
          <div className="mt-2 pt-1.5 border-t border-white/[0.06] flex items-center justify-between text-[10px] sm:text-xs text-slate-400">
            <span>Quitadas:</span>
            <span className="text-slate-300 font-semibold tabular-nums">
              {expenses.filter((e) => e.status === 'pago').length} conta(s)
            </span>
          </div>
        </div>

        {/* Card 3: Despesas a Pagar */}
        <div className="p-3.5 sm:p-4 rounded-2xl bg-[#121420] border border-white/[0.08] flex flex-col justify-between shadow-md hover:border-white/[0.14] transition-all min-h-[142px]">
          <div>
            <div className="flex items-center justify-between gap-1.5">
              <span className="text-[11px] sm:text-xs text-slate-400 font-medium truncate">Despesas a Pagar</span>
              <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-lg bg-red-500/10 text-red-400 border border-red-500/20 flex items-center justify-center shrink-0">
                <Clock className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-base sm:text-xl font-bold text-[#EF4444] tabular-nums tracking-tight mt-2 whitespace-nowrap truncate">
              <AnimatedNumber value={despesasPendentes} format="currency" />
            </div>
            <p className="text-[10px] sm:text-xs text-slate-400 mt-1 truncate">
              {expenses.filter((e) => getExpenseStatus(e) === 'vencido').length > 0 ? (
                <span className="text-rose-400 font-medium">
                  {expenses.filter((e) => getExpenseStatus(e) === 'vencido').length} vencida(s)
                </span>
              ) : (
                'Previsão de saída'
              )}
            </p>
          </div>
          <div className="mt-2 pt-1.5 border-t border-white/[0.06] flex items-center justify-between text-[10px] sm:text-xs text-slate-400">
            <span>A pagar:</span>
            <span className="text-rose-400 font-semibold tabular-nums">
              {expenses.filter((e) => e.status !== 'pago').length} conta(s)
            </span>
          </div>
        </div>

        {/* Card 4: Saldo Líquido em Caixa */}
        <div className="p-3.5 sm:p-4 rounded-2xl bg-[#121420] border border-white/[0.08] flex flex-col justify-between shadow-md hover:border-white/[0.14] transition-all min-h-[142px]">
          <div>
            <div className="flex items-center justify-between gap-1.5">
              <span className="text-[11px] sm:text-xs font-semibold text-slate-400 truncate">
                Saldo Líquido
              </span>
              <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-lg bg-violet-500/10 text-violet-400 border border-violet-500/20 flex items-center justify-center shrink-0">
                <Wallet className="w-3.5 h-3.5" />
              </div>
            </div>
            <div
              className={`text-base sm:text-xl font-bold tabular-nums tracking-tight mt-2 whitespace-nowrap truncate ${
                lucroLiquidoReal < 0 ? 'text-red-400' : lucroLiquidoReal > 0 ? 'text-emerald-400' : 'text-slate-100'
              }`}
            >
              <AnimatedNumber value={lucroLiquidoReal} format="currency" />
            </div>
            <p className="text-[10px] sm:text-xs text-slate-400 mt-1 truncate">
              Receitas - Despesas pagas
            </p>
          </div>
          <div className="mt-2 pt-1.5 border-t border-white/[0.06] flex items-center justify-between text-[10px] sm:text-xs text-slate-400">
            <span>Margem:</span>
            <span className={`font-semibold tabular-nums ${lucroLiquidoReal >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {totalReceitasPagas > 0 ? `${((lucroLiquidoReal / totalReceitasPagas) * 100).toFixed(0)}%` : '0%'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Mode Navigation Tabs - Enhanced Horizontal Scroll with smooth auto-center */}
      <div
        ref={modeScroll.containerRef}
        className="overflow-x-auto pb-1 -mx-1 px-1 flex items-center gap-2 sm:gap-2.5 no-scrollbar scroll-smooth touch-pan-x"
      >
        <motion.button
          ref={modeScroll.registerItem('despesas')}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.96 }}
          onClick={() => {
            setActiveTab('despesas');
            modeScroll.scrollItemIntoView('despesas');
          }}
          className={`px-3.5 py-2 sm:px-4 sm:py-2.5 rounded-xl text-xs sm:text-sm font-semibold shrink-0 whitespace-nowrap transition-all duration-200 cursor-pointer flex items-center gap-2 select-none border ${
            activeTab === 'despesas'
              ? 'bg-purple-500/20 text-purple-200 border-purple-400/90 ring-1 ring-purple-400/40 font-bold'
              : 'bg-[#0E111D] text-slate-400 border-white/[0.08] hover:border-purple-500/50 hover:bg-purple-500/[0.08] hover:text-purple-300'
          }`}
        >
          <span>Despesas & Contas</span>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] sm:text-xs font-mono font-bold transition-all ${
              activeTab === 'despesas'
                ? 'bg-purple-500 text-slate-950 font-black'
                : 'bg-[#161B2B] text-slate-400 border border-white/[0.06]'
            }`}
          >
            {expenses.length}
          </span>
        </motion.button>

        <motion.button
          ref={modeScroll.registerItem('recorrentes')}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.96 }}
          onClick={() => {
            setActiveTab('recorrentes');
            modeScroll.scrollItemIntoView('recorrentes');
          }}
          className={`px-3.5 py-2 sm:px-4 sm:py-2.5 rounded-xl text-xs sm:text-sm font-semibold shrink-0 whitespace-nowrap transition-all duration-200 cursor-pointer flex items-center gap-2 select-none border ${
            activeTab === 'recorrentes'
              ? 'bg-sky-500/20 text-sky-200 border-sky-400/90 ring-1 ring-sky-400/40 font-bold'
              : 'bg-[#0E111D] text-slate-400 border-white/[0.08] hover:border-sky-500/50 hover:bg-sky-500/[0.08] hover:text-sky-300'
          }`}
        >
          <span>Contas Recorrentes</span>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] sm:text-xs font-mono font-bold transition-all ${
              activeTab === 'recorrentes'
                ? 'bg-sky-500 text-slate-950 font-black'
                : 'bg-[#161B2B] text-slate-400 border border-white/[0.06]'
            }`}
          >
            {expenses.filter((e) => e.recurrence !== 'nenhuma').length}
          </span>
        </motion.button>

        <motion.button
          ref={modeScroll.registerItem('lancamentos')}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.96 }}
          onClick={() => {
            setActiveTab('lancamentos');
            modeScroll.scrollItemIntoView('lancamentos');
          }}
          className={`px-3.5 py-2 sm:px-4 sm:py-2.5 rounded-xl text-xs sm:text-sm font-semibold shrink-0 whitespace-nowrap transition-all duration-200 cursor-pointer flex items-center gap-2 select-none border ${
            activeTab === 'lancamentos'
              ? 'bg-emerald-500/20 text-emerald-200 border-emerald-400/90 ring-1 ring-emerald-400/40 font-bold'
              : 'bg-[#0E111D] text-slate-400 border-white/[0.08] hover:border-emerald-500/50 hover:bg-emerald-500/[0.08] hover:text-emerald-300'
          }`}
        >
          <span>Receitas Quitadas</span>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] sm:text-xs font-mono font-bold transition-all ${
              activeTab === 'lancamentos'
                ? 'bg-emerald-500 text-slate-950 font-black'
                : 'bg-[#161B2B] text-slate-400 border border-white/[0.06]'
            }`}
          >
            {allInflows.length}
          </span>
        </motion.button>
      </div>

      {activeTab === 'lancamentos' ? (
        /* Inflows / Historical Revenue View */
        <div className="bg-[#11131c] border border-white/[0.08] rounded-2xl overflow-hidden shadow-lg">
          <div className="p-4 border-b border-white/[0.08] flex flex-wrap items-center justify-between gap-2 bg-[#151722]">
            <div>
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">Histórico de Receitas Quitadas</h3>
              <p className="text-[11px] text-slate-400 mt-0.5">Entradas confirmadas de aluguéis e cauções</p>
            </div>
            <div className="flex items-center gap-2 flex-wrap text-xs">
              <span className="px-2.5 py-1 rounded-lg bg-orange-500/15 text-orange-400 border border-orange-500/30 font-bold text-[11px] flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span>
                Cauções: {formatCurrency(totalCaucoesRecebidas)}
              </span>
              <span className="text-xs text-emerald-400 font-semibold">{allInflows.length} lançamentos</span>
            </div>
          </div>

          {allInflows.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-xs">
              Nenhuma receita quitada no momento.
            </div>
          ) : (
            <>
              {/* Mobile View */}
              <div className="block sm:hidden divide-y divide-white/[0.08] p-3 space-y-2.5">
                {allInflows.map((item, index) => (
                  <div
                    key={item.id}
                    style={{ animationDelay: `${Math.min(index * 40, 280)}ms` }}
                    className="p-3.5 bg-[#161824] rounded-xl border border-white/[0.08] space-y-2 animate-card-enter"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h4 className="font-semibold text-xs text-white">{item.title}</h4>
                        <div className="flex items-center gap-1.5 mt-1">
                          <span className="text-[10px] text-slate-400 capitalize">
                            Tipo: {item.type === 'moto' ? 'Moto' : 'Kitnet'}
                          </span>
                          <span className="text-slate-600">•</span>
                          <span
                            className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                              item.category === 'caucao'
                                ? 'bg-orange-500/15 text-orange-400 border border-orange-500/30'
                                : 'bg-violet-500/10 text-violet-300 border border-violet-500/20'
                            }`}
                          >
                            {item.category === 'caucao' ? 'Caução de Entrada' : 'Parcela / Aluguel'}
                          </span>
                        </div>
                      </div>
                      <span className={`text-sm font-bold tabular-nums shrink-0 ${
                        item.category === 'caucao' ? 'text-orange-400' : 'text-emerald-400'
                      }`}>
                        +{formatCurrency(item.amount)}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-white/[0.06]">
                      <span>Recebido em: <strong className="text-slate-200">{formatDate(item.date)}</strong></span>
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                        item.category === 'caucao'
                          ? 'bg-orange-500/15 text-orange-400 border border-orange-500/30'
                          : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                      }`}>
                        {item.category === 'caucao' ? 'Caução Retido' : 'Recebido'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Desktop View */}
              <div className="hidden sm:block overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#161824] text-slate-400 uppercase text-[10px] font-semibold tracking-wider border-b border-white/[0.08]">
                    <tr>
                      <th className="p-3.5">Origem / Referência</th>
                      <th className="p-3.5">Categoria</th>
                      <th className="p-3.5">Tipo</th>
                      <th className="p-3.5">Data de Pagamento</th>
                      <th className="p-3.5">Valor Recebido</th>
                      <th className="p-3.5 text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/[0.06]">
                    {allInflows.map((item) => (
                      <tr key={item.id} className="hover:bg-white/[0.02] transition-colors">
                        <td className="p-3.5 font-semibold text-slate-200">{item.title}</td>
                        <td className="p-3.5">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                              item.category === 'caucao'
                                ? 'bg-orange-500/15 text-orange-400 border border-orange-500/30'
                                : 'bg-violet-500/10 text-violet-300 border border-violet-500/20'
                            }`}
                          >
                            {item.category === 'caucao' ? 'Caução de Entrada' : 'Parcela / Aluguel'}
                          </span>
                        </td>
                        <td className="p-3.5 text-slate-400 capitalize">{item.type === 'moto' ? 'Moto' : 'Kitnet'}</td>
                        <td className="p-3.5 text-slate-200 font-medium tabular-nums">{formatDate(item.date)}</td>
                        <td className={`p-3.5 font-bold tabular-nums whitespace-nowrap ${
                          item.category === 'caucao' ? 'text-orange-400' : 'text-emerald-400'
                        }`}>
                          +{formatCurrency(item.amount)}
                        </td>
                        <td className="p-3.5 text-right">
                          <span className={`px-2.5 py-1 rounded-md text-[10px] font-semibold ${
                            item.category === 'caucao'
                              ? 'bg-orange-500/15 text-orange-400 border border-orange-500/30'
                              : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          }`}>
                            {item.category === 'caucao' ? 'Caução Retido' : 'Recebido'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      ) : (
        /* Expenses Section - EXACT LAYOUT AS IN THE USER IMAGE */
        <div className="space-y-3">
          {/* Search Bar - Matching IMG_0418.jpeg */}
          <div className="relative flex items-center w-full">
            <Search className="absolute left-4 w-4 h-4 text-slate-400 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar despesa..."
              className="w-full bg-[#12141f] hover:bg-[#161825] focus:bg-[#161825] border border-white/[0.09] focus:border-violet-500/60 rounded-2xl pl-11 pr-11 py-3 text-xs sm:text-sm text-white placeholder:text-slate-500 focus:outline-none transition-all shadow-md shadow-black/20"
            />
            <button
              type="button"
              onClick={() => setShowFilterMenu(!showFilterMenu)}
              className="absolute right-3 p-1.5 text-violet-400 hover:text-violet-300 hover:bg-violet-500/10 rounded-xl transition-all cursor-pointer"
              title="Filtrar despesas"
            >
              <SlidersHorizontal className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Filter Menu if opened */}
          {showFilterMenu && (
            <div className="p-3 bg-[#12141f] border border-white/[0.08] rounded-2xl flex flex-wrap items-center gap-2.5 animate-fadeIn">
              <span className="text-xs text-slate-400 font-semibold">Situação:</span>
              <div className="flex items-center gap-1.5 flex-wrap">
                {(['todos', 'vencido', 'pendente', 'pago'] as const).map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setStatusFilter(st)}
                    className={`px-3 py-1 text-xs font-semibold rounded-lg capitalize transition-all cursor-pointer border ${
                      statusFilter === st
                        ? 'bg-violet-600 text-white border-violet-500 shadow-xs'
                        : 'bg-[#181a28] text-slate-400 border-white/[0.06] hover:text-white'
                    }`}
                  >
                    {st === 'todos' ? 'Todos os Status' : st}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Category Chips Bar with smooth auto-center and fluid animations */}
          <div
            ref={categoryScroll.containerRef}
            className="overflow-x-auto pb-1.5 -mx-1 px-1 flex items-center gap-2 no-scrollbar scroll-smooth touch-pan-x"
          >
            {categoryChips.map((chip) => {
              const isSelected = filterCategory === chip.id;
              const IconComponent = chip.icon;
              return (
                <motion.button
                  key={chip.id}
                  ref={categoryScroll.registerItem(chip.id)}
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    setFilterCategory(chip.id);
                    categoryScroll.scrollItemIntoView(chip.id);
                  }}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold shrink-0 whitespace-nowrap transition-all duration-200 cursor-pointer select-none flex items-center gap-1.5 border ${
                    isSelected
                      ? `${chip.activeClass} scale-[1.03]`
                      : `bg-[#151724] hover:bg-[#1a1d2c] text-slate-300 ${chip.hoverBorder} border-white/[0.06]`
                  }`}
                >
                  <IconComponent
                    className={`w-3.5 h-3.5 transition-transform duration-200 ${
                      isSelected ? 'scale-110' : 'opacity-70'
                    }`}
                  />
                  <span>{chip.label}</span>
                </motion.button>
              );
            })}
          </div>

          {/* Expenses List Cards - EXACT CRISP 2-ROW / DUAL-COLUMN CARD AS IN IMG_0418.jpeg */}
          <div className="space-y-2.5">
            {filteredExpenses.length === 0 ? (
              <div className="p-10 text-center bg-[#12141f] border border-white/[0.08] rounded-2xl space-y-3">
                <Receipt className="w-9 h-9 text-slate-500 mx-auto" />
                <p className="text-sm text-slate-300 font-medium">Nenhuma despesa encontrada.</p>
                <p className="text-xs text-slate-500">Tente ajustar os filtros ou cadastre uma nova despesa.</p>
                <button
                  type="button"
                  onClick={() => setShowNewExpenseModal(true)}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl inline-flex items-center gap-1.5 cursor-pointer shadow-md transition-all mt-1"
                >
                  <Plus className="w-4 h-4" />
                  <span>Cadastrar Despesa</span>
                </button>
              </div>
            ) : (
              filteredExpenses.map((exp, index) => {
                const { mainTitle, subtitle } = parseExpenseInfo(exp);
                const status = getExpenseStatus(exp);
                const isPaid = status === 'pago';
                const isOverdue = status === 'vencido';
                const isPending = status === 'pendente';

                return (
                  <div
                    key={exp.id}
                    style={{ animationDelay: `${Math.min(index * 25, 200)}ms` }}
                    className={`bg-[#121420] hover:bg-[#151724] border rounded-2xl p-3.5 sm:p-4 transition-all duration-200 shadow-md flex items-center justify-between gap-3 group ${
                      isOverdue
                        ? 'border-rose-500/60 ring-1 ring-rose-500/40 animate-pulse-red-subtle shadow-rose-950/30'
                        : 'border-white/[0.07] hover:border-white/[0.14] shadow-black/25 animate-card-enter'
                    }`}
                  >
                    {/* Left Section: Category Icon Circle + Info Block */}
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      {/* Circle Icon Badge */}
                      <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-[#181a28] border border-white/[0.08] flex items-center justify-center shrink-0 shadow-inner">
                        {getCategoryCircleIcon(exp.category)}
                      </div>

                      {/* Text details */}
                      <div className="min-w-0 flex-1 space-y-0.5">
                        {/* Main Title */}
                        <h3 className="text-xs sm:text-sm font-bold text-white tracking-tight truncate">
                          {mainTitle}
                        </h3>

                        {/* Subtitle / Location */}
                        <p className="text-[11px] sm:text-xs text-slate-400 font-normal truncate">
                          {subtitle}
                        </p>

                        {/* Category • Recurrence */}
                        <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                          <span className="font-medium text-slate-300">{getCategoryLabel(exp.category)}</span>
                          <span
                            className="inline-block w-1.5 h-1.5 rounded-full shrink-0"
                            style={{ backgroundColor: getCategoryBulletColor(exp.category) }}
                          />
                          <span>{getRecurrenceLabel(exp.recurrence)}</span>
                        </div>

                        {/* Due Date */}
                        <div className="flex items-center gap-1 text-[11px] text-slate-400 pt-0.5">
                          <Calendar className="w-3 h-3 text-slate-400 shrink-0" />
                          <span>
                            Vencimento:{' '}
                            <strong className="text-slate-200 font-medium tabular-nums">
                              {formatDate(exp.dueDate)}
                            </strong>
                          </span>
                        </div>
                      </div>
                    </div>

                      {/* Right Section: Top (Amount + Pending/Overdue Status + Chevron) & Bottom (Pagar/Quitada + Trash) */}
                      <div className="flex flex-col items-end justify-between self-stretch shrink-0 gap-3">
                        {/* Top Right: Amount + Status Pill (if pending/overdue) + Chevron */}
                        <div className="flex items-start gap-2 sm:gap-2.5">
                          <div className="flex flex-col items-end gap-1">
                            <span
                              className={`text-sm sm:text-base font-bold tabular-nums tracking-tight ${
                                isPaid
                                  ? 'text-emerald-400'
                                  : isOverdue
                                  ? 'text-[#EF4444]'
                                  : 'text-slate-100'
                              }`}
                            >
                              {formatCurrency(exp.amount)}
                            </span>

                            {isOverdue && (
                              <div className="mt-0.5">
                                <span className="px-2.5 py-0.5 sm:py-1 rounded-full bg-rose-500/15 border border-rose-500/30 text-rose-400 text-[11px] font-semibold flex items-center gap-1.5 shadow-xs tracking-wide select-none">
                                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse shrink-0" />
                                  <span>Vencido</span>
                                </span>
                              </div>
                            )}
                            {isPending && (
                              <div className="mt-0.5">
                                <span className="px-2.5 py-0.5 sm:py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-400 text-[11px] font-semibold flex items-center gap-1.5 shadow-xs tracking-wide select-none">
                                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                                  <span>Pendente</span>
                                </span>
                              </div>
                            )}
                          </div>

                          {/* Chevron button to open details */}
                          <button
                            type="button"
                            onClick={() => setSelectedExpenseForDetail(exp)}
                            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/[0.08] active:scale-90 transition-all cursor-pointer mt-0.5"
                            title="Ver detalhes da despesa"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        </div>

                        {/* Bottom Right: Green Pagar Button (when pending/overdue) OR Quitada Badge & Trash */}
                        <div className="flex items-center gap-2">
                          {isPaid ? (
                            <div className="px-3 py-1 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-bold text-xs flex items-center gap-1.5 shadow-xs select-none">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                              <span>Quitada</span>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setExpenseToPay(exp)}
                              className="px-3.5 py-1.5 rounded-xl bg-[#10B981] hover:bg-[#059669] active:scale-95 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm shadow-[#10B981]/25 hover:shadow-[#10B981]/40 transition-all duration-150 cursor-pointer whitespace-nowrap"
                            >
                              <CreditCard className="w-3.5 h-3.5" />
                              <span>Pagar</span>
                            </button>
                          )}

                          <button
                            type="button"
                            onClick={() => setExpenseToDelete(exp)}
                            className="p-2 rounded-xl bg-[#181a28] hover:bg-red-500/15 border border-white/[0.08] hover:border-red-500/30 text-slate-400 hover:text-red-400 active:scale-90 transition-all duration-150 cursor-pointer flex items-center justify-center shrink-0"
                            title="Excluir despesa"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* MODAL 1: Confirm Payment */}
      <PayExpenseModal
        expense={expenseToPay}
        onClose={() => setExpenseToPay(null)}
        onConfirm={(expenseId) => {
          payExpense(expenseId);
          setExpenseToPay(null);
        }}
      />

      {/* MODAL 2: View Expense Details */}
      <ExpenseDetailModal
        expense={selectedExpenseForDetail}
        onClose={() => setSelectedExpenseForDetail(null)}
        onDelete={(exp) => {
          setSelectedExpenseForDetail(null);
          setExpenseToDelete(exp);
        }}
        onPay={(exp) => {
          setSelectedExpenseForDetail(null);
          setExpenseToPay(exp);
        }}
      />

      {/* MODAL 3: New Expense Modal */}
      <NewExpenseModal
        isOpen={showNewExpenseModal}
        onClose={() => setShowNewExpenseModal(false)}
        onSubmit={(form) => {
          addExpense({
            title: form.subtitle ? `${form.title} — ${form.subtitle}` : form.title,
            category: form.category,
            targetType: form.targetType,
            targetId: form.targetId || undefined,
            amount: form.amount,
            dueDate: form.dueDate,
            recurrence: form.recurrence,
            notes: form.notes || undefined,
            status: 'pendente',
          });
          setShowNewExpenseModal(false);
        }}
        motos={motos}
        kitnets={kitnets}
      />

      {/* MODAL 4: Delete Expense Confirmation Modal */}
      <DeleteExpenseModal
        expense={expenseToDelete}
        onClose={() => setExpenseToDelete(null)}
        onConfirmDelete={(expenseId) => {
          deleteExpense(expenseId);
          setExpenseToDelete(null);
        }}
      />
    </div>
  );
});
