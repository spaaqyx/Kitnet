import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'motion/react';
import {
  Motorbike,
  X,
  ChevronRight,
  ChevronLeft,
  Check,
  AlertCircle,
  User,
  FileText,
  Calendar,
  DollarSign,
  Wallet,
  FileCheck,
  ClipboardCheck,
} from 'lucide-react';
import { useBodyScrollLock } from '../../../hooks/useBodyScrollLock';
import { MotoStatus, MotoTenant } from '../../../types';
import { NewMotoStepVehicle } from './wizard/NewMotoStepVehicle';
import { NewMotoStepTenant } from './wizard/NewMotoStepTenant';
import { NewMotoStepIncome } from './wizard/NewMotoStepIncome';
import { NewMotoStepContractTerms } from './wizard/NewMotoStepContractTerms';
import { NewMotoStepFinancials } from './wizard/NewMotoStepFinancials';
import { NewMotoStepPayment } from './wizard/NewMotoStepPayment';
import { NewMotoStepDeliveryInspection } from './wizard/NewMotoStepDeliveryInspection';
import { NewMotoStepReviewContract } from './wizard/NewMotoStepReviewContract';
import { validateLicensePlate } from '../../../utils/formatters';
import {
  formatCurrency as defaultFormatCurrency,
  formatDate as defaultFormatDate,
} from '../../../utils/formatters';

const defaultMaskCPF = (v: string) => {
  return v
    .replace(/\D/g, '')
    .slice(0, 11)
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
};

const defaultMaskPhone = (v: string) => {
  return v
    .replace(/\D/g, '')
    .slice(0, 11)
    .replace(/(\d{2})(\d)/, '($1) $2')
    .replace(/(\d{5})(\d{4})$/, '$1-$2');
};

export interface NewMotoWizardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (e: React.FormEvent) => void;
  form: any;
  setForm: React.Dispatch<React.SetStateAction<any>>;
  handleTenantPhotoUpload?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  maskCPFInput?: (v: string) => string;
  maskPhoneInput?: (v: string) => string;
  formatCurrency?: (value: number) => string;
  formatDate?: (dateStr: string) => string;
  existingTenants?: MotoTenant[];
  settings?: any;
}

export const NewMotoWizardModal: React.FC<NewMotoWizardModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  form,
  setForm,
  handleTenantPhotoUpload = () => {},
  maskCPFInput = defaultMaskCPF,
  maskPhoneInput = defaultMaskPhone,
  formatCurrency = defaultFormatCurrency,
  formatDate = defaultFormatDate,
  existingTenants = [],
  settings,
}) => {
  useBodyScrollLock(isOpen);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const [currentStep, setCurrentStep] = useState<1 | 2 | 3 | 4 | 5 | 6 | 7 | 8>(1);
  const [stepError, setStepError] = useState<string | null>(null);

  const isAlugada = form.status === 'alugada';

  // Se o status mudar para diferente de alugada, reseta para a etapa 1
  useEffect(() => {
    if (!isAlugada) {
      setCurrentStep(1);
    }
  }, [isAlugada]);

  // Reseta a etapa ao reabrir o modal
  const wasOpenRef = useRef(isOpen);
  useEffect(() => {
    if (!wasOpenRef.current && isOpen) {
      setCurrentStep(1);
      setStepError(null);
    }
    wasOpenRef.current = isOpen;
  }, [isOpen]);

  const stepperRef = useRef<HTMLDivElement>(null);
  const stepButtonRefs = useRef<{ [key: number]: HTMLButtonElement | null }>({});

  // Auto-scroll fluido para manter o botão ativo visível no centro da barra
  useEffect(() => {
    if (isAlugada && stepButtonRefs.current[currentStep]) {
      stepButtonRefs.current[currentStep]?.scrollIntoView({
        behavior: 'smooth',
        inline: 'center',
        block: 'nearest',
      });
    }
  }, [currentStep, isAlugada]);

  if (typeof document === 'undefined') return null;

  const steps = [
    { num: 1 as const, label: 'Veículo', icon: Motorbike },
    { num: 2 as const, label: 'Locatário', icon: User },
    { num: 3 as const, label: 'Renda & Docs', icon: FileCheck },
    { num: 4 as const, label: 'Contrato', icon: Calendar },
    { num: 5 as const, label: 'Valores', icon: DollarSign },
    { num: 6 as const, label: 'Pagamento', icon: Wallet },
    { num: 7 as const, label: 'Vistoria de Entrega', icon: ClipboardCheck },
    { num: 8 as const, label: 'Emitir Contrato', icon: FileText },
  ];

  const validateForSave = () => {
    setStepError(null);

    // Passo 1: Veículo
    if (!form.model || !form.model.trim()) {
      setStepError('Por favor, informe o Modelo da moto.');
      setCurrentStep(1);
      return false;
    }
    if (!form.plate || !form.plate.trim()) {
      setStepError('Por favor, informe a Placa do veículo.');
      setCurrentStep(1);
      return false;
    }
    const val = validateLicensePlate(form.plate);
    if (!val.isValid) {
      setStepError(
        'Placa inválida. Utilize o formato tradicional (ABC-1234) ou Mercosul (BRA2E19).'
      );
      setCurrentStep(1);
      return false;
    }

    if (!isAlugada) return true;

    // Passo 2: Locatário
    if (!form.tenantName || !form.tenantName.trim()) {
      setStepError('Por favor, informe o Nome Completo do locatário.');
      setCurrentStep(2);
      return false;
    }

    // Passo 5: Valores
    const installmentValue =
      form.paymentFrequency === 'semanal' ? Number(form.weeklyValue) : Number(form.monthlyValue);
    if (!installmentValue || installmentValue <= 0) {
      setStepError('Por favor, informe o valor da locação (semanal ou mensal).');
      setCurrentStep(5);
      return false;
    }

    // Passo 6: Primeiro Pagamento (se marcado como recebido)
    if (form.firstPaymentReceived) {
      if (!form.firstPaymentPaidDate) {
        setStepError('Por favor, informe a data em que o 1º pagamento foi recebido.');
        setCurrentStep(6);
        return false;
      }
    }

    // Passo 7: Vistoria de Entrega
    if (form.inspection) {
      if (!form.inspection.date) {
        setStepError('Por favor, informe a Data da Vistoria.');
        setCurrentStep(7);
        return false;
      }
      if (!form.inspection.time) {
        setStepError('Por favor, informe a Hora da Retirada.');
        setCurrentStep(7);
        return false;
      }
    }

    return true;
  };

  const handleNext = () => {
    setStepError(null);
    if (currentStep === 1) {
      if (!form.model || !form.model.trim()) {
        setStepError('Por favor, informe o Modelo da moto.');
        return;
      }
      if (!form.plate || !form.plate.trim()) {
        setStepError('Por favor, informe a Placa do veículo.');
        return;
      }
      const val = validateLicensePlate(form.plate);
      if (!val.isValid) {
        setStepError('Placa inválida. Utilize o formato tradicional (ABC-1234) ou Mercosul (BRA2E19).');
        return;
      }
    }
    if (currentStep === 2 && isAlugada) {
      if (!form.tenantName || !form.tenantName.trim()) {
        setStepError('Por favor, informe o Nome Completo do locatário.');
        return;
      }
    }
    if (currentStep === 4 || currentStep === 5) {
      // Garante que o total acordado esteja sempre matematicamente consistente
      const isWeekly = form.paymentFrequency === 'semanal';
      const durationMonths = Number(form.durationMonths) || 36;
      const totalWeeks = Math.round(durationMonths * (52 / 12));
      const totalInstallments = isWeekly ? totalWeeks : durationMonths;
      const periodVal = isWeekly ? Number(form.weeklyValue) || 0 : Number(form.monthlyValue) || 0;
      const calculatedTotal = Math.round(periodVal * totalInstallments * 100) / 100;
      const currentTotal = Number(form.totalAgreedValue) || 0;

      if ((currentTotal === 0 || (currentTotal < 100 && calculatedTotal >= 100)) && calculatedTotal > 0) {
        setForm((prev: any) => ({ ...prev, totalAgreedValue: calculatedTotal }));
      }
    }
    if (currentStep === 5 && isAlugada) {
      const installmentValue =
        form.paymentFrequency === 'semanal' ? Number(form.weeklyValue) : Number(form.monthlyValue);
      if (!installmentValue || installmentValue <= 0) {
        setStepError('Por favor, informe o valor da locação (semanal ou mensal).');
        return;
      }
    }
    if (currentStep < 8) {
      setCurrentStep((prev) => (prev + 1) as any);
    }
  };

  const handlePrev = () => {
    setStepError(null);
    if (currentStep > 1) {
      setCurrentStep((prev) => (prev - 1) as any);
    }
  };

  const handleFinalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStepError(null);

    if (!isAlugada) {
      if (!validateForSave()) return;
      setForm((prev: any) => ({
        ...prev,
        tenantName: '',
        tenantCpf: '',
        tenantPhone: '',
        tenantEmail: '',
        tenantRg: '',
        tenantPhoto: '',
        firstPaymentReceived: false,
      }));
      onSubmit(e);
      return;
    }

    if (!validateForSave()) return;

    // Garante que o total acordado seja enviado sem anomalias
    const isWeekly = form.paymentFrequency === 'semanal';
    const durationMonths = Number(form.durationMonths) || 36;
    const totalWeeks = Math.round(durationMonths * (52 / 12));
    const totalInstallments = isWeekly ? totalWeeks : durationMonths;
    const periodVal = isWeekly ? Number(form.weeklyValue) || 0 : Number(form.monthlyValue) || 0;
    const calculatedTotal = Math.round(periodVal * totalInstallments * 100) / 100;
    const currentTotal = Number(form.totalAgreedValue) || 0;

    if ((currentTotal === 0 || (currentTotal < 100 && calculatedTotal >= 100)) && calculatedTotal > 0) {
      form.totalAgreedValue = calculatedTotal;
    }

    onSubmit(e);
  };

  return createPortal(
    <AnimatePresence>
      {isOpen && (
        <motion.div
          key="new-moto-root"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.18 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-2 sm:p-4 overflow-y-auto overflow-x-hidden font-sans touch-pan-y w-full max-w-full"
          style={{ overflowX: 'hidden', touchAction: 'pan-y' }}
          role="dialog"
          aria-modal="true"
          aria-label="Cadastrar Nova Moto"
        >
          {/* Backdrop */}
          <motion.div
            key="new-moto-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/85 backdrop-blur-md"
            onClick={onClose}
          />

          {/* Dialog Card */}
          <motion.div
            key="new-moto-card"
            initial={{ opacity: 0, scale: 0.95, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 12 }}
            transition={{ type: 'spring', damping: 28, stiffness: 350 }}
            onClick={(e) => e.stopPropagation()}
            className={`relative bg-[#0B0D13] border border-white/[0.12] rounded-2xl sm:rounded-3xl w-full ${
              currentStep >= 6 ? 'max-w-6xl' : 'max-w-3xl'
            } max-h-[92vh] sm:max-h-[88vh] shadow-2xl shadow-black/80 overflow-hidden flex flex-col my-auto min-w-0 z-10`}
          >
        {/* MODAL HEADER */}
        <div className="p-4 sm:p-5 border-b border-white/[0.08] flex items-center justify-between bg-[#0E111A]/90 backdrop-blur-sm shrink-0 gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div
              className={`w-9 h-9 sm:w-10 sm:h-10 rounded-2xl border flex items-center justify-center shrink-0 transition-colors ${
                form.status === 'alugada'
                  ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400'
                  : form.status === 'manutencao'
                  ? 'bg-amber-500/15 border-amber-500/30 text-amber-400'
                  : 'bg-sky-500/15 border-sky-500/30 text-sky-400'
              }`}
            >
              <Motorbike className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-sm sm:text-base md:text-lg font-bold text-white truncate">
                  Cadastro de Moto & Locação
                </h2>
                <span
                  className={`text-[10px] sm:text-xs px-2.5 py-0.5 rounded-full font-semibold border shrink-0 transition-colors ${
                    form.status === 'alugada'
                      ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                      : form.status === 'manutencao'
                      ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                      : 'bg-sky-500/15 text-sky-300 border-sky-500/30'
                  }`}
                >
                  {isAlugada ? `Passo ${currentStep} de ${steps.length}` : 'Etapa Única'}
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block truncate">
                {isAlugada
                  ? 'Cadastre a moto, vincule o condutor, configure valores, primeiro pagamento e emita o contrato.'
                  : 'Cadastre a moto e defina seu status operacional no pátio.'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/[0.08] border border-transparent hover:border-white/[0.10] transition-all cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* STEPPER BAR (QUANDO ALUGADA - 8 ETAPAS COMPLETAS) */}
        {isAlugada && (
          <div className="relative bg-[#090B10] border-b border-white/[0.08] px-3 sm:px-5 py-2.5 shrink-0 overflow-hidden">
            {/* Soft fade masks on left and right for seamless scroll indication */}
            <div className="pointer-events-none absolute left-0 top-0 bottom-0 w-6 bg-gradient-to-r from-[#090B10] to-transparent z-10" />
            <div className="pointer-events-none absolute right-0 top-0 bottom-0 w-6 bg-gradient-to-l from-[#090B10] to-transparent z-10" />

            <div
              ref={stepperRef}
              className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto scrollbar-none scroll-smooth py-0.5 px-2"
              style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
            >
              {steps.map((s, idx) => {
                const Icon = s.icon;
                const isCompleted = currentStep > s.num;
                const isCurrent = currentStep === s.num;
                return (
                  <React.Fragment key={s.num}>
                    <motion.button
                      ref={(el) => {
                        stepButtonRefs.current[s.num] = el;
                      }}
                      type="button"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => {
                        setStepError(null);
                        setCurrentStep(s.num);
                      }}
                      className={`group relative flex items-center gap-2 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer shrink-0 whitespace-nowrap border ${
                        isCurrent
                          ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/60 ring-1 ring-emerald-400/30 font-bold'
                          : isCompleted
                          ? 'bg-emerald-500/[0.08] text-emerald-400/90 border-emerald-500/30 hover:bg-emerald-500/[0.14] hover:border-emerald-500/50'
                          : 'bg-[#0E111A]/80 text-slate-400 border-white/[0.06] hover:text-slate-200 hover:border-white/[0.16] hover:bg-white/[0.04]'
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 transition-colors ${
                          isCurrent
                            ? 'bg-emerald-500 text-slate-950'
                            : isCompleted
                            ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-500/40'
                            : 'bg-white/[0.08] text-slate-400 group-hover:text-slate-300'
                        }`}
                      >
                        {isCompleted ? <Check className="w-3 h-3 stroke-[3]" /> : s.num}
                      </div>
                      <Icon
                        className={`w-3.5 h-3.5 shrink-0 transition-colors ${
                          isCurrent
                            ? 'text-emerald-300'
                            : isCompleted
                            ? 'text-emerald-400/80'
                            : 'text-slate-400'
                        }`}
                      />
                      <span className="tracking-tight">{s.label}</span>
                    </motion.button>
                    {idx < steps.length - 1 && (
                      <ChevronRight
                        className={`w-3.5 h-3.5 shrink-0 mx-0.5 transition-colors ${
                          currentStep > s.num ? 'text-emerald-500/60' : 'text-white/[0.15]'
                        }`}
                      />
                    )}
                  </React.Fragment>
                );
              })}
            </div>
          </div>
        )}

        {/* FEEDBACK DE ERRO */}
        {stepError && (
          <div className="mx-4 sm:mx-6 mt-4 p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl flex items-center gap-2.5 text-xs text-rose-300 animate-shake shrink-0">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{stepError}</span>
          </div>
        )}

        {/* MODAL BODY (FORM STEP RENDER) */}
        <form
          id="moto-wizard-form"
          onSubmit={handleFinalSubmit}
          className="flex-1 overflow-y-auto overflow-x-hidden p-4 sm:p-6 space-y-6 scrollbar-thin scrollbar-thumb-white/10"
        >
          {/* ETAPA 1: VEÍCULO */}
          {currentStep === 1 && (
            <NewMotoStepVehicle
              form={form}
              setForm={setForm}
            />
          )}

          {/* ETAPA 2: LOCATÁRIO (DADOS PESSOAIS & ENDEREÇO) */}
          {currentStep === 2 && isAlugada && (
            <NewMotoStepTenant
              form={form}
              setForm={setForm}
              handleTenantPhotoUpload={handleTenantPhotoUpload}
              maskCPFInput={maskCPFInput}
              maskPhoneInput={maskPhoneInput}
              existingTenants={existingTenants}
            />
          )}

          {/* ETAPA 3: CNH, RENDA & DOCUMENTOS */}
          {currentStep === 3 && isAlugada && (
            <NewMotoStepIncome
              form={form}
              setForm={setForm}
              handleTenantPhotoUpload={handleTenantPhotoUpload}
            />
          )}

          {/* ETAPA 4: TERMOS DO CONTRATO */}
          {currentStep === 4 && isAlugada && (
            <NewMotoStepContractTerms
              form={form}
              setForm={setForm}
            />
          )}

          {/* ETAPA 5: VALORES & CONDIÇÕES FINANCEIRAS */}
          {currentStep === 5 && isAlugada && (
            <NewMotoStepFinancials
              form={form}
              setForm={setForm}
            />
          )}

          {/* ETAPA 6: PAGAMENTO & PRIMEIRO PAGAMENTO (SIM/NÃO) */}
          {currentStep === 6 && isAlugada && (
            <NewMotoStepPayment
              form={form}
              setForm={setForm}
              settings={settings}
            />
          )}

          {/* ETAPA 7: VISTORIA DE ENTREGA */}
          {currentStep === 7 && isAlugada && (
            <NewMotoStepDeliveryInspection
              form={form}
              setForm={setForm}
              selectedMoto={{
                brand: form.brand,
                model: form.model,
                plate: form.plate,
                year: form.year,
                color: form.color,
                currentKm: form.currentKm,
              }}
            />
          )}

          {/* ETAPA 8: EMITIR CONTRATO & REVISÃO */}
          {currentStep === 8 && isAlugada && (
            <NewMotoStepReviewContract
              form={form}
              settings={settings}
            />
          )}
        </form>

        {/* MODAL FOOTER */}
        <div className="p-4 sm:p-5 border-t border-white/[0.08] flex items-center justify-between bg-[#0E111A]/90 backdrop-blur-sm shrink-0 gap-3">
          <div>
            {isAlugada && currentStep > 1 && (
              <button
                type="button"
                onClick={handlePrev}
                className="px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold text-slate-300 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Voltar</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              Cancelar
            </button>

            {/* SE NÃO FOR ALUGADA OU SE JÁ ESTIVER NA ÚLTIMA ETAPA (8) -> SALVAR */}
            {!isAlugada || currentStep === 8 ? (
              <button
                type="submit"
                form="moto-wizard-form"
                className={`px-4 sm:px-6 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-slate-950 flex items-center gap-2 transition-all cursor-pointer active:scale-95 ${
                  form.status === 'alugada'
                    ? 'bg-emerald-500 hover:bg-emerald-400 ring-1 ring-emerald-400/40'
                    : form.status === 'manutencao'
                    ? 'bg-amber-500 hover:bg-amber-400 ring-1 ring-amber-400/40'
                    : 'bg-sky-500 hover:bg-sky-400 ring-1 ring-sky-400/40'
                }`}
              >
                <Check className="w-4 h-4 stroke-[2.5] shrink-0" />
                <span className="whitespace-nowrap">
                  {isAlugada ? (
                    <>
                      <span className="hidden sm:inline">Concluir Locação e Gerar Contrato</span>
                      <span className="sm:hidden">Concluir Locação</span>
                    </>
                  ) : (
                    'Salvar Moto no Pátio'
                  )}
                </span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleNext}
                className="px-4 sm:px-6 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-slate-950 bg-emerald-500 hover:bg-emerald-400 flex items-center gap-2 ring-1 ring-emerald-400/40 transition-all cursor-pointer active:scale-95 hover:brightness-110"
              >
                <span className="whitespace-nowrap">
                  {currentStep === 1 ? (
                    <>
                      <span className="hidden sm:inline">Avançar para Locatário</span>
                      <span className="sm:hidden">Avançar</span>
                    </>
                  ) : (
                    'Avançar'
                  )}
                </span>
                <ChevronRight className="w-4 h-4 shrink-0" />
              </button>
            )}
          </div>
        </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
};
