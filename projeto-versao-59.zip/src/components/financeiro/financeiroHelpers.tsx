import React from 'react';
import {
  Wifi,
  Droplets,
  Zap,
  Building2,
  Shield,
  Wrench,
  Receipt,
} from 'lucide-react';
import { Expense, ExpenseCategory, ExpenseRecurrence } from '../../types';
import { getTodayLocalDateString } from '../../utils/formatters';

export const getCategoryCircleIcon = (cat: ExpenseCategory | string) => {
  switch (cat) {
    case 'internet':
      return <Wifi className="w-5 h-5 text-[#A855F7]" />;
    case 'agua':
      return <Droplets className="w-5 h-5 text-[#38BDF8]" />;
    case 'energia':
      return <Zap className="w-5 h-5 text-[#F59E0B]" />;
    case 'iptu':
      return <Building2 className="w-5 h-5 text-[#10B981]" />;
    case 'seguro':
      return <Shield className="w-5 h-5 text-[#818CF8]" />;
    case 'manutencao_moto':
    case 'reparo':
    case 'reforma':
      return <Wrench className="w-5 h-5 text-[#FB923C]" />;
    default:
      return <Receipt className="w-5 h-5 text-[#A855F7]" />;
  }
};

export const getCategoryBulletColor = (cat: ExpenseCategory | string): string => {
  switch (cat) {
    case 'internet':
      return '#A855F7';
    case 'agua':
      return '#38BDF8';
    case 'energia':
      return '#F59E0B';
    case 'iptu':
      return '#10B981';
    case 'seguro':
      return '#818CF8';
    case 'manutencao_moto':
    case 'reparo':
    case 'reforma':
      return '#FB923C';
    default:
      return '#A855F7';
  }
};

export const getCategoryLabel = (cat: ExpenseCategory | string): string => {
  switch (cat) {
    case 'internet':
      return 'Internet';
    case 'agua':
      return 'Água';
    case 'energia':
      return 'Energia';
    case 'iptu':
      return 'IPTU';
    case 'seguro':
      return 'Seguro';
    case 'manutencao_moto':
      return 'Manutenção';
    case 'reparo':
      return 'Reparo';
    case 'reforma':
      return 'Reforma';
    default:
      return 'Serviços';
  }
};

export const getRecurrenceLabel = (rec: ExpenseRecurrence): string => {
  switch (rec) {
    case 'mensal':
      return 'Mensal';
    case 'anual':
      return 'Anual';
    case 'trimestral':
      return 'Trimestral';
    case 'semestral':
      return 'Semestral';
    default:
      return 'Eventual';
  }
};

export const getExpenseStatus = (exp: Expense): 'pago' | 'vencido' | 'pendente' => {
  if (exp.status === 'pago') return 'pago';
  const today = getTodayLocalDateString();
  if (exp.dueDate < today) return 'vencido';
  return 'pendente';
};
