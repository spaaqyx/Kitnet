import React from 'react';
import { createPortal } from 'react-dom';
import { Trash2, X } from 'lucide-react';
import { Expense } from '../../types';
import { formatCurrency, formatDate } from '../../utils/formatters';

interface DeleteExpenseModalProps {
  expense: Expense | null;
  onClose: () => void;
  onConfirmDelete: (expenseId: string) => void;
}

export const DeleteExpenseModal: React.FC<DeleteExpenseModalProps> = ({
  expense,
  onClose,
  onConfirmDelete,
}) => {
  if (!expense || typeof document === 'undefined') return null;

  return createPortal(
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Excluir Despesa"
      className="fixed inset-0 z-[110] flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn font-sans"
    >
      <div className="bg-[#11131c] border border-white/[0.12] rounded-2xl sm:rounded-3xl w-full max-w-md overflow-hidden shadow-2xl my-auto animate-modal-enter">
        <div className="p-5 border-b border-white/[0.08] flex items-center justify-between bg-[#161825]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-red-500/15 border border-red-500/30 text-red-400">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Excluir Despesa</h3>
              <p className="text-[11px] text-slate-400">Esta ação removerá a conta do histórico</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-white/[0.06] transition-colors cursor-pointer"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-4">
          <p className="text-xs sm:text-sm text-slate-300">
            Tem certeza de que deseja excluir permanentemente a despesa{' '}
            <strong className="text-white font-semibold">"{expense.title}"</strong>?
          </p>

          <div className="p-3.5 rounded-xl bg-[#161825] border border-white/[0.06] space-y-1.5 text-xs text-slate-400">
            <div className="flex justify-between">
              <span>Valor:</span>
              <span className="font-bold text-white tabular-nums">{formatCurrency(expense.amount)}</span>
            </div>
            <div className="flex justify-between">
              <span>Vencimento:</span>
              <span className="text-slate-300 tabular-nums">{formatDate(expense.dueDate)}</span>
            </div>
            <div className="flex justify-between">
              <span>Status:</span>
              <span className="capitalize text-slate-300">{expense.status}</span>
            </div>
          </div>

          <div className="pt-3 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs font-semibold text-slate-400 hover:text-white rounded-xl hover:bg-white/[0.05] transition-colors cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={() => onConfirmDelete(expense.id)}
              className="px-5 py-2.5 bg-red-600 hover:bg-red-500 active:scale-95 text-white font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Trash2 className="w-4 h-4" />
              <span>Sim, Excluir Despesa</span>
            </button>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
};
