import React, { useState } from 'react';
import { createPortal } from 'react-dom';
import { Plus, X } from 'lucide-react';
import { Moto, Kitnet, ExpenseCategory, ExpenseRecurrence } from '../../types';
import { getTodayLocalDateString } from '../../utils/formatters';
import { CurrencyInput } from '../NumericInput';

interface NewExpenseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (expenseData: {
    title: string;
    subtitle: string;
    category: ExpenseCategory;
    targetType: 'geral' | 'moto' | 'kitnet';
    targetId: string;
    amount: number;
    dueDate: string;
    recurrence: ExpenseRecurrence;
    notes: string;
  }) => void;
  motos: Moto[];
  kitnets: Kitnet[];
}

export const NewExpenseModal: React.FC<NewExpenseModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  motos,
  kitnets,
}) => {
  const [form, setForm] = useState({
    title: '',
    subtitle: '',
    category: 'internet' as ExpenseCategory,
    targetType: 'kitnet' as 'geral' | 'moto' | 'kitnet',
    targetId: '',
    amount: 129.9,
    dueDate: getTodayLocalDateString(),
    recurrence: 'mensal' as ExpenseRecurrence,
    notes: '',
  });

  if (!isOpen || typeof document === 'undefined') return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) return;
    onSubmit(form);
    // Reset form
    setForm({
      title: '',
      subtitle: '',
      category: 'internet',
      targetType: 'kitnet',
      targetId: '',
      amount: 129.9,
      dueDate: getTodayLocalDateString(),
      recurrence: 'mensal',
      notes: '',
    });
  };

  return createPortal(
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Cadastrar Nova Despesa"
      className="fixed inset-0 z-[100] flex items-center justify-center p-2.5 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn font-sans"
    >
      <div className="bg-[#11131c] border border-white/[0.12] rounded-2xl sm:rounded-3xl w-full max-w-lg max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl my-auto animate-modal-enter min-w-0">
        {/* Modal Header */}
        <div className="p-3.5 sm:p-4.5 border-b border-white/[0.08] flex items-center justify-between bg-[#161825] shrink-0">
          <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
            <Plus className="w-4 h-4 sm:w-5 sm:h-5 text-violet-400" />
            <span>Cadastrar Nova Despesa</span>
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-white/[0.06] transition-colors cursor-pointer"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form & Scrollable Fields Container */}
        <form onSubmit={handleSubmit} className="flex flex-col flex-1 min-h-0 overflow-hidden">
          <div className="flex-1 overflow-y-auto min-h-0 p-4 sm:p-5 space-y-3 sm:space-y-3.5 custom-scrollbar">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Título da Despesa</label>
              <input
                type="text"
                required
                placeholder="Ex: Internet Fibra 600MB"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                className="w-full bg-[#161825] border border-white/[0.1] rounded-xl px-3 sm:px-3.5 py-2 sm:py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-violet-500 placeholder:text-slate-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Subtítulo / Local / Bloco</label>
              <input
                type="text"
                placeholder="Ex: Bloco Kitnets, Iluminação Externa, Geral"
                value={form.subtitle}
                onChange={(e) => setForm({ ...form, subtitle: e.target.value })}
                className="w-full bg-[#161825] border border-white/[0.1] rounded-xl px-3 sm:px-3.5 py-2 sm:py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-violet-500 placeholder:text-slate-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Categoria</label>
                <select
                  value={form.category}
                  onChange={(e) => {
                    const cat = e.target.value as ExpenseCategory;
                    let newTarget = form.targetType;
                    let newSub = form.subtitle;
                    if (cat === 'manutencao_moto') {
                      newTarget = 'moto';
                      newSub = 'Frota de Motos';
                    } else if (cat === 'iptu' || cat === 'reparo' || cat === 'reforma' || cat === 'agua' || cat === 'energia' || cat === 'internet') {
                      newTarget = 'kitnet';
                      newSub = 'Geral Kitnets';
                    }
                    setForm({ ...form, category: cat, targetType: newTarget, subtitle: newSub });
                  }}
                  className="w-full bg-[#161825] border border-white/[0.1] rounded-xl px-3 sm:px-3.5 py-2 sm:py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-violet-500 cursor-pointer"
                >
                  <option value="manutencao_moto">🏍️ Manutenção de Moto</option>
                  <option value="internet">📶 Internet</option>
                  <option value="agua">💧 Água</option>
                  <option value="energia">⚡ Energia</option>
                  <option value="iptu">🏛️ IPTU</option>
                  <option value="seguro">🛡️ Seguro</option>
                  <option value="reparo">🔧 Reparo Kitnet</option>
                  <option value="reforma">🔨 Reforma</option>
                  <option value="outros">🧾 Outros / Serviços</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Vínculo do Patrimônio</label>
                <select
                  value={form.targetType}
                  onChange={(e) => {
                    const tType = e.target.value as 'kitnet' | 'moto' | 'geral';
                    let sub = form.subtitle;
                    if (tType === 'moto' && (!sub || sub === 'Geral Kitnets')) sub = 'Frota de Motos';
                    if (tType === 'kitnet' && (!sub || sub === 'Frota de Motos')) sub = 'Geral Kitnets';
                    setForm({ ...form, targetType: tType, subtitle: sub });
                  }}
                  className="w-full bg-[#161825] border border-white/[0.1] rounded-xl px-3 sm:px-3.5 py-2 sm:py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-violet-500 cursor-pointer"
                >
                  <option value="moto">🏍️ Frota de Motos</option>
                  <option value="kitnet">🏢 Kitnets (Imóveis)</option>
                  <option value="geral">💼 Geral / Administrativo</option>
                </select>
              </div>
            </div>

            {form.targetType === 'moto' && motos.length > 0 && (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Moto Específica (Opcional)</label>
                <select
                  value={form.targetId || ''}
                  onChange={(e) => {
                    const selId = e.target.value;
                    const selMoto = motos.find((m) => m.id === selId);
                    setForm({
                      ...form,
                      targetId: selId,
                      subtitle: selMoto ? `${selMoto.brand} ${selMoto.model} (${selMoto.plate})` : 'Frota de Motos',
                    });
                  }}
                  className="w-full bg-[#161825] border border-white/[0.1] rounded-xl px-3 sm:px-3.5 py-2 sm:py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-amber-500 cursor-pointer"
                >
                  <option value="">Todas / Frota Geral de Motos</option>
                  {motos.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.brand} {m.model} — {m.plate} ({m.color})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {form.targetType === 'kitnet' && kitnets.length > 0 && (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Kitnet Específica (Opcional)</label>
                <select
                  value={form.targetId || ''}
                  onChange={(e) => {
                    const selId = e.target.value;
                    const selKitnet = kitnets.find((k) => k.id === selId);
                    setForm({
                      ...form,
                      targetId: selId,
                      subtitle: selKitnet ? selKitnet.name : 'Geral Kitnets',
                    });
                  }}
                  className="w-full bg-[#161825] border border-white/[0.1] rounded-xl px-3 sm:px-3.5 py-2 sm:py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-sky-500 cursor-pointer"
                >
                  <option value="">Todas / Geral Kitnets</option>
                  {kitnets.map((k) => (
                    <option key={k.id} value={k.id}>
                      {k.name} ({k.address || `Nº ${k.number}`})
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Valor (R$)</label>
              <CurrencyInput
                value={form.amount}
                onChange={(val) => setForm({ ...form, amount: val })}
                className="h-10 sm:h-11 w-full bg-[#161825] border border-white/[0.1] rounded-xl px-3 sm:px-3.5 text-xs sm:text-sm text-white focus:outline-none focus:border-violet-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Data de Vencimento</label>
                <input
                  type="date"
                  required
                  value={form.dueDate}
                  onChange={(e) => setForm({ ...form, dueDate: e.target.value })}
                  className="h-10 sm:h-11 w-full flex items-center bg-[#161825] border border-white/[0.1] rounded-xl px-3 sm:px-3.5 text-xs sm:text-sm text-white focus:outline-none focus:border-violet-500 leading-normal [color-scheme:dark]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Recorrência</label>
                <select
                  value={form.recurrence}
                  onChange={(e) => setForm({ ...form, recurrence: e.target.value as any })}
                  className="h-10 sm:h-11 w-full bg-[#161825] border border-white/[0.1] rounded-xl px-3 sm:px-3.5 text-xs sm:text-sm text-white focus:outline-none focus:border-violet-500 cursor-pointer"
                >
                  <option value="mensal">Mensal</option>
                  <option value="anual">Anual</option>
                  <option value="trimestral">Trimestral</option>
                  <option value="semestral">Semestral</option>
                  <option value="nenhuma">Eventual / Única</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Observações (Opcional)</label>
              <input
                type="text"
                placeholder="Ex: Código do boleto, operadora, etc."
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                className="w-full bg-[#161825] border border-white/[0.1] rounded-xl px-3 sm:px-3.5 py-2 sm:py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-violet-500 placeholder:text-slate-500"
              />
            </div>
          </div>

          {/* Bottom Actions Footer */}
          <div className="p-3 sm:p-4 border-t border-white/[0.08] flex items-center justify-end gap-2.5 bg-[#161825] shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 sm:px-4 py-2 sm:py-2.5 text-xs font-semibold text-slate-400 hover:text-white rounded-xl hover:bg-white/[0.05] transition-colors cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 sm:px-5 py-2 sm:py-2.5 bg-violet-600 hover:bg-violet-500 active:scale-95 text-white font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Salvar Despesa</span>
            </button>
          </div>
        </form>
      </div>
    </div>,
    document.body
  );
};
