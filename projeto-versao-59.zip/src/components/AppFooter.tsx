import React from 'react';
import { useApp } from '../context/AppContext';

export const AppFooter: React.FC = React.memo(() => {
  const { settings, isReadOnlyMode } = useApp();
  const adminName = settings?.adminName || settings?.representativeName || 'Wigne Leal Xavier Macedo';

  return (
    <footer
      id="app-global-footer"
      role="contentinfo"
      className="w-full shrink-0 border-t border-white/[0.06] bg-[#090A0F]/90 backdrop-blur-sm mt-auto transition-all"
    >
      <div
        className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 sm:py-4 flex flex-col sm:flex-row items-center justify-between gap-2 sm:gap-4 text-[11px] text-slate-400 select-none ${
          isReadOnlyMode
            ? 'pb-[calc(1.25rem+env(safe-area-inset-bottom,0px))] lg:pb-4'
            : 'pb-[calc(5rem+env(safe-area-inset-bottom,0px))] lg:pb-4'
        }`}
      >
        {/* Status indicator */}
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block animate-pulse shrink-0" />
          <span className="font-medium text-slate-300">Sistema Operacional</span>
          <span className="text-slate-600">&middot;</span>
          <span className="text-slate-400">Integridade 100%</span>
        </div>

        {/* Version & Admin */}
        <div className="flex items-center gap-2 text-slate-400">
          <span className="font-mono text-slate-400 bg-white/[0.04] px-1.5 py-0.5 rounded border border-white/[0.06]">
            v2.4.0
          </span>
          <span className="text-slate-600">&middot;</span>
          <span>
            Admin: <strong className="text-slate-200 font-semibold">{adminName}</strong>
          </span>
        </div>
      </div>
    </footer>
  );
});

AppFooter.displayName = 'AppFooter';
