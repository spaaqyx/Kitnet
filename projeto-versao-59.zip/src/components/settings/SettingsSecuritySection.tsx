import React, { useState } from 'react';
import { Shield, Lock, LogOut, CheckCircle2, ChevronRight, KeyRound, Check, Eye, EyeOff } from 'lucide-react';
import { SystemSettings } from '../../types';

interface SettingsSecuritySectionProps {
  settings: SystemSettings;
  lockApp: () => void;
  onOpenLogoutModal: () => void;
  updateSettings?: (newSettings: Partial<SystemSettings>) => void;
  isReadOnlyMode?: boolean;
  toggleReadOnlyMode?: (arg?: any) => any;
}

export const SettingsSecuritySection: React.FC<SettingsSecuritySectionProps> = ({
  settings,
  lockApp,
  onOpenLogoutModal,
  updateSettings,
  isReadOnlyMode = false,
  toggleReadOnlyMode,
}) => {
  const [newPin, setNewPin] = useState(settings.pinCode || '1234');
  const [pinSaved, setPinSaved] = useState(false);

  const handleSavePin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPin.trim() || !updateSettings) return;
    updateSettings({ pinCode: newPin.trim() });
    setPinSaved(true);
    setTimeout(() => setPinSaved(false), 2500);
  };
  return (
    <div className="rounded-2xl bg-[#11141e]/90 border border-white/[0.08] p-5 sm:p-6 shadow-xl shadow-black/30 space-y-4 backdrop-blur-md">
      {/* Header */}
      <div className="flex items-center justify-between pb-3.5 border-b border-white/[0.06]">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-violet-500/10 border border-violet-500/20 flex items-center justify-center text-violet-400">
            <Shield className="w-4 h-4" />
          </div>
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            Segurança & Sessão
          </h3>
        </div>
        <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-full shadow-xs">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          Google Autenticado
        </span>
      </div>

      {/* Security Action Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        {/* Bloquear App */}
        <button
          type="button"
          onClick={lockApp}
          className="group relative overflow-hidden p-4 rounded-xl bg-gradient-to-b from-[#161a27] to-[#12141f] hover:from-[#1b2030] hover:to-[#151824] border border-white/[0.08] hover:border-violet-500/40 text-left flex items-center justify-between gap-3 transition-all duration-200 cursor-pointer active:scale-[0.98]"
        >
          <div className="flex items-center gap-3.5 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center text-violet-400 group-hover:bg-violet-500/20 group-hover:scale-105 group-hover:text-violet-300 transition-all shrink-0">
              <Lock className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <p className="text-xs font-bold text-slate-100 group-hover:text-violet-300 transition-colors">
                  Bloquear Acesso Agora
                </p>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5 truncate">
                Retorna à tela de login seguro
              </p>
            </div>
          </div>
          <div className="w-7 h-7 rounded-lg bg-white/[0.04] group-hover:bg-violet-500/20 flex items-center justify-center text-slate-400 group-hover:text-violet-300 shrink-0 transition-all group-hover:translate-x-0.5">
            <ChevronRight className="w-4 h-4" />
          </div>
        </button>

        {/* Sair da Conta Google */}
        <button
          type="button"
          onClick={onOpenLogoutModal}
          className="group relative overflow-hidden p-4 rounded-xl bg-gradient-to-b from-[#161a27] to-[#12141f] hover:from-rose-950/20 hover:to-[#151824] border border-white/[0.08] hover:border-rose-500/40 text-left flex items-center justify-between gap-3 transition-all duration-200 cursor-pointer active:scale-[0.98]"
        >
          <div className="flex items-center gap-3.5 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 group-hover:bg-rose-500/20 group-hover:scale-105 group-hover:text-rose-300 transition-all shrink-0">
              <LogOut className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-slate-100 group-hover:text-rose-300 transition-colors">
                Encerrar Sessão
              </p>
              <p className="text-[11px] text-slate-400 mt-0.5 truncate">
                Desconecta {settings.adminEmail || 'Google Auth'}
              </p>
            </div>
          </div>
          <div className="w-7 h-7 rounded-lg bg-white/[0.04] group-hover:bg-rose-500/20 flex items-center justify-center text-slate-400 group-hover:text-rose-300 shrink-0 transition-all group-hover:translate-x-0.5">
            <ChevronRight className="w-4 h-4" />
          </div>
        </button>
      </div>

      {/* Modo Leitura (Exibe apenas Dashboard e Valores) */}
      {toggleReadOnlyMode && (
        <div className="pt-3 border-t border-white/[0.06] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-[#161a27]/60 border border-violet-500/20">
          <div className="flex items-center gap-3">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
              isReadOnlyMode
                ? 'bg-violet-500/20 text-violet-300 border border-violet-500/40'
                : 'bg-white/[0.05] text-slate-400 border border-white/[0.08]'
            }`}>
              {isReadOnlyMode ? <Eye className="w-4 h-4 text-violet-400 animate-pulse" /> : <EyeOff className="w-4 h-4" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <p className="text-xs font-bold text-slate-100">
                  Modo Leitura
                </p>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                    isReadOnlyMode
                      ? 'bg-violet-500/20 text-violet-300 border border-violet-500/40'
                      : 'bg-white/[0.06] text-slate-400'
                  }`}
                >
                  {isReadOnlyMode ? 'Ligado' : 'Desligado'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                Exibe apenas a Dashboard e os valores do patrimônio, sem ações ou botões de edição.
              </p>
            </div>
          </div>

          <button
            type="button"
            id="btn-toggle-readonly-mode"
            onClick={() => toggleReadOnlyMode()}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shrink-0 active:scale-95 shadow-sm ${
              isReadOnlyMode
                ? 'bg-rose-500/90 hover:bg-rose-500 text-white font-bold'
                : 'bg-violet-600 hover:bg-violet-500 text-white font-bold'
            }`}
          >
            {isReadOnlyMode ? (
              <>
                <EyeOff className="w-3.5 h-3.5" />
                <span>Desligar Modo Leitura</span>
              </>
            ) : (
              <>
                <Eye className="w-3.5 h-3.5" />
                <span>Ligar Modo Leitura</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* Gerenciar PIN de Segurança */}
      {updateSettings && (
        <form
          onSubmit={handleSavePin}
          className="pt-3 border-t border-white/[0.06] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
              <KeyRound className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-200">
                Código PIN de Acesso Local
              </p>
              <p className="text-[11px] text-slate-400">
                Utilizado para desbloquear o sistema sem conexão (4 a 8 dígitos)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <input
              type="text"
              id="input-settings-pin"
              aria-label="Código PIN de acesso local"
              inputMode="numeric"
              maxLength={8}
              value={newPin}
              onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ''))}
              placeholder="Ex: 1234"
              className="h-9 w-28 px-3 rounded-lg bg-[#161a27] border border-white/[0.1] text-center font-mono text-sm text-white focus:outline-none focus:border-amber-500/60"
            />
            <button
              type="submit"
              className={`h-9 px-3.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                pinSaved
                  ? 'bg-emerald-500 text-slate-950'
                  : 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 active:scale-95'
              }`}
            >
              {pinSaved ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Salvo!</span>
                </>
              ) : (
                <span>Salvar PIN</span>
              )}
            </button>
          </div>
        </form>
      )}
    </div>
  );
};

