import React from 'react';
import { X, ZoomIn } from 'lucide-react';

export interface PhotoZoomModalProps {
  photoPreview?: { url: string; title?: string } | null;
  photo?: string | { url: string; title?: string } | null;
  photoUrl?: string | null;
  title?: string;
  onClose: () => void;
}

export const PhotoZoomModal: React.FC<PhotoZoomModalProps> = ({
  photoPreview,
  photo,
  photoUrl,
  title,
  onClose,
}) => {
  let displayUrl = '';
  let displayTitle = title || 'Visualização da Foto';

  if (photoPreview?.url) {
    displayUrl = photoPreview.url;
    if (photoPreview.title) displayTitle = photoPreview.title;
  } else if (typeof photo === 'string') {
    displayUrl = photo;
  } else if (photo && typeof photo === 'object' && photo.url) {
    displayUrl = photo.url;
    if (photo.title) displayTitle = photo.title;
  } else if (photoUrl) {
    displayUrl = photoUrl;
  }

  if (!displayUrl) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={displayTitle}
      className="fixed inset-0 z-[150] flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-modal-enter"
      onClick={onClose}
    >
      <div
        className="relative max-w-4xl max-h-[90vh] w-full flex flex-col items-center"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-full flex items-center justify-between pb-3 text-white border-b border-white/[0.1] mb-3">
          <div className="flex items-center gap-2">
            <ZoomIn className="w-4 h-4 text-violet-400" />
            <span className="text-sm font-semibold truncate">{displayTitle}</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar visualização"
            className="w-8 h-8 rounded-full bg-white/[0.1] hover:bg-white/[0.2] text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="relative max-h-[80vh] overflow-hidden rounded-xl border border-white/[0.1] bg-black/40 flex items-center justify-center">
          <img
            src={displayUrl}
            alt={displayTitle}
            className="max-h-[78vh] w-auto object-contain rounded-lg shadow-2xl"
          />
        </div>
      </div>
    </div>
  );
};
