import React from 'react';

export interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
  actionIcon?: React.ReactNode;
  category?: 'motos' | 'kitnets' | string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon,
  title,
  description,
  actionLabel,
  onAction,
  actionIcon,
  category = 'motos',
}) => {
  const isKitnets = category === 'kitnets';
  const btnClass = isKitnets
    ? 'bg-[#0EA5E9] hover:bg-[#0284C7] text-white shadow-[#0EA5E9]/20'
    : 'bg-[#E07A3F] hover:bg-[#C25E26] text-white shadow-[#E07A3F]/20';

  return (
    <div className="flex flex-col items-center justify-center p-8 text-center rounded-2xl bg-[#0F1322]/80 border border-white/[0.06] my-4">
      {icon && <div className="mb-4 text-slate-400">{icon}</div>}
      <h3 className="text-base font-bold text-white mb-1.5">{title}</h3>
      {description && (
        <p className="text-xs text-slate-400 max-w-sm mb-5 leading-relaxed">
          {description}
        </p>
      )}
      {actionLabel && onAction && (
        <button
          type="button"
          onClick={onAction}
          className={`h-10 px-4 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer shadow-md active:scale-95 ${btnClass}`}
        >
          {actionIcon}
          <span>{actionLabel}</span>
        </button>
      )}
    </div>
  );
};
