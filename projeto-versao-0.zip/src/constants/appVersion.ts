/**
 * src/constants/appVersion.ts
 * 
 * Fonte Única da Verdade para a versão e build da aplicação no cliente.
 * Atualizado automaticamente pelo sistema de build (scripts/generate-source-zip.js e scripts/increment-build.js).
 * NUNCA utilize números fixos mágicos como fallback no código.
 */

export const CURRENT_APP_VERSION_NUMBER = 0;
export const CURRENT_APP_VERSION_STRING = 'Versão 0';
export const CURRENT_APP_BUILD_ID = 'BUILD-V0-MTREJC68';
export const CURRENT_APP_ZIP_FILENAME = 'projeto-versao-0.zip';
export const CURRENT_APP_ZIP_URL = '/versions/projeto-versao-0.zip';
export const CURRENT_APP_GENERIC_ZIP_URL = '/projeto-completo.zip';

export const CURRENT_APP_BUILD_DATE = '07/09/2026';
export const CURRENT_APP_BUILD_DATETIME = '07/09/2026 às 12:35:00';
