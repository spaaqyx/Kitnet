import React, { useState } from 'react';
import {
  FileText,
  Copy,
  Printer,
  Download,
  Check,
  FileCheck,
  ShieldCheck,
  Calendar,
  Clock,
  Gauge,
  Fuel,
  Video,
  CheckCircle2,
  AlertCircle,
  Sparkles,
} from 'lucide-react';
import { formatCPF, formatDate } from '../../../../utils/formatters';
import {
  generateMotoRentalContractPdfFile,
  MotoRentalContractPdfOptions,
} from '../../../../utils/pdf/motoPdfGenerator';
import {
  extractOfficialMotoContractData,
  getOfficialMotoContractSections,
  getOfficialMotoContractRawText,
} from '../../../../utils/pdf/officialMotoContract';
import { copyTextToClipboard, printContractDocument } from '../../../../utils/printHelper';
import {
  IconPneuDianteiro,
  IconPneuTraseiro,
  IconFreioDianteiro,
  IconFreioTraseiro,
  IconFarolLanternas,
  IconSetas,
  IconBuzina,
  IconRetrovisores,
  IconAssentoBanco,
  IconPinturaLataria,
  IconCombustivel,
  IconCapacete,
  IconCapaChuva,
  IconSuporteCelular,
  IconBauBauleto,
  IconChaveReserva,
  IconOutros,
  IconStatusBom,
  IconStatusRegular,
  IconStatusRuim,
} from './inspectionIcons';

interface NewMotoStepReviewContractProps {
  form: any;
  settings: any;
}

export const NewMotoStepReviewContract: React.FC<NewMotoStepReviewContractProps> = ({
  form,
  settings,
}) => {
  const [contractTab, setContractTab] = useState<'preview' | 'text'>('preview');
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Fonte canônica única de dados do contrato oficial
  const contractData = extractOfficialMotoContractData(form, settings);
  const sections = getOfficialMotoContractSections(contractData);
  const rawContractText = getOfficialMotoContractRawText(contractData);

  const getPdfOptions = (autoDownload = true): MotoRentalContractPdfOptions => ({
    moto: {
      id: 'preview',
      brand: contractData.moto.brand,
      model: contractData.moto.model,
      plate: contractData.moto.plate,
      year: Number(contractData.moto.year),
      color: contractData.moto.color,
      renavam: contractData.moto.renavam,
      chassi: contractData.moto.chassi,
      currentKm: Number(contractData.moto.initialKm),
      purchasePrice: Number(form.purchasePrice) || 0,
      purchaseDate: form.purchaseDate || contractData.terms.startDate,
      status: 'alugada' as const,
      insuranceDeductible: contractData.terms.depositFormatted,
      documents: [],
      photos: [],
      kmLogs: [],
    } as any,
    tenant: {
      id: 'preview',
      fullName: contractData.locatario.name,
      cpf: contractData.locatario.cpf.replace(/\D/g, ''),
      rg: contractData.locatario.rg || '',
      phone: contractData.locatario.phone.replace(/\D/g, ''),
      whatsapp: contractData.locatario.whatsapp.replace(/\D/g, ''),
      email: contractData.locatario.email,
      address: contractData.locatario.address,
      profession: contractData.locatario.profession,
      company: form.tenantCompany || 'Autônomo',
      income: Number(form.monthlyIncome) || contractData.terms.weeklyValue * 4,
      cnh: {
        number: contractData.locatario.cnh,
        category: contractData.locatario.cnhCategory,
        expirationDate: form.cnhExpiration || '',
      },
      birthDate: form.tenantBirthDate || '',
      documents: form.documents || {},
      approvalChecklist: {
        cnhValid: true,
        docsChecked: true,
        addressValidated: true,
        incomeAnalyzed: true,
        depositReceived: true,
        contractSigned: true,
        result: 'aprovado' as const,
      },
    } as any,
    contract: {
      id: 'preview',
      motoId: 'preview',
      tenantId: 'preview',
      durationMonths: contractData.terms.minimumMonths,
      paymentFrequency: contractData.terms.isWeekly ? 'semanal' : 'mensal',
      startDate: contractData.terms.startDate,
      dueDay: form.dueDay || 10,
      dueDayOfWeek: form.dueDayOfWeek ?? 1,
      monthlyValue: contractData.terms.monthlyValue,
      weeklyValue: contractData.terms.weeklyValue,
      deposit: contractData.terms.deposit,
      depositStatus: form.depositStatus || 'retida',
      totalAgreedValue: contractData.terms.isWeekly
        ? Math.round(contractData.terms.minimumMonths * (52 / 12) * contractData.terms.weeklyValue)
        : contractData.terms.monthlyValue * contractData.terms.minimumMonths,
      insuranceDeductible: contractData.terms.depositFormatted,
      status: 'ativo' as const,
      installments: [],
      inspection: contractData.inspection,
    } as any,
    inspection: contractData.inspection,
    settings,
    autoDownload,
  });

  const validateBeforeAction = () => {
    if (!contractData.moto.hasModel) {
      alert('Por favor, informe o Modelo da moto para emitir o contrato.');
      return false;
    }
    if (!contractData.moto.hasPlate) {
      alert('Por favor, informe a Placa da moto para emitir o contrato.');
      return false;
    }
    return true;
  };

  const handleCopy = async () => {
    if (!validateBeforeAction()) return;
    const success = await copyTextToClipboard(rawContractText);
    if (success) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handlePrint = () => {
    if (!validateBeforeAction()) return;
    printContractDocument('Contrato Oficial de Locação de Motocicleta', rawContractText);
  };

  const handleDownloadPdf = () => {
    if (!validateBeforeAction()) return;
    try {
      setDownloading(true);
      generateMotoRentalContractPdfFile(getPdfOptions(true));
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3000);
    } catch (err) {
      console.error('Erro ao gerar PDF da moto:', err);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="space-y-4 sm:space-y-5 animate-fadeIn font-sans" id="moto-contract-review-container">
      {/* CABEÇALHO DA ETAPA */}
      <div className="flex items-center justify-between border-b border-white/[0.08] pb-3.5">
        <div className="flex items-center gap-2.5 text-white font-bold text-sm sm:text-base">
          <span className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center text-xs font-black shrink-0">
            7
          </span>
          <span>Contrato Oficial de Locação & Emissão</span>
        </div>
        <span className="text-xs text-emerald-400 font-semibold bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20">
          12 Cláusulas Oficiais + Anexo I
        </span>
      </div>

      {/* AVISO SE FALTAR DADOS DO VEÍCULO */}
      {(!contractData.moto.hasModel || !contractData.moto.hasPlate) && (
        <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/25 text-xs text-rose-300 flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
          <div>
            <strong className="block text-rose-200">Atenção: Dados da motocicleta incompletos</strong>
            <span>
              {!contractData.moto.hasModel ? 'O Modelo da moto não foi preenchido. ' : ''}
              {!contractData.moto.hasPlate ? 'A Placa da moto não foi preenchida. ' : ''}
              Preencha os dados do veículo na Etapa 1 para emitir o contrato oficial.
            </span>
          </div>
        </div>
      )}

      {/* RESUMO RÁPIDO DO CONTRATO */}
      <div className="p-4 sm:p-5 rounded-2xl bg-[#090B10] border border-white/[0.08] text-xs">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="space-y-1">
            <span className="text-slate-400 text-[11px] font-medium block">Locador & Veículo:</span>
            <strong className="text-white text-sm block truncate font-bold">
              {contractData.locador.name}
            </strong>
            <span className="text-slate-300 truncate block text-[11px]">
              {contractData.moto.hasModel ? (
                <>
                  {contractData.moto.brandModelDisplay}
                  {contractData.moto.year && contractData.moto.year !== 'Não informado'
                    ? ` (${contractData.moto.year})`
                    : ''}
                </>
              ) : (
                <span className="text-rose-400 font-bold">
                  {contractData.moto.brandModelDisplay}
                </span>
              )}{' '}
              •{' '}
              <span
                className={`font-mono font-semibold ${
                  contractData.moto.hasPlate ? 'text-emerald-400' : 'text-amber-400'
                }`}
              >
                {contractData.moto.plate}
              </span>
            </span>
          </div>

          <div className="space-y-1">
            <span className="text-slate-400 text-[11px] font-medium block">Locatário / Condutor:</span>
            <strong className="text-white text-sm block truncate font-bold">
              {contractData.locatario.name}
            </strong>
            <span className="text-slate-300 block text-[11px] font-mono">
              CPF: {formatCPF(contractData.locatario.cpf)} • CNH: {contractData.locatario.cnh} ({contractData.locatario.cnhCategory})
            </span>
          </div>

          <div className="space-y-1">
            <span className="text-slate-400 text-[11px] font-medium block">Valores & Pagamento:</span>
            <strong className="text-emerald-400 text-sm block font-mono font-bold">
              {contractData.terms.isWeekly
                ? `${contractData.terms.weeklyValueFormatted} / semana`
                : `${contractData.terms.monthlyValueFormatted} / mês`}
            </strong>
            <span className="text-slate-300 block text-[11px]">
              {contractData.terms.minimumMonths} meses de prazo mínimo • Vencimento: {contractData.terms.dueDayName} até às {contractData.terms.dueLimitTime}
            </span>
          </div>
        </div>
      </div>

      {/* TOOLBAR UNIFICADA */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 sm:p-3.5 rounded-2xl bg-[#090B10] border border-white/[0.08]">
        {/* Toggle de Modo: Minuta Formatada vs Texto Puro */}
        <div className="flex items-center gap-1 p-1 bg-[#0E111A] border border-white/[0.08] rounded-xl">
          <button
            type="button"
            id="btn-tab-preview"
            onClick={() => setContractTab('preview')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              contractTab === 'preview'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileCheck className="w-3.5 h-3.5" />
            <span>Contrato Formatado</span>
          </button>

          <button
            type="button"
            id="btn-tab-text"
            onClick={() => setContractTab('text')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              contractTab === 'text'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Texto Puro</span>
          </button>
        </div>

        {/* Botões de Ação Direta */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            id="btn-copy-contract"
            onClick={handleCopy}
            className="px-3.5 py-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.10] border border-white/[0.10] text-slate-200 hover:text-white font-semibold text-xs flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
            title="Copiar texto integral do contrato oficial"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400 font-bold">Texto Copiado!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-slate-400" />
                <span>Copiar Texto</span>
              </>
            )}
          </button>

          <button
            type="button"
            id="btn-print-contract"
            onClick={handlePrint}
            className="px-3.5 py-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.10] border border-white/[0.10] text-slate-200 hover:text-white font-semibold text-xs flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
            title="Imprimir contrato oficial completo"
          >
            <Printer className="w-3.5 h-3.5 text-slate-400" />
            <span>Imprimir</span>
          </button>

          <button
            type="button"
            id="btn-download-pdf"
            onClick={handleDownloadPdf}
            disabled={downloading}
            className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-500/30 hover:shadow-emerald-500/50 hover:brightness-110 active:scale-95 transition-all cursor-pointer ring-1 ring-emerald-400/40"
            title="Baixar Contrato Oficial em PDF"
          >
            {downloadSuccess ? (
              <>
                <Check className="w-4 h-4 stroke-[3]" />
                <span>PDF Baixado!</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Baixar PDF Oficial</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* VISUALIZAÇÃO INTEGRAL DO CONTRATO OFICIAL */}
      {contractTab === 'preview' ? (
        <div
          id="official-contract-preview-scroll"
          className="p-5 sm:p-8 bg-[#07090E] border border-white/[0.12] rounded-2xl space-y-6 max-h-[62vh] overflow-y-auto font-sans shadow-2xl custom-scrollbar text-slate-200"
        >
          {/* CABEÇALHO FORMAL DO CONTRATO */}
          <div className="text-center pb-5 border-b border-white/[0.12] space-y-2">
            <div className="inline-flex items-center gap-1.5 bg-emerald-500/10 text-emerald-400 px-3 py-1 rounded-full border border-emerald-500/20 text-[10px] font-bold tracking-wider uppercase">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Contrato Oficial de Locação de Motocicleta</span>
            </div>
            <h2 className="text-base sm:text-lg font-black text-white uppercase tracking-wide">
              CONTRATO DE LOCAÇÃO DE MOTOCICLETA COM PRAZO MÍNIMO E RENOVAÇÃO AUTOMÁTICA
            </h2>
            <p className="text-xs text-slate-400 max-w-xl mx-auto">
              Instrumento Jurídico de Locação com Todas as Cláusulas Oficiais, Direitos, Deveres e Anexo I de Vistoria
            </p>
          </div>

          {/* TODAS AS CLÁUSULAS OFICIAIS RENDERIZADAS EM 100% PARIDADE */}
          <div className="space-y-5 text-xs leading-relaxed text-slate-300 divide-y divide-white/[0.06]">
            {sections.map((section, idx) => (
              <div key={idx} className={idx === 0 ? '' : 'pt-4'}>
                <h3 className="font-bold text-emerald-400 uppercase text-xs mb-2">
                  {section.title}
                </h3>
                <div className="space-y-2">
                  {section.paragraphs.map((p, pIdx) => {
                    // Detecção de marcadores ou alíneas
                    const isBullet =
                      p.startsWith('•') ||
                      p.startsWith('-') ||
                      /^[a-z]\)/i.test(p);
                    const isSubheading =
                      p.startsWith('1.1.') ||
                      p.startsWith('1.2.') ||
                      p.startsWith('Dados do Veículo:');

                    return (
                      <p
                        key={pIdx}
                        className={`${
                          isBullet
                            ? 'pl-4 text-slate-200 border-l border-emerald-500/30 ml-1 py-0.5'
                            : isSubheading
                            ? 'font-medium text-white'
                            : 'text-slate-300'
                        }`}
                      >
                        {p}
                      </p>
                    );
                  })}

                  {/* Renderiza bullets da seção para garantir que nenhuma cláusula (ex: Cláusula 3) seja truncada */}
                  {section.bullets && section.bullets.length > 0 && (
                    <div className="space-y-1.5 pt-1 pl-1">
                      {section.bullets.map((b, bIdx) => (
                        <div
                          key={bIdx}
                          className="flex items-start gap-2 pl-3 py-1 border-l-2 border-emerald-500/40 text-slate-200 text-xs bg-emerald-500/[0.02] rounded-r-lg"
                        >
                          <span className="text-emerald-400 font-bold shrink-0">•</span>
                          <span>{b}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* LOCAL, DATA E ASSINATURAS DO CONTRATO PRINCIPAL */}
          <div className="pt-6 border-t border-white/[0.12] space-y-6">
            <p className="text-center font-bold text-xs text-slate-200">
              {contractData.terms.contractCity}, {contractData.terms.contractDateFormatted}.
            </p>

            {/* LINHAS DE ASSINATURA PRINCIPAIS */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-4">
              <div className="text-center border-t border-white/40 pt-2 space-y-0.5">
                <strong className="text-white text-xs block font-bold">
                  {contractData.locador.name}
                </strong>
                <span className="text-[11px] text-slate-400 block uppercase tracking-wider">
                  LOCADOR (Proprietário)
                </span>
                <span className="text-[10px] text-slate-400 block font-mono">
                  CPF: {formatCPF(contractData.locador.cpf)}
                </span>
              </div>

              <div className="text-center border-t border-white/40 pt-2 space-y-0.5">
                <strong className="text-white text-xs block font-bold">
                  {contractData.locatario.name}
                </strong>
                <span className="text-[11px] text-slate-400 block uppercase tracking-wider">
                  LOCATÁRIO (Condutor)
                </span>
                <span className="text-[10px] text-slate-400 block font-mono">
                  CPF: {formatCPF(contractData.locatario.cpf)}
                </span>
              </div>
            </div>

            {/* TESTEMUNHAS */}
            <div className="pt-4 border-t border-white/[0.06]">
              <span className="text-[10px] text-slate-400 block uppercase tracking-wider font-bold mb-3 text-center">
                TESTEMUNHAS INSTRUMENTÁRIAS:
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-[11px] text-slate-300">
                <div className="border-t border-white/20 pt-2">
                  <p>1. Nome: _____________________________________</p>
                  <p className="mt-1">CPF: ________________________________________</p>
                </div>
                <div className="border-t border-white/20 pt-2">
                  <p>2. Nome: _____________________________________</p>
                  <p className="mt-1">CPF: ________________________________________</p>
                </div>
              </div>
            </div>
          </div>

          {/* ANEXO I – TERMO DE VISTORIA E RETIRADA DO VEÍCULO (INTEGRAL E 100% SINCRONIZADO) */}
          <div className="pt-8 border-t-2 border-emerald-500/30 space-y-6">
            <div className="p-5 sm:p-7 rounded-2xl bg-[#0B0D16] border border-white/[0.12] space-y-6 shadow-xl">
              {/* CABEÇALHO DO ANEXO I */}
              <div className="text-center pb-5 border-b border-white/[0.10] space-y-2">
                <div className="inline-flex items-center gap-1.5 bg-emerald-500/10 text-emerald-400 px-3 py-1 rounded-full border border-emerald-500/20 text-[10px] font-bold tracking-wider uppercase">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Anexo Oficial Integrante</span>
                </div>
                <h3 className="text-sm sm:text-base font-black text-white uppercase tracking-wide">
                  ANEXO I – TERMO DE VISTORIA E RETIRADA DO VEÍCULO
                </h3>
                <p className="text-xs text-slate-400 max-w-xl mx-auto">
                  Este termo é parte integrante e indissociável do Contrato de Locação de Motocicleta com Prazo Mínimo e Renovação Automática firmado entre as partes.
                </p>
              </div>

              {/* DADOS DE IDENTIFICAÇÃO E RETIRADA */}
              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.08] space-y-3">
                <div className="text-[11px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                  <Gauge className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Dados da Entrega e Vistoria Inicial</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
                  <div className="p-2.5 rounded-lg bg-black/30 border border-white/[0.06]">
                    <span className="text-slate-400 block text-[10px]">Data da Retirada:</span>
                    <strong className="text-white font-sans text-xs">
                      {formatDate(contractData.inspection.date)}
                    </strong>
                  </div>
                  <div className="p-2.5 rounded-lg bg-black/30 border border-white/[0.06]">
                    <span className="text-slate-400 block text-[10px]">Hora da Retirada:</span>
                    <strong className="text-white font-sans text-xs">
                      {contractData.inspection.time || '10:00'}
                    </strong>
                  </div>
                  <div className="p-2.5 rounded-lg bg-black/30 border border-white/[0.06]">
                    <span className="text-slate-400 block text-[10px]">Odômetro Inicial:</span>
                    <strong className="text-emerald-400 text-xs">
                      {Number(contractData.inspection.initialKm).toLocaleString('pt-BR')} km
                    </strong>
                  </div>
                  <div className="p-2.5 rounded-lg bg-black/30 border border-white/[0.06]">
                    <span className="text-slate-400 block text-[10px]">Placa do Veículo:</span>
                    <strong className="text-emerald-400 text-xs">
                      {contractData.moto.plate}
                    </strong>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1 text-[11px] text-slate-300">
                  <div>
                    <span className="text-slate-500 block text-[10px]">Veículo:</span>
                    <span className="font-semibold text-white">{contractData.moto.brand} {contractData.moto.model}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Ano / Cor:</span>
                    <span className="font-semibold text-white">{contractData.moto.year} • {contractData.moto.color}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Chassi:</span>
                    <span className="font-mono text-white text-[10px]">{contractData.moto.chassi}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Renavam:</span>
                    <span className="font-mono text-white text-[10px]">{contractData.moto.renavam || 'Conforme Doc.'}</span>
                  </div>
                </div>
              </div>

              {/* TABELA COMPLETA DOS 10 ITENS DE VISTORIA FÍSICA COM ÍCONES SVG */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Condições Gerais da Motocicleta (10 Itens Vistoriados)</span>
                  </h4>
                  <span className="text-[10px] text-slate-400 font-mono">
                    Todos os itens testados e verificados
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                  {[
                    { key: 'pneuDianteiro' as const, label: 'Pneu Dianteiro', Icon: IconPneuDianteiro },
                    { key: 'pneuTraseiro' as const, label: 'Pneu Traseiro', Icon: IconPneuTraseiro },
                    { key: 'freioDianteiro' as const, label: 'Freio Dianteiro', Icon: IconFreioDianteiro },
                    { key: 'freioTraseiro' as const, label: 'Freio Traseiro', Icon: IconFreioTraseiro },
                    { key: 'farolLanternas' as const, label: 'Farol e Lanternas', Icon: IconFarolLanternas },
                    { key: 'setas' as const, label: 'Setas (D / T)', Icon: IconSetas },
                    { key: 'buzina' as const, label: 'Buzina', Icon: IconBuzina },
                    { key: 'retrovisores' as const, label: 'Retrovisores', Icon: IconRetrovisores },
                    { key: 'assentoBanco' as const, label: 'Assento / Banco', Icon: IconAssentoBanco },
                    { key: 'pinturaLataria' as const, label: 'Pintura / Lataria', Icon: IconPinturaLataria },
                  ].map(({ key, label, Icon }, i) => {
                    const item = contractData.inspection.checklist?.[key] || { checked: true, status: 'bom', notes: '' };
                    const isBom = item.status === 'bom';
                    const isRegular = item.status === 'regular';
                    const isRuim = item.status === 'ruim';

                    return (
                      <div
                        key={key}
                        className="p-3 rounded-xl bg-black/25 border border-white/[0.07] space-y-1.5 hover:border-white/[0.12] transition-colors"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded-lg bg-white/[0.05] flex items-center justify-center text-slate-300 shrink-0">
                              <Icon className="w-3.5 h-3.5" />
                            </div>
                            <span className="text-xs font-semibold text-white">
                              {i + 1}. {label}
                            </span>
                          </div>

                          <div className="flex items-center gap-1 text-[11px] font-bold">
                            {isBom && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                                <IconStatusBom className="w-3 h-3 text-emerald-400" />
                                <span>[X] Bom</span>
                              </span>
                            )}
                            {isRegular && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-400 border border-amber-500/30">
                                <IconStatusRegular className="w-3 h-3 text-amber-400" />
                                <span>[X] Regular</span>
                              </span>
                            )}
                            {isRuim && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-rose-500/15 text-rose-400 border border-rose-500/30">
                                <IconStatusRuim className="w-3 h-3 text-rose-400" />
                                <span>[X] Ruim</span>
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="text-[11px] text-slate-400 pl-8">
                          <span className="text-slate-500 text-[10px]">Obs: </span>
                          <span className={item.notes ? 'text-slate-300 italic' : 'text-slate-500 italic'}>
                            {item.notes || 'Sem avarias relatadas / Em perfeito estado'}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* NÍVEL DE COMBUSTÍVEL NA RETIRADA */}
              <div className="p-4 rounded-xl bg-black/25 border border-white/[0.08] space-y-2.5">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
                  <IconCombustivel className="w-4 h-4 text-emerald-400" />
                  <span className="uppercase tracking-wider">Nível de Combustível na Retirada:</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {[
                    { key: 'cheio', label: 'Cheio (100%)' },
                    { key: '3/4', label: '3/4 Tanque' },
                    { key: '1/2', label: '1/2 Tanque' },
                    { key: '1/4', label: '1/4 Tanque' },
                    { key: 'reserva', label: 'Reserva' },
                  ].map((level) => {
                    const isSelected = contractData.inspection.fuelLevel === level.key;
                    return (
                      <div
                        key={level.key}
                        className={`p-2 rounded-lg text-center text-xs font-semibold border transition-all ${
                          isSelected
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-sm shadow-emerald-500/20 font-bold'
                            : 'bg-white/[0.02] text-slate-500 border-white/[0.05]'
                        }`}
                      >
                        <span>{isSelected ? '[ X ]' : '[   ]'} {level.label}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* ACESSÓRIOS ENTREGUES */}
              <div className="p-4 rounded-xl bg-black/25 border border-white/[0.08] space-y-2.5">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span className="uppercase tracking-wider">Acessórios Entregues com a Motocicleta:</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                  {[
                    { key: 'capacete', label: 'Capacete', Icon: IconCapacete, active: contractData.inspection.accessories?.capacete },
                    { key: 'capaChuva', label: 'Capa de Chuva', Icon: IconCapaChuva, active: contractData.inspection.accessories?.capaChuva },
                    { key: 'suporteCelular', label: 'Suporte de Celular', Icon: IconSuporteCelular, active: contractData.inspection.accessories?.suporteCelular },
                    { key: 'bauBauleto', label: 'Baú / Bauleto', Icon: IconBauBauleto, active: contractData.inspection.accessories?.bauBauleto },
                    { key: 'chaveReserva', label: 'Chave Reserva', Icon: IconChaveReserva, active: contractData.inspection.accessories?.chaveReserva },
                    {
                      key: 'outros',
                      label: contractData.inspection.accessories?.outrosDescricao
                        ? `Outros: ${contractData.inspection.accessories.outrosDescricao}`
                        : 'Outros Itens',
                      Icon: IconOutros,
                      active: contractData.inspection.accessories?.outros,
                    },
                  ].map((acc) => (
                    <div
                      key={acc.key}
                      className={`p-2 rounded-lg flex items-center gap-2 border text-xs ${
                        acc.active
                          ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40 font-semibold'
                          : 'bg-white/[0.02] text-slate-500 border-white/[0.05]'
                      }`}
                    >
                      <acc.Icon className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">{acc.active ? '[X]' : '[ ]'} {acc.label}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* DESCRIÇÃO DE AVARIAS EXISTENTES */}
              <div className="p-4 rounded-xl bg-black/25 border border-white/[0.08] space-y-1.5">
                <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block">
                  Descrição Detalhada de Avarias Existentes (Lataria, Pintura, Ralados, etc.):
                </span>
                <p className="text-xs text-slate-300 leading-relaxed bg-white/[0.02] p-3 rounded-lg border border-white/[0.05] italic">
                  {contractData.inspection.damagesDescription ||
                    'Nenhuma avaria estrutural identificada na vistoria inicial. Veículo entregue revisado, lavado e em perfeitas condições operacionais.'}
                </p>
              </div>

              {/* REGISTRO EM VÍDEO 360° */}
              <div className="p-4 rounded-xl bg-indigo-500/10 border border-indigo-500/20 space-y-1.5 text-xs">
                <div className="flex items-center gap-2 text-indigo-300 font-bold uppercase tracking-wide">
                  <Video className="w-4 h-4 text-indigo-400" />
                  <span>Registro em Vídeo 360° da Entrega:</span>
                </div>
                <p className="text-indigo-200/80 leading-relaxed text-[11.5px]">
                  Nota: Além deste termo impresso, foi realizado e armazenado um vídeo de vistoria em 360 graus do veículo no ato da entrega, servindo ambos como prova das condições iniciais da motocicleta.
                </p>
                {contractData.inspection.videoUrl && (
                  <p className="text-[11px] text-indigo-300 font-mono pt-1">
                    Arquivo/Link: {contractData.inspection.videoUrl}
                  </p>
                )}
              </div>

              {/* DECLARAÇÃO DE CIÊNCIA E ACEITE DO LOCATÁRIO */}
              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.08] space-y-2">
                <p className="text-xs text-slate-300 leading-relaxed">
                  Pelo presente termo, o <strong>LOCATÁRIO</strong> declara que vistoriou a motocicleta acima qualificada, conferiu todos os 10 itens de segurança, recebeu os acessórios marcados e concorda que o veículo está em perfeitas condições de uso, segurança e funcionamento, obrigando-se a devolvê-lo nas mesmas condições em que o recebeu.
                </p>
              </div>

              {/* ASSINATURAS DO TERMO DE VISTORIA (ANEXO I) */}
              <div className="pt-4 border-t border-white/[0.12] space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-4">
                  <div className="text-center border-t border-white/40 pt-2 space-y-0.5">
                    <strong className="text-white text-xs block font-bold">
                      {contractData.locador.name}
                    </strong>
                    <span className="text-[10px] text-slate-400 block uppercase tracking-wider">
                      Assinatura do LOCADOR
                    </span>
                    <span className="text-[10px] text-slate-500 block font-mono">
                      CPF: {formatCPF(contractData.locador.cpf)}
                    </span>
                  </div>

                  <div className="text-center border-t border-white/40 pt-2 space-y-0.5">
                    <strong className="text-white text-xs block font-bold">
                      {contractData.locatario.name}
                    </strong>
                    <span className="text-[10px] text-slate-400 block uppercase tracking-wider">
                      Assinatura do LOCATÁRIO
                    </span>
                    <span className="text-[10px] text-slate-500 block font-mono">
                      CPF: {formatCPF(contractData.locatario.cpf)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* ABA DE TEXTO PURO DO CONTRATO OFICIAL */
        <div className="p-4 sm:p-5 bg-[#07090E] border border-white/[0.12] rounded-2xl max-h-[62vh] overflow-y-auto font-mono text-xs text-slate-300 shadow-2xl">
          <div className="flex items-center justify-between text-xs text-slate-400 pb-2 mb-3 border-b border-white/[0.08]">
            <span>Texto oficial e integral do contrato para envio por WhatsApp ou e-mail:</span>
            <span className="text-[11px] font-mono text-emerald-400">12 Cláusulas + Anexo I • UTF-8</span>
          </div>
          <pre className="whitespace-pre-wrap leading-relaxed font-mono select-all text-[11px] sm:text-xs">
            {rawContractText}
          </pre>
        </div>
      )}
    </div>
  );
};
