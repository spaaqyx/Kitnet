import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import { CheckCircle, X, CreditCard } from 'lucide-react';
import { Installment, Moto } from '../../../types';
import { formatCurrency, formatDate } from '../../../utils/formatters';
import { STANDARD_EASE } from '../../../utils/motion';
import { useBodyScrollLock } from '../../../hooks/useBodyScrollLock';

interface MotoPaymentModalProps {
  paymentData: { contractId: string; installment: Installment } | null;
  moto?: Moto;
  onClose: () => void;
  onConfirm: (contractId: string, installmentId: string, notes?: string) => void;
}

export const MotoPaymentModal: React.FC<MotoPaymentModalProps> = ({
  paymentData,
  moto,
  onClose,
  onConfirm,
}) => {
  const isOpen = Boolean(paymentData);
  const shouldReduceMotion = useReducedMotion();
  const lastPaymentDataRef = useRef(paymentData);
  const lastMotoRef = useRef(moto);

  if (paymentData) {
    lastPaymentDataRef.current = paymentData;
  }
  if (moto) {
    lastMotoRef.current = moto;
  }

  const currentData = paymentData || lastPaymentDataRef.current;
  const currentMoto = moto || lastMotoRef.current;

  useBodyScrollLock(isOpen);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const [paymentMethod, setPaymentMethod] = useState<'PIX' | 'Dinheiro' | 'Transferência' | 'Cartão'>('PIX');
  const [notes, setNotes] = useState('');

  if (typeof document === 'undefined') return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentData) return;
    const noteText = notes.trim()
      ? `Baixa de parcela (${paymentMethod}): ${notes.trim()}`
      : `Baixa de parcela confirmada via ${paymentMethod}`;
    onConfirm(currentData.contractId, currentData.installment.id, noteText);
  };

  return createPortal(
    <AnimatePresence>
      {isOpen && currentData && (
        <motion.div
          key="moto-payment-backdrop"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          role="dialog"
          aria-modal="true"
          aria-label="Confirmar Pagamento de Parcela de Moto"
          className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md font-sans"
          onClick={onClose}
        >
          <motion.div
            key="moto-payment-card"
            initial={{ opacity: 0, scale: shouldReduceMotion ? 1 : 0.96, y: shouldReduceMotion ? 0 : 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: shouldReduceMotion ? 1 : 0.96, y: shouldReduceMotion ? 0 : 8 }}
            transition={{ duration: 0.22, ease: STANDARD_EASE }}
            className="bg-[#0B0D13] border border-white/[0.12] rounded-2xl sm:rounded-3xl w-full max-w-md p-5 sm:p-6 shadow-2xl shadow-black/80 space-y-4 my-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-white/[0.08] pb-3.5">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
                  <CheckCircle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Baixar / Confirmar Parcela</h3>
                  {currentMoto && (
                    <p className="text-xs text-slate-400">
                      {currentMoto.brand} {currentMoto.model} ({currentMoto.plate})
                    </p>
                  )}
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-white/[0.08] transition-colors duration-150 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Resumo da Parcela */}
            <div className="p-4 bg-[#090B10] rounded-xl border border-white/[0.08] space-y-2 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Parcela:</span>
                <span className="font-bold text-white font-mono">
                  #{String(currentData.installment.number).padStart(2, '0')}/{currentData.installment.totalInstallments}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Vencimento:</span>
                <span className="text-slate-300 font-medium">{formatDate(currentData.installment.dueDate)}</span>
              </div>
              <div className="flex justify-between items-center pt-1 border-t border-white/[0.06]">
                <span className="text-slate-400">Valor a Receber:</span>
                <span className="text-base font-bold text-emerald-400 font-mono">
                  {formatCurrency(currentData.installment.amount)}
                </span>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
              {/* Método de Pagamento */}
              <div>
                <label className="block text-slate-300 font-semibold mb-1.5">Forma de Pagamento</label>
                <div className="grid grid-cols-2 gap-2">
                  {(['PIX', 'Dinheiro', 'Transferência', 'Cartão'] as const).map((method) => (
                    <button
                      key={method}
                      type="button"
                      onClick={() => setPaymentMethod(method)}
                      className={`py-2 px-3 rounded-xl border text-xs font-semibold transition-colors duration-150 flex items-center justify-center gap-1.5 cursor-pointer ${
                        paymentMethod === method
                          ? 'bg-emerald-500/15 border-emerald-500/60 text-emerald-300 ring-2 ring-emerald-500/25 font-bold'
                          : 'bg-[#090B10] border-white/[0.10] text-slate-400 hover:text-white hover:border-white/[0.20]'
                      }`}
                    >
                      <CreditCard className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{method}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Observações */}
              <div>
                <label className="block text-slate-300 font-semibold mb-1.5">Observações (Opcional)</label>
                <input
                  type="text"
                  placeholder="Ex: Pago via PIX pelo locatário"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full bg-[#090B10] border border-white/[0.12] hover:border-white/[0.20] focus:bg-[#0E111A] rounded-xl px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/25 transition-colors duration-150"
                />
              </div>

              {/* Botões de Ação */}
              <div className="flex justify-end gap-2.5 pt-2 border-t border-white/[0.08]">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 bg-white/[0.06] hover:bg-white/[0.10] text-slate-300 hover:text-white border border-white/[0.10] rounded-xl text-xs font-semibold transition-colors duration-150 cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs active:scale-95 transition-colors duration-150 cursor-pointer flex items-center gap-1.5"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>Confirmar Pagamento</span>
                </button>
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
};
