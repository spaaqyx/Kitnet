import React, { useState, useEffect, useRef } from 'react';
import { useBodyScrollLock } from '../../../hooks/useBodyScrollLock';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import { Calendar, X } from 'lucide-react';
import { Kitnet, KitnetContract, KitnetTenant } from '../../../types';
import { formatCurrency } from '../../../utils/formatters';
import { CurrencyInput } from '../../NumericInput';

interface RenewKitnetContractModalProps {
  isOpen: boolean;
  selectedKitnet: Kitnet | null;
  activeContract: KitnetContract | null;
  tenant?: KitnetTenant;
  onClose: () => void;
  onConfirm: (additionalMonths: number, newRentValue: number, reason: string) => void;
}

export const RenewKitnetContractModal: React.FC<RenewKitnetContractModalProps> = ({
  isOpen,
  selectedKitnet,
  activeContract,
  tenant,
  onClose,
  onConfirm,
}) => {
  const shouldReduceMotion = useReducedMotion();

  const lastKitnetRef = useRef(selectedKitnet);
  if (selectedKitnet) lastKitnetRef.current = selectedKitnet;
  const currentKitnet = selectedKitnet || lastKitnetRef.current;

  const lastContractRef = useRef(activeContract);
  if (activeContract) lastContractRef.current = activeContract;
  const currentContract = activeContract || lastContractRef.current;

  const lastTenantRef = useRef(tenant);
  if (tenant) lastTenantRef.current = tenant;
  const currentTenant = tenant || lastTenantRef.current;

  const [renewForm, setRenewForm] = useState({
    additionalMonths: 12,
    newRentValue: currentContract?.rentValue || 0,
    reason: 'Renovação anual com emissão de novo cronograma de pagamentos',
  });

  useBodyScrollLock(isOpen);

  useEffect(() => {
    if (activeContract && isOpen) {
      setRenewForm((prev) => ({
        ...prev,
        newRentValue: activeContract.rentValue || 0,
      }));
    }
  }, [activeContract?.id, isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (typeof document === 'undefined') return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onConfirm(
      Number(renewForm.additionalMonths),
      Number(renewForm.newRentValue),
      renewForm.reason
    );
  };

  return createPortal(
    <AnimatePresence>
      {isOpen && currentKitnet && currentContract && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Formalizar Aditivo de Renovação"
          className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-5 overflow-y-auto font-sans"
        >
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: shouldReduceMotion ? 0.05 : 0.2 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
            onClick={onClose}
          />

          {/* Modal Container */}
          <motion.div
            initial={shouldReduceMotion ? { opacity: 0 } : { opacity: 0, scale: 0.95, y: 12 }}
            animate={shouldReduceMotion ? { opacity: 1 } : { opacity: 1, scale: 1, y: 0 }}
            exit={shouldReduceMotion ? { opacity: 0 } : { opacity: 0, scale: 0.95, y: 12 }}
            transition={{
              duration: shouldReduceMotion ? 0.05 : 0.22,
              ease: [0.16, 1, 0.3, 1],
            }}
            className="relative bg-[#090B10] border border-white/[0.12] rounded-2xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col max-h-[90vh] my-auto z-10"
          >
            {/* Header Fixo */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.08] bg-[#0E111A] shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-sky-500/15 border border-sky-500/30 text-sky-400">
                  <Calendar className="w-4 h-4" />
                </div>
                <h3 className="text-base text-white font-bold">Formalizar Aditivo de Renovação</h3>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/[0.06] transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="flex flex-col flex-1 min-h-0 overflow-hidden">
              <div className="flex-1 overflow-y-auto overscroll-contain p-5 space-y-4 text-xs modal-scroll-container">
                <div className="p-3.5 bg-[#0E111A] border border-sky-500/20 rounded-xl space-y-1">
                  <span className="text-[11px] text-slate-400 block font-medium">Locatário / Unidade:</span>
                  <p className="font-bold text-white text-sm">
                    {currentTenant?.fullName || 'Inquilino'} • {currentKitnet.name} (Unidade {currentKitnet.number})
                  </p>
                  <p className="text-xs text-sky-400 font-medium">
                    Vigência atual com {currentContract.installments.length} parcelas registradas no histórico.
                  </p>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1.5">Extensão de Prazo (Meses) *</label>
                  <select
                    value={renewForm.additionalMonths}
                    onChange={(e) => setRenewForm({ ...renewForm, additionalMonths: Number(e.target.value) })}
                    className="w-full bg-[#0E111A] border border-white/[0.12] hover:border-white/[0.20] focus:bg-[#121520] rounded-xl px-3.5 py-2.5 text-white font-semibold focus:outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-500/25 transition-all text-xs"
                  >
                    <option value={12}>+ 12 Meses (1 Ano)</option>
                    <option value={24}>+ 24 Meses (2 Anos)</option>
                    <option value={6}>+ 6 Meses (Semestral)</option>
                    <option value={36}>+ 36 Meses (3 Anos)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1.5">Novo Aluguel Base Líquido (R$) *</label>
                  <CurrencyInput
                    value={renewForm.newRentValue}
                    onChange={(val) => setRenewForm({ ...renewForm, newRentValue: val })}
                    className="w-full bg-[#0E111A] border border-white/[0.12] rounded-xl px-3.5 py-2.5 text-white font-mono font-bold focus:outline-none focus:border-sky-500 text-sm"
                  />
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    Taxa de água de {formatCurrency(currentContract.waterValue)} será somada em cada vencimento.
                  </span>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1.5">Motivo / Fundamentação do Aditivo</label>
                  <input
                    type="text"
                    required
                    value={renewForm.reason}
                    onChange={(e) => setRenewForm({ ...renewForm, reason: e.target.value })}
                    className="w-full bg-[#0E111A] border border-white/[0.12] hover:border-white/[0.20] focus:bg-[#121520] rounded-xl px-3.5 py-2 text-white placeholder:text-slate-500 focus:outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-500/25 transition-all text-xs"
                  />
                </div>
              </div>

              {/* Rodapé Fixo */}
              <div className="flex justify-end gap-2.5 px-5 py-4 border-t border-white/[0.08] bg-[#0E111A] shrink-0">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 bg-white/[0.06] hover:bg-white/[0.10] text-slate-300 hover:text-white font-semibold rounded-xl text-xs border border-white/[0.10] active:scale-95 transition-all cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold rounded-xl text-xs active:scale-95 transition-all cursor-pointer"
                >
                  Confirmar Aditivo & Gerar Parcelas
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body
  );
};
