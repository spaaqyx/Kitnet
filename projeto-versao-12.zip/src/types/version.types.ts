export interface AppVersionItem {
  num?: number;
  version: string;
  displayName?: string;
  filename: string;
  downloadUrl: string;
  sizeBytes: number;
  sizeFormatted: string;
  sha256?: string;
  updatedAt: string;
  formattedDateTime: string;
  formattedTime: string;
  formattedDate: string;
  isLatest: boolean;
}

export interface VersionComparison {
  hasPrevious: boolean;
  oldSizeFormatted: string;
  oldSizeBytes: number;
  newSizeFormatted: string;
  newSizeBytes: number;
  diffBytes: number;
  diffFormatted: string;
  diffPercent: string;
  isIncrease: boolean;
}

export interface ProjectVersionInfo {
  version?: string;
  versionNumber?: number;
  file?: string;
  filename?: string;
  downloadUrl?: string;
  size?: number;
  sizeBytes?: number;
  sizeFormatted?: string;
  sha256?: string;
  generatedAt?: string;
  lastGenerated: string;
  updatedAt: string;
  formattedTime: string;
  formattedDate: string;
  formattedDateTime: string;
  currentVersion: AppVersionItem;
  previousVersion: AppVersionItem | null;
  comparison: VersionComparison;
  allVersions: AppVersionItem[];
}
