import React, { useState, useEffect, useCallback } from 'react';
import {
  FileArchive,
  Download,
  Clock,
  ArrowRight,
  History,
  Check,
  Loader2,
  ChevronDown,
  ChevronUp,
  Sparkles,
  RefreshCw,
  HardDrive,
  ShieldCheck,
  Copy,
  AlertCircle,
} from 'lucide-react';
import type { ProjectVersionInfo, AppVersionItem } from '../../types';
import {
  fetchProjectVersionInfo,
  downloadLatestProjectZip,
  downloadSpecificVersion,
  INITIAL_EMPTY_VERSION_INFO,
} from '../../utils/zipDownloader';

export const SourceCodeDownloadBox: React.FC = () => {
  const [versionInfo, setVersionInfo] = useState<ProjectVersionInfo>(INITIAL_EMPTY_VERSION_INFO);
  const [isLoadingInfo, setIsLoadingInfo] = useState<boolean>(true);
  const [infoError, setInfoError] = useState<string | null>(null);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);
  const [downloadError, setDownloadError] = useState<string | null>(null);
  const [downloadingFile, setDownloadingFile] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [copiedSha, setCopiedSha] = useState<boolean>(false);

  const loadVersionInfo = useCallback(async () => {
    setIsLoadingInfo(true);
    setInfoError(null);
    try {
      const data = await fetchProjectVersionInfo();
      setVersionInfo(data);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Falha ao carregar metadados da versão.';
      setInfoError(msg);
      console.error('[SourceCodeDownloadBox] Erro ao carregar metadados:', err);
    } finally {
      setIsLoadingInfo(false);
    }
  }, []);

  useEffect(() => {
    loadVersionInfo();
  }, [loadVersionInfo]);

  const handleDownloadLatest = async () => {
    setDownloadError(null);
    try {
      setIsDownloading(true);
      await downloadLatestProjectZip(current?.filename);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Erro ao processar download da versão atual.';
      setDownloadError(msg);
      console.error('[SourceCodeDownloadBox] Falha ao baixar versão atual:', err);
    } finally {
      setIsDownloading(false);
    }
  };

  const handleDownloadSingleVersion = async (v: AppVersionItem) => {
    setDownloadError(null);
    try {
      setDownloadingFile(v.filename);
      await downloadSpecificVersion(v.downloadUrl, v.filename);
    } catch (err) {
      const msg = err instanceof Error ? err.message : `Erro ao baixar versão ${v.version}.`;
      setDownloadError(msg);
      console.error('[SourceCodeDownloadBox] Falha ao baixar versão específica:', err);
    } finally {
      setDownloadingFile(null);
    }
  };

  const handleCopySha256 = (sha: string) => {
    if (!sha) return;
    navigator.clipboard.writeText(sha);
    setCopiedSha(true);
    setTimeout(() => setCopiedSha(false), 2500);
  };

  const current = versionInfo.currentVersion;
  const previous = versionInfo.previousVersion;
  const comparison = versionInfo.comparison;
  const allVersions = versionInfo.allVersions || [];

  return (
    <div
      id="source-code-download-box"
      className="relative overflow-hidden rounded-2xl bg-gradient-to-b from-emerald-950/40 via-[#0d1e18] to-[#0a1613] border border-emerald-500/30 p-5 sm:p-6 shadow-xl shadow-black/40 transition-all duration-300 hover:border-emerald-500/40"
    >
      {/* Decorative ambient glow */}
      <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-64 h-24 bg-emerald-500/10 blur-3xl rounded-full pointer-events-none" />

      <div className="relative z-10 flex flex-col items-center text-center space-y-4">
        {/* Top Centered Header & Icon */}
        <div className="flex flex-col items-center space-y-2">
          <div className="relative flex items-center justify-center">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/15 border border-emerald-400/30 flex items-center justify-center text-emerald-400 shadow-md shadow-emerald-500/10">
              <FileArchive className="w-6 h-6 animate-pulse" />
            </div>
            <button
              type="button"
              onClick={loadVersionInfo}
              title="Recarregar dados de versão"
              aria-label="Recarregar dados de versão"
              className="absolute -right-2 -bottom-1 p-1 rounded-full bg-[#14231e] border border-emerald-500/30 text-emerald-400 hover:text-emerald-300 hover:scale-110 active:rotate-180 transition-all cursor-pointer"
            >
              <RefreshCw className={`w-3 h-3 ${isLoadingInfo ? 'animate-spin' : ''}`} />
            </button>
          </div>

          <div>
            <h4 className="text-base sm:text-lg font-bold text-emerald-200 tracking-tight leading-snug">
              Baixar Código-Fonte Completo (.ZIP)
            </h4>
            <p className="text-xs text-emerald-400/80 font-medium mt-0.5">
              Versão Sincronizada com a Build de Produção
            </p>
          </div>
        </div>

        {/* Error State if version-info.json could not be fetched */}
        {infoError ? (
          <div className="w-full max-w-md p-3.5 rounded-xl bg-amber-950/40 border border-amber-500/40 text-amber-200 text-xs flex flex-col items-center gap-2">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="font-semibold">{infoError}</span>
            </div>
            <button
              type="button"
              onClick={loadVersionInfo}
              className="px-3 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-bold border border-amber-500/30 cursor-pointer transition-colors"
            >
              Recarregar Metadados
            </button>
          </div>
        ) : (
          <>
            {/* Update Timestamp Badge */}
            <div className="inline-flex items-center justify-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/25 text-emerald-300 text-xs font-medium tracking-wide shadow-xs">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
              </span>
              <Clock className="w-3.5 h-3.5 text-emerald-400" />
              <span>
                {isLoadingInfo ? (
                  'Carregando versão da build...'
                ) : (
                  <>
                    Atualizado às <strong className="font-bold text-emerald-100">{versionInfo.formattedTime}</strong>
                    {versionInfo.formattedDate ? ` • ${versionInfo.formattedDate}` : ''}
                  </>
                )}
              </span>
            </div>

            {/* SHA-256 Cryptographic Hash Badge */}
            {current?.sha256 && (
              <div className="inline-flex items-center justify-center gap-2 px-3 py-1 rounded-xl bg-black/50 border border-emerald-500/25 text-[11px] font-mono text-emerald-300">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="text-slate-400 font-sans font-medium">SHA-256:</span>
                <span className="tracking-wider text-emerald-200 font-semibold" title={current.sha256}>
                  {current.sha256.substring(0, 12)}...{current.sha256.substring(current.sha256.length - 8)}
                </span>
                <button
                  type="button"
                  onClick={() => handleCopySha256(current.sha256!)}
                  className="ml-0.5 p-1 rounded hover:bg-emerald-500/20 text-slate-400 hover:text-emerald-200 transition-colors cursor-pointer"
                  title="Copiar hash SHA-256 completo"
                  aria-label="Copiar hash SHA-256"
                >
                  {copiedSha ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            )}

            {/* Old vs New Size Comparison Box */}
            <div className="w-full max-w-md p-3 sm:p-3.5 rounded-xl bg-black/40 border border-emerald-500/20 backdrop-blur-sm">
              <div className="text-[11px] font-semibold text-emerald-400/90 uppercase tracking-wider mb-2 flex items-center justify-center gap-1.5">
                <HardDrive className="w-3.5 h-3.5 text-emerald-400" />
                <span>Comparativo de Versões</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 items-center justify-center gap-2 text-xs">
                {/* Old Version */}
                <div className="flex flex-col items-center justify-center p-2 rounded-lg bg-white/[0.03] border border-white/[0.06]">
                  <span className="text-[10px] uppercase font-semibold text-slate-400">
                    {previous?.version || 'Versão Anterior'}
                  </span>
                  <span className="text-xs font-mono font-bold text-slate-300 mt-0.5">
                    {comparison?.oldSizeFormatted || '-'}
                  </span>
                </div>

                {/* Transition Indicator / Diff */}
                <div className="flex flex-col items-center justify-center">
                  <div className="flex items-center justify-center gap-1 text-emerald-400">
                    <ArrowRight className="w-4 h-4 hidden sm:block" />
                    <span
                      className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                        comparison?.isIncrease
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-teal-500/20 text-teal-300 border border-teal-500/30'
                      }`}
                    >
                      {comparison?.diffFormatted || '0 KB'}
                    </span>
                  </div>
                  <span className="text-[10px] text-emerald-400/70 mt-0.5 font-medium">
                    {comparison?.diffPercent || '0%'}
                  </span>
                </div>

                {/* New Version */}
                <div className="flex flex-col items-center justify-center p-2 rounded-lg bg-emerald-500/15 border border-emerald-400/30">
                  <span className="text-[10px] uppercase font-bold text-emerald-300 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-emerald-300" />
                    {current?.version || 'Nova Versão'}
                  </span>
                  <span className="text-xs font-mono font-extrabold text-emerald-100 mt-0.5">
                    {current?.sizeFormatted || comparison?.newSizeFormatted || '...'}
                  </span>
                </div>
              </div>
            </div>

            {/* Error Notification if download fails */}
            {downloadError && (
              <div className="w-full max-w-md p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs flex items-center justify-between gap-2 text-left">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{downloadError}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setDownloadError(null)}
                  className="text-rose-400 hover:text-rose-100 font-bold px-1"
                >
                  ✕
                </button>
              </div>
            )}

            {/* Main Central Download Button */}
            <div className="w-full max-w-md pt-1">
              <button
                type="button"
                id="btn-download-latest-source"
                onClick={handleDownloadLatest}
                disabled={isDownloading || isLoadingInfo}
                className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 active:from-emerald-700 active:to-teal-700 text-white font-bold text-sm tracking-wide flex items-center justify-center gap-2.5 active:scale-[0.98] transition-all cursor-pointer shadow-lg shadow-emerald-950/50 group disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {isDownloading ? (
                  <>
                    <Loader2 className="w-4 h-4 text-white animate-spin" />
                    <span>Baixando {current?.filename || 'pacote ZIP'}...</span>
                  </>
                ) : downloadSuccess ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-200 animate-bounce" />
                    <span className="text-emerald-100 font-bold">Download Concluído com Sucesso!</span>
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4 text-emerald-200 group-hover:translate-y-0.5 transition-transform" />
                    <span>
                      Baixar {current?.version ? `${current.version} (.ZIP)` : 'Código-Fonte (.ZIP)'}{' '}
                      {current?.sizeFormatted ? `(${current.sizeFormatted})` : ''}
                    </span>
                  </>
                )}
              </button>
            </div>
          </>
        )}

        {/* All Available Versions Section */}
        {allVersions.length > 0 && !infoError && (
          <div className="w-full max-w-md pt-1">
            <button
              type="button"
              id="btn-toggle-versions-history"
              onClick={() => setShowHistory((prev) => !prev)}
              className="inline-flex items-center justify-center gap-1.5 text-xs font-semibold text-emerald-400 hover:text-emerald-200 py-1.5 px-3 rounded-lg hover:bg-emerald-500/10 transition-colors cursor-pointer"
            >
              <History className="w-3.5 h-3.5" />
              <span>
                {showHistory ? 'Ocultar' : 'Ver'} histórico de versões ({allVersions.length})
              </span>
              {showHistory ? (
                <ChevronUp className="w-3.5 h-3.5 ml-0.5" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5 ml-0.5" />
              )}
            </button>

            {showHistory && (
              <div className="mt-3 space-y-2 text-left bg-black/30 border border-emerald-500/15 rounded-xl p-3 animate-in fade-in duration-200">
                <div className="flex items-center justify-between pb-1.5 border-b border-white/[0.06] text-[11px] font-semibold text-slate-400 px-1">
                  <span>Versão & Tamanho</span>
                  <span>Ações</span>
                </div>

                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {allVersions.map((v) => {
                    const isCurrent = v.isLatest;
                    const isBusy = downloadingFile === v.filename;

                    return (
                      <div
                        key={v.filename}
                        className={`flex items-center justify-between gap-2 p-2.5 rounded-lg border transition-all ${
                          isCurrent
                            ? 'bg-emerald-500/10 border-emerald-500/30'
                            : 'bg-white/[0.02] border-white/[0.06] hover:border-white/[0.12]'
                        }`}
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span
                              className={`text-xs font-bold font-mono px-2 py-0.5 rounded-md ${
                                isCurrent
                                  ? 'bg-emerald-500/25 text-emerald-200'
                                  : 'bg-white/[0.08] text-slate-300'
                              }`}
                            >
                              {v.version}
                            </span>
                            {isCurrent && (
                              <span className="text-[10px] font-bold text-emerald-300 uppercase tracking-wider bg-emerald-500/20 px-1.5 py-0.5 rounded">
                                Atual
                              </span>
                            )}
                            <span className="text-xs font-mono text-slate-300 font-semibold">
                              {v.sizeFormatted}
                            </span>
                          </div>

                          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
                            <Clock className="w-3 h-3 text-slate-400 shrink-0" />
                            <span className="truncate">{v.formattedDateTime}</span>
                          </div>

                          {v.sha256 && (
                            <div className="text-[10px] font-mono text-slate-500 mt-0.5 truncate" title={`SHA-256: ${v.sha256}`}>
                              SHA: {v.sha256.substring(0, 16)}...
                            </div>
                          )}
                        </div>

                        <button
                          type="button"
                          onClick={() => handleDownloadSingleVersion(v)}
                          disabled={isBusy}
                          className="shrink-0 p-2 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 active:scale-95 text-emerald-300 border border-emerald-500/30 hover:border-emerald-500/50 text-xs font-semibold inline-flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
                          title={`Baixar ${v.version} (${v.filename})`}
                        >
                          {isBusy ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-300" />
                          ) : (
                            <Download className="w-3.5 h-3.5 text-emerald-300" />
                          )}
                          <span className="hidden sm:inline">Baixar .ZIP</span>
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
