import type { ProjectVersionInfo, AppVersionItem } from '../types';

export const INITIAL_EMPTY_VERSION_INFO: ProjectVersionInfo = {
  version: '',
  versionNumber: 0,
  lastGenerated: '',
  updatedAt: '',
  formattedTime: '--:--:--',
  formattedDate: '--/--/----',
  formattedDateTime: 'Carregando versão...',
  currentVersion: {
    num: 0,
    version: 'Carregando...',
    displayName: 'Carregando...',
    filename: '',
    downloadUrl: '',
    sizeBytes: 0,
    sizeFormatted: 'Calculando...',
    updatedAt: '',
    formattedDateTime: '',
    formattedTime: '',
    formattedDate: '',
    isLatest: true,
  },
  previousVersion: null,
  comparison: {
    hasPrevious: false,
    oldSizeFormatted: '-',
    oldSizeBytes: 0,
    newSizeFormatted: '-',
    newSizeBytes: 0,
    diffBytes: 0,
    diffFormatted: '0 KB',
    diffPercent: '0%',
    isIncrease: false,
  },
  allVersions: [],
};

// Kept for backward compatibility with existing imports
export const DEFAULT_VERSION_INFO = INITIAL_EMPTY_VERSION_INFO;

/**
 * Loads the latest version-info.json generated during build.
 * Validates integrity and never returns a stale mock object.
 */
export async function fetchProjectVersionInfo(): Promise<ProjectVersionInfo> {
  const res = await fetch(`/version-info.json?t=${Date.now()}`, {
    cache: 'no-store',
    headers: {
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      Pragma: 'no-cache',
    },
  });

  if (!res.ok) {
    throw new Error(`Falha ao carregar metadados da versão (HTTP ${res.status}).`);
  }

  const contentType = res.headers.get('content-type') || '';
  if (contentType.includes('text/html')) {
    throw new Error('Arquivo de metadados version-info.json não encontrado no servidor.');
  }

  const data = (await res.json()) as ProjectVersionInfo;

  if (!data || !data.currentVersion || !data.currentVersion.filename) {
    throw new Error('Metadados de versão corrompidos ou incompletos.');
  }

  // Cross-verify real binary size via HEAD request to the current zip
  try {
    const headUrl = `${data.currentVersion.downloadUrl || `/versions/${data.currentVersion.filename}`}?t=${Date.now()}`;
    const headRes = await fetch(headUrl, {
      method: 'HEAD',
      cache: 'no-store',
      headers: { 'Cache-Control': 'no-cache, no-store, must-revalidate' },
    });

    if (headRes.ok) {
      const cl = headRes.headers.get('content-length');
      if (cl) {
        const bytes = parseInt(cl, 10);
        if (!isNaN(bytes) && bytes > 0) {
          const formatted =
            bytes >= 1024 * 1024
              ? `${(bytes / (1024 * 1024)).toFixed(1)} MB`
              : `${(bytes / 1024).toFixed(1)} KB`;

          data.currentVersion.sizeBytes = bytes;
          data.currentVersion.sizeFormatted = formatted;
        }
      }
    }
  } catch {
    // Non-blocking HEAD check
  }

  return data;
}

/**
 * Downloads a specific version archive by URL and filename with strict integrity checks.
 * NEVER falls back to an older version or mock zip.
 */
export async function downloadSpecificVersion(downloadUrl: string, filename: string): Promise<void> {
  if (!downloadUrl || !filename) {
    throw new Error('Parâmetros de download inválidos: URL ou nome do arquivo ausente.');
  }

  const cleanUrl = `${downloadUrl}?t=${Date.now()}`;
  const res = await fetch(cleanUrl, {
    cache: 'no-store',
    headers: {
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      Pragma: 'no-cache',
    },
  });

  if (!res.ok) {
    throw new Error(`Falha no download da versão ${filename}: Servidor respondeu com código HTTP ${res.status}.`);
  }

  const contentType = res.headers.get('content-type') || '';
  if (contentType.includes('text/html')) {
    throw new Error(`O arquivo da versão ${filename} não está disponível no servidor.`);
  }

  const blob = await res.blob();
  if (blob.size < 100) {
    throw new Error(`O arquivo baixado (${filename}) está corrompido ou vazio (${blob.size} bytes).`);
  }

  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(url);
  document.body.removeChild(a);
}

/**
 * Downloads the exact latest project ZIP file for the current build.
 * Always resolves version from fresh version-info.json metadata.
 * NEVER falls back to an older version or creates a fake zip.
 */
export async function downloadLatestProjectZip(customFilename?: string): Promise<void> {
  const vInfo = await fetchProjectVersionInfo();

  if (!vInfo || !vInfo.currentVersion || !vInfo.currentVersion.filename) {
    throw new Error('Não foi possível identificar a versão atual do projeto nos metadados da build.');
  }

  const current = vInfo.currentVersion;
  const zipName = customFilename || current.filename;
  const downloadUrl = current.downloadUrl || `/versions/${zipName}`;
  const shaParam = current.sha256 ? `&h=${current.sha256.substring(0, 8)}` : '';
  const urlWithCacheBusting = `${downloadUrl}?v=${current.num || current.version}${shaParam}&t=${Date.now()}`;

  const res = await fetch(urlWithCacheBusting, {
    cache: 'no-store',
    headers: {
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      Pragma: 'no-cache',
    },
  });

  if (!res.ok) {
    throw new Error(`Falha no download da versão atual (${zipName}): Servidor respondeu com HTTP ${res.status}.`);
  }

  const contentType = res.headers.get('content-type') || '';
  if (contentType.includes('text/html')) {
    throw new Error(`O pacote da versão atual (${zipName}) não foi encontrado no servidor.`);
  }

  const blob = await res.blob();
  if (blob.size < 100) {
    throw new Error(`O pacote baixado (${zipName}) é inválido ou vazio (${blob.size} bytes).`);
  }

  const blobUrl = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = blobUrl;
  a.download = zipName;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(blobUrl);
  document.body.removeChild(a);
}
