#!/usr/bin/env node

/**
 * scripts/increment-build.js
 * 
 * The EXCLUSIVE single authority for incrementing the build number.
 * 
 * Rules:
 * 1. package.json ("version": "X.0.0") is the SINGLE SOURCE OF TRUTH.
 * 2. Runs ONLY after vite build has succeeded (never on failure).
 * 3. Increments the build number by exactly +1 (e.g. 9 -> 10).
 * 4. No other script, prebuild, postbuild, or ZIP generator is permitted to increment.
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

const pkgPath = path.join(rootDir, 'package.json');
const verPath = path.join(rootDir, '.version');

if (!fs.existsSync(pkgPath)) {
  console.error('❌ [Build Manager] package.json não encontrado!');
  process.exit(1);
}

try {
  const pkgRaw = fs.readFileSync(pkgPath, 'utf8');
  const pkg = JSON.parse(pkgRaw);

  const currentVerStr = pkg.version || '1.0.0';
  const match = currentVerStr.match(/^(\d+)/);
  if (!match) {
    throw new Error(`Formato de versão inválido em package.json: ${currentVerStr}`);
  }

  const currentBuild = parseInt(match[1], 10);
  const nextBuild = currentBuild + 1;

  pkg.version = `${nextBuild}.0.0`;
  fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n', 'utf8');

  try {
    fs.writeFileSync(verPath, String(nextBuild), 'utf8');
  } catch (err) {
    console.warn(`[Aviso] Não foi possível sincronizar .version: ${err.message}`);
  }

  console.log(`\n=======================================================`);
  console.log(`🚀 [Build Manager] Build incrementada com sucesso:`);
  console.log(`   Build anterior: V${currentBuild}`);
  console.log(`   Nova Build:     V${nextBuild}`);
  console.log(`   Fonte única:    package.json ("version": "${pkg.version}")`);
  console.log(`=======================================================\n`);
} catch (err) {
  console.error(`❌ [Build Manager] Erro fatal ao incrementar build: ${err.message}`);
  process.exit(1);
}
