#!/usr/bin/env node

/**
 * scripts/generate-source-zip.js
 * Automated Source Code Packager and Version Publisher.
 * 
 * Executed automatically via 'npm run postbuild' after Vite build:
 * 1. Inspects source code to detect changes since last build.
 * 2. Increments project version in package.json and .version if changes exist.
 * 3. Generates a pristine, compressed source ZIP (excluding node_modules, .git, dist, zips).
 * 4. Calculates cryptographic SHA-256 and exact byte size.
 * 5. Updates public/version-info.json and dist/version-info.json.
 * 6. Publishes the ZIP into public/versions/ and dist/versions/ for instant download.
 * 7. Performs strict integrity validation (fails build if corrupt or inconsistent).
 */

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import JSZip from 'jszip';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

const BRAZIL_TIMEZONE = 'America/Sao_Paulo';

function getBrazilDateInfo() {
  const now = new Date();
  
  // Format in America/Sao_Paulo
  const formatter = new Intl.DateTimeFormat('pt-BR', {
    timeZone: BRAZIL_TIMEZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });

  const parts = formatter.formatToParts(now);
  const partMap = {};
  for (const p of parts) {
    partMap[p.type] = p.value;
  }

  const dateStr = `${partMap.day}/${partMap.month}/${partMap.year}`;
  const timeStr = `${partMap.hour}:${partMap.minute}:${partMap.second}`;
  const datetimeStr = `${dateStr} às ${timeStr}`;
  const isoStr = now.toISOString();

  return { dateStr, timeStr, datetimeStr, isoStr, now };
}

function formatSize(bytes) {
  if (bytes >= 1024 * 1024) {
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }
  return `${(bytes / 1024).toFixed(1)} KB`;
}

function computeFileSha256(filePath) {
  const fileBuffer = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(fileBuffer).digest('hex');
}

/**
 * Computes deterministic consolidated hash of all source files.
 * Ignores the 'version' field in package.json to prevent circular hash invalidation.
 */
function computeSourceCodeHash() {
  const hash = crypto.createHash('sha256');
  const checkPaths = [
    'src',
    'public',
    'scripts',
    'package.json',
    'tsconfig.json',
    'vite.config.ts',
    'index.html',
    '.env.example',
    '.gitignore',
    'metadata.json',
  ];

  const allFiles = [];

  function walk(dir) {
    if (!fs.existsSync(dir)) return;
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const ent of entries) {
      const name = ent.name;
      if (
        name === 'node_modules' ||
        name === 'dist' ||
        name === '.git' ||
        name === 'versions' ||
        name === '__pycache__' ||
        name === '.cache' ||
        name.endsWith('.tmp')
      ) {
        continue;
      }

      const fullPath = path.join(dir, name);
      if (ent.isDirectory()) {
        walk(fullPath);
      } else if (ent.isFile()) {
        if (
          name.endsWith('.zip') ||
          name.endsWith('.pyc') ||
          name === 'version-info.json' ||
          name === '.build-source-hash' ||
          name === '.project-backup.zip' ||
          name.startsWith('.DS_Store')
        ) {
          continue;
        }
        allFiles.push(path.relative(rootDir, fullPath));
      }
    }
  }

  for (const item of checkPaths) {
    const full = path.join(rootDir, item);
    if (!fs.existsSync(full)) continue;
    const stat = fs.statSync(full);
    if (stat.isFile()) {
      allFiles.push(path.relative(rootDir, full));
    } else if (stat.isDirectory()) {
      walk(full);
    }
  }

  allFiles.sort();

  for (const relPath of allFiles) {
    const fullPath = path.join(rootDir, relPath);
    try {
      hash.update(relPath);
      if (relPath === 'package.json') {
        const pkgRaw = fs.readFileSync(fullPath, 'utf8');
        const pkgObj = JSON.parse(pkgRaw);
        // Exclude version from hash
        const { version, ...normalized } = pkgObj;
        hash.update(JSON.stringify(normalized));
      } else {
        const buf = fs.readFileSync(fullPath);
        hash.update(buf);
      }
    } catch {
      // Ignore transient read issues
    }
  }

  return hash.digest('hex');
}

/**
 * Reads the current build number strictly from the single source of truth (package.json).
 * Postbuild NEVER increments or modifies the build number.
 */
function getBuildNumber() {
  const pkgPath = path.join(rootDir, 'package.json');
  if (!fs.existsSync(pkgPath)) {
    throw new Error('package.json não encontrado para leitura da versão da build.');
  }
  const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
  const match = (pkg.version || '').match(/^(\d+)/);
  if (!match) {
    throw new Error(`Campo 'version' inválido em package.json: ${pkg.version}`);
  }
  return parseInt(match[1], 10);
}

/**
 * Traverses source files and creates a zipped archive using JSZip.
 */
async function buildSourceZip(targetZipPath) {
  const zip = new JSZip();

  const excludeDirs = new Set([
    'node_modules',
    'dist',
    '.git',
    '.cache',
    '__pycache__',
    'versions',
    'tmp',
    '.system_generated',
  ]);

  const excludeFilesExact = new Set([
    '.build-source-hash',
    '.project-backup.zip',
    'version-info.json',
  ]);

  function addFolder(currentDir, relativePrefix = '') {
    const entries = fs.readdirSync(currentDir, { withFileTypes: true });

    for (const ent of entries) {
      const name = ent.name;

      if (ent.isDirectory()) {
        if (excludeDirs.has(name) || name.startsWith('.git')) {
          continue;
        }
        const nextRel = relativePrefix ? `${relativePrefix}/${name}` : name;
        addFolder(path.join(currentDir, name), nextRel);
      } else if (ent.isFile()) {
        // Absolute exclusion of any .zip file anywhere
        if (name.endsWith('.zip') || name.endsWith('.pyc') || name.endsWith('.tmp') || name.startsWith('.DS_Store')) {
          continue;
        }
        if (excludeFilesExact.has(name)) {
          continue;
        }
        if (name.startsWith('projeto-versao-') || name.startsWith('projeto-completo')) {
          continue;
        }

        const arcName = relativePrefix ? `${relativePrefix}/${name}` : name;

        // Skip any path inside public/versions
        if (arcName.startsWith('public/versions/') || arcName.startsWith('public/versions\\')) {
          continue;
        }

        const fullPath = path.join(currentDir, name);
        const data = fs.readFileSync(fullPath);
        zip.file(arcName, data);
      }
    }
  }

  addFolder(rootDir);

  const tempPath = `${targetZipPath}.tmp`;
  if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);

  const buffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });

  fs.writeFileSync(tempPath, buffer);

  if (fs.existsSync(targetZipPath)) fs.unlinkSync(targetZipPath);
  fs.renameSync(tempPath, targetZipPath);
}

/**
 * Validates zip archive integrity and enforces safety constraints.
 */
async function validateZipIntegrity(zipPath) {
  if (!fs.existsSync(zipPath)) {
    throw new Error(`Arquivo ZIP não encontrado: ${zipPath}`);
  }

  const stat = fs.statSync(zipPath);
  if (stat.size < 1000) {
    throw new Error(`Arquivo ZIP com tamanho inválido (${stat.size} bytes): ${zipPath}`);
  }

  const data = fs.readFileSync(zipPath);
  const zip = await JSZip.loadAsync(data);
  const names = Object.keys(zip.files);

  for (const name of names) {
    if (name.endsWith('.zip')) {
      throw new Error(`ERRO CRÍTICO: Arquivo ZIP aninhado detectado: ${name}`);
    }
    if (name.includes('node_modules/') || name === 'node_modules' || name.startsWith('node_modules/')) {
      throw new Error(`ERRO CRÍTICO: node_modules incluído indevidamente no ZIP: ${name}`);
    }
    if (name.includes('dist/') || name === 'dist' || name.startsWith('dist/')) {
      throw new Error(`ERRO CRÍTICO: dist incluído indevidamente no ZIP: ${name}`);
    }
    if (name.includes('.git/') || name === '.git' || name.startsWith('.git/')) {
      throw new Error(`ERRO CRÍTICO: .git incluído indevidamente no ZIP: ${name}`);
    }
  }

  const essential = ['src/App.tsx', 'src/main.tsx', 'package.json', 'index.html'];
  for (const req of essential) {
    if (!names.includes(req)) {
      throw new Error(`ERRO CRÍTICO: Arquivo essencial '${req}' ausente no ZIP.`);
    }
  }

  return { valid: true, fileCount: names.length, size: stat.size };
}

async function main() {
  const { dateStr, timeStr, datetimeStr, isoStr } = getBrazilDateInfo();

  console.log('\n=======================================================');
  console.log('📦 [Kitnet Build Postbuild] Gerador Automático de ZIP');
  console.log(`⏰ Data/Hora: ${datetimeStr}`);
  console.log('=======================================================');

  const publicDir = path.join(rootDir, 'public');
  const versionsDir = path.join(publicDir, 'versions');
  if (!fs.existsSync(versionsDir)) {
    fs.mkdirSync(versionsDir, { recursive: true });
  }

  const distDir = path.join(rootDir, 'dist');
  const distVersionsDir = path.join(distDir, 'versions');

  // 1. Resolve build number strictly from single source of truth (package.json)
  const targetVersion = getBuildNumber();
  console.log(`📌 Build ativa: V${targetVersion} (lida exclusivamente de package.json)`);

  const currentSourceHash = computeSourceCodeHash();
  const hashFile = path.join(rootDir, '.build-source-hash');

  const targetFilename = `projeto-versao-${targetVersion}.zip`;
  const targetZipPath = path.join(versionsDir, targetFilename);

  // 2. Build the ZIP
  console.log(`🔨 Empacotando código-fonte em ${targetFilename}...`);
  await buildSourceZip(targetZipPath);

  // 3. Validate ZIP on disk
  await validateZipIntegrity(targetZipPath);
  const targetSize = fs.statSync(targetZipPath).size;
  const targetSha256 = computeFileSha256(targetZipPath);
  const targetSizeFmt = formatSize(targetSize);

  console.log(`✅ ZIP gerado com sucesso:`);
  console.log(`   Arquivo: ${targetFilename}`);
  console.log(`   Tamanho: ${targetSizeFmt} (${targetSize} bytes)`);
  console.log(`   SHA-256: ${targetSha256}`);

  // 4. Index all version archives in public/versions
  const versionItems = [];
  const versionFiles = fs.readdirSync(versionsDir);

  for (const f of versionFiles) {
    const match = f.match(/^projeto-versao-(\d+)\.zip$/);
    if (match) {
      const vNum = parseInt(match[1], 10);
      if (vNum > targetVersion) {
        continue;
      }
      const filePath = path.join(versionsDir, f);
      const fStat = fs.statSync(filePath);
      const fSha = computeFileSha256(filePath);

      let vIso, vDtStr, vTStr, vDStr;
      if (vNum === targetVersion) {
        vIso = isoStr;
        vDtStr = datetimeStr;
        vTStr = timeStr;
        vDStr = dateStr;
      } else {
        const mtime = fStat.mtime;
        vIso = mtime.toISOString();
        const d = new Intl.DateTimeFormat('pt-BR', {
          timeZone: BRAZIL_TIMEZONE,
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }).formatToParts(mtime);
        const map = {};
        for (const part of d) map[part.type] = part.value;
        vDStr = `${map.day}/${map.month}/${map.year}`;
        vTStr = `${map.hour}:${map.minute}:${map.second}`;
        vDtStr = `${vDStr} às ${vTStr}`;
      }

      versionItems.push({
        num: vNum,
        version: `Versão ${vNum}`,
        displayName: `Projeto Versão ${vNum}`,
        filename: f,
        downloadUrl: `/versions/${f}`,
        sizeBytes: fStat.size,
        sizeFormatted: formatSize(fStat.size),
        sha256: fSha,
        updatedAt: vIso,
        formattedDateTime: vDtStr,
        formattedTime: vTStr,
        formattedDate: vDStr,
        isLatest: vNum === targetVersion,
      });
    }
  }

  // Sort descending by version number
  versionItems.sort((a, b) => b.num - a.num);
  versionItems.forEach((item) => {
    item.isLatest = item.num === targetVersion;
  });

  const currentV = versionItems.find(v => v.num === targetVersion) || versionItems[0];
  const previousV = versionItems.find(v => v.num < targetVersion) || null;

  const comparison = {
    hasPrevious: previousV !== null,
    oldSizeFormatted: previousV ? previousV.sizeFormatted : '-',
    oldSizeBytes: previousV ? previousV.sizeBytes : 0,
    newSizeFormatted: currentV.sizeFormatted,
    newSizeBytes: currentV.sizeBytes,
    diffBytes: 0,
    diffFormatted: '0 KB',
    diffPercent: '0%',
    isIncrease: false,
  };

  if (previousV && previousV.sizeBytes > 0) {
    const diff = currentV.sizeBytes - previousV.sizeBytes;
    comparison.diffBytes = diff;
    const sign = diff > 0 ? '+' : diff === 0 ? '' : '-';
    const diffKb = Math.abs(parseFloat((diff / 1024).toFixed(1)));
    comparison.diffFormatted = diff !== 0 ? `${sign}${diffKb} KB` : '0 KB';
    const pct = Math.abs(parseFloat(((diff / previousV.sizeBytes) * 100).toFixed(1)));
    comparison.diffPercent = diff !== 0 ? `${sign}${pct}%` : '0%';
    comparison.isIncrease = diff > 0;
  }

  const metadata = {
    version: String(targetVersion),
    versionNumber: targetVersion,
    file: `/versions/${targetFilename}`,
    filename: targetFilename,
    downloadUrl: `/versions/${targetFilename}`,
    size: targetSize,
    sizeBytes: targetSize,
    sizeFormatted: targetSizeFmt,
    sha256: targetSha256,
    generatedAt: isoStr,
    lastGenerated: isoStr,
    updatedAt: isoStr,
    formattedTime: timeStr,
    formattedDate: dateStr,
    formattedDateTime: datetimeStr,
    currentVersion: currentV,
    previousVersion: previousV,
    comparison: comparison,
    allVersions: versionItems,
  };

  const infoJsonPath = path.join(publicDir, 'version-info.json');
  fs.writeFileSync(infoJsonPath, JSON.stringify(metadata, null, 2) + '\n', 'utf8');

  // 5. Publish / sync to dist, backups, and compatibility locations
  fs.copyFileSync(targetZipPath, path.join(publicDir, 'projeto-completo.zip'));
  fs.copyFileSync(targetZipPath, path.join(rootDir, '.project-backup.zip'));

  if (fs.existsSync(distDir)) {
    if (!fs.existsSync(distVersionsDir)) {
      fs.mkdirSync(distVersionsDir, { recursive: true });
    }
    fs.copyFileSync(targetZipPath, path.join(distVersionsDir, targetFilename));
    fs.copyFileSync(targetZipPath, path.join(distDir, 'projeto-completo.zip'));
    fs.copyFileSync(infoJsonPath, path.join(distDir, 'version-info.json'));
    console.log(`📡 Sincronizado para pasta de distribuição dist/`);
  }

  // 6. Save current source code hash
  fs.writeFileSync(hashFile, currentSourceHash, 'utf8');

  // 7. Final integrity validation of published files
  if (fs.existsSync(distDir)) {
    const publishedZip = path.join(distVersionsDir, targetFilename);
    const publishedInfo = path.join(distDir, 'version-info.json');

    if (!fs.existsSync(publishedZip)) {
      throw new Error(`Falha na publicação: ${publishedZip} ausente.`);
    }
    if (!fs.existsSync(publishedInfo)) {
      throw new Error(`Falha na publicação: ${publishedInfo} ausente.`);
    }

    const pubSha = computeFileSha256(publishedZip);
    if (pubSha !== targetSha256) {
      throw new Error(`Inconsistência de SHA-256 no pacote publicado!`);
    }
  }

  console.log(`📋 Metadados gravados em public/version-info.json e dist/version-info.json`);
  console.log(`🎉 Versão ativa e pronta para download: ${currentV.version} (${currentV.filename})`);
  console.log('=======================================================\n');
}

main().catch((err) => {
  console.error(`\n❌ ERRO NA GERAÇÃO/PUBLICAÇÃO DO PACOTE ZIP: ${err.message}`, err);
  process.exit(1);
});
