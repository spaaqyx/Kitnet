import { useEffect, useRef } from 'react';
import { COLORS } from '../styles/colors';

/**
 * Performance Tracking Hook & Logger
 * Identifies component re-render frequency, renders per second, and potential infinite loops.
 */
interface RenderStats {
  count: number;
  lastRenderTime: number;
  rendersInLastSecond: number;
  secondStartTime: number;
}

const renderStatsMap = new Map<string, RenderStats>();

// Performance diagnostics are strictly opt-in via window.__ENABLE_PERF_LOGS__ to preserve production FPS
const isPerfLogEnabled = (): boolean => {
  if (typeof window === 'undefined') return false;
  return Boolean((window as any).__ENABLE_PERF_LOGS__);
};

export function useRenderTracker(componentName: string, trackedProps?: Record<string, any>) {
  const renderCount = useRef(0);
  const prevProps = useRef(trackedProps);
  renderCount.current += 1;

  useEffect(() => {
    if (!isPerfLogEnabled()) return;

    const now = performance.now();
    let stats = renderStatsMap.get(componentName);

    if (!stats) {
      stats = {
        count: 0,
        lastRenderTime: now,
        rendersInLastSecond: 0,
        secondStartTime: now,
      };
      renderStatsMap.set(componentName, stats);
    }

    stats.count += 1;

    // Calculate frequency in the last 1 second
    if (now - stats.secondStartTime > 1000) {
      stats.secondStartTime = now;
      stats.rendersInLastSecond = 1;
    } else {
      stats.rendersInLastSecond += 1;
    }

    stats.lastRenderTime = now;

    // Detect high frequency / potential loop
    if (stats.rendersInLastSecond > 12) {
      console.warn(
        `%c[PERF ALERT] ⚠️ <${componentName} /> rendered ${stats.rendersInLastSecond} times in <1s! (Total: ${stats.count})`,
        `color: ${COLORS.money.warning}; font-weight: bold; background: rgba(120, 53, 15, 0.12); padding: 2px 6px; border-radius: 4px;`
      );
    }

    // Check changed props if provided
    if (trackedProps && prevProps.current) {
      const changedKeys: string[] = [];
      Object.keys(trackedProps).forEach((key) => {
        if (trackedProps[key] !== prevProps.current?.[key]) {
          changedKeys.push(key);
        }
      });
      if (changedKeys.length > 0) {
        console.debug(`  ↳ Props changed for <${componentName} />:`, changedKeys);
      }
    }
    prevProps.current = trackedProps;
  }, [componentName, trackedProps]);
}

/**
 * Diagnostic Lifecycle Logger
 * Identifies mounts, unmounts, and lifecycle events when __ENABLE_PERF_LOGS__ is active.
 */
export function useLifecycleLogger(componentName: string, details?: any) {
  const renderCount = useRef(0);
  renderCount.current += 1;
  const currentRender = renderCount.current;

  useEffect(() => {
    if (!isPerfLogEnabled()) return;
    console.log(
      `%c[LIFECYCLE] 🟢 MOUNT: <${componentName} /> (Initial Render #${currentRender})`,
      `color: ${COLORS.money.positive}; font-weight: bold; background: rgba(6, 78, 59, 0.2); padding: 2px 4px; border-radius: 4px;`
    );
    return () => {
      console.log(
        `%c[LIFECYCLE] 🔴 UNMOUNT: <${componentName} /> (Total renders: ${renderCount.current})`,
        `color: ${COLORS.money.negative}; font-weight: bold; background: rgba(127, 29, 29, 0.2); padding: 2px 4px; border-radius: 4px;`
      );
    };
  }, [componentName]);
}
