/**
 * Dedicated IndexedDB Blob and Binary Storage Layer
 * Solves QuotaExceededError in mobile browsers (Safari/Chrome 5MB limits)
 * by persisting heavy binary payloads (photos, inspection records, PDFs, signatures)
 * in an asynchronous, unlimited IndexedDB store.
 */

const BLOB_DB_NAME = 'gp_motos_kitnets_blobs';
const BLOB_STORE_NAME = 'blobs';
const BLOB_DB_VERSION = 1;

let dbPromise: Promise<IDBDatabase | null> | null = null;

function getBlobDB(): Promise<IDBDatabase | null> {
  if (typeof window === 'undefined' || !window.indexedDB) {
    return Promise.resolve(null);
  }

  if (!dbPromise) {
    dbPromise = new Promise((resolve) => {
      try {
        const request = window.indexedDB.open(BLOB_DB_NAME, BLOB_DB_VERSION);

        request.onupgradeneeded = () => {
          const db = request.result;
          if (!db.objectStoreNames.contains(BLOB_STORE_NAME)) {
            db.createObjectStore(BLOB_STORE_NAME);
          }
        };

        request.onsuccess = () => resolve(request.result);
        request.onerror = (e) => {
          console.warn('[BlobStorage] Failed to open IndexedDB:', e);
          resolve(null);
        };
      } catch (err) {
        console.warn('[BlobStorage] Initialization error:', err);
        resolve(null);
      }
    });
  }

  return dbPromise;
}

/**
 * Saves a binary string or Blob under a unique key
 */
export async function saveBlob(key: string, data: string | Blob): Promise<boolean> {
  const db = await getBlobDB();
  if (!db) return false;

  return new Promise((resolve) => {
    try {
      const tx = db.transaction(BLOB_STORE_NAME, 'readwrite');
      const store = tx.objectStore(BLOB_STORE_NAME);
      const req = store.put(data, key);

      req.onsuccess = () => resolve(true);
      req.onerror = (err) => {
        console.warn(`[BlobStorage] Error saving key "${key}":`, err);
        resolve(false);
      };
    } catch (err) {
      console.warn(`[BlobStorage] Exception saving key "${key}":`, err);
      resolve(false);
    }
  });
}

/**
 * Retrieves a stored Blob or string by key
 */
export async function getBlob(key: string): Promise<string | Blob | null> {
  const db = await getBlobDB();
  if (!db) return null;

  return new Promise((resolve) => {
    try {
      const tx = db.transaction(BLOB_STORE_NAME, 'readonly');
      const store = tx.objectStore(BLOB_STORE_NAME);
      const req = store.get(key);

      req.onsuccess = () => resolve(req.result ?? null);
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

/**
 * Deletes a stored blob by key
 */
export async function deleteBlob(key: string): Promise<boolean> {
  const db = await getBlobDB();
  if (!db) return false;

  return new Promise((resolve) => {
    try {
      const tx = db.transaction(BLOB_STORE_NAME, 'readwrite');
      const store = tx.objectStore(BLOB_STORE_NAME);
      const req = store.delete(key);

      req.onsuccess = () => resolve(true);
      req.onerror = () => resolve(false);
    } catch {
      resolve(false);
    }
  });
}

/**
 * Returns all keys stored in the blob database
 */
export async function listBlobKeys(): Promise<string[]> {
  const db = await getBlobDB();
  if (!db) return [];

  return new Promise((resolve) => {
    try {
      const tx = db.transaction(BLOB_STORE_NAME, 'readonly');
      const store = tx.objectStore(BLOB_STORE_NAME);
      const req = store.getAllKeys();

      req.onsuccess = () => resolve((req.result as string[]) || []);
      req.onerror = () => resolve([]);
    } catch {
      resolve([]);
    }
  });
}

/**
 * Clears all stored binary data
 */
export async function clearAllBlobs(): Promise<boolean> {
  const db = await getBlobDB();
  if (!db) return false;

  return new Promise((resolve) => {
    try {
      const tx = db.transaction(BLOB_STORE_NAME, 'readwrite');
      const store = tx.objectStore(BLOB_STORE_NAME);
      const req = store.clear();

      req.onsuccess = () => resolve(true);
      req.onerror = () => resolve(false);
    } catch {
      resolve(false);
    }
  });
}
