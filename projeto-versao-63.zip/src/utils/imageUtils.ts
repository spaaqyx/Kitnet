import { saveBlob } from './blobStorage';

/**
 * Image processing utilities for compression and file reading
 */

export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(file);
  });
}

/**
 * Compresses an image file or base64 string to an optimized width/height and quality
 * to ensure fast rendering and lightweight storage (under 30KB per photo to protect storage quota).
 */
export function compressImage(
  fileOrBase64: File | string,
  maxWidth: number = 600,
  maxHeight: number = 600,
  quality: number = 0.60
): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    
    img.onload = () => {
      let width = img.width;
      let height = img.height;

      // Calculate the new dimensions maintaining aspect ratio
      if (width > height) {
        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
      } else {
        if (height > maxHeight) {
          width = Math.round((width * maxHeight) / height);
          height = maxHeight;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(typeof fileOrBase64 === 'string' ? fileOrBase64 : '');
        return;
      }

      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(img, 0, 0, width, height);

      const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
      resolve(compressedDataUrl);
    };

    img.onerror = (err) => {
      reject(err);
    };

    if (typeof fileOrBase64 === 'string') {
      img.src = fileOrBase64;
    } else {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          img.src = e.target.result as string;
        } else {
          reject(new Error('Failed to read image file'));
        }
      };
      reader.onerror = reject;
      reader.readAsDataURL(fileOrBase64);
    }
  });
}

/**
 * Compresses and persists image into both a lightweight base64 string
 * and optionally directly into IndexedDB blob storage for full resilience.
 */
export async function compressAndStoreImage(
  fileOrBase64: File | string,
  storageKey?: string
): Promise<string> {
  const compressed = await compressImage(fileOrBase64, 600, 600, 0.60);
  if (storageKey) {
    try {
      await saveBlob(storageKey, compressed);
    } catch (e) {
      console.warn('[ImageUtils] Failed to mirror image to BlobStorage:', e);
    }
  }
  return compressed;
}

