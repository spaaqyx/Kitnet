/**
 * Motion Design System Tokens & Standard Framer Motion Presets
 * Standardized on cubic-bezier(0.16, 1, 0.3, 1) and Apple/Material 3 motion guidelines
 */

export const STANDARD_EASE = [0.16, 1, 0.3, 1] as const;

export const MOTION_DURATIONS = {
  micro: 0.15,
  tab: 0.2,
  modalIn: 0.22,
  modalOut: 0.18,
  drawer: 0.28,
} as const;

export const STANDARD_SPRING = {
  type: 'spring',
  stiffness: 380,
  damping: 30,
} as const;

export const tabVariants = {
  initial: (reduced: boolean) => ({
    opacity: 0,
    y: reduced ? 0 : 8,
  }),
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      duration: MOTION_DURATIONS.tab,
      ease: STANDARD_EASE,
    },
  },
  exit: (reduced: boolean) => ({
    opacity: 0,
    y: reduced ? 0 : -8,
    transition: {
      duration: 0.16,
      ease: STANDARD_EASE,
    },
  }),
};

export const modalBackdropVariants = {
  initial: { opacity: 0 },
  animate: {
    opacity: 1,
    transition: { duration: MOTION_DURATIONS.modalIn, ease: 'easeOut' },
  },
  exit: {
    opacity: 0,
    transition: { duration: MOTION_DURATIONS.modalOut, ease: 'easeIn' },
  },
};

export const modalCardVariants = {
  initial: (reduced: boolean) => ({
    opacity: 0,
    scale: reduced ? 1 : 0.96,
    y: reduced ? 0 : 10,
  }),
  animate: {
    opacity: 1,
    scale: 1,
    y: 0,
    transition: {
      duration: MOTION_DURATIONS.modalIn,
      ease: STANDARD_EASE,
    },
  },
  exit: (reduced: boolean) => ({
    opacity: 0,
    scale: reduced ? 1 : 0.96,
    y: reduced ? 0 : 8,
    transition: {
      duration: MOTION_DURATIONS.modalOut,
      ease: STANDARD_EASE,
    },
  }),
};
