/**
 * src/styles/colors.ts
 *
 * Ponto ÚNICO e centralizado de tokens de cor do sistema.
 * Todas as superfícies, ações, categorias e destaques devem referenciar este arquivo.
 */

export const COLORS = {
  surface: {
    base: '#0E111A',        // fundo geral de tela e modal
    card: '#161B2B',        // cards e seções internas
    header: '#0C0F1D',      // cabeçalho/rodapé de modal
    input: '#0C0F1D',       // campos de formulário e inputs de busca
    elevated: '#1F2438',    // dropdowns, popovers e gavetas
    subtle: '#121420',      // superfícies secundárias escuras
    hover: '#1D2235',       // hover em linhas e listas
    sidebar: '#0B0D13',     // navegação e barras laterais
    overlay: 'rgba(0, 0, 0, 0.75)',
  },
  border: {
    subtle: 'rgba(255, 255, 255, 0.08)',
    hover: 'rgba(255, 255, 255, 0.14)',
    dark: '#2A2A2E',
    darkHover: '#3E3E44',
    focus: '#8B5CF6',
  },
  action: {
    primary: '#8B5CF6',     // Roxo elétrico primário
    hover: '#7C4FE0',       // Hover de botão primário
    active: '#6D28D9',      // Botão ativo / selecionado
    light: '#A78BFA',       // Variação clara
    dark: '#5B21B6',        // Variação escura
  },
  category: {
    motos: '#E07A3F',       // Laranja quente exclusivo motos
    motosAlt: '#F59E0B',    // Âmbar
    kitnets: '#4CA6E0',     // Azul kitnets padrão
    kitnetsSky: '#0EA5E9',  // Sky blue para badges e destaques
    kitnetsCyan: '#38BDF8', // Cyan claro
  },
  money: {
    positive: '#10B981',        // Verde receita / pago
    positiveHover: '#059669',   // Verde hover
    positiveDark: '#047857',    // Verde escuro
    negative: '#EF4444',        // Vermelho despesa / atraso
    negativeHover: '#DC2626',   // Vermelho hover
    negativeDark: '#B91C1C',    // Vermelho escuro
    warning: '#F59E0B',         // Amarelo atenção
    warningHover: '#D97706',    // Amarelo hover
    warningDark: '#B45309',     // Amarelo escuro
  },
  text: {
    primary: '#F2F1ED',     // Texto principal
    secondary: '#94A3B8',   // Texto secundário
    muted: '#64748B',       // Texto desabilitado / placeholders
    dim: '#475569',         // Texto sutil
    white: '#FFFFFF',       // Branco puro
    dark: '#0F172A',        // Preto texto para documentos/impressão
  },
  status: {
    success: '#10B981',
    danger: '#EF4444',
    warning: '#F59E0B',
    info: '#0EA5E9',
  },
  social: {
    whatsapp: '#25D366',    // Verde oficial WhatsApp
    google: {
      blue: '#4285F4',
      green: '#34A853',
      yellow: '#FBBC05',
      red: '#EA4335',
    },
  },
  logo: {
    crestStop0: '#FAF5FF',
    crestStop18: '#E9D5FF',
    crestStop42: '#C084FC',
    crestStop75: '#9333EA',
    crestStop100: '#6366F1',
    borderStop0: '#FFFFFF',
    borderStop45: '#E9D5FF',
    borderStop85: '#C084FC',
    borderStop100: '#8B5CF6',
    glowNear: '#D8B4FE',
    glowMid: '#A855F7',
    glowFar: '#6366F1',
    plateTop: '#181A2A',
    plateMid: '#11131E',
    plateBase: '#090A10',
    pureWhite: '#FFFFFF',
  },
  presetVehicleColors: [
    { name: 'Preta', hex: '#18181B', border: '#3F3F46' },
    { name: 'Vermelha', hex: '#DC2626', border: '#EF4444' },
    { name: 'Azul', hex: '#2563EB', border: '#3B82F6' },
    { name: 'Branca', hex: '#F8FAFC', border: '#CBD5E1' },
    { name: 'Prata', hex: '#94A3B8', border: '#CBD5E1' },
    { name: 'Cinza', hex: '#475569', border: '#64748B' },
    { name: 'Amarela', hex: '#EAB308', border: '#FDE047' },
  ],
  pdf: {
    text: '#1E293B',
    title: '#0F172A',
    subtext: '#64748B',
    cardBg: '#FFFFFF',
    cardBorder: '#E2E8F0',
    line: '#334155',
    successText: '#059669',
    successBg: '#ECFDF5',
    successBorder: '#A7F3D0',
    warningText: '#B45309',
    warningBg: '#FFFBEB',
    warningBorder: '#F59E0B',
    dangerText: '#991B1B',
    dangerBg: '#FEF2F2',
    dangerBorder: '#FECACA',
  },
} as const;

export type ColorTokens = typeof COLORS;
