import React, { useState, useEffect, useCallback } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import { STANDARD_EASE, MOTION_DURATIONS } from './utils/motion';
import { useApp, AppProvider } from './context/AppContext';
import { ErrorBoundary } from './components/ErrorBoundary';
import { usePWA } from './hooks/usePWA';
import { DisconnectingScreen } from './components/DisconnectingScreen';
import { LockScreen } from './components/LockScreen';
import { Navigation, TabType } from './components/Navigation';
import { DashboardView } from './components/DashboardView';
import { CentralDeCobrancasView } from './components/CentralDeCobrancasView';
import { ClientesView } from './components/ClientesView';
import { ClientDetailDrawer } from './components/ClientDetailDrawer';
import { CalendarioOperacionalView } from './components/CalendarioOperacionalView';
import { RelatoriosView } from './components/RelatoriosView';
import { MotosView } from './components/MotosView';
import { KitnetsView } from './components/KitnetsView';
import { FinanceiroView } from './components/FinanceiroView';
import { DocumentosView } from './components/DocumentosView';
import { SettingsAndTimelineView } from './components/SettingsAndTimelineView';
import { NotificationsModal } from './components/NotificationsModal';
import { WhatsAppReminderModal } from './components/WhatsAppReminderModal';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { QuickContactsModal } from './components/QuickContactsModal';
import { SimuladorCompraMotoModal } from './components/SimuladorCompraMotoModal';
import { PWAInstallGuideModal } from './components/PWAInstallGuideModal';
import { OfflineBanner } from './components/OfflineBanner';
import { PWAUpdateBanner } from './components/PWAUpdateBanner';
import { StorageWarningBanner } from './components/StorageWarningBanner';
import { AppFooter } from './components/AppFooter';
import { generateContractPDF, generateReceiptPDF } from './utils/pdfGenerator';
import { generateMotoRentalContractPdfFile } from './utils/pdf/motoPdfGenerator';
import { Moto, MotoContract, MotoTenant, Kitnet, KitnetContract, KitnetTenant } from './types';
import { ShieldAlert } from 'lucide-react';
import { safeLocalStorage, safeSessionStorage } from './utils/storage';
import { getTodayLocalDateString } from './utils/formatters';
import { forceUnlockBodyScroll } from './hooks/useBodyScrollLock';
import { useLifecycleLogger } from './utils/perfLogger';
import { CURRENT_APP_BUILD_ID, CURRENT_APP_BUILD_DATETIME } from './constants/appVersion';

// Sincronização automática de build e código-fonte verificada
export const KITNET_BUILD_TIMESTAMP = CURRENT_APP_BUILD_DATETIME;
export const BUILD_VALIDATION_TOKEN = CURRENT_APP_BUILD_ID;

const VALID_TABS: TabType[] = [
  'dashboard',
  'cobrancas',
  'motos',
  'kitnets',
  'clientes',
  'calendario',
  'financeiro',
  'relatorios',
  'documentos',
  'configuracoes',
];

const parseTabFromHash = (): TabType => {
  if (typeof window === 'undefined') return 'dashboard';
  const hash = window.location.hash.replace(/^#\/?/, '').toLowerCase().trim();
  if (VALID_TABS.includes(hash as TabType)) {
    return hash as TabType;
  }
  return 'dashboard';
};

function AppContent() {
  const {
    isAuthenticated,
    isDisconnecting,
    isLogoutDisconnect,
    completeDisconnect,
    settings,
    isReadOnlyMode,
    toggleReadOnlyMode,
  } = useApp();

  const { isOnline, hasUpdate, applyUpdate, isInstallable, promptInstall } = usePWA();
  const shouldReduceMotion = useReducedMotion();

  const [activeTab, setActiveTabState] = useState<TabType>(() => parseTabFromHash());
  const [isNotificationsOpen, setIsNotificationsOpen] = useState<boolean>(false);
  const [isWhatsAppOpen, setIsWhatsAppOpen] = useState<boolean>(false);
  const [whatsAppContractId, setWhatsAppContractId] = useState<string | undefined>(undefined);
  const [whatsAppInstallmentId, setWhatsAppInstallmentId] = useState<string | undefined>(undefined);

  // Unified Modals
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [isContactsOpen, setIsContactsOpen] = useState<boolean>(false);
  const [isSimulatorOpen, setIsSimulatorOpen] = useState<boolean>(false);
  const [isPwaGuideOpen, setIsPwaGuideOpen] = useState<boolean>(false);
  const [readOnlyToast, setReadOnlyToast] = useState<string | null>(null);

  useEffect(() => {
    const handleBlocked = (e: any) => {
      setReadOnlyToast(e?.detail?.message || 'Ação bloqueada: O sistema está no Modo Somente Leitura.');
      const timer = setTimeout(() => setReadOnlyToast(null), 4000);
      return () => clearTimeout(timer);
    };
    window.addEventListener('readonly-blocked-action', handleBlocked);
    return () => window.removeEventListener('readonly-blocked-action', handleBlocked);
  }, []);

  // Global shortcut for search (Ctrl+K / Cmd+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Sync state with URL hash safely using replaceState
  const setActiveTab = useCallback((tab: TabType) => {
    if (isReadOnlyMode && tab !== 'dashboard') {
      return;
    }
    setActiveTabState(tab);
    const targetHash = `#/${tab}`;
    try {
      if (window.location.hash !== targetHash) {
        window.history.replaceState(null, '', targetHash);
      }
    } catch {
      // Ignore
    }
  }, [isReadOnlyMode]);

  // When read-only mode is active, direct immediately to Dashboard, close modals, and prevent leaving
  useEffect(() => {
    if (isReadOnlyMode) {
      setActiveTabState('dashboard');
      setIsClientDrawerOpen(false);
      setIsNotificationsOpen(false);
      setIsWhatsAppOpen(false);
      setIsSearchOpen(false);
      setIsContactsOpen(false);
      setIsSimulatorOpen(false);
      setIsPwaGuideOpen(false);
      if (window.location.hash !== '#/dashboard') {
        try {
          window.history.replaceState(null, '', '#/dashboard');
        } catch {
          window.location.hash = '#/dashboard';
        }
      }
    }
  }, [isReadOnlyMode]);

  // Listen to browser Back/Forward & direct URL hash changes without reload loops
  useEffect(() => {
    const handleHashChange = () => {
      const currentHashTab = parseTabFromHash();
      if (isReadOnlyMode && currentHashTab !== 'dashboard') {
        try {
          window.history.replaceState(null, '', '#/dashboard');
        } catch {
          window.location.hash = '#/dashboard';
        }
        setActiveTabState('dashboard');
        return;
      }
      setActiveTabState(currentHashTab);
    };

    try {
      if (!window.location.hash || window.location.hash === '#' || (isReadOnlyMode && window.location.hash !== '#/dashboard')) {
        window.history.replaceState(null, '', '#/dashboard');
        setActiveTabState('dashboard');
      } else {
        const initialTab = parseTabFromHash();
        setActiveTabState(initialTab);
      }
    } catch {
      // Ignore
    }

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [isReadOnlyMode]);

  // Unlock body scroll and scroll to top smoothly on tab switch
  useEffect(() => {
    forceUnlockBodyScroll();
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [activeTab]);

  // Client Detail Drawer state
  const [selectedTenantId, setSelectedTenantId] = useState<string | null>(null);
  const [selectedTenantType, setSelectedTenantType] = useState<'moto' | 'kitnet'>('moto');
  const [isClientDrawerOpen, setIsClientDrawerOpen] = useState<boolean>(false);

  const handleOpenInstallPrompt = useCallback(async () => {
    if (isInstallable) {
      const installed = await promptInstall();
      if (!installed) {
        setIsPwaGuideOpen(true);
      }
    } else {
      setIsPwaGuideOpen(true);
    }
  }, [isInstallable, promptInstall]);

  // Memoized navigation & modal handlers to avoid cascading re-renders
  const handleOpenWhatsAppForContract = useCallback((contractId?: string, installmentId?: string) => {
    setWhatsAppContractId(contractId);
    setWhatsAppInstallmentId(installmentId);
    setIsWhatsAppOpen(true);
  }, []);

  const handleOpenClientProfile = useCallback((tenantId: string, type: 'moto' | 'kitnet') => {
    setSelectedTenantId(tenantId);
    setSelectedTenantType(type);
    setIsClientDrawerOpen(true);
  }, []);

  const handleOpenSimulator = useCallback(() => setIsSimulatorOpen(true), []);
  const handleOpenContacts = useCallback(() => setIsContactsOpen(true), []);
  const handleOpenSearch = useCallback(() => setIsSearchOpen(true), []);
  const handleOpenNotifications = useCallback(() => setIsNotificationsOpen(true), []);

  const handleGenerateDoc = (
    type: string,
    asset?: Moto | Kitnet,
    contract?: MotoContract | KitnetContract,
    tenant?: MotoTenant | KitnetTenant
  ) => {
    if ((type === 'contrato_moto' || type === 'contrato_locacao') && asset && contract && tenant) {
      const m = asset as Moto;
      const c = contract as MotoContract;
      const t = tenant as MotoTenant;

      generateMotoRentalContractPdfFile({
        moto: m,
        tenant: t,
        contract: c,
        settings,
        autoDownload: true,
      });
    } else if (type === 'recibo_pagamento' && asset && contract && tenant) {
      const c = contract as MotoContract;
      const t = tenant as MotoTenant;
      const m = asset as Moto;
      const inst = c.installments[0];
      generateReceiptPDF({
        title: 'RECIBO DE PAGAMENTO DE PARCELA',
        payerName: t.fullName,
        payerCpf: t.cpf,
        amount: inst.amount,
        description: `Quitação de parcela referente à locação do veículo placa ${m.plate}.`,
        date: getTodayLocalDateString(),
        ownerName: settings.adminName,
        ownerCpf: settings.adminCpf,
      });
    } else if (type === 'termo_entrega_moto' && asset && contract && tenant) {
      const m = asset as Moto;
      const t = tenant as MotoTenant;
      const c = contract as MotoContract;
      const tenantSignature = safeLocalStorage.getItem(`signature_moto_${m.id}`) ||
                              (m.plate && safeLocalStorage.getItem(`signature_moto_${m.plate}`)) ||
                              safeLocalStorage.getItem(`signature_locatario_${t.id}`) ||
                              undefined;

      generateContractPDF({
        title: 'TERMO DE ENTREGA E VISTORIA DA MOTOCICLETA',
        ownerName: settings.adminName,
        ownerCpf: settings.adminCpf,
        ownerAddress: settings.adminAddress,
        tenantName: t.fullName,
        tenantCpf: t.cpf,
        tenantRg: t.rg,
        tenantAddress: t.address,
        assetDescription: `Veículo ${m.brand} ${m.model}, Placa ${m.plate}, KM Inicial: ${m.delivery?.initialKm || m.currentKm} km`,
        valueMonthly: c.monthlyValue,
        deposit: c.deposit,
        durationMonths: c.durationMonths,
        dueDay: c.dueDay,
        startDate: m.delivery?.date || c.startDate,
        tenantSignature,
        extraTerms: [
          'O LOCATÁRIO declara ter recebido o veículo em perfeitas condições mecânicas e estéticas.',
          'Quilometragem e fotos registradas no aplicativo no ato da entrega.',
        ],
      });
    } else {
      setActiveTab('documentos');
    }
  };

  useLifecycleLogger('App');

  // If disconnecting, show animated disconnecting sequence
  if (isDisconnecting) {
    return <DisconnectingScreen onComplete={completeDisconnect} isLogout={isLogoutDisconnect} />;
  }

  // If not unlocked, show lock screen
  if (!isAuthenticated) {
    return <LockScreen />;
  }

  return (
    <div className="min-h-screen bg-[#090A0F] text-[#F5F5F7] flex flex-col font-sans selection:bg-[#8B5CF6] selection:text-white">
      {/* Real-time Offline Warning Banner */}
      <OfflineBanner isOnline={isOnline} />

      {/* Device Storage Full Warning Banner */}
      <StorageWarningBanner onNavigateToSettings={() => setActiveTab('configuracoes')} />

      {/* Service Worker PWA Update Notification Banner */}
      <PWAUpdateBanner hasUpdate={hasUpdate} onApplyUpdate={applyUpdate} />

      {/* Top and Mobile Navigation */}
      <Navigation
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenNotifications={handleOpenNotifications}
        onOpenSearch={handleOpenSearch}
        onOpenContacts={handleOpenContacts}
        onOpenSimulator={handleOpenSimulator}
        onOpenPwaGuide={handleOpenInstallPrompt}
      />

      {/* Main Content Viewport with Smooth Animated Tab Switching */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 pt-3 sm:pt-5 pb-6 sm:pb-8">
        <div className="w-full">
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: shouldReduceMotion ? 0 : 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: shouldReduceMotion ? 0 : -8 }}
              transition={{ duration: MOTION_DURATIONS.tab, ease: STANDARD_EASE }}
              className="w-full"
            >
              {activeTab === 'dashboard' && (
                <DashboardView
                  onNavigateTab={setActiveTab}
                  onOpenWhatsAppModal={handleOpenWhatsAppForContract}
                />
              )}

              {activeTab === 'cobrancas' && (
                <CentralDeCobrancasView
                  onOpenWhatsApp={handleOpenWhatsAppForContract}
                  onOpenClientProfile={handleOpenClientProfile}
                  onNavigateTab={setActiveTab}
                />
              )}

              {activeTab === 'clientes' && (
                <ClientesView
                  onOpenClientProfile={handleOpenClientProfile}
                  onOpenWhatsApp={handleOpenWhatsAppForContract}
                  onNavigateTab={setActiveTab}
                />
              )}

              {activeTab === 'calendario' && (
                <CalendarioOperacionalView onOpenWhatsApp={handleOpenWhatsAppForContract} />
              )}

              {activeTab === 'relatorios' && <RelatoriosView />}

              {activeTab === 'motos' && (
                <MotosView
                  onOpenWhatsApp={handleOpenWhatsAppForContract}
                  onGenerateDocument={handleGenerateDoc}
                  onOpenSimulator={handleOpenSimulator}
                  onOpenClientProfile={handleOpenClientProfile}
                />
              )}

              {activeTab === 'kitnets' && (
                <KitnetsView
                  onOpenWhatsApp={handleOpenWhatsAppForContract}
                  onGenerateDocument={handleGenerateDoc}
                  onOpenClientProfile={handleOpenClientProfile}
                />
              )}

              {activeTab === 'financeiro' && <FinanceiroView />}

              {activeTab === 'documentos' && <DocumentosView />}

              {activeTab === 'configuracoes' && (
                <SettingsAndTimelineView onOpenPwaGuide={handleOpenInstallPrompt} />
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Global Permanent App Footer - Responsive & Immune to Module Updates */}
      <AppFooter />

      {/* Client Detail Drawer */}
      <ClientDetailDrawer
        isOpen={isClientDrawerOpen}
        onClose={() => setIsClientDrawerOpen(false)}
        tenantId={selectedTenantId}
        tenantType={selectedTenantType}
        onOpenWhatsApp={handleOpenWhatsAppForContract}
      />

      {/* Notifications Modal */}
      <NotificationsModal
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        onNavigateToTab={setActiveTab}
        onOpenWhatsApp={handleOpenWhatsAppForContract}
      />

      {/* WhatsApp Message Generator Modal */}
      <WhatsAppReminderModal
        isOpen={isWhatsAppOpen}
        onClose={() => setIsWhatsAppOpen(false)}
        contractId={whatsAppContractId}
        installmentId={whatsAppInstallmentId}
      />

      {/* Unified Global Search Modal */}
      <GlobalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onNavigate={(tab) => setActiveTab(tab as TabType)}
      />

      {/* Quick Contacts Modal */}
      <QuickContactsModal
        isOpen={isContactsOpen}
        onClose={() => setIsContactsOpen(false)}
      />

      {/* Pre-purchase Financial Simulator Modal */}
      <SimuladorCompraMotoModal
        isOpen={isSimulatorOpen}
        onClose={() => setIsSimulatorOpen(false)}
        onNavigateToMotos={() => setActiveTab('motos')}
      />

      {/* PWA Mobile Installation Guide Modal */}
      <PWAInstallGuideModal
        isOpen={isPwaGuideOpen}
        onClose={() => setIsPwaGuideOpen(false)}
        isInstallable={isInstallable}
        onDirectInstall={async () => {
          const installed = await promptInstall();
          if (installed) {
            setIsPwaGuideOpen(false);
          }
        }}
      />

      {readOnlyToast && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-[200] max-w-md w-[92%] bg-amber-950/95 border border-amber-500/60 text-amber-200 px-4 py-3 rounded-xl shadow-2xl backdrop-blur-md flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 animate-pulse" />
            <span className="text-xs font-semibold leading-tight">{readOnlyToast}</span>
          </div>
          <button
            type="button"
            onClick={() => setReadOnlyToast(null)}
            className="text-amber-300 hover:text-white text-xs font-bold px-2 py-1 bg-amber-500/20 rounded-md cursor-pointer shrink-0"
          >
            Entendido
          </button>
        </div>
      )}
    </div>
  );
}

export function App() {
  return (
    <ErrorBoundary>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </ErrorBoundary>
  );
}

export default App;
