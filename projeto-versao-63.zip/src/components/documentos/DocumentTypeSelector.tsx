import React, { useState, useMemo } from 'react';
import { DOCUMENT_TYPES_LIST } from './documentTypesList';
import { Motorbike, Home, ShieldCheck, Scale, Check, ChevronDown } from 'lucide-react';

interface DocumentTypeSelectorProps {
  docType: string;
  onSelectDocType: (id: string) => void;
}

interface CategoryConfig {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  count: number;
  activeTabStyle: string;
  activeIconStyle: string;
  activeBadgeStyle: string;
  hoverTabStyle: string;
  selectedCardStyle: string;
  selectedIconBoxStyle: string;
  selectedCheckStyle: string;
}

export const DocumentTypeSelector: React.FC<DocumentTypeSelectorProps> = ({
  docType,
  onSelectDocType,
}) => {
  // Infer active category from currently selected docType
  const currentDoc = DOCUMENT_TYPES_LIST.find((d) => d.id === docType);
  const initialCategory = currentDoc
    ? currentDoc.category === 'Financeiro' || currentDoc.category === 'Garantia'
      ? 'Garantia'
      : currentDoc.category === 'Encerramento' || currentDoc.category === 'Jurídico'
      ? 'Jurídico'
      : currentDoc.category
    : 'Motos';

  const [activeCategory, setActiveCategory] = useState<string>(initialCategory);

  const categories: CategoryConfig[] = [
    {
      id: 'Motos',
      label: 'Motos',
      icon: Motorbike,
      count: 3,
      activeTabStyle:
        'bg-category-motos/15 border-category-motos/50 text-category-motos-alt',
      activeIconStyle: 'text-category-motos-alt',
      activeBadgeStyle: 'bg-category-motos/25 text-category-motos-alt border border-category-motos/40',
      hoverTabStyle: 'hover:text-category-motos-alt hover:bg-category-motos/10 hover:border-category-motos/25',
      selectedCardStyle:
        'bg-surface-card border-category-motos',
      selectedIconBoxStyle: 'bg-category-motos text-slate-950 shadow-sm',
      selectedCheckStyle: 'bg-category-motos text-slate-950',
    },
    {
      id: 'Kitnets',
      label: 'Kitnets',
      icon: Home,
      count: 1,
      activeTabStyle:
        'bg-category-kitnets-sky/15 border-category-kitnets-sky/50 text-category-kitnets-cyan',
      activeIconStyle: 'text-category-kitnets-cyan',
      activeBadgeStyle: 'bg-category-kitnets-sky/25 text-category-kitnets-cyan border border-category-kitnets-sky/40',
      hoverTabStyle: 'hover:text-category-kitnets-cyan hover:bg-category-kitnets-sky/10 hover:border-category-kitnets-sky/25',
      selectedCardStyle:
        'bg-surface-subtle border-category-kitnets-sky',
      selectedIconBoxStyle: 'bg-category-kitnets-sky text-slate-950 shadow-sm',
      selectedCheckStyle: 'bg-category-kitnets-sky text-slate-950',
    },
    {
      id: 'Garantia',
      label: 'Recibos & Caução',
      icon: ShieldCheck,
      count: 2,
      activeTabStyle:
        'bg-category-motos-alt/15 border-category-motos-alt/50 text-category-motos-alt',
      activeIconStyle: 'text-category-motos-alt',
      activeBadgeStyle: 'bg-category-motos-alt/25 text-category-motos-alt border border-category-motos-alt/40',
      hoverTabStyle: 'hover:text-category-motos-alt hover:bg-category-motos-alt/10 hover:border-category-motos-alt/25',
      selectedCardStyle:
        'bg-surface-card border-category-motos-alt',
      selectedIconBoxStyle: 'bg-category-motos-alt text-slate-950 shadow-sm',
      selectedCheckStyle: 'bg-category-motos-alt text-slate-950',
    },
    {
      id: 'Jurídico',
      label: 'Jurídico & Distrato',
      icon: Scale,
      count: 2,
      activeTabStyle:
        'bg-action-primary/15 border-action-primary/50 text-action-light',
      activeIconStyle: 'text-action-light',
      activeBadgeStyle: 'bg-action-primary/25 text-action-light border border-action-primary/40',
      hoverTabStyle: 'hover:text-action-light hover:bg-action-primary/10 hover:border-action-primary/25',
      selectedCardStyle:
        'bg-surface-subtle border-action-primary',
      selectedIconBoxStyle: 'bg-action-primary text-white shadow-sm',
      selectedCheckStyle: 'bg-action-primary text-white',
    },
  ];

  const currentCategoryConfig = categories.find((c) => c.id === activeCategory) || categories[0];

  const filteredDocs = useMemo(() => {
    if (activeCategory === 'Garantia') {
      return DOCUMENT_TYPES_LIST.filter(
        (d) => d.category === 'Garantia' || d.category === 'Financeiro'
      );
    }
    if (activeCategory === 'Jurídico') {
      return DOCUMENT_TYPES_LIST.filter(
        (d) => d.category === 'Jurídico' || d.category === 'Encerramento'
      );
    }
    return DOCUMENT_TYPES_LIST.filter((d) => d.category === activeCategory);
  }, [activeCategory]);

  return (
    <div className="space-y-4">
      {/* Category Tabs: Sophisticated Segmented Control with Category-Specific Accents */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1.5 bg-surface-base border border-border-dark rounded-xl shadow-inner">
        {categories.map((cat) => {
          const Icon = cat.icon;
          const isActive = activeCategory === cat.id;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => {
                setActiveCategory(cat.id);
                // If the currently selected doc isn't in this category, select first in category
                const docsInCat =
                  cat.id === 'Garantia'
                    ? DOCUMENT_TYPES_LIST.filter(
                        (d) => d.category === 'Garantia' || d.category === 'Financeiro'
                      )
                    : cat.id === 'Jurídico'
                    ? DOCUMENT_TYPES_LIST.filter(
                        (d) => d.category === 'Jurídico' || d.category === 'Encerramento'
                      )
                    : DOCUMENT_TYPES_LIST.filter((d) => d.category === cat.id);
                if (docsInCat.length > 0 && !docsInCat.some((d) => d.id === docType)) {
                  onSelectDocType(docsInCat[0].id);
                }
              }}
              className={`w-full py-2.5 px-2.5 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 border transition-all duration-150 cursor-pointer select-none active:scale-[0.98] ${
                isActive
                  ? cat.activeTabStyle
                  : `border-transparent text-text-secondary bg-transparent hover:bg-surface-card ${cat.hoverTabStyle}`
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 transition-colors ${isActive ? cat.activeIconStyle : 'text-text-muted'}`} />
              <span className="truncate">{cat.label}</span>
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold shrink-0 transition-colors ${
                  isActive
                    ? cat.activeBadgeStyle
                    : 'bg-white/[0.05] text-text-secondary border border-white/[0.06]'
                }`}
              >
                {cat.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Document Selection Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {filteredDocs.map((item) => {
          const Icon = item.icon;
          const isSelected = docType === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectDocType(item.id)}
              className={`w-full text-left p-3.5 rounded-xl border transition-all duration-150 cursor-pointer relative flex flex-col justify-between gap-2.5 select-none active:scale-[0.99] ${
                isSelected
                  ? currentCategoryConfig.selectedCardStyle
                  : 'bg-surface-card/70 border-border-dark hover:bg-surface-card hover:border-border-dark-hover'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className={`p-2 rounded-lg shrink-0 transition-colors ${
                      isSelected
                        ? currentCategoryConfig.selectedIconBoxStyle
                        : 'bg-surface-base text-text-secondary border border-white/[0.05]'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <span
                      className={`font-bold text-xs tracking-tight block truncate ${
                        isSelected ? 'text-text-primary' : 'text-text-secondary'
                      }`}
                    >
                      {item.title}
                    </span>
                    <span
                      className={`text-[10px] block truncate font-medium ${
                        isSelected ? currentCategoryConfig.activeIconStyle : 'text-text-secondary'
                      }`}
                    >
                      {item.badge}
                    </span>
                  </div>
                </div>

                {isSelected && (
                  <div
                    className={`w-4 h-4 rounded-full flex items-center justify-center shrink-0 shadow-xs ${currentCategoryConfig.selectedCheckStyle}`}
                  >
                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                  </div>
                )}
              </div>

              <p className="text-[11px] text-text-secondary line-clamp-2 leading-relaxed pl-0.5">
                {item.desc}
              </p>
            </button>
          );
        })}
      </div>

      {/* Direct Dropdown for Fast Access on Mobile */}
      <div className="sm:hidden pt-1">
        <div className="flex items-center justify-between text-[11px] text-text-secondary mb-1 px-1">
          <span>Ou escolha direto por menu:</span>
          <span className={`font-semibold truncate max-w-[180px] ${currentCategoryConfig.activeIconStyle}`}>
            {currentDoc?.title}
          </span>
        </div>
        <div className="relative">
          <select
            value={docType}
            onChange={(e) => {
              onSelectDocType(e.target.value);
              const found = DOCUMENT_TYPES_LIST.find((d) => d.id === e.target.value);
              if (found) {
                const cat =
                  found.category === 'Financeiro' || found.category === 'Garantia'
                    ? 'Garantia'
                    : found.category === 'Encerramento' || found.category === 'Jurídico'
                    ? 'Jurídico'
                    : found.category;
                setActiveCategory(cat);
              }
            }}
            className="w-full bg-surface-base border border-border-dark rounded-xl px-3.5 py-2.5 text-xs text-text-primary appearance-none focus:outline-none focus:border-category-motos pr-9"
          >
            {DOCUMENT_TYPES_LIST.map((doc) => (
              <option key={doc.id} value={doc.id}>
                [{doc.category}] {doc.title}
              </option>
            ))}
          </select>
          <ChevronDown className="w-4 h-4 text-text-secondary absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>
      </div>
    </div>
  );
};
