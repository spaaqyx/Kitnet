import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { COLORS } from '../../styles/colors';
import {
  ChevronDown,
  User,
  Calendar,
  AlertTriangle,
  Wrench,
  CheckCircle2,
} from 'lucide-react';
import { Moto, MotoContract, MotoTenant } from '../../types';
import { MotoIcon } from '../CategoryIcons';
import { MotoDetailContent } from '../MotoDetailContent';
import { isInstallmentOverdue } from '../../utils/formatters';
import { monthlyToWeekly } from '../../domain';

interface MotoCardItemProps {
  moto: Moto;
  index: number;
  isSelected: boolean;
  isMobileExpanded?: boolean;
  contract: MotoContract | undefined;
  tenant: MotoTenant | undefined;
  activeSubTab: 'geral' | 'contrato' | 'manutencoes' | 'locatario' | 'km' | 'vistoria' | 'fotos' | 'documentos';
  onToggleSelect: (id: string) => void;
  setActiveSubTab: (tab: 'geral' | 'contrato' | 'manutencoes' | 'locatario' | 'km' | 'vistoria' | 'fotos' | 'documentos') => void;
  handleOpenEditModal: (moto: Moto) => void;
  setShowNewContractModal: (show: boolean) => void;
  onGenerateDocument: (type: any, moto: Moto, contract?: MotoContract, tenant?: MotoTenant) => void;
  onOpenWhatsApp: (contractId: string, installmentId?: string) => void;
  setShowMaintenanceModal: (show: boolean) => void;
  setShowCompareModal: (show: boolean) => void;
  duplicateMoto: (id: string) => void;
  setTerminateMotoForm: (data: { finalKm: number; notes: string }) => void;
  setMotoToTerminate: (data: { contract: MotoContract; moto: Moto }) => void;
  setMotoToDelete: (moto: Moto) => void;
  setShowAdjustmentModal: (show: boolean) => void;
  setShowPaymentModal: (data: { contractId: string; installment: any }) => void;
  deleteMotoMaintenance: (motoId: string, maintId: string) => void;
  setShowNewKmModal: (show: boolean) => void;
  setShowDeliveryModal: (show: boolean) => void;
  setSelectedPhotoPreview: (data: { url: string; title: string }) => void;
  handleTriggerQuickUpload: (angleKey: 'front' | 'rear' | 'right' | 'left' | 'dashboard') => void;
  handleRemovePhotoAngle: (angleKey: 'front' | 'rear' | 'right' | 'left' | 'dashboard') => void;
  onOpenClientProfile?: (tenantId: string, type: 'moto' | 'kitnet') => void;
  formatCurrency: (value: number) => string;
  formatDate: (dateStr: string) => string;
  formatCPF: (cpf: string) => string;
  formatPhone: (phone: string) => string;
  getCNHStatus: (expirationDate: string) => { label: string; badgeClass: string };
  isPlateCorruptedOrInvalid: (plate: string) => boolean;
}

export const MotoCardItem: React.FC<MotoCardItemProps> = React.memo(({
  moto,
  index,
  isSelected,
  isMobileExpanded = false,
  contract,
  tenant,
  activeSubTab,
  onToggleSelect,
  setActiveSubTab,
  handleOpenEditModal,
  setShowNewContractModal,
  onGenerateDocument,
  onOpenWhatsApp,
  setShowMaintenanceModal,
  setShowCompareModal,
  duplicateMoto,
  setTerminateMotoForm,
  setMotoToTerminate,
  setMotoToDelete,
  setShowAdjustmentModal,
  setShowPaymentModal,
  deleteMotoMaintenance,
  setShowNewKmModal,
  setShowDeliveryModal,
  setSelectedPhotoPreview,
  handleTriggerQuickUpload,
  handleRemovePhotoAngle,
  onOpenClientProfile,
  formatCurrency,
  formatDate,
  formatCPF,
  formatPhone,
  getCNHStatus,
  isPlateCorruptedOrInvalid,
}) => {
  // Next due date formatted for active contract - dynamic based on next pending installment
  const nextDueDate = React.useMemo(() => {
    if (!contract || !contract.installments || contract.installments.length === 0) {
      return null;
    }
    // Filter all installments that are not paid
    const pendingInstallments = contract.installments.filter(
      (i) => i.status !== 'pago'
    );

    if (pendingInstallments.length === 0) {
      return 'Quitado';
    }

    // Sort by dueDate ascending, fallback to installment number
    pendingInstallments.sort((a, b) => {
      if (a.dueDate && b.dueDate) {
        return a.dueDate.localeCompare(b.dueDate);
      }
      return a.number - b.number;
    });

    const nextPending = pendingInstallments[0];
    if (nextPending?.dueDate) {
      const parts = nextPending.dueDate.split('T')[0].split('-');
      if (parts.length === 3) {
        return `${parts[2]}/${parts[1]}/${parts[0]}`;
      }
      return formatDate(nextPending.dueDate);
    }

    return null;
  }, [contract, formatDate]);

  // Is expanded (either selected or mobile expanded)
  const isExpanded = isSelected || isMobileExpanded;

  // Exact card border styling according to status
  const borderClass = React.useMemo(() => {
    if (isExpanded) {
      return 'border-action-primary ring-1 ring-action-primary/30';
    }
    if (moto.status === 'alugada') {
      return 'border-money-positive';
    }
    if (moto.status === 'manutencao') {
      return 'border-money-warning-hover';
    }
    return 'border-category-kitnets-cyan';
  }, [moto.status, isExpanded]);

  return (
    <motion.div
      layout="position"
      id={`moto-card-${moto.id}`}
      style={{ animationDelay: `${Math.min(index * 50, 300)}ms` }}
      className={`bg-surface-input rounded-3xl border transition-colors duration-200 overflow-hidden ${borderClass}`}
    >
      {/* Clickable Header / Main Card Info */}
      <div
        onClick={() => onToggleSelect(moto.id)}
        className="p-3.5 sm:p-6 cursor-pointer select-none transition-colors hover:bg-white/[0.02] active:scale-[0.995] transition-transform duration-100"
      >
        <div className="flex items-start gap-3 sm:gap-5">
          {/* Square Photo Thumbnail */}
          <div className="w-20 h-20 sm:w-28 sm:h-28 rounded-2xl overflow-hidden relative shrink-0 border border-white/[0.08] bg-surface-card shadow-md">
            {moto.photos?.front ? (
              <img
                src={moto.photos.front}
                alt={`${moto.brand} ${moto.model}`}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-surface-card">
                <MotoIcon size={28} color={COLORS.action.primary} />
              </div>
            )}
          </div>

          {/* Right Info Section */}
          <div className="flex-1 min-w-0">
            {/* Row 1: Title & Status Badge */}
            <div className="flex items-center justify-between gap-2 sm:gap-3 flex-wrap">
              <h3 className="text-sm sm:text-lg font-bold text-white tracking-tight truncate">
                {moto.brand} {moto.model} {moto.year}
              </h3>

              {/* Status Badge */}
              {moto.status === 'alugada' && (
                <span className="bg-money-positive-dark text-money-positive border border-money-positive/50 text-[10px] sm:text-xs font-bold px-2.5 sm:px-3 py-0.5 sm:py-1 rounded-lg uppercase tracking-wider shrink-0">
                  ALUGADA
                </span>
              )}
              {moto.status === 'manutencao' && (
                <span className="bg-surface-subtle text-money-warning-light border border-category-motos-alt/50 text-[10px] sm:text-xs font-bold px-2.5 sm:px-3 py-0.5 sm:py-1 rounded-lg uppercase tracking-wider shrink-0">
                  MANUTENÇÃO
                </span>
              )}
              {moto.status === 'disponivel' && (
                <span className="bg-category-kitnets-cyan text-category-kitnets-cyan border border-category-kitnets-sky/50 text-[10px] sm:text-xs font-bold px-2.5 sm:px-3 py-0.5 sm:py-1 rounded-lg uppercase tracking-wider shrink-0">
                  DISPONÍVEL
                </span>
              )}
              {moto.status === 'encerrada' && (
                <span className="bg-surface-card text-text-secondary border border-white/10 text-[10px] sm:text-xs font-bold px-2.5 sm:px-3 py-0.5 sm:py-1 rounded-lg uppercase tracking-wider shrink-0">
                  ENCERRADA
                </span>
              )}
            </div>

            {/* Row 2: Plate & KM */}
            <div className="flex items-center gap-2 mt-1.5 sm:mt-2 text-xs text-text-secondary flex-wrap">
              <span
                className={`font-mono font-bold px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-lg text-xs inline-flex items-center gap-1 shrink-0 ${
                  Boolean(moto.plate && isPlateCorruptedOrInvalid(moto.plate))
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    : 'bg-surface-subtle border border-white/10 text-white'
                }`}
              >
                {moto.plate?.trim() ? moto.plate : 'Sem placa'}
                {Boolean(moto.plate && isPlateCorruptedOrInvalid(moto.plate)) && (
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                )}
              </span>
              <span className="text-text-muted">•</span>
              <span className="text-text-secondary font-medium">
                {moto.currentKm.toLocaleString('pt-BR')} KM
              </span>
            </div>

            {/* Row 3: Tenant Name or Maintenance/Availability Note */}
            <div className="mt-2 sm:mt-2.5">
              {moto.status === 'alugada' ? (
                <div className="flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm text-white font-medium truncate">
                  <User className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-400 shrink-0" />
                  <span className="truncate">
                    {tenant?.fullName || (moto.statusNote?.startsWith('Locatário:') ? moto.statusNote.replace('Locatário:', '').trim() : '') || 'Locatário(a) Ativo(a)'}
                  </span>
                </div>
              ) : moto.status === 'manutencao' ? (
                <div className="flex items-center gap-1.5 sm:gap-2 text-xs text-category-motos-alt font-medium">
                  <Wrench className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-category-motos-alt shrink-0" />
                  <span className="truncate">{moto.statusNote || moto.notes || 'Em oficina para revisão preventiva'}</span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 sm:gap-2 text-xs text-category-kitnets-cyan font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-category-kitnets-cyan shrink-0" />
                  <span className="truncate">{moto.statusNote || moto.notes || 'Revisada e pronta para locação'}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Values & Due Date Container matching Kitnets design */}
        <div className="mt-3 sm:mt-4 pt-2.5 sm:pt-3 border-t border-white/[0.08] flex items-center justify-between gap-2 sm:gap-3 flex-wrap sm:flex-nowrap">
          {/* Left: Valor de Locação ou Compra */}
          <div className="min-w-0">
            {contract ? (
              <>
                <div className="text-[11px] sm:text-xs text-text-secondary font-medium">
                  {contract.paymentFrequency === 'semanal' ? 'Aluguel Semanal' : 'Aluguel Mensal'}
                </div>
                <div className="text-sm sm:text-lg font-bold text-money-positive mt-0.5">
                  {contract.paymentFrequency === 'semanal'
                    ? formatCurrency(contract.weeklyValue || (contract.monthlyValue ? monthlyToWeekly(contract.monthlyValue) : (contract.installments?.[0]?.amount || 0)))
                    : formatCurrency(contract.monthlyValue || 0)}
                  <span className="text-[11px] sm:text-sm font-semibold text-money-positive">
                    {contract.paymentFrequency === 'semanal' ? '/sem' : '/mês'}
                  </span>
                </div>
              </>
            ) : (
              <>
                <div className="text-[11px] sm:text-xs text-text-secondary font-medium">Valor de Compra</div>
                <div className="text-sm sm:text-lg font-bold text-white mt-0.5">
                  {formatCurrency(moto.purchasePrice)}
                </div>
              </>
            )}
          </div>

          {/* Middle: Vencimento */}
          {moto.status === 'alugada' && nextDueDate ? (
            <div className="pl-3 sm:pl-4 border-l border-white/[0.08] min-w-0">
              <div className="text-[11px] sm:text-xs text-text-secondary font-medium">Vencimento</div>
              <div className="text-xs sm:text-sm font-semibold text-white flex items-center gap-1.5 sm:gap-2 mt-0.5 whitespace-nowrap">
                <Calendar className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white shrink-0" />
                <span className="truncate">{nextDueDate}</span>
              </div>
            </div>
          ) : (
            <div />
          )}

          {/* Right: Circular Chevron Button */}
          <button
            id={`btn-toggle-moto-${moto.id}`}
            type="button"
            aria-label={isExpanded ? 'Recolher detalhes da moto' : 'Expandir detalhes da moto'}
            aria-expanded={isExpanded}
            onClick={(e) => {
              e.stopPropagation();
              onToggleSelect(moto.id);
            }}
            className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-surface-subtle hover:bg-surface-card border border-white/10 text-white flex items-center justify-center transition-colors duration-150 cursor-pointer active:scale-95 group shrink-0 shadow-md ml-auto focus:outline-none focus:ring-2 focus:ring-action-primary/50"
          >
            <ChevronDown
              className={`w-4 h-4 sm:w-5 sm:h-5 text-white transition-transform duration-300 ${
                isExpanded ? 'rotate-180' : 'group-hover:translate-y-0.5'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Expanded Accordion Body */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.28, ease: 'easeInOut' }}
            className="border-t border-white/[0.08] bg-surface-base overflow-hidden"
          >
            <div className="p-4 sm:p-6 space-y-4">
              <MotoDetailContent
                moto={moto}
                activeContract={contract}
                tenant={tenant}
                activeSubTab={activeSubTab}
                setActiveSubTab={setActiveSubTab}
                handleOpenEditModal={handleOpenEditModal}
                setShowNewContractModal={setShowNewContractModal}
                onGenerateDocument={onGenerateDocument}
                onOpenWhatsApp={onOpenWhatsApp}
                setShowMaintenanceModal={setShowMaintenanceModal}
                setShowCompareModal={setShowCompareModal}
                duplicateMoto={duplicateMoto}
                setTerminateMotoForm={setTerminateMotoForm}
                setMotoToTerminate={setMotoToTerminate}
                setMotoToDelete={setMotoToDelete}
                setShowAdjustmentModal={setShowAdjustmentModal}
                setShowPaymentModal={setShowPaymentModal}
                deleteMotoMaintenance={deleteMotoMaintenance}
                setShowNewKmModal={setShowNewKmModal}
                setShowDeliveryModal={setShowDeliveryModal}
                setSelectedPhotoPreview={setSelectedPhotoPreview}
                handleTriggerQuickUpload={handleTriggerQuickUpload}
                handleRemovePhotoAngle={handleRemovePhotoAngle}
                onOpenClientProfile={onOpenClientProfile}
                formatCurrency={formatCurrency}
                formatDate={formatDate}
                formatCPF={formatCPF}
                formatPhone={formatPhone}
                getCNHStatus={getCNHStatus}
                isPlateCorruptedOrInvalid={isPlateCorruptedOrInvalid}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
});

MotoCardItem.displayName = 'MotoCardItem';
