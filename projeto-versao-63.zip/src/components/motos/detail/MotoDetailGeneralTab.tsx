import React from 'react';
import { Moto, MotoTenant } from '../../../types';
import { Edit } from 'lucide-react';
import { StandardizedPhotoGallery, PhotoGalleryItem } from '../../common/StandardizedPhotoGallery';

interface MotoDetailGeneralTabProps {
  moto: Moto;
  tenant?: MotoTenant;
  formatCurrency: (value: number) => string;
  formatCPF: (cpf: string) => string;
  setActiveSubTab: (tab: any) => void;
  setSelectedPhotoPreview: (data: { url: string; title: string }) => void;
  handleTriggerQuickUpload: (angle: 'front' | 'rear' | 'right' | 'left' | 'dashboard') => void;
  handleRemovePhotoAngle: (angle: 'front' | 'rear' | 'right' | 'left' | 'dashboard') => void;
}

export const MotoDetailGeneralTab: React.FC<MotoDetailGeneralTabProps> = ({
  moto,
  tenant,
  formatCurrency,
  formatCPF,
  setActiveSubTab,
  setSelectedPhotoPreview,
  handleTriggerQuickUpload,
  handleRemovePhotoAngle,
}) => {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        <div className="p-3 bg-surface-base rounded-xl border border-white/[0.08]">
          <span className="text-text-secondary block text-[11px]">Placa / UF:</span>
          <strong className="text-sm font-mono text-text-primary tracking-wider block mt-0.5">
            {moto.plate?.trim() ? moto.plate : 'Não informada'}
          </strong>
        </div>
        <div className="p-3 bg-surface-base rounded-xl border border-white/[0.08]">
          <span className="text-text-secondary block text-[11px]">Renavam:</span>
          <strong className="text-xs font-mono text-text-primary block mt-0.5">
            {moto.renavam?.trim() ? moto.renavam : 'Não informado'}
          </strong>
        </div>
        <div className="p-3 bg-surface-base rounded-xl border border-white/[0.08]">
          <span className="text-text-secondary block text-[11px]">Chassi:</span>
          <strong className="text-[11px] font-mono text-text-primary truncate block mt-0.5" title={moto.chassi || ''}>
            {moto.chassi?.trim() ? moto.chassi : 'Não informado'}
          </strong>
        </div>
        <div className="p-3 bg-surface-base rounded-xl border border-white/[0.08]">
          <span className="text-text-secondary block text-[11px]">Valor de Compra:</span>
          <strong className="text-xs text-money-positive block mt-0.5">
            {moto.purchasePrice && Number(moto.purchasePrice) > 0 ? formatCurrency(moto.purchasePrice) : 'Não informado'}
          </strong>
        </div>
      </div>

      {/* Quick Client Summary if Rented */}
      {tenant && (
        <div className="p-3.5 bg-surface-card rounded-xl border border-category-motos/20 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="relative w-11 h-11 rounded-xl overflow-hidden bg-surface-base border border-white/[0.08] flex items-center justify-center shrink-0">
              {tenant.photoUrl || tenant.documents?.photo ? (
                <img
                  src={tenant.photoUrl || tenant.documents?.photo}
                  alt={tenant.fullName}
                  className="w-full h-full object-cover"
                />
              ) : (
                <span className="text-category-motos font-bold text-base">{tenant.fullName.charAt(0)}</span>
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-category-motos">
                  Locatário Atual
                </span>
                <span className="text-[10px] text-text-secondary">CPF: {formatCPF(tenant.cpf)}</span>
              </div>
              <h4 className="text-sm font-bold text-text-primary">{tenant.fullName}</h4>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setActiveSubTab('locatario')}
            className="px-3 py-1.5 bg-surface-base hover:bg-surface-elevated text-category-motos border border-category-motos/30 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
          >
            Ver Locatário
          </button>
        </div>
      )}

      {/* Photo Gallery Grid */}
      <StandardizedPhotoGallery
        title="Fotos Oficiais do Veículo"
        subtitle="Fotos registradas dos 5 ângulos da motocicleta. Toque para ampliar, atualizar ou remover."
        items={[
          { key: 'front', label: 'Frente', url: moto.photos?.front },
          { key: 'rear', label: 'Traseira', url: moto.photos?.rear },
          { key: 'right', label: 'Lat. Direita', url: moto.photos?.right },
          { key: 'left', label: 'Lat. Esquerda', url: moto.photos?.left },
          { key: 'dashboard', label: 'Painel / KM', url: moto.photos?.dashboard },
        ]}
        columnsCount={5}
        badgeThemeColor="amber"
        onPreview={(url, label) =>
          setSelectedPhotoPreview({
            url,
            title: `Foto ${label} - ${moto.model} (${moto.plate})`,
          })
        }
        onUpload={(key) => handleTriggerQuickUpload(key as any)}
        onDelete={(key) => handleRemovePhotoAngle(key as any)}
      />
    </div>
  );
};
