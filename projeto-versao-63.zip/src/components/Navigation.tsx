import React, { useState, useEffect, useMemo, memo } from 'react';
import {
  LayoutDashboard,
  LayoutGrid,
  Wallet,
  FileText,
  Settings,
  Lock,
  Bell,
  BadgeAlert,
  Layers,
  Users,
  Calendar,
  FileSpreadsheet,
  Bot,
  Search,
  Phone,
  ShieldAlert,
  MoreHorizontal,
  User,
  Eye,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useApp } from '../context/AppContext';
import { getCNHStatus, getDaysUntil, isInstallmentOverdue } from '../utils/formatters';
import { Logo } from './Logo';
import { MotoIcon, KitnetIcon } from './CategoryIcons';
import { MoreMenuDrawer } from './MoreMenuDrawer';
import { useRenderTracker } from '../utils/perfLogger';
import { COLORS } from '../styles/colors';

export type TabType =
  | 'dashboard'
  | 'cobrancas'
  | 'motos'
  | 'kitnets'
  | 'clientes'
  | 'calendario'
  | 'financeiro'
  | 'relatorios'
  | 'documentos'
  | 'configuracoes';

interface NavigationProps {
  activeTab?: TabType;
  currentTab?: TabType;
  onTabChange?: (tab: TabType) => void;
  onSelectTab?: (tab: TabType) => void;
  onOpenSettings?: () => void;
  onOpenNotifications: () => void;
  onOpenSearch?: () => void;
  onOpenContacts?: () => void;
  onOpenSimulator?: () => void;
  onOpenPwaGuide?: () => void;
}

export const NavigationComponent: React.FC<NavigationProps> = ({
  activeTab,
  currentTab,
  onTabChange,
  onSelectTab,
  onOpenSettings,
  onOpenNotifications,
  onOpenSearch,
  onOpenContacts,
  onOpenSimulator,
  onOpenPwaGuide,
}) => {
  useRenderTracker('Navigation');
  const current = activeTab || currentTab || 'dashboard';
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);

  // Dynamic Scroll Overlay & Header Glow
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    let ticking = false;

    const updateScroll = () => {
      const scrollY =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop ||
        window.scrollY ||
        (document.getElementById('root')?.scrollTop || 0);
      const nextScrolled = scrollY > 10;
      setIsScrolled((prev) => (prev !== nextScrolled ? nextScrolled : prev));
      ticking = false;
    };

    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(updateScroll);
        ticking = true;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true, capture: true });
    document.addEventListener('scroll', handleScroll, { passive: true, capture: true });
    updateScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll, true);
      document.removeEventListener('scroll', handleScroll, true);
    };
  }, []);

  const handleSelect = (tab: TabType) => {
    if (isReadOnlyMode && tab !== 'dashboard') {
      return;
    }
    if (onTabChange) onTabChange(tab);
    else if (onSelectTab) onSelectTab(tab);
  };
  const handleSettings = () => {
    if (isReadOnlyMode) return;
    if (onOpenSettings) onOpenSettings();
    else handleSelect('configuracoes');
  };

  const handleLogoClick = () => {
    handleSelect('dashboard');
  };

  const {
    lockApp,
    motos,
    kitnets,
    motoTenants,
    motoContracts,
    kitnetContracts,
    expenses,
    isReadOnlyMode,
    toggleReadOnlyMode,
    isDemoMode,
    toggleDemoMode,
  } = useApp();

  // Automatically close more menu drawer if read-only mode becomes active
  useEffect(() => {
    if (isReadOnlyMode && isMoreMenuOpen) {
      setIsMoreMenuOpen(false);
    }
  }, [isReadOnlyMode, isMoreMenuOpen]);

  // Overdue and active alerts count for badge (memoized)
  const { overdueCount, alertCount } = useMemo(() => {
    let overdue = 0;
    let upcomingRentals = 0;

    motoContracts.forEach((c) => {
      c.installments.forEach((i) => {
        if (i.status === 'pago') return;
        if (isInstallmentOverdue(i)) {
          overdue++;
        } else {
          const days = getDaysUntil(i.dueDate);
          if (days <= 3) upcomingRentals++;
        }
      });
    });

    kitnetContracts.forEach((c) => {
      c.installments.forEach((i) => {
        if (i.status === 'pago') return;
        if (isInstallmentOverdue(i)) {
          overdue++;
        } else {
          const days = getDaysUntil(i.dueDate);
          if (days <= 3) upcomingRentals++;
        }
      });
    });

    let alerts = overdue + upcomingRentals;
    const activeMotoTenantIds = new Set(
      motoContracts.filter((c) => c.status === 'ativo').map((c) => c.tenantId)
    );

    motoTenants.forEach((t) => {
      if (activeMotoTenantIds.has(t.id) && t.cnh?.expirationDate) {
        const cnh = getCNHStatus(t.cnh.expirationDate);
        if (cnh.status === 'vencendo' || cnh.status === 'vencida') alerts++;
      }
    });

    motos.forEach((m) => {
      if (m.ipvaDueDate) {
        const days = getDaysUntil(m.ipvaDueDate);
        if (days >= 0 && days <= 15) alerts++;
      }
    });

    expenses.forEach((e) => {
      if (e.status === 'pendente') {
        const days = getDaysUntil(e.dueDate);
        if (days <= 3) alerts++;
      }
    });

    return { overdueCount: overdue, alertCount: alerts };
  }, [motoContracts, kitnetContracts, motoTenants, motos, expenses]);

  // Centralized theme colors for tabs and indicators
  const TAB_THEMES: Record<string, {
    activeText: string;
    activeGlow: string;
    activeBg: string;
    activeBorder: string;
    activeColor: string;
  }> = {
    dashboard: {
      activeText: 'text-action-primary',
      activeGlow: 'bg-action-primary',
      activeBg: 'bg-action-primary/15',
      activeBorder: 'border-action-primary/30',
      activeColor: COLORS.action.primary,
    },
    motos: {
      activeText: 'text-category-motos',
      activeGlow: 'bg-category-motos',
      activeBg: 'bg-category-motos/15',
      activeBorder: 'border-category-motos/30',
      activeColor: COLORS.category.motos,
    },
    kitnets: {
      activeText: 'text-category-kitnets-sky',
      activeGlow: 'bg-category-kitnets-sky',
      activeBg: 'bg-category-kitnets-sky/15',
      activeBorder: 'border-category-kitnets-sky/30',
      activeColor: COLORS.category.kitnetsSky,
    },
    financeiro: {
      activeText: 'text-money-positive',
      activeGlow: 'bg-money-positive',
      activeBg: 'bg-money-positive/15',
      activeBorder: 'border-money-positive/30',
      activeColor: COLORS.money.positive,
    },
    cobrancas: {
      activeText: 'text-money-negative',
      activeGlow: 'bg-money-negative',
      activeBg: 'bg-money-negative/15',
      activeBorder: 'border-money-negative/30',
      activeColor: COLORS.money.negative,
    },
    clientes: {
      activeText: 'text-action-primary',
      activeGlow: 'bg-action-primary',
      activeBg: 'bg-action-primary/15',
      activeBorder: 'border-action-primary/30',
      activeColor: COLORS.action.primary,
    },
    calendario: {
      activeText: 'text-category-motos-alt',
      activeGlow: 'bg-category-motos-alt',
      activeBg: 'bg-category-motos-alt/15',
      activeBorder: 'border-category-motos-alt/30',
      activeColor: COLORS.money.warning,
    },
    relatorios: {
      activeText: 'text-money-positive',
      activeGlow: 'bg-money-positive',
      activeBg: 'bg-money-positive/15',
      activeBorder: 'border-money-positive/30',
      activeColor: COLORS.money.positive,
    },
    ia: {
      activeText: 'text-action-light',
      activeGlow: 'bg-action-primary',
      activeBg: 'bg-action-primary/15',
      activeBorder: 'border-action-primary/30',
      activeColor: COLORS.action.primary,
    },
    documentos: {
      activeText: 'text-category-kitnets-cyan',
      activeGlow: 'bg-category-kitnets-cyan',
      activeBg: 'bg-category-kitnets-cyan/15',
      activeBorder: 'border-category-kitnets-cyan/30',
      activeColor: COLORS.category.kitnetsCyan,
    },
    configuracoes: {
      activeText: 'text-text-primary',
      activeGlow: 'bg-white',
      activeBg: 'bg-white/10',
      activeBorder: 'border-white/20',
      activeColor: COLORS.text.white,
    },
    mais: {
      activeText: 'text-action-primary',
      activeGlow: 'bg-action-primary',
      activeBg: 'bg-action-primary/15',
      activeBorder: 'border-action-primary/30',
      activeColor: COLORS.action.primary,
    },
  };

  // Desktop Navigation Items
  const desktopNavItems: Array<{
    id: TabType;
    label: string;
    icon: React.ComponentType<{ className?: string; size?: number; color?: string }>;
    badge?: number;
    badgeColor?: string;
  }> = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    {
      id: 'cobrancas',
      label: 'Cobranças',
      icon: BadgeAlert,
      badge: overdueCount > 0 ? overdueCount : undefined,
      badgeColor: 'bg-money-negative text-white',
    },
    {
      id: 'motos',
      label: 'Motos',
      icon: (props) => <MotoIcon {...props} size={15} color={COLORS.category.motos} />,
      badge: motos.length,
      badgeColor: 'bg-category-motos/20 text-category-motos border border-category-motos/30',
    },
    {
      id: 'kitnets',
      label: 'Kitnets',
      icon: (props) => <KitnetIcon {...props} size={15} color={COLORS.category.kitnetsSky} />,
      badge: kitnets.length,
      badgeColor: 'bg-category-kitnets-sky/20 text-category-kitnets-sky border border-category-kitnets-sky/30',
    },
    { id: 'clientes', label: 'Clientes & Score', icon: Users },
    { id: 'calendario', label: 'Calendário', icon: Calendar },
    { id: 'financeiro', label: 'Financeiro', icon: Wallet },
    { id: 'relatorios', label: 'Relatórios', icon: FileSpreadsheet },
    { id: 'documentos', label: 'Documentos', icon: FileText },
  ];

  // Mobile bottom items matching exact 5 tabs from screenshot
  const mobileBottomItems = [
    { id: 'dashboard' as TabType, label: 'Dashboard', icon: LayoutGrid },
    {
      id: 'motos' as TabType,
      label: 'Motos',
      icon: (props: any) => <MotoIcon {...props} size={20} color={COLORS.category.motos} />,
      badge: motos.filter((m) => m.status === 'alugada').length,
    },
    {
      id: 'kitnets' as TabType,
      label: 'Kitnets',
      icon: (props: any) => <KitnetIcon {...props} size={20} color={COLORS.category.kitnetsSky} />,
      badge: kitnets.filter((k) => k.status === 'alugada').length,
    },
    { id: 'financeiro' as TabType, label: 'Financeiro', icon: Wallet },
    { id: 'mais' as any, label: 'Mais', icon: MoreHorizontal },
  ];

  return (
    <>
      {/* Top Navbar: Permanently fixed at top-0 with floating card and safe-area support */}
      <header className="fixed top-0 left-0 right-0 z-40 w-full px-2 sm:px-4 lg:px-6 pt-safe-header pb-2 sm:py-2.5 pointer-events-none">
        {/* Elegant Clean Card Container wrapping around the header */}
        <div
          className={`relative max-w-7xl mx-auto rounded-2xl pointer-events-auto transition-all duration-300 ease-in-out ${
            isScrolled
              ? 'header-box-scrolled'
              : 'header-box'
          }`}
        >
          <div className="relative z-20 px-3.5 sm:px-6 lg:px-7 flex items-center justify-between gap-2 sm:gap-4 h-15 sm:h-16">
            {/* Main Logo & Brand */}
            <div
              className="cursor-pointer shrink-0 transition-transform active:scale-95 flex items-center gap-2.5 group relative"
              onClick={handleLogoClick}
              title="Ir para o Dashboard"
            >
              <Logo
                variant="main"
                size="md"
                showSubtitle={true}
                animated={true}
              />
            </div>

            {/* Desktop Nav Links - Hidden completely during Read-Only Mode */}
            {!isReadOnlyMode && (
              <nav className="hidden xl:flex items-center gap-1 overflow-x-auto py-1">
                {desktopNavItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = current === item.id;
                  const theme = TAB_THEMES[item.id] || TAB_THEMES.dashboard;

                  const activeClass = `${theme.activeBg} ${theme.activeText} border ${theme.activeBorder} shadow-xs`;
                  const iconActiveClass = theme.activeText;

                  return (
                    <button
                      type="button"
                      key={item.id}
                      id={`nav-link-${item.id}`}
                      onClick={() => handleSelect(item.id)}
                      className={`relative px-3 py-1.5 rounded-xl text-xs font-semibold transition-all duration-150 flex items-center gap-1.5 whitespace-nowrap cursor-pointer active:scale-95 ${
                        isActive
                          ? activeClass
                          : 'text-text-secondary hover:text-text-primary hover:bg-white/[0.05]'
                      }`}
                    >
                      <Icon
                        className={`w-3.5 h-3.5 ${isActive ? iconActiveClass : ''}`}
                        color={
                          item.id === 'motos'
                            ? COLORS.category.motos
                            : item.id === 'kitnets'
                            ? COLORS.category.kitnetsSky
                            : isActive
                            ? theme.activeColor
                            : undefined
                        }
                      />
                      <span className="shrink-0">{item.label}</span>
                      {item.badge !== undefined && (
                        <span
                          className={`min-w-[16px] h-4 px-1 rounded-full text-[9px] font-bold inline-flex items-center justify-center shrink-0 leading-none ${
                            item.badgeColor || 'bg-white/10 text-text-secondary'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </nav>
            )}

            {/* Right Action Buttons */}
            <div className="flex items-center gap-1 sm:gap-2 shrink-0">
              {isReadOnlyMode ? (
                /* Perfectly framed, sleek header toggle button - inside the card box */
                <button
                  type="button"
                  id="header-btn-readonly-toggle"
                  onClick={() => toggleReadOnlyMode()}
                  className="h-8.5 sm:h-9 px-2 sm:px-3 rounded-xl bg-violet-600/90 hover:bg-violet-600 border border-violet-400/30 text-white font-semibold text-xs flex items-center gap-1.5 sm:gap-2 shadow-sm shadow-violet-600/20 transition-all cursor-pointer active:scale-95 shrink-0 select-none touch-manipulation"
                  title="Clique para desligar o Modo Leitura"
                  aria-label="Desligar Modo Leitura"
                >
                  <Eye className="w-3.5 h-3.5 text-violet-200 shrink-0 animate-pulse" />
                  <span className="text-xs font-bold whitespace-nowrap">Modo Leitura</span>
                  <span className="text-[10px] bg-violet-950/70 border border-violet-400/30 text-violet-200 px-1.5 py-0.5 rounded font-bold uppercase tracking-wider">
                    Desligar
                  </span>
                </button>
              ) : (
                <>
                  {/* Dedicated Modo Leitura Toggle Button */}
                  <button
                    type="button"
                    id="header-btn-readonly-toggle"
                    onClick={() => toggleReadOnlyMode()}
                    className="h-9 sm:h-10 min-h-[36px] sm:min-h-[40px] px-2 sm:px-3 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] border border-white/[0.08] text-slate-300 hover:text-white font-medium text-xs flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-xs touch-manipulation"
                    title="Ligar Modo Leitura"
                    aria-label="Ligar Modo Leitura"
                  >
                    <Eye className="w-3.5 sm:w-4 h-3.5 sm:h-4 text-violet-400 shrink-0" />
                    <span className="hidden sm:inline text-xs whitespace-nowrap">Modo Leitura</span>
                  </button>

                  {/* Search circular button */}
                  {onOpenSearch && (
                    <button
                      type="button"
                      id="header-btn-search"
                      onClick={onOpenSearch}
                      className="w-9 h-9 sm:w-10 sm:h-10 min-w-[36px] min-h-[36px] sm:min-w-[40px] sm:min-h-[40px] rounded-xl bg-surface-card hover:bg-surface-elevated border border-white/[0.08] text-text-primary flex items-center justify-center transition-colors cursor-pointer active:scale-95 shadow-xs touch-manipulation"
                      title="Busca Unificada (Ctrl+K)"
                      aria-label="Buscar"
                    >
                      <Search className="w-3.5 sm:w-4 h-3.5 sm:h-4 text-text-primary" />
                    </button>
                  )}

                  {/* Notifications circular button with badge */}
                  <button
                    type="button"
                    id="header-btn-notifications"
                    onClick={onOpenNotifications}
                    className="w-9 h-9 sm:w-10 sm:h-10 min-w-[36px] min-h-[36px] sm:min-w-[40px] sm:min-h-[40px] relative rounded-xl bg-surface-card hover:bg-surface-elevated border border-white/[0.08] text-text-primary flex items-center justify-center transition-all cursor-pointer active:scale-95 shadow-xs touch-manipulation"
                    title="Alertas e Notificações"
                    aria-label="Alertas e Notificações"
                  >
                    <Bell className="w-3.5 sm:w-4 h-3.5 sm:h-4 text-text-primary" />
                    {alertCount > 0 && (
                      <span className="absolute -top-1 -right-1 min-w-4 h-4 px-1 rounded-full bg-money-negative text-white text-[10px] font-bold flex items-center justify-center ring-2 ring-surface-base shadow-sm animate-pulse">
                        {alertCount}
                      </span>
                    )}
                  </button>

                  {/* User Profile / Settings circular button */}
                  <button
                    type="button"
                    id="header-btn-user"
                    onClick={handleSettings}
                    className="w-9 h-9 sm:w-10 sm:h-10 min-w-[36px] min-h-[36px] sm:min-w-[40px] sm:min-h-[40px] rounded-xl bg-surface-card hover:bg-surface-elevated border border-white/[0.08] text-text-primary flex items-center justify-center transition-all cursor-pointer active:scale-95 shadow-xs touch-manipulation"
                    title="Perfil & Configurações"
                    aria-label="Perfil & Configurações"
                  >
                    <User className="w-3.5 sm:w-4 h-3.5 sm:h-4 text-text-primary" />
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Structural layout spacer ensuring page content starts cleanly below the fixed header */}
      <div
        className="w-full shrink-0 pointer-events-none spacer-safe-header"
        aria-hidden="true"
      />

      {/* Mobile Sticky Bottom Tab Bar - Hidden entirely in Read-Only Mode to eliminate clutter */}
      {isReadOnlyMode ? null : (
        <nav
          aria-label="Menu Principal"
          className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-surface-base/95 border-t border-white/[0.08] backdrop-blur-md px-1.5 sm:px-3 pt-1.5 pb-safe shadow-2xl"
        >
          <div className="flex items-center justify-between max-w-md mx-auto w-full gap-0.5">
            {mobileBottomItems.map((item) => {
              const Icon = item.icon;
              const isMais = item.id === 'mais';
              const isTabActive = !isMais && current === item.id;
              const theme = TAB_THEMES[item.id] || TAB_THEMES.dashboard;

              return (
                <button
                  type="button"
                  key={item.id}
                  id={`mobile-tab-${item.id}`}
                  aria-label={item.label}
                  onClick={() => {
                    if (isMais) {
                      setIsMoreMenuOpen(true);
                    } else {
                      handleSelect(item.id);
                    }
                  }}
                  className={`relative flex-1 min-w-0 flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all duration-200 ease-out cursor-pointer min-h-[48px] touch-manipulation active:scale-[0.96] ${
                    isTabActive
                      ? theme.activeText
                      : 'text-text-secondary hover:text-text-primary'
                  }`}
                >
                  {/* Active Indicator Top Glow Line with dynamic themed color */}
                  {isTabActive && (
                    <motion.div
                      layoutId="mobileTopIndicator"
                      className={`absolute -top-1.5 w-8 h-0.5 rounded-full ${theme.activeGlow}`}
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}

                  <div className="relative flex items-center justify-center">
                    <Icon
                      className={`w-5 h-5 transition-transform duration-200 ease-out ${
                        isTabActive ? `${theme.activeText} scale-[1.08]` : 'text-text-secondary'
                      }`}
                      color={
                        item.id === 'motos'
                          ? COLORS.category.motos
                          : item.id === 'kitnets'
                          ? COLORS.category.kitnetsSky
                          : isTabActive
                          ? theme.activeColor
                          : undefined
                      }
                    />
                    {item.badge !== undefined && item.badge > 0 && (
                      <span
                        className={`absolute -top-1 -right-1.5 w-2 h-2 rounded-full ring-2 ring-surface-base ${
                          item.id === 'motos'
                            ? 'bg-category-motos'
                            : item.id === 'kitnets'
                            ? 'bg-category-kitnets-sky'
                            : 'bg-money-negative'
                        }`}
                      />
                    )}
                  </div>
                  <span
                    className={`text-[11px] mt-1 tracking-tight transition-colors duration-200 ease-out ${
                      isTabActive ? `${theme.activeText} font-bold` : 'text-text-secondary font-medium'
                    }`}
                  >
                    {item.label}
                  </span>
                </button>
              );
            })}
          </div>
        </nav>
      )}

      {/* Drawer Menu for "Mais" */}
      <MoreMenuDrawer
        isOpen={isMoreMenuOpen}
        onClose={() => setIsMoreMenuOpen(false)}
        onSelectTab={handleSelect}
        onOpenSimulator={() => {
          if (onOpenSimulator) onOpenSimulator();
        }}
        onOpenContacts={() => {
          if (onOpenContacts) onOpenContacts();
        }}
        onOpenPwaGuide={() => {
          if (onOpenPwaGuide) onOpenPwaGuide();
        }}
        overdueCount={overdueCount}
      />
    </>
  );
};

export const Navigation = memo(NavigationComponent);


