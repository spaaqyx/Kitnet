import React, { useState, useEffect, useRef } from 'react';
import { useBodyScrollLock } from '../../../hooks/useBodyScrollLock';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import {
  Home,
  X,
  User,
  FileSpreadsheet,
  Check,
  Camera,
  Trash2,
  DollarSign,
  Key,
  Wrench,
  Sparkles,
  MapPin,
  Calendar,
  Phone,
  Mail,
  Shield,
  Briefcase,
  AlertCircle,
} from 'lucide-react';
import { Kitnet, KitnetContract, KitnetTenant, KitnetStatus } from '../../../types';
import { formatCurrency, maskCPFInput, maskPhoneInput, maskCEPInput } from '../../../utils/formatters';
import { CurrencyInput } from '../../NumericInput';
import { ImageUploadInput } from '../../ImageUploadInput';

export interface EditKitnetModalProps {
  isOpen?: boolean;
  kitnetToEdit: Kitnet | null;
  kitnetContracts: KitnetContract[];
  kitnetTenants: KitnetTenant[];
  onClose: () => void;
  onSave: (
    kitnetId: string,
    updatedKitnetData: any,
    tenantUpdates?: any,
    contractUpdates?: any
  ) => void;
}

const KITNET_STATUS_PRESETS = {
  disponivel: [
    'Pronta para locação imediata',
    'Mobiliada e pronta para morar',
    'Chaves disponíveis para visitação',
    'Excelente ventilação e iluminação',
    'Recém-pintada e higienizada',
  ],
  reforma: [
    'Previsão de entrega: 15 dias',
    'Pintura geral e reparos hidráulicos',
    'Instalação de mobília planejada',
    'Reforma elétrica e acabamentos',
    'Troca de pisos e revestimentos',
  ],
  alugada: [
    'Contrato ativo de locação',
    'Locação residencial em dia',
    'Inquilino residente',
  ],
};

export const EditKitnetModal: React.FC<EditKitnetModalProps> = ({
  isOpen: propIsOpen,
  kitnetToEdit,
  kitnetContracts,
  kitnetTenants,
  onClose,
  onSave,
}) => {
  const isOpen = propIsOpen !== undefined ? propIsOpen : Boolean(kitnetToEdit);
  const shouldReduceMotion = useReducedMotion();
  const lastKitnetRef = useRef<Kitnet | null>(kitnetToEdit);

  if (kitnetToEdit) {
    lastKitnetRef.current = kitnetToEdit;
  }
  const currentKitnet = kitnetToEdit || lastKitnetRef.current;

  useBodyScrollLock(isOpen);

  const [activeTab, setActiveTab] = useState<'imovel' | 'tenant' | 'contract'>('imovel');

  // Form State: Imóvel
  const [formImovel, setFormImovel] = useState({
    name: '',
    number: '',
    address: '',
    description: '',
    status: 'disponivel' as KitnetStatus,
    statusNote: '',
    notes: '',
    monthlyRentBase: 0,
    monthlyWaterBase: 0,
    monthlyInternetBase: 0,
    otherFeesBase: 0,
    depositBase: 0,
    cleaningFeeBase: 400,
    livingRoomPhoto: '',
    bedroomPhoto: '',
    bathroomPhoto: '',
    kitchenPhoto: '',
    outdoorPhoto: '',
    installationsPhoto: '',
  });

  // Form State: Inquilino
  const [formTenant, setFormTenant] = useState({
    fullName: '',
    cpf: '',
    rg: '',
    birthDate: '',
    phone: '',
    whatsapp: '',
    email: '',
    profession: '',
    company: '',
    maritalStatus: 'solteiro' as 'solteiro' | 'casado' | 'uniao_estavel' | 'divorciado' | 'viuvo',
    incomeType: 'CLT' as 'CLT' | 'Autônomo' | 'Empresário' | 'Funcionário Público' | 'Aposentado',
    monthlyIncome: 0,
    photoUrl: '',
  });

  // Form State: Contrato
  const [formContract, setFormContract] = useState({
    startDate: '',
    durationMonths: 12,
    dueDay: 10,
    rentValue: 0,
    waterValue: 0,
    internetValue: 0,
    otherFees: 0,
    deposit: 0,
    depositStatus: 'retida' as 'retida' | 'devolvida' | 'a_definir',
    cleaningFee: 400,
  });

  // Populate form when kitnetToEdit changes
  useEffect(() => {
    if (!kitnetToEdit) return;

    const contract = kitnetContracts.find(
      (c) => c.kitnetId === kitnetToEdit.id && c.status === 'ativo'
    );
    const tenant = kitnetTenants.find((t) => t.id === contract?.tenantId);

    setFormImovel({
      name: kitnetToEdit.name || '',
      number: kitnetToEdit.number || '',
      address: kitnetToEdit.address || '',
      description: kitnetToEdit.description || '',
      status: (kitnetToEdit.status || 'disponivel') as KitnetStatus,
      statusNote: kitnetToEdit.statusNote || '',
      notes: kitnetToEdit.notes || '',
      monthlyRentBase: kitnetToEdit.monthlyRentBase || 0,
      monthlyWaterBase: kitnetToEdit.monthlyWaterBase || 0,
      monthlyInternetBase: kitnetToEdit.monthlyInternetBase || 0,
      otherFeesBase: kitnetToEdit.otherFeesBase || 0,
      depositBase:
        kitnetToEdit.depositBase !== undefined
          ? kitnetToEdit.depositBase
          : kitnetToEdit.monthlyRentBase || 0,
      cleaningFeeBase:
        kitnetToEdit.cleaningFeeBase !== undefined
          ? kitnetToEdit.cleaningFeeBase
          : 400,
      livingRoomPhoto: kitnetToEdit.photos?.livingRoom || '',
      bedroomPhoto: kitnetToEdit.photos?.bedroom || '',
      bathroomPhoto: kitnetToEdit.photos?.bathroom || '',
      kitchenPhoto: kitnetToEdit.photos?.kitchen || '',
      outdoorPhoto: kitnetToEdit.photos?.outdoor || '',
      installationsPhoto: kitnetToEdit.photos?.installations || '',
    });

    setFormTenant({
      fullName: tenant?.fullName || '',
      cpf: tenant?.cpf ? maskCPFInput(tenant.cpf) : '',
      rg: tenant?.rg || '',
      birthDate: tenant?.birthDate || '',
      phone: tenant?.phone ? maskPhoneInput(tenant.phone) : '',
      whatsapp: tenant?.whatsapp ? maskPhoneInput(tenant.whatsapp) : '',
      email: tenant?.email || '',
      profession: tenant?.profession || '',
      company: tenant?.cltDetails?.company || tenant?.empresarioDetails?.company || '',
      maritalStatus: (tenant?.maritalStatus || 'solteiro') as any,
      incomeType: (tenant?.incomeType || 'CLT') as any,
      monthlyIncome: tenant?.cltDetails?.salary || tenant?.autonomoDetails?.avgIncome || 0,
      photoUrl: tenant?.photoUrl || '',
    });

    setFormContract({
      startDate: contract?.startDate || new Date().toISOString().split('T')[0],
      durationMonths: contract?.durationMonths || 12,
      dueDay: contract?.dueDay || 10,
      rentValue:
        contract?.rentValue !== undefined
          ? contract.rentValue
          : kitnetToEdit.monthlyRentBase || 0,
      waterValue:
        contract?.waterValue !== undefined
          ? contract.waterValue
          : kitnetToEdit.monthlyWaterBase || 0,
      internetValue:
        contract?.internetValue !== undefined
          ? contract.internetValue
          : kitnetToEdit.monthlyInternetBase || 0,
      otherFees:
        contract?.otherFees !== undefined
          ? contract.otherFees
          : kitnetToEdit.otherFeesBase || 0,
      deposit:
        contract?.deposit !== undefined
          ? contract.deposit
          : kitnetToEdit.depositBase || 0,
      depositStatus: contract?.depositStatus || 'retida',
      cleaningFee:
        contract?.cleaningFee !== undefined
          ? contract.cleaningFee
          : kitnetToEdit.cleaningFeeBase || 400,
    });
  }, [kitnetToEdit, kitnetContracts, kitnetTenants]);

  // Keyboard shortcut for closing
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const isAlugada = formImovel.status === 'alugada';

  useEffect(() => {
    if (!isAlugada && (activeTab === 'tenant' || activeTab === 'contract')) {
      setActiveTab('imovel');
    }
  }, [isAlugada, activeTab]);

  if (typeof document === 'undefined') return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentKitnet) return;

    if (!formImovel.name.trim()) {
      alert('Por favor, informe o Nome/Identificação da Kitnet.');
      setActiveTab('imovel');
      return;
    }

    if (!formImovel.number.trim()) {
      alert('Por favor, informe o Número da unidade.');
      setActiveTab('imovel');
      return;
    }

    const updatedKitnet = {
      name: formImovel.name.trim(),
      number: formImovel.number.trim(),
      address: formImovel.address.trim(),
      description: formImovel.description.trim(),
      status: formImovel.status,
      statusNote: formImovel.statusNote.trim() || undefined,
      notes: formImovel.notes.trim() || undefined,
      monthlyRentBase: Number(formImovel.monthlyRentBase) || 0,
      monthlyWaterBase: Number(formImovel.monthlyWaterBase) || 0,
      monthlyInternetBase: Number(formImovel.monthlyInternetBase) || 0,
      otherFeesBase: Number(formImovel.otherFeesBase) || 0,
      depositBase: Number(formImovel.depositBase) || 0,
      cleaningFeeBase: Number(formImovel.cleaningFeeBase) || 400,
      photos: {
        livingRoom: formImovel.livingRoomPhoto || undefined,
        bedroom: formImovel.bedroomPhoto || undefined,
        bathroom: formImovel.bathroomPhoto || undefined,
        kitchen: formImovel.kitchenPhoto || undefined,
        outdoor: formImovel.outdoorPhoto || undefined,
        installations: formImovel.installationsPhoto || undefined,
      },
    };

    let tenantUpdates: any = undefined;
    let contractUpdates: any = undefined;

    if (isAlugada && formTenant.fullName.trim()) {
      tenantUpdates = {
        fullName: formTenant.fullName.trim(),
        cpf: formTenant.cpf.replace(/\D/g, '') || undefined,
        rg: formTenant.rg.trim() || undefined,
        birthDate: formTenant.birthDate || undefined,
        phone: formTenant.phone.replace(/\D/g, '') || undefined,
        whatsapp: (formTenant.whatsapp || formTenant.phone).replace(/\D/g, '') || undefined,
        email: formTenant.email.trim() || undefined,
        profession: formTenant.profession.trim() || undefined,
        company: formTenant.company.trim() || undefined,
        maritalStatus: formTenant.maritalStatus,
        incomeType: formTenant.incomeType,
        monthlyIncome: Number(formTenant.monthlyIncome) || 0,
        photoUrl: formTenant.photoUrl || undefined,
      };

      contractUpdates = {
        startDate: formContract.startDate,
        durationMonths: Number(formContract.durationMonths) || 12,
        dueDay: Number(formContract.dueDay) || 10,
        rentValue: Number(formContract.rentValue) || updatedKitnet.monthlyRentBase,
        waterValue: Number(formContract.waterValue) || updatedKitnet.monthlyWaterBase,
        internetValue: Number(formContract.internetValue) || updatedKitnet.monthlyInternetBase,
        otherFees: Number(formContract.otherFees) || updatedKitnet.otherFeesBase,
        deposit: Number(formContract.deposit) || updatedKitnet.depositBase,
        depositStatus: formContract.depositStatus,
        cleaningFee: Number(formContract.cleaningFee) || updatedKitnet.cleaningFeeBase,
      };
    }

    onSave(currentKitnet.id, updatedKitnet, tenantUpdates, contractUpdates);
  };

  return createPortal(
    <AnimatePresence>
      {isOpen && currentKitnet && (
        <motion.div
          key="edit-kitnet-backdrop"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: shouldReduceMotion ? 0.05 : 0.2 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto overflow-x-hidden font-sans touch-pan-y w-full max-w-full"
          style={{ overflowX: 'hidden', touchAction: 'pan-y' }}
          onClick={onClose}
          role="dialog"
          aria-modal="true"
        >
          <motion.div
            key="edit-kitnet-card"
            initial={shouldReduceMotion ? { opacity: 0 } : { opacity: 0, scale: 0.95, y: 14 }}
            animate={shouldReduceMotion ? { opacity: 1 } : { opacity: 1, scale: 1, y: 0 }}
            exit={shouldReduceMotion ? { opacity: 0 } : { opacity: 0, scale: 0.95, y: 14 }}
            transition={{
              duration: shouldReduceMotion ? 0.05 : 0.22,
              ease: [0.16, 1, 0.3, 1],
            }}
            className="bg-surface-sidebar border border-white/[0.12] rounded-2xl sm:rounded-3xl w-full max-w-3xl max-h-[92vh] sm:max-h-[88vh] shadow-2xl shadow-black/80 overflow-hidden flex flex-col my-auto min-w-0 z-10"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="p-4 sm:p-5 border-b border-white/[0.08] flex items-center justify-between bg-surface-base/90 backdrop-blur-sm shrink-0 gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className={`w-9 h-9 sm:w-10 sm:h-10 rounded-2xl border flex items-center justify-center shrink-0 transition-colors ${
                    formImovel.status === 'alugada'
                      ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400'
                      : formImovel.status === 'reforma'
                      ? 'bg-amber-500/15 border-amber-500/30 text-amber-400'
                      : 'bg-sky-500/15 border-sky-500/30 text-sky-400'
                  }`}
                >
                  <Home className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-sm sm:text-base md:text-lg font-bold text-white tracking-tight truncate">
                      Editar: {kitnetToEdit.name} - Nº {kitnetToEdit.number}
                    </h3>
                    <span
                      className={`px-2 py-0.5 rounded-lg text-xs font-semibold uppercase ${
                        formImovel.status === 'alugada'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : formImovel.status === 'reforma'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                      }`}
                    >
                      {formImovel.status === 'alugada'
                        ? 'Alugada'
                        : formImovel.status === 'reforma'
                        ? 'Em Reforma'
                        : 'Disponível'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 hidden sm:block truncate">
                    {isAlugada
                      ? 'Atualize as especificações do imóvel, inquilino ou plano contratual'
                      : 'Atualize as especificações da kitnet e status operacional'}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={onClose}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/[0.08] border border-transparent hover:border-white/[0.10] transition-all cursor-pointer shrink-0 active:scale-90"
                title="Fechar"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Abas de Navegação (Disponíveis quando alugada) */}
            {isAlugada && (
              <div className="bg-surface-base border-b border-white/[0.08] px-3 sm:px-5 py-2.5 shrink-0 animate-fadeIn">
                <div className="flex p-1 bg-surface-base border border-white/[0.08] rounded-xl">
                  <button
                    type="button"
                    onClick={() => setActiveTab('imovel')}
                    className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                      activeTab === 'imovel'
                        ? 'bg-emerald-500 text-slate-950 shadow-md'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Home className="w-3.5 h-3.5" />
                    <span>1. Imóvel</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveTab('tenant')}
                    className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                      activeTab === 'tenant'
                        ? 'bg-emerald-500 text-slate-950 shadow-md'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <User className="w-3.5 h-3.5" />
                    <span>2. Inquilino</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveTab('contract')}
                    className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                      activeTab === 'contract'
                        ? 'bg-emerald-500 text-slate-950 shadow-md'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                    <span>3. Contrato</span>
                  </button>
                </div>
              </div>
            )}

            {/* Form Body */}
            <form onSubmit={handleSubmit} className="flex flex-col flex-1 min-h-0 overflow-hidden w-full max-w-full">
              <div
                className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 min-w-0"
                style={{ WebkitOverflowScrolling: 'touch', touchAction: 'pan-y' }}
              >
                {/* TAB 1: IMÓVEL */}
                {activeTab === 'imovel' && (
                  <div className="space-y-5 animate-fadeIn">
                    {/* Status Operacional */}
                    <div className="bg-surface-subtle p-4 rounded-2xl border border-white/[0.08] space-y-3">
                      <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
                        Status da Unidade
                      </label>
                      <div className="grid grid-cols-3 gap-2.5">
                        <button
                          type="button"
                          onClick={() => {
                            setFormImovel((prev) => ({
                              ...prev,
                              status: 'disponivel',
                              statusNote: prev.statusNote || 'Pronta para locação imediata',
                            }));
                          }}
                          className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                            formImovel.status === 'disponivel'
                              ? 'bg-sky-500/20 border-sky-500 text-sky-300 font-bold shadow-lg shadow-sky-500/10'
                              : 'bg-white/[0.03] border-white/[0.08] text-slate-400 hover:text-white hover:bg-white/[0.06]'
                          }`}
                        >
                          <Key className="w-4 h-4" />
                          <span className="text-xs font-semibold">Disponível</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setFormImovel((prev) => ({
                              ...prev,
                              status: 'alugada',
                              statusNote: prev.statusNote || 'Contrato ativo de locação',
                            }));
                          }}
                          className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                            formImovel.status === 'alugada'
                              ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-bold shadow-lg shadow-emerald-500/10'
                              : 'bg-white/[0.03] border-white/[0.08] text-slate-400 hover:text-white hover:bg-white/[0.06]'
                          }`}
                        >
                          <Home className="w-4 h-4" />
                          <span className="text-xs font-semibold">Alugada</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setFormImovel((prev) => ({
                              ...prev,
                              status: 'reforma',
                              statusNote: prev.statusNote || 'Previsão de entrega: 15 dias',
                            }));
                          }}
                          className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                            formImovel.status === 'reforma'
                              ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold shadow-lg shadow-amber-500/10'
                              : 'bg-white/[0.03] border-white/[0.08] text-slate-400 hover:text-white hover:bg-white/[0.06]'
                          }`}
                        >
                          <Wrench className="w-4 h-4" />
                          <span className="text-xs font-semibold">Em Reforma</span>
                        </button>
                      </div>

                      {/* Presets de Nota de Status */}
                      <div className="space-y-1.5 pt-1">
                        <label className="text-[11px] font-medium text-slate-400 block">
                          Observação do Status / Previsão:
                        </label>
                        <input
                          type="text"
                          value={formImovel.statusNote}
                          onChange={(e) =>
                            setFormImovel((prev) => ({ ...prev, statusNote: e.target.value }))
                          }
                          placeholder="Ex: Pronta para morar, previsão de entrega, etc."
                          className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500 transition-colors"
                        />
                        <div className="flex items-center gap-1.5 flex-wrap pt-1">
                          {KITNET_STATUS_PRESETS[formImovel.status]?.map((preset, idx) => (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => setFormImovel((prev) => ({ ...prev, statusNote: preset }))}
                              className="text-[10px] px-2 py-0.5 rounded-md bg-white/[0.05] hover:bg-white/[0.10] text-slate-300 border border-white/[0.06] transition-colors cursor-pointer"
                            >
                              {preset}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Dados Básicos */}
                    <div className="bg-surface-subtle p-4 rounded-2xl border border-white/[0.08] space-y-3">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                        Identificação da Unidade
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div className="sm:col-span-2 space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Nome do Imóvel / Bloco *
                          </label>
                          <input
                            type="text"
                            value={formImovel.name}
                            onChange={(e) =>
                              setFormImovel((prev) => ({ ...prev, name: e.target.value }))
                            }
                            required
                            placeholder="Ex: Residencial Flores"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500 transition-colors"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Número / Apto *
                          </label>
                          <input
                            type="text"
                            value={formImovel.number}
                            onChange={(e) =>
                              setFormImovel((prev) => ({ ...prev, number: e.target.value }))
                            }
                            required
                            placeholder="Ex: 01"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500 transition-colors"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-slate-300">
                          Endereço Completo
                        </label>
                        <input
                          type="text"
                          value={formImovel.address}
                          onChange={(e) =>
                            setFormImovel((prev) => ({ ...prev, address: e.target.value }))
                          }
                          placeholder="Rua, número, bairro, cidade e CEP"
                          className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500 transition-colors"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-slate-300">
                          Descrição / Características
                        </label>
                        <textarea
                          rows={2}
                          value={formImovel.description}
                          onChange={(e) =>
                            setFormImovel((prev) => ({ ...prev, description: e.target.value }))
                          }
                          placeholder="Ambientes, mobílias inclusas, regras de convivência..."
                          className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500 transition-colors resize-none"
                        />
                      </div>
                    </div>

                    {/* Valores Base */}
                    <div className="bg-surface-subtle p-4 rounded-2xl border border-white/[0.08] space-y-3">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                        Valores Base da Unidade (Mensais)
                      </h4>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Aluguel Base
                          </label>
                          <CurrencyInput
                            value={formImovel.monthlyRentBase}
                            onChange={(val) =>
                              setFormImovel((prev) => ({ ...prev, monthlyRentBase: val }))
                            }
                            placeholder="R$ 0,00"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-violet-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Água / Condomínio
                          </label>
                          <CurrencyInput
                            value={formImovel.monthlyWaterBase}
                            onChange={(val) =>
                              setFormImovel((prev) => ({ ...prev, monthlyWaterBase: val }))
                            }
                            placeholder="R$ 0,00"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-violet-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Internet Wi-Fi
                          </label>
                          <CurrencyInput
                            value={formImovel.monthlyInternetBase}
                            onChange={(val) =>
                              setFormImovel((prev) => ({ ...prev, monthlyInternetBase: val }))
                            }
                            placeholder="R$ 0,00"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-violet-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Outras Taxas
                          </label>
                          <CurrencyInput
                            value={formImovel.otherFeesBase}
                            onChange={(val) =>
                              setFormImovel((prev) => ({ ...prev, otherFeesBase: val }))
                            }
                            placeholder="R$ 0,00"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-violet-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Caução Base
                          </label>
                          <CurrencyInput
                            value={formImovel.depositBase}
                            onChange={(val) =>
                              setFormImovel((prev) => ({ ...prev, depositBase: val }))
                            }
                            placeholder="R$ 0,00"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-violet-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Taxa de Limpeza
                          </label>
                          <CurrencyInput
                            value={formImovel.cleaningFeeBase}
                            onChange={(val) =>
                              setFormImovel((prev) => ({ ...prev, cleaningFeeBase: val }))
                            }
                            placeholder="R$ 0,00"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-violet-500"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Fotos dos Ambientes */}
                    <div className="bg-surface-subtle p-4 rounded-2xl border border-white/[0.08] space-y-3">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                        <Camera className="w-3.5 h-3.5 text-violet-400" />
                        <span>Fotos dos Ambientes</span>
                      </h4>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                        <ImageUploadInput
                          label="Sala de Estar"
                          value={formImovel.livingRoomPhoto}
                          onChange={(val) =>
                            setFormImovel((prev) => ({ ...prev, livingRoomPhoto: val }))
                          }
                        />
                        <ImageUploadInput
                          label="Dormitório"
                          value={formImovel.bedroomPhoto}
                          onChange={(val) =>
                            setFormImovel((prev) => ({ ...prev, bedroomPhoto: val }))
                          }
                        />
                        <ImageUploadInput
                          label="Banheiro"
                          value={formImovel.bathroomPhoto}
                          onChange={(val) =>
                            setFormImovel((prev) => ({ ...prev, bathroomPhoto: val }))
                          }
                        />
                        <ImageUploadInput
                          label="Cozinha"
                          value={formImovel.kitchenPhoto}
                          onChange={(val) =>
                            setFormImovel((prev) => ({ ...prev, kitchenPhoto: val }))
                          }
                        />
                        <ImageUploadInput
                          label="Área Externa"
                          value={formImovel.outdoorPhoto}
                          onChange={(val) =>
                            setFormImovel((prev) => ({ ...prev, outdoorPhoto: val }))
                          }
                        />
                        <ImageUploadInput
                          label="Instalações"
                          value={formImovel.installationsPhoto}
                          onChange={(val) =>
                            setFormImovel((prev) => ({ ...prev, installationsPhoto: val }))
                          }
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* TAB 2: INQUILINO */}
                {isAlugada && activeTab === 'tenant' && (
                  <div className="space-y-5 animate-fadeIn">
                    <div className="bg-surface-subtle p-4 rounded-2xl border border-white/[0.08] space-y-3">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Identificação do Inquilino</span>
                      </h4>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="space-y-1 sm:col-span-2">
                          <label className="text-xs font-semibold text-slate-300">
                            Nome Completo *
                          </label>
                          <input
                            type="text"
                            value={formTenant.fullName}
                            onChange={(e) =>
                              setFormTenant((prev) => ({ ...prev, fullName: e.target.value }))
                            }
                            required
                            placeholder="Nome completo do inquilino"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">CPF</label>
                          <input
                            type="text"
                            value={formTenant.cpf}
                            onChange={(e) =>
                              setFormTenant((prev) => ({
                                ...prev,
                                cpf: maskCPFInput(e.target.value),
                              }))
                            }
                            maxLength={14}
                            placeholder="000.000.000-00"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">RG</label>
                          <input
                            type="text"
                            value={formTenant.rg}
                            onChange={(e) =>
                              setFormTenant((prev) => ({ ...prev, rg: e.target.value }))
                            }
                            placeholder="Número do RG"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Telefone / WhatsApp
                          </label>
                          <input
                            type="text"
                            value={formTenant.phone}
                            onChange={(e) => {
                              const masked = maskPhoneInput(e.target.value);
                              setFormTenant((prev) => ({
                                ...prev,
                                phone: masked,
                                whatsapp: masked,
                              }));
                            }}
                            placeholder="(11) 99999-9999"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">E-mail</label>
                          <input
                            type="email"
                            value={formTenant.email}
                            onChange={(e) =>
                              setFormTenant((prev) => ({ ...prev, email: e.target.value }))
                            }
                            placeholder="email@inquilino.com"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Data de Nascimento
                          </label>
                          <input
                            type="date"
                            value={formTenant.birthDate}
                            onChange={(e) =>
                              setFormTenant((prev) => ({ ...prev, birthDate: e.target.value }))
                            }
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500 transition-colors"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Estado Civil
                          </label>
                          <select
                            value={formTenant.maritalStatus}
                            onChange={(e) =>
                              setFormTenant((prev) => ({
                                ...prev,
                                maritalStatus: e.target.value as any,
                              }))
                            }
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                          >
                            <option value="solteiro">Solteiro(a)</option>
                            <option value="casado">Casado(a)</option>
                            <option value="uniao_estavel">União Estável</option>
                            <option value="divorciado">Divorciado(a)</option>
                            <option value="viuvo">Viúvo(a)</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    <div className="bg-surface-subtle p-4 rounded-2xl border border-white/[0.08] space-y-3">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                        <Briefcase className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Renda & Atividade Profissional</span>
                      </h4>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Profissão / Cargo
                          </label>
                          <input
                            type="text"
                            value={formTenant.profession}
                            onChange={(e) =>
                              setFormTenant((prev) => ({ ...prev, profession: e.target.value }))
                            }
                            placeholder="Ex: Desenvolvedor, Vendedor"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Tipo de Renda
                          </label>
                          <select
                            value={formTenant.incomeType}
                            onChange={(e) =>
                              setFormTenant((prev) => ({
                                ...prev,
                                incomeType: e.target.value as any,
                              }))
                            }
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                          >
                            <option value="CLT">CLT (Carteira Assinada)</option>
                            <option value="Autônomo">Autônomo / Profissional Liberal</option>
                            <option value="Empresário">Empresário / PJ</option>
                            <option value="Funcionário Público">Funcionário Público</option>
                            <option value="Aposentado">Aposentado / Pensionista</option>
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Renda Mensal (R$)
                          </label>
                          <CurrencyInput
                            value={formTenant.monthlyIncome}
                            onChange={(val) =>
                              setFormTenant((prev) => ({ ...prev, monthlyIncome: val }))
                            }
                            placeholder="R$ 0,00"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                          />
                        </div>
                      </div>

                      <div className="pt-2">
                        <ImageUploadInput
                          label="Foto de Perfil do Inquilino"
                          value={formTenant.photoUrl}
                          onChange={(val) =>
                            setFormTenant((prev) => ({ ...prev, photoUrl: val }))
                          }
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* TAB 3: CONTRATO */}
                {isAlugada && activeTab === 'contract' && (
                  <div className="space-y-5 animate-fadeIn">
                    <div className="bg-surface-subtle p-4 rounded-2xl border border-white/[0.08] space-y-3">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Vigência e Vencimento</span>
                      </h4>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Data de Início *
                          </label>
                          <input
                            type="date"
                            value={formContract.startDate}
                            onChange={(e) =>
                              setFormContract((prev) => ({ ...prev, startDate: e.target.value }))
                            }
                            required
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Duração (meses)
                          </label>
                          <input
                            type="number"
                            min="1"
                            max="60"
                            value={formContract.durationMonths}
                            onChange={(e) =>
                              setFormContract((prev) => ({
                                ...prev,
                                durationMonths: parseInt(e.target.value) || 12,
                              }))
                            }
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Dia de Vencimento
                          </label>
                          <select
                            value={formContract.dueDay}
                            onChange={(e) =>
                              setFormContract((prev) => ({
                                ...prev,
                                dueDay: parseInt(e.target.value) || 10,
                              }))
                            }
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                          >
                            {[5, 10, 15, 20, 25, 28].map((day) => (
                              <option key={day} value={day}>
                                Todo dia {day}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </div>

                    <div className="bg-surface-subtle p-4 rounded-2xl border border-white/[0.08] space-y-3">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                        <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Valores Acordados no Contrato</span>
                      </h4>

                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Aluguel Acordado
                          </label>
                          <CurrencyInput
                            value={formContract.rentValue}
                            onChange={(val) =>
                              setFormContract((prev) => ({ ...prev, rentValue: val }))
                            }
                            placeholder="R$ 0,00"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Água Acordada
                          </label>
                          <CurrencyInput
                            value={formContract.waterValue}
                            onChange={(val) =>
                              setFormContract((prev) => ({ ...prev, waterValue: val }))
                            }
                            placeholder="R$ 0,00"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Internet Wi-Fi
                          </label>
                          <CurrencyInput
                            value={formContract.internetValue}
                            onChange={(val) =>
                              setFormContract((prev) => ({ ...prev, internetValue: val }))
                            }
                            placeholder="R$ 0,00"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Outras Taxas
                          </label>
                          <CurrencyInput
                            value={formContract.otherFees}
                            onChange={(val) =>
                              setFormContract((prev) => ({ ...prev, otherFees: val }))
                            }
                            placeholder="R$ 0,00"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Caução Acordado
                          </label>
                          <CurrencyInput
                            value={formContract.deposit}
                            onChange={(val) =>
                              setFormContract((prev) => ({ ...prev, deposit: val }))
                            }
                            placeholder="R$ 0,00"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-300">
                            Status do Caução
                          </label>
                          <select
                            value={formContract.depositStatus}
                            onChange={(e) =>
                              setFormContract((prev) => ({
                                ...prev,
                                depositStatus: e.target.value as any,
                              }))
                            }
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                          >
                            <option value="retida">Retida com o Proprietário</option>
                            <option value="devolvida">Devolvida ao Inquilino</option>
                            <option value="a_definir">A Definir / Parcelada</option>
                          </select>
                        </div>
                      </div>

                      <div className="pt-2">
                        <div className="space-y-1 max-w-xs">
                          <label className="text-xs font-semibold text-slate-300">
                            Taxa de Limpeza de Rescisão
                          </label>
                          <CurrencyInput
                            value={formContract.cleaningFee}
                            onChange={(val) =>
                              setFormContract((prev) => ({ ...prev, cleaningFee: val }))
                            }
                            placeholder="R$ 0,00"
                            className="w-full bg-surface-sidebar border border-white/[0.10] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="p-4 sm:p-5 border-t border-white/[0.08] flex items-center justify-between bg-surface-base/95 backdrop-blur-sm shrink-0 gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold text-slate-400 hover:text-white hover:bg-white/[0.08] transition-all cursor-pointer active:scale-95"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-slate-950 transition-all cursor-pointer flex items-center gap-2 active:scale-[0.98] shadow-lg ${
                    formImovel.status === 'alugada'
                      ? 'bg-emerald-500 hover:bg-emerald-400 shadow-emerald-500/20'
                      : formImovel.status === 'reforma'
                      ? 'bg-amber-500 hover:bg-amber-400 shadow-amber-500/20'
                      : 'bg-sky-500 hover:bg-sky-400 shadow-sky-500/20'
                  }`}
                >
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>Salvar Alterações</span>
                </button>
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
};
