import React, { useRef, useState } from 'react';
import {
  User,
  Briefcase,
  Camera,
  Trash2,
  ZoomIn,
  RefreshCw,
} from 'lucide-react';
import { Kitnet, KitnetTenant } from '../../../types';
import { useApp } from '../../../context/AppContext';
import { compressImage } from '../../../utils/imageUtils';
import { PhotoZoomModal } from '../../common/PhotoZoomModal';

interface KitnetDetailTenantTabProps {
  kitnet: Kitnet;
  tenant?: KitnetTenant;
  formatCurrency: (value: number) => string;
  formatCPF: (cpf: string) => string;
  formatPhone: (phone: string) => string;
  onOpenClientProfile?: (tenantId: string, type: 'moto' | 'kitnet') => void;
}

export const KitnetDetailTenantTab: React.FC<KitnetDetailTenantTabProps> = ({
  kitnet,
  tenant,
  formatCurrency,
  formatCPF,
  formatPhone,
  onOpenClientProfile,
}) => {
  const { updateKitnetTenant, addTimelineEvent } = useApp();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [photoPreviewModal, setPhotoPreviewModal] = useState<{ url: string; title: string } | null>(null);

  const handleClientPhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !tenant) return;

    try {
      setIsUploadingPhoto(true);
      const base64Data = await compressImage(file, 800, 800, 0.70);
      updateKitnetTenant(tenant.id, {
        photoUrl: base64Data,
        documents: {
          ...tenant.documents,
          photo: base64Data,
        },
      });
      addTimelineEvent({
        type: 'ocorrencia_cliente',
        title: `Foto do inquilino atualizada`,
        description: `Foto de perfil atualizada para ${tenant.fullName} (Kitnet ${kitnet.name})`,
        entityType: 'cliente',
        entityId: tenant.id,
      });
    } catch {
      alert('Erro ao carregar imagem. Tente outro arquivo.');
    } finally {
      setIsUploadingPhoto(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleRemoveClientPhoto = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!tenant) return;
    updateKitnetTenant(tenant.id, {
      photoUrl: undefined,
      documents: {
        ...tenant.documents,
        photo: undefined,
      },
    });
  };

  return (
    <div className="space-y-4">
      {/* Modal de visualização de foto em alta definição */}
      <PhotoZoomModal
        photo={photoPreviewModal}
        onClose={() => setPhotoPreviewModal(null)}
      />

      {tenant ? (
        <div className="p-4 bg-surface-base border border-white/[0.08] rounded-xl space-y-4 text-xs">
          {/* Inquilino Profile Header with Photo Upload */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-surface-card rounded-xl border border-white/[0.08]">
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="relative group w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden bg-surface-base border-2 border-category-kitnets-sky/30 shrink-0 shadow-md">
                {tenant.photoUrl || tenant.documents?.photo ? (
                  <>
                    <img
                      src={tenant.photoUrl || tenant.documents?.photo}
                      alt={tenant.fullName}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1.5">
                      <button
                        type="button"
                        onClick={() =>
                          setPhotoPreviewModal({
                            url: tenant.photoUrl || tenant.documents?.photo || '',
                            title: `Foto do Inquilino: ${tenant.fullName}`,
                          })
                        }
                        className="p-1 bg-black/70 hover:bg-black text-white rounded-md cursor-pointer transition-colors"
                        title="Ampliar foto"
                      >
                        <ZoomIn className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={handleRemoveClientPhoto}
                        className="p-1 bg-money-negative hover:bg-money-negative/80 text-white rounded-md cursor-pointer transition-colors"
                        title="Remover foto"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </>
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center text-category-kitnets-sky">
                    <User className="w-7 h-7" />
                    <span className="text-[9px] text-text-secondary mt-0.5 font-bold">Sem Foto</span>
                  </div>
                )}
              </div>

              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-base sm:text-lg font-bold text-text-primary tracking-tight truncate">
                    {tenant.fullName}
                  </h3>
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-category-kitnets-sky/10 text-category-kitnets-sky border border-category-kitnets-sky/25 uppercase">
                    {tenant.incomeType}
                  </span>
                </div>
                <p className="text-xs text-text-secondary mt-0.5 font-mono">
                  CPF: {formatCPF(tenant.cpf)} • {tenant.maritalStatus}
                </p>
                <p className="text-[11px] text-category-kitnets-sky mt-1 font-semibold flex items-center gap-1">
                  <span>Inquilino da Kitnet {kitnet.name}</span>
                </p>
              </div>
            </div>

            {/* Photo Upload Button */}
            <div className="flex sm:flex-col items-center sm:items-end gap-2 shrink-0">
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                onChange={handleClientPhotoSelect}
                className="hidden"
                id={`upload-client-photo-kitnet-${tenant.id}`}
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploadingPhoto}
                className="px-3.5 py-2 rounded-xl bg-action-primary hover:bg-action-hover text-white text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all shadow-sm active:scale-98"
              >
                {isUploadingPhoto ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Enviando Foto...</span>
                  </>
                ) : (
                  <>
                    <Camera className="w-3.5 h-3.5" />
                    <span>{tenant.photoUrl || tenant.documents?.photo ? 'Alterar Foto' : 'Upar Foto do Cliente'}</span>
                  </>
                )}
              </button>
              <span className="text-[10px] text-text-secondary hidden sm:block">JPG, PNG ou foto da câmera</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <span className="text-text-secondary">WhatsApp / Celular:</span>
              <p className="font-medium text-text-primary">{formatPhone(tenant.whatsapp || tenant.phone)}</p>
            </div>
            <div>
              <span className="text-text-secondary">E-mail:</span>
              <p className="font-medium text-text-primary">{tenant.email || 'N/A'}</p>
            </div>
          </div>

          {/* Income Analysis Details */}
          <div className="p-3 bg-surface-card rounded-xl border border-white/[0.08] space-y-2">
            <div className="flex items-center gap-2 text-category-kitnets-sky font-semibold">
              <Briefcase className="w-3.5 h-3.5" />
              <span>Análise de Renda — Categoria: {tenant.incomeType.toUpperCase()}</span>
            </div>

            {tenant.incomeType === 'CLT' && tenant.cltDetails && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                <div>
                  <span className="text-text-secondary">Empresa:</span>
                  <p className="font-medium text-text-primary">{tenant.cltDetails.company}</p>
                </div>
                <div>
                  <span className="text-text-secondary">Cargo:</span>
                  <p className="font-medium text-text-primary">{tenant.cltDetails.role}</p>
                </div>
                <div>
                  <span className="text-text-secondary">Salário:</span>
                  <p className="font-semibold text-money-positive">
                    {formatCurrency(tenant.cltDetails.salary)}
                  </p>
                </div>
                <div>
                  <span className="text-text-secondary">Tempo de Casa:</span>
                  <p className="font-medium text-text-primary">{tenant.cltDetails.tenureMonths} meses</p>
                </div>
              </div>
            )}

            {tenant.incomeType === 'empresario' && tenant.empresarioDetails && (
              <div className="grid grid-cols-3 gap-2 text-[11px]">
                <div>
                  <span className="text-text-secondary">Razão Social:</span>
                  <p className="font-medium text-text-primary">{tenant.empresarioDetails.company}</p>
                </div>
                <div>
                  <span className="text-text-secondary">CNPJ:</span>
                  <p className="font-medium text-text-primary">{tenant.empresarioDetails.cnpj}</p>
                </div>
                <div>
                  <span className="text-text-secondary">Tempo de Atividade:</span>
                  <p className="font-medium text-text-primary">{tenant.empresarioDetails.activityYears} anos</p>
                </div>
              </div>
            )}

            {onOpenClientProfile && (
              <button
                type="button"
                onClick={() => onOpenClientProfile(tenant.id, 'kitnet')}
                className="mt-3 w-full py-2.5 px-3 bg-surface-base hover:bg-surface-elevated text-action-primary hover:text-text-primary rounded-xl border border-white/[0.08] text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xs active:scale-98"
              >
                <User className="w-4 h-4 text-action-primary" />
                <span>Abrir Ficha Cadastral e Score Completo</span>
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="py-8 text-center text-xs text-text-secondary bg-surface-base border border-white/[0.08] rounded-xl">
          Nenhum inquilino cadastrado nesta unidade no momento.
        </div>
      )}
    </div>
  );
};
