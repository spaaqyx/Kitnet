import React from 'react';
import { motion } from 'motion/react';
import { AlertTriangle, CheckCircle2, Send } from 'lucide-react';
import { CategoryStamp } from '../CategoryIcons';
import { useApp } from '../../context/AppContext';

interface AlertItem {
  id: string;
  type: 'critical' | 'warning' | 'info';
  category?: 'moto' | 'kitnet';
  text: string;
  subtext: string;
  contractId?: string;
  installmentId?: string;
}

interface DashboardAlertsListProps {
  alertItems: AlertItem[];
  onOpenWhatsAppModal: (contractId?: string, installmentId?: string) => void;
}

export const DashboardAlertsList: React.FC<DashboardAlertsListProps> = ({
  alertItems,
  onOpenWhatsAppModal,
}) => {
  const { isReadOnlyMode } = useApp();
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.18 }}
      className="lg:col-span-1 app-card p-5 flex flex-col"
    >
      <div className="flex items-center justify-between pb-3 border-b border-[rgba(255,255,255,0.07)]">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
          <h3 className="text-sm font-bold text-text-primary">Alertas Operacionais</h3>
        </div>
        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30 tabular-nums">
          {alertItems.length} ativos
        </span>
      </div>

      <div className="mt-3 space-y-2.5 flex-1 overflow-y-auto max-h-80 pr-1">
        {alertItems.length === 0 ? (
          <div className="py-12 text-center text-xs text-text-secondary">
            <CheckCircle2 className="w-7 h-7 text-money-positive mx-auto mb-2 opacity-80" />
            Sem alertas pendentes no momento!
          </div>
        ) : (
          alertItems.map((alert) => {
            const isMoto = alert.category === 'moto';
            const isCritical = alert.type === 'critical';
            return (
              <div
                key={alert.id}
                className={`p-3 rounded-xl border text-xs flex flex-col gap-1.5 transition-all ${
                  isCritical
                    ? 'bg-money-negative/10 border-money-negative/35 text-money-negative animate-pulse-red-subtle shadow-sm shadow-money-negative/10'
                    : isMoto
                    ? 'bg-category-motos/10 border-category-motos/25 text-category-motos'
                    : 'bg-category-kitnets-sky/10 border-category-kitnets-sky/25 text-category-kitnets-sky'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 min-w-0">
                    {alert.category && (
                      <CategoryStamp category={alert.category} size="xs" iconOnly />
                    )}
                    <span className="font-bold text-text-primary truncate">{alert.text}</span>
                  </div>
                  {alert.contractId && !isReadOnlyMode && (
                    <button
                      type="button"
                      onClick={() => onOpenWhatsAppModal(alert.contractId!, alert.installmentId)}
                      className="min-h-[30px] sm:h-7 px-3 py-1 rounded-lg bg-social-whatsapp/20 hover:bg-social-whatsapp/30 border border-social-whatsapp/40 text-social-whatsapp font-bold text-[11px] inline-flex items-center justify-center gap-1.5 cursor-pointer transition-all duration-150 active:scale-95 shrink-0 shadow-xs select-none"
                      title="Enviar cobrança via WhatsApp"
                    >
                      <Send className="w-3 h-3 shrink-0" />
                      <span>Cobrar</span>
                    </button>
                  )}
                </div>
                <span className="text-[11px] text-text-secondary">{alert.subtext}</span>
              </div>
            );
          })
        )}
      </div>
    </motion.div>
  );
};
