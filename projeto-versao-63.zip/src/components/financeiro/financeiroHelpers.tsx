import React from 'react';
import {
  Wifi,
  Droplets,
  Zap,
  Building2,
  Shield,
  Wrench,
  Receipt,
} from 'lucide-react';
import { Expense, ExpenseCategory, ExpenseRecurrence } from '../../types';
import { getTodayLocalDateString } from '../../utils/formatters';
import { COLORS } from '../../styles/colors';

export const getCategoryCircleIcon = (cat: ExpenseCategory | string) => {
  switch (cat) {
    case 'internet':
      return <Wifi className="w-5 h-5 text-action-light" />;
    case 'agua':
      return <Droplets className="w-5 h-5 text-category-kitnets-cyan" />;
    case 'energia':
      return <Zap className="w-5 h-5 text-category-motos-alt" />;
    case 'iptu':
      return <Building2 className="w-5 h-5 text-money-positive" />;
    case 'seguro':
      return <Shield className="w-5 h-5 text-action-light" />;
    case 'manutencao_moto':
    case 'reparo':
    case 'reforma':
      return <Wrench className="w-5 h-5 text-category-motos-alt" />;
    default:
      return <Receipt className="w-5 h-5 text-action-light" />;
  }
};

export const getCategoryBulletColor = (cat: ExpenseCategory | string): string => {
  switch (cat) {
    case 'internet':
      return COLORS.action.light;
    case 'agua':
      return COLORS.category.kitnetsCyan;
    case 'energia':
      return COLORS.money.warning;
    case 'iptu':
      return COLORS.money.positive;
    case 'seguro':
      return COLORS.action.light;
    case 'manutencao_moto':
    case 'reparo':
    case 'reforma':
      return COLORS.category.motosAlt;
    default:
      return COLORS.action.light;
  }
};

export const getCategoryLabel = (cat: ExpenseCategory | string): string => {
  switch (cat) {
    case 'internet':
      return 'Internet';
    case 'agua':
      return 'Água';
    case 'energia':
      return 'Energia';
    case 'iptu':
      return 'IPTU';
    case 'seguro':
      return 'Seguro';
    case 'manutencao_moto':
      return 'Manutenção';
    case 'reparo':
      return 'Reparo';
    case 'reforma':
      return 'Reforma';
    default:
      return 'Serviços';
  }
};

export const getRecurrenceLabel = (rec: ExpenseRecurrence): string => {
  switch (rec) {
    case 'mensal':
      return 'Mensal';
    case 'anual':
      return 'Anual';
    case 'trimestral':
      return 'Trimestral';
    case 'semestral':
      return 'Semestral';
    default:
      return 'Eventual';
  }
};

export const getExpenseStatus = (exp: Expense): 'pago' | 'vencido' | 'pendente' => {
  if (exp.status === 'pago') return 'pago';
  const today = getTodayLocalDateString();
  if (exp.dueDate < today) return 'vencido';
  return 'pendente';
};
