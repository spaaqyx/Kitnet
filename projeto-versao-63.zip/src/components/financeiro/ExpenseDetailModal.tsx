import React from 'react';
import { createPortal } from 'react-dom';
import { X, Trash2, CreditCard } from 'lucide-react';
import { Expense } from '../../types';
import { formatCurrency, formatDate } from '../../utils/formatters';
import {
  getCategoryCircleIcon,
  getCategoryLabel,
  getRecurrenceLabel,
  getExpenseStatus,
} from './financeiroHelpers';

interface ExpenseDetailModalProps {
  expense: Expense | null;
  onClose: () => void;
  onDelete: (expense: Expense) => void;
  onPay: (expense: Expense) => void;
}

export const ExpenseDetailModal: React.FC<ExpenseDetailModalProps> = ({
  expense,
  onClose,
  onDelete,
  onPay,
}) => {
  if (!expense || typeof document === 'undefined') return null;

  return createPortal(
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Detalhes da Despesa"
      className="fixed inset-0 z-[100] flex items-center justify-center p-2.5 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn font-sans"
    >
      <div className="bg-surface-subtle border border-white/[0.12] rounded-2xl sm:rounded-3xl w-full max-w-md max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl my-auto animate-modal-enter min-w-0">
        <div className="p-4 sm:p-5 border-b border-white/[0.08] flex items-center justify-between bg-surface-card shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-surface-card border border-white/[0.08] flex items-center justify-center">
              {getCategoryCircleIcon(expense.category)}
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Detalhes da Despesa</h3>
              <p className="text-xs text-slate-400 capitalize">{getCategoryLabel(expense.category)}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-white/[0.06] transition-colors cursor-pointer"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto min-h-0 p-4 sm:p-5 space-y-4 text-xs custom-scrollbar">
          <div className="space-y-2 p-4 bg-surface-card rounded-xl border border-white/[0.08]">
            <div className="flex justify-between">
              <span className="text-slate-400">Título Completo:</span>
              <span className="font-bold text-white text-right">{expense.title}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Recorrência:</span>
              <span className="font-medium text-slate-200 capitalize">{getRecurrenceLabel(expense.recurrence)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Vencimento:</span>
              <span className="font-medium text-slate-200">{formatDate(expense.dueDate)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Situação:</span>
              <span className="font-bold capitalize text-slate-200">
                {getExpenseStatus(expense)}
              </span>
            </div>
            {expense.paidDate && (
              <div className="flex justify-between">
                <span className="text-slate-400">Data de Quitação:</span>
                <span className="font-medium text-emerald-400">{formatDate(expense.paidDate)}</span>
              </div>
            )}
            {expense.notes && (
              <div className="pt-2 border-t border-white/[0.06]">
                <span className="text-slate-400 block mb-1">Observações:</span>
                <p className="text-slate-200 bg-surface-subtle p-2 rounded-lg">{expense.notes}</p>
              </div>
            )}
            <div className="pt-2 border-t border-white/[0.06] flex justify-between items-center">
              <span className="text-slate-300 font-bold">Valor Total:</span>
              <span className="text-base font-bold text-emerald-400 tabular-nums">
                {formatCurrency(expense.amount)}
              </span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-3 sm:p-4 border-t border-white/[0.08] flex items-center justify-between gap-2 bg-surface-card shrink-0">
          <button
            type="button"
            onClick={() => onDelete(expense)}
            className="px-3 py-2 text-xs font-semibold text-red-400 hover:text-red-300 rounded-xl hover:bg-red-500/10 transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <Trash2 className="w-4 h-4" />
            <span>Excluir</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 text-xs font-semibold text-slate-400 hover:text-white rounded-xl hover:bg-white/[0.05] transition-colors cursor-pointer"
            >
              Fechar
            </button>
            {expense.status !== 'pago' && (
              <button
                type="button"
                onClick={() => onPay(expense)}
                className="px-4 py-2 bg-money-positive hover:bg-money-positive-hover text-white font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-md shadow-money-positive/25 active:scale-95 transition-all"
              >
                <CreditCard className="w-4 h-4" />
                <span>Pagar Agora</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
};
