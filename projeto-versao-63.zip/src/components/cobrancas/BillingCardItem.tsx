import React from 'react';
import { motion } from 'motion/react';
import { Motorbike, Home, Check, MessageCircle, CheckCheck } from 'lucide-react';
import { BillingItem } from './types';
import { formatCurrency, formatDate } from '../../utils/formatters';

interface BillingCardItemProps {
  item: BillingItem;
  isSelected: boolean;
  onToggleSelect: (id: string) => void;
  onOpenWhatsApp: (contractId: string, installmentId?: string) => void;
  onOpenSinglePay: (item: BillingItem) => void;
  onOpenClientProfile?: (tenantId: string, type: 'moto' | 'kitnet') => void;
}

export const BillingCardItem: React.FC<BillingCardItemProps> = ({
  item,
  isSelected,
  onToggleSelect,
  onOpenWhatsApp,
  onOpenSinglePay,
  onOpenClientProfile,
}) => {
  const isAtrasado = item.status === 'atrasado';
  const isHoje = item.status === 'vencendo_hoje';
  const is7Dias = item.status === 'proximos_7_dias';
  const isEmDia = item.status === 'em_dia';

  return (
    <motion.div
      layout="position"
      id={`billing-card-${item.id}`}
      className={`bg-surface-base border rounded-xl p-4 sm:p-5 transition-colors duration-200 flex flex-col lg:flex-row lg:items-center justify-between gap-4 ${
        isSelected
          ? 'border-action-primary bg-action-primary/[0.05] shadow-md shadow-action-primary/10 ring-1 ring-action-primary/30'
          : isAtrasado
          ? 'border-money-negative/40 hover:border-money-negative animate-pulse-red-subtle'
          : isHoje
          ? 'border-category-motos-alt/40 hover:border-category-motos-alt'
          : is7Dias
          ? 'border-action-primary/30 hover:border-action-primary/60'
          : 'border-white/[0.06] hover:border-white/[0.15]'
      }`}
    >
      {/* Left: Checkbox (only for actionable items), Client & Asset info */}
      <div className="flex items-start gap-3.5 flex-1 min-w-0">
        {/* Checkbox Selector ONLY for items that require collection */}
        {!isEmDia && (
          <button
            type="button"
            onClick={() => onToggleSelect(item.id)}
            className={`mt-1.5 w-5 h-5 rounded flex items-center justify-center border transition-colors duration-150 cursor-pointer shrink-0 ${
              isSelected
                ? 'bg-action-primary border-action-primary text-white'
                : 'bg-surface-card border-white/[0.15] text-transparent hover:border-action-primary'
            }`}
            title={isSelected ? 'Desmarcar' : 'Selecionar para cobrança em lote'}
          >
            <Check className="w-3.5 h-3.5 stroke-[3]" />
          </button>
        )}

        <div
          className={`p-2.5 rounded-lg border shrink-0 mt-1 ${
            item.assetType === 'moto'
              ? 'bg-category-motos/10 border-category-motos/25 text-category-motos'
              : 'bg-category-kitnets-sky/10 border-category-kitnets-sky/25 text-category-kitnets-sky'
          }`}
        >
          {item.assetType === 'moto' ? <Motorbike className="w-5 h-5" /> : <Home className="w-5 h-5" />}
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span
              onClick={() => onOpenClientProfile && onOpenClientProfile(item.tenantId, item.assetType)}
              className="text-base font-semibold text-text-primary hover:text-action-primary cursor-pointer transition-colors duration-150"
            >
              {item.clientName}
            </span>

            {isAtrasado && (
              <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-money-negative/15 text-money-negative border border-money-negative/30">
                {item.daysOverdue} {item.daysOverdue === 1 ? 'dia' : 'dias'} em atraso
              </span>
            )}
            {isHoje && (
              <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-category-motos-alt/15 text-category-motos-alt border border-category-motos-alt/30">
                Vence Hoje
              </span>
            )}
            {is7Dias && (
              <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-action-primary/15 text-action-primary border border-action-primary/30">
                Vence em breve
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 text-xs text-text-secondary mt-1 flex-wrap">
            <span className="font-semibold text-text-primary">{item.assetName}</span>
            <span>•</span>
            <span className={item.assetType === 'moto' ? 'text-category-motos font-medium' : 'text-category-kitnets-sky font-medium'}>
              {item.assetDetails}
            </span>
            <span>•</span>
            <span>
              Parcela: <strong className="text-text-primary tabular-nums">{item.installmentNumber}/{item.totalInstallments}</strong>
            </span>
            <span>•</span>
            <span>
              Vencimento: <strong className="text-text-primary tabular-nums">{formatDate(item.dueDate)}</strong>
            </span>
          </div>

          {/* Visual Contract Progress Bar */}
          <div className="mt-3 max-w-md">
            <div className="flex items-center justify-between text-[11px] text-text-secondary mb-1">
              <span className="text-text-primary font-mono text-xs">{item.progressVisual}</span>
              <span className="font-bold text-action-primary tabular-nums">{item.progressPercent}% concluído</span>
            </div>
            <div className="w-full bg-surface-card rounded-full h-1.5 overflow-hidden border border-white/[0.06]">
              <div
                className="h-full bg-action-primary rounded-full transition-all duration-500"
                style={{ width: `${item.progressPercent}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[10px] text-text-secondary mt-1">
              <span>
                Pago: <strong className="text-money-positive tabular-nums">{item.paidCount}x ({formatCurrency(item.paidAmount)})</strong>
              </span>
              <span>
                Restam: <strong className="text-text-secondary tabular-nums">{item.pendingCount}x ({formatCurrency(item.remainingAmount)})</strong>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Right: Value & Fast Actions */}
      <div className="flex items-center justify-between lg:justify-end gap-3 pt-3 lg:pt-0 border-t lg:border-t-0 border-white/[0.06]">
        <div className="text-left lg:text-right">
          <span className="text-[10px] text-text-secondary uppercase font-semibold">Valor da Parcela</span>
          <div className="text-lg font-bold text-text-primary tabular-nums whitespace-nowrap">
            {formatCurrency(item.amount)}
          </div>
          {isAtrasado && item.daysOverdue > 0 && (
            <div className="text-[11px] text-money-negative font-semibold tabular-nums whitespace-nowrap mt-0.5" title={`Multa: ${formatCurrency(item.fineAmount)} | Juros: ${formatCurrency(item.interestAmount)}`}>
              Total c/ encargos: {formatCurrency(item.totalDueWithCharges)}
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          {isEmDia ? (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-money-positive/10 border border-money-positive/25 text-money-positive text-xs font-semibold whitespace-nowrap">
              <span>Pontual</span>
            </div>
          ) : (
            <>
              {/* Botão de Cobrança / Lembrete */}
              <button
                id={`btn-cobrar-${item.id}`}
                onClick={() => onOpenWhatsApp(item.contractId, item.installmentId)}
                className={`px-3.5 py-2 text-xs font-bold flex items-center gap-1.5 cursor-pointer whitespace-nowrap rounded-lg transition-colors duration-150 active:scale-95 ${
                  is7Dias
                    ? 'bg-action-primary/15 hover:bg-action-primary/25 text-action-light border border-action-primary/30'
                    : 'btn-primary'
                }`}
                title="Gerar cobrança no WhatsApp"
              >
                <MessageCircle className="w-4 h-4" />
                {is7Dias ? 'Lembrete' : 'Cobrar'}
              </button>

              {/* Baixa de Pagamento Rápida (apenas para parcelas com pendência / vencimento próximo) */}
              <button
                id={`btn-baixa-${item.id}`}
                onClick={() => onOpenSinglePay(item)}
                className="p-2 bg-surface-card hover:bg-surface-elevated text-money-positive hover:text-money-positive rounded-lg transition-colors duration-150 border border-white/[0.08] hover:border-money-positive/40 cursor-pointer active:scale-95 shadow-sm"
                title="Registrar baixa de pagamento recebido"
              >
                <CheckCheck className="w-4 h-4" />
              </button>
            </>
          )}
        </div>
      </div>
    </motion.div>
  );
};
