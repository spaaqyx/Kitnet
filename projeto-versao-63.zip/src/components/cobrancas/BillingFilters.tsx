import React from 'react';
import { motion } from 'motion/react';
import { Search, Motorbike, Home, AlertCircle, Clock, Calendar, CheckCircle2 } from 'lucide-react';
import { useScrollActiveIntoView } from '../../hooks/useScrollActiveIntoView';

interface BillingFiltersProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  filterType: 'todos' | 'moto' | 'kitnet';
  setFilterType: (type: 'todos' | 'moto' | 'kitnet') => void;
  activeCategory: 'todos' | 'atrasado' | 'vencendo_hoje' | 'proximos_7_dias' | 'em_dia';
  setActiveCategory: (cat: 'todos' | 'atrasado' | 'vencendo_hoje' | 'proximos_7_dias' | 'em_dia') => void;
  motosCount: number;
  kitnetsCount: number;
  atrasadosCount: number;
  vencendoHojeCount: number;
  proximos7DiasCount: number;
  emDiaCount: number;
  totalCount: number;
}

export const BillingFilters: React.FC<BillingFiltersProps> = ({
  searchQuery,
  setSearchQuery,
  filterType,
  setFilterType,
  activeCategory,
  setActiveCategory,
  motosCount,
  kitnetsCount,
  atrasadosCount,
  vencendoHojeCount,
  proximos7DiasCount,
  emDiaCount,
  totalCount,
}) => {
  const { containerRef, registerItem, scrollItemIntoView } = useScrollActiveIntoView(activeCategory);

  const statusCategories = [
    {
      id: 'todos' as const,
      label: 'Todos',
      count: totalCount,
      icon: null,
      activeClass: 'bg-gradient-to-r from-purple-500/25 via-purple-500/15 to-violet-500/20 text-purple-200 border-purple-400/90 font-bold',
      badgeClass: 'bg-purple-500 text-slate-950 font-black',
      hoverClass: 'hover:border-purple-500/50 hover:bg-purple-500/[0.08] hover:text-purple-300',
    },
    {
      id: 'atrasado' as const,
      label: 'Atrasados',
      count: atrasadosCount,
      icon: <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />,
      activeClass: 'bg-gradient-to-r from-rose-500/25 via-rose-500/15 to-red-500/20 text-rose-200 border-rose-400/90 font-bold',
      badgeClass: 'bg-rose-500 text-slate-950 font-black',
      hoverClass: 'hover:border-rose-500/50 hover:bg-rose-500/[0.08] hover:text-rose-300',
    },
    {
      id: 'vencendo_hoje' as const,
      label: 'Vencendo Hoje',
      count: vencendoHojeCount,
      icon: <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0" />,
      activeClass: 'bg-gradient-to-r from-amber-500/25 via-amber-500/15 to-orange-500/20 text-amber-200 border-amber-400/90 font-bold',
      badgeClass: 'bg-amber-500 text-slate-950 font-black',
      hoverClass: 'hover:border-amber-500/50 hover:bg-amber-500/[0.08] hover:text-amber-300',
    },
    {
      id: 'proximos_7_dias' as const,
      label: 'Próximos 7 Dias',
      count: proximos7DiasCount,
      icon: <Calendar className="w-3.5 h-3.5 text-sky-400 shrink-0" />,
      activeClass: 'bg-gradient-to-r from-sky-500/25 via-sky-500/15 to-cyan-500/20 text-sky-200 border-sky-400/90 font-bold',
      badgeClass: 'bg-sky-500 text-slate-950 font-black',
      hoverClass: 'hover:border-sky-500/50 hover:bg-sky-500/[0.08] hover:text-sky-300',
    },
    {
      id: 'em_dia' as const,
      label: 'Em Dia',
      count: emDiaCount,
      icon: <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />,
      activeClass: 'bg-gradient-to-r from-emerald-500/25 via-emerald-500/15 to-teal-500/20 text-emerald-200 border-emerald-400/90 font-bold',
      badgeClass: 'bg-emerald-500 text-slate-950 font-black',
      hoverClass: 'hover:border-emerald-500/50 hover:bg-emerald-500/[0.08] hover:text-emerald-300',
    },
  ];
  return (
    <div className="bg-surface-base border border-white/[0.06] p-4 rounded-xl space-y-3">
      {/* Top row: Search and Asset Type */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-text-secondary" />
          <input
            type="text"
            placeholder="Buscar por cliente, placa, CPF ou kitnet..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-surface-card border border-white/[0.08] rounded-lg pl-9 pr-4 py-2 text-xs sm:text-sm text-text-primary placeholder-text-secondary/60 focus:outline-none focus:border-action-primary transition-all"
          />
        </div>

        {/* Asset Type Selector */}
        <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0 scrollbar-none no-scrollbar">
          <button
            type="button"
            onClick={() => setFilterType('todos')}
            className={`shrink-0 min-w-max px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer border ${
              filterType === 'todos'
                ? 'bg-gradient-to-r from-purple-500/25 via-purple-500/15 to-violet-500/20 text-purple-200 border-purple-400/90'
                : 'bg-surface-input text-slate-400 border-white/[0.08] hover:border-purple-500/50 hover:bg-purple-500/[0.08] hover:text-purple-300'
            }`}
          >
            Todos os Ativos ({motosCount + kitnetsCount})
          </button>
          <button
            type="button"
            onClick={() => setFilterType('moto')}
            className={`shrink-0 min-w-max px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer border ${
              filterType === 'moto'
                ? 'bg-gradient-to-r from-amber-500/25 via-amber-500/15 to-orange-500/20 text-amber-200 border-amber-400/90'
                : 'bg-surface-input text-slate-400 border-white/[0.08] hover:border-amber-500/50 hover:bg-amber-500/[0.08] hover:text-amber-300'
            }`}
          >
            <Motorbike className={`w-3.5 h-3.5 shrink-0 ${filterType === 'moto' ? 'text-amber-300' : 'text-slate-400'}`} />
            <span>Motos ({motosCount})</span>
          </button>
          <button
            type="button"
            onClick={() => setFilterType('kitnet')}
            className={`shrink-0 min-w-max px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer border ${
              filterType === 'kitnet'
                ? 'bg-gradient-to-r from-sky-500/25 via-sky-500/15 to-cyan-500/20 text-sky-200 border-sky-400/90'
                : 'bg-surface-input text-slate-400 border-white/[0.08] hover:border-sky-500/50 hover:bg-sky-500/[0.08] hover:text-sky-300'
            }`}
          >
            <Home className={`w-3.5 h-3.5 shrink-0 ${filterType === 'kitnet' ? 'text-sky-300' : 'text-slate-400'}`} />
            <span>Kitnets ({kitnetsCount})</span>
          </button>
        </div>
      </div>

      {/* Bottom row: Status Filter Badges with smooth auto-center */}
      <div
        ref={containerRef}
        className="flex items-center gap-2 overflow-x-auto pt-2 border-t border-white/[0.06] pb-1 scrollbar-none no-scrollbar scroll-smooth touch-pan-x"
      >
        {statusCategories.map((cat) => {
          const isSelected = activeCategory === cat.id;
          return (
            <motion.button
              key={cat.id}
              ref={registerItem(cat.id)}
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => {
                setActiveCategory(cat.id);
                scrollItemIntoView(cat.id);
              }}
              className={`shrink-0 min-w-max px-3.5 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 border select-none ${
                isSelected
                  ? cat.activeClass
                  : `bg-surface-input text-slate-400 border-white/[0.08] ${cat.hoverClass}`
              }`}
            >
              {cat.icon}
              <span className={`shrink-0 whitespace-nowrap ${isSelected ? 'font-bold' : ''}`}>{cat.label}</span>
              <span
                className={`shrink-0 inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full text-[11px] font-bold tabular-nums transition-all ${
                  isSelected ? cat.badgeClass : 'bg-surface-card text-slate-400 border border-white/[0.06]'
                }`}
              >
                {cat.count}
              </span>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
};
