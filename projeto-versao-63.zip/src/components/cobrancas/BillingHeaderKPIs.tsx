import React from 'react';
import { ArrowLeft, DollarSign, Send } from 'lucide-react';
import { TabType } from '../../types';
import { formatCurrency } from '../../utils/formatters';
import { AnimatedNumber } from '../AnimatedNumber';
import { BillingItem } from './types';

interface BillingHeaderKPIsProps {
  onNavigateTab?: (tab: TabType) => void;
  selectedForBatchCount: number;
  onOpenBatchModal: () => void;
  onSelectAllOverdueAndOpenModal: () => void;
  atrasados: BillingItem[];
  vencendoHoje: BillingItem[];
  proximos7Dias: BillingItem[];
  emDia: BillingItem[];
  totalAtrasadoAmount: number;
  totalHojeAmount: number;
  total7DiasAmount: number;
  activeCategory: 'todos' | 'atrasado' | 'vencendo_hoje' | 'proximos_7_dias' | 'em_dia';
  onToggleCategory: (cat: 'atrasado' | 'vencendo_hoje' | 'proximos_7_dias' | 'em_dia') => void;
}

export const BillingHeaderKPIs: React.FC<BillingHeaderKPIsProps> = ({
  onNavigateTab,
  selectedForBatchCount,
  onOpenBatchModal,
  onSelectAllOverdueAndOpenModal,
  atrasados,
  vencendoHoje,
  proximos7Dias,
  emDia,
  totalAtrasadoAmount,
  totalHojeAmount,
  total7DiasAmount,
  activeCategory,
  onToggleCategory,
}) => {
  return (
    <div className="space-y-4">
      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 app-card p-5 sm:p-6">
        <div className="flex items-center gap-3">
          {onNavigateTab && (
            <button
              onClick={() => onNavigateTab('dashboard')}
              className="p-2.5 rounded-lg bg-surface-card hover:bg-surface-elevated border border-white/[0.08] text-text-secondary hover:text-text-primary transition-all cursor-pointer flex items-center gap-1 text-xs font-semibold shrink-0 active:scale-95"
              title="Voltar ao Dashboard"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Dashboard</span>
            </button>
          )}

          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-action-primary/10 text-action-primary border border-action-primary/25 shrink-0">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-text-primary tracking-tight flex items-center gap-2">
                Central de Cobranças
              </h1>
              <p className="text-xs text-text-secondary mt-0.5">
                Gestão inteligente de cobranças com envio de mensagens no WhatsApp e baixa direta
              </p>
            </div>
          </div>
        </div>

        {/* Global Action Header Button */}
        <div className="flex items-center gap-2.5">
          {selectedForBatchCount > 0 ? (
            <button
              onClick={onOpenBatchModal}
              className="btn-primary px-4 py-2.5 text-xs sm:text-sm font-bold flex items-center gap-2 cursor-pointer whitespace-nowrap active:scale-95 transition-transform"
            >
              <Send className="w-4 h-4 stroke-[2.5]" />
              Encaminhar para Selecionados ({selectedForBatchCount})
            </button>
          ) : (
            <button
              onClick={onSelectAllOverdueAndOpenModal}
              className="btn-primary px-4 py-2.5 text-xs sm:text-sm font-bold flex items-center gap-2 cursor-pointer whitespace-nowrap active:scale-95 transition-transform"
            >
              <Send className="w-4 h-4 stroke-[2.5]" />
              Cobrar em Lote ({atrasados.length + vencendoHoje.length})
            </button>
          )}
        </div>
      </div>

      {/* 4 Smart Buckets Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. ATRASADOS */}
        <div
          onClick={() => onToggleCategory('atrasado')}
          className={`cursor-pointer p-4 sm:p-5 rounded-xl border transition-all duration-200 ${
            atrasados.length > 0 ? 'animate-pulse-red-subtle' : ''
          } ${
            activeCategory === 'atrasado'
              ? 'bg-money-negative/10 border-money-negative/50 ring-1 ring-money-negative/40'
              : 'bg-surface-base border-white/[0.06] hover:border-money-negative/40'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-money-negative uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-money-negative animate-pulse" />
              Atrasados
            </span>
            <span className="text-xs px-2 py-0.5 rounded-md bg-money-negative/15 text-money-negative font-bold tabular-nums">
              <AnimatedNumber value={atrasados.length} format="number" /> parcelas
            </span>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-money-negative tabular-nums whitespace-nowrap">
              <AnimatedNumber value={totalAtrasadoAmount} format="currency" />
            </div>
            <p className="text-[11px] text-text-secondary mt-0.5">Exigem contato imediato</p>
          </div>
        </div>

        {/* 2. VENCENDO HOJE */}
        <div
          onClick={() => onToggleCategory('vencendo_hoje')}
          className={`cursor-pointer p-4 sm:p-5 rounded-xl border transition-all duration-200 ${
            activeCategory === 'vencendo_hoje'
              ? 'bg-category-motos-alt/10 border-category-motos-alt/50 ring-1 ring-category-motos-alt/40'
              : 'bg-surface-base border-white/[0.06] hover:border-category-motos-alt/40'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-category-motos-alt uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-category-motos-alt" />
              Vencendo Hoje
            </span>
            <span className="text-xs px-2 py-0.5 rounded-md bg-category-motos-alt/15 text-category-motos-alt font-bold tabular-nums">
              <AnimatedNumber value={vencendoHoje.length} format="number" /> parcelas
            </span>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-category-motos-alt tabular-nums whitespace-nowrap">
              <AnimatedNumber value={totalHojeAmount} format="currency" />
            </div>
            <p className="text-[11px] text-text-secondary mt-0.5">Vencimento na data corrente</p>
          </div>
        </div>

        {/* 3. VENCENDO EM ATÉ 7 DIAS */}
        <div
          onClick={() => onToggleCategory('proximos_7_dias')}
          className={`cursor-pointer p-4 sm:p-5 rounded-xl border transition-all duration-200 ${
            activeCategory === 'proximos_7_dias'
              ? 'bg-action-primary/10 border-action-primary/50 ring-1 ring-action-primary/40'
              : 'bg-surface-base border-white/[0.06] hover:border-action-primary/40'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-text-secondary uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-text-secondary" />
              Próximos 7 Dias
            </span>
            <span className="text-xs px-2 py-0.5 rounded-md bg-surface-card text-text-primary font-bold tabular-nums border border-white/[0.06]">
              <AnimatedNumber value={proximos7Dias.length} format="number" /> parcelas
            </span>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-text-primary tabular-nums whitespace-nowrap">
              <AnimatedNumber value={total7DiasAmount} format="currency" />
            </div>
            <p className="text-[11px] text-text-secondary mt-0.5">Lembretes preventivos</p>
          </div>
        </div>

        {/* 4. EM DIA */}
        <div
          onClick={() => onToggleCategory('em_dia')}
          className={`cursor-pointer p-4 sm:p-5 rounded-xl border transition-all duration-200 ${
            activeCategory === 'em_dia'
              ? 'bg-money-positive/10 border-money-positive/50 ring-1 ring-money-positive/40'
              : 'bg-surface-base border-white/[0.06] hover:border-money-positive/40'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-money-positive uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-money-positive" />
              Em Dia
            </span>
            <span className="text-xs px-2 py-0.5 rounded-md bg-money-positive/15 text-money-positive font-bold tabular-nums">
              <AnimatedNumber value={emDia.length} format="number" /> parcelas
            </span>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-money-positive tabular-nums whitespace-nowrap">
              <AnimatedNumber value={emDia.reduce((acc, i) => acc + i.amount, 0)} format="currency" />
            </div>
            <p className="text-[11px] text-text-secondary mt-0.5">Contratos regulares</p>
          </div>
        </div>
      </div>
    </div>
  );
};
