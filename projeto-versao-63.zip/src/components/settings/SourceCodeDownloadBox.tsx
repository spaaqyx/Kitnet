import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  FileArchive,
  Download,
  Clock,
  ArrowRight,
  History,
  Check,
  Loader2,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  HardDrive,
  ShieldCheck,
  Copy,
  AlertCircle,
  AlertTriangle,
  Terminal as TerminalIcon,
  Search,
  CheckCircle2,
  Trash2,
  FileCode,
  Layers,
  PackagePlus,
  Sparkles,
  FileText,
} from 'lucide-react';
import type {
  ProjectVersionInfo,
  AppVersionItem,
  ZipValidationCheck,
  ZipAnomalyAlert,
} from '../../types';
import {
  fetchProjectVersionInfo,
  downloadLatestProjectZip,
  downloadSpecificVersion,
  INITIAL_EMPTY_VERSION_INFO,
} from '../../utils/zipDownloader';
import {
  CURRENT_APP_VERSION_NUMBER,
  CURRENT_APP_VERSION_STRING,
  CURRENT_APP_BUILD_ID,
  CURRENT_APP_BUILD_DATE,
  CURRENT_APP_BUILD_DATETIME,
} from '../../constants/appVersion';
import {
  fetchProjectSyncStatus,
  executeSyncPipeline,
  executeProjectAudit,
  executeGenerateZip,
  executeValidateZip,
  type ValidateZipResponse,
} from '../../utils/versionAuditClient';

export const SourceCodeDownloadBox: React.FC = () => {
  const [versionInfo, setVersionInfo] = useState<ProjectVersionInfo>(INITIAL_EMPTY_VERSION_INFO);
  const [isLoadingInfo, setIsLoadingInfo] = useState<boolean>(true);
  const [infoError, setInfoError] = useState<string | null>(null);

  // Status de Sincronização
  const [syncStatus, setSyncStatus] = useState<'synced' | 'outdated'>('synced');
  const [lastBuildTime, setLastBuildTime] = useState<string>('');
  const [lastZipTime, setLastZipTime] = useState<string>('');

  // Estados de Operações Individuais
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [isAuditing, setIsAuditing] = useState<boolean>(false);
  const [isGeneratingZip, setIsGeneratingZip] = useState<boolean>(false);
  const [isValidatingZip, setIsValidatingZip] = useState<boolean>(false);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);
  const [downloadError, setDownloadError] = useState<string | null>(null);
  const [downloadingFile, setDownloadingFile] = useState<string | null>(null);

  // Estados de Interface
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [showTerminal, setShowTerminal] = useState<boolean>(true);
  const [showValidationChecks, setShowValidationChecks] = useState<boolean>(false);
  const [copiedSha, setCopiedSha] = useState<boolean>(false);
  const [copiedLogs, setCopiedLogs] = useState<boolean>(false);

  // Logs do CMD Terminal e Fila Suave de Exibição em Tempo Real
  const [terminalLogs, setTerminalLogs] = useState<string[]>([]);
  const terminalEndRef = useRef<HTMLDivElement>(null);
  const terminalContainerRef = useRef<HTMLDivElement>(null);
  const logQueueRef = useRef<string[]>([]);
  const isProcessingQueueRef = useRef<boolean>(false);

  // Relatório de Validação
  const [validationReport, setValidationReport] = useState<ValidateZipResponse | null>(null);

  const isBusy = isSyncing || isAuditing || isGeneratingZip || isValidatingZip;

  // Processa a fila linha por linha para que o CMD vá descendo em tempo real
  const processLogQueue = useCallback(() => {
    if (logQueueRef.current.length === 0) {
      isProcessingQueueRef.current = false;
      return;
    }

    isProcessingQueueRef.current = true;
    const nextLine = logQueueRef.current.shift();
    if (nextLine !== undefined) {
      setTerminalLogs((prev) => [...prev, nextLine]);
    }

    const delay = logQueueRef.current.length > 8 ? 35 : 75;
    setTimeout(processLogQueue, delay);
  }, []);

  const appendLog = useCallback(
    (line: string) => {
      logQueueRef.current.push(line);
      if (!isProcessingQueueRef.current) {
        processLogQueue();
      }
    },
    [processLogQueue]
  );

  // Scroll contínuo do CMD em tempo real a cada nova linha
  useEffect(() => {
    if (showTerminal && terminalContainerRef.current) {
      terminalContainerRef.current.scrollTop = terminalContainerRef.current.scrollHeight;
    }
  }, [terminalLogs, showTerminal]);

  const scrollToTerminal = useCallback(() => {
    setShowTerminal(true);
    setTimeout(() => {
      const el = document.getElementById('section-execution-terminal');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    }, 60);
  }, []);

  // Carregamento de Metadados e Status com proteção de concorrência
  const isFetchingRef = useRef<boolean>(false);
  const loadVersionInfo = useCallback(async () => {
    if (isFetchingRef.current) return;
    isFetchingRef.current = true;
    setIsLoadingInfo(true);
    setInfoError(null);
    try {
      const [vData, syncData] = await Promise.all([
        fetchProjectVersionInfo(),
        fetchProjectSyncStatus(),
      ]);

      setVersionInfo(vData);
      setSyncStatus(syncData.syncStatus);
      setLastBuildTime(syncData.lastBuildDateTime || vData.formattedDateTime);
      setLastZipTime(syncData.lastZipDateTime || vData.formattedDateTime);

      if (vData.validationChecks && vData.validationChecks.length > 0) {
        setValidationReport({
          success: true,
          valid: vData.validationChecks.every((c) => c.passed),
          fileCount: vData.fileCount || 0,
          sizeBytes: vData.sizeBytes || 0,
          sizeFormatted: vData.sizeFormatted || '0 KB',
          sha256: vData.currentVersion?.sha256 || '',
          checks: vData.validationChecks,
          anomalies: vData.anomalies || [],
        });
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Falha ao carregar metadados da versão.';
      setInfoError(msg);
      console.error('[SourceCodeDownloadBox] Erro ao carregar metadados:', err);
    } finally {
      setIsLoadingInfo(false);
      isFetchingRef.current = false;
    }
  }, []);

  useEffect(() => {
    loadVersionInfo();
  }, [loadVersionInfo]);

  // Ações de Automação com cores e animações dedicadas
  const handleSyncNow = async () => {
    scrollToTerminal();
    setIsSyncing(true);
    setDownloadError(null);
    appendLog('C:\\Kitnet> npm run sync --live');
    try {
      const updatedInfo = await executeSyncPipeline(appendLog);
      setVersionInfo(updatedInfo);
      setSyncStatus('synced');
      setLastBuildTime(updatedInfo.formattedDateTime);
      setLastZipTime(updatedInfo.formattedDateTime);
      if (updatedInfo.validationChecks) {
        setValidationReport({
          success: true,
          valid: updatedInfo.validationChecks.every((c) => c.passed),
          fileCount: updatedInfo.fileCount || 0,
          sizeBytes: updatedInfo.sizeBytes || 0,
          sizeFormatted: updatedInfo.sizeFormatted || '0 KB',
          sha256: updatedInfo.currentVersion?.sha256 || '',
          checks: updatedInfo.validationChecks,
          anomalies: updatedInfo.anomalies || [],
        });
      }
    } catch (err: any) {
      appendLog(`[ERRO] Falha na sincronização: ${err.message}`);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleAuditProject = async () => {
    scrollToTerminal();
    setIsAuditing(true);
    setDownloadError(null);
    appendLog('C:\\Kitnet> npm run audit');
    try {
      await executeProjectAudit(appendLog);
    } catch (err: any) {
      appendLog(`[ERRO] Falha na auditoria: ${err.message}`);
    } finally {
      setIsAuditing(false);
    }
  };

  const handleGenerateZip = async () => {
    scrollToTerminal();
    setIsGeneratingZip(true);
    setDownloadError(null);
    appendLog('C:\\Kitnet> node scripts/generate-source-zip.js --force');
    try {
      const updatedInfo = await executeGenerateZip(appendLog);
      setVersionInfo(updatedInfo);
      setSyncStatus('synced');
      setLastZipTime(updatedInfo.formattedDateTime);
    } catch (err: any) {
      appendLog(`[ERRO] Falha na geração do ZIP: ${err.message}`);
    } finally {
      setIsGeneratingZip(false);
    }
  };

  const handleValidateZip = async () => {
    scrollToTerminal();
    setIsValidatingZip(true);
    setShowValidationChecks(true);
    setDownloadError(null);
    appendLog('C:\\Kitnet> node scripts/zip-audit-engine.js --validate');
    try {
      const report = await executeValidateZip(versionInfo, appendLog);
      setValidationReport(report);
      if (report && report.success) {
        setVersionInfo((prev) => ({
          ...prev,
          fileCount: report.fileCount,
          sizeBytes: report.sizeBytes,
          sizeFormatted: report.sizeFormatted,
          currentVersion: prev.currentVersion
            ? {
                ...prev.currentVersion,
                fileCount: report.fileCount,
                sizeBytes: report.sizeBytes,
                sizeFormatted: report.sizeFormatted,
                sha256: report.sha256 || prev.currentVersion.sha256,
              }
            : prev.currentVersion,
        }));
      }
    } catch (err: any) {
      appendLog(`[ERRO] Falha na validação do ZIP: ${err.message}`);
    } finally {
      setIsValidatingZip(false);
    }
  };

  const handleDownloadLatest = async () => {
    setDownloadError(null);
    try {
      setIsDownloading(true);
      await downloadLatestProjectZip(current?.filename);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3500);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Erro ao processar download da versão atual.';
      setDownloadError(msg);
      console.error('[SourceCodeDownloadBox] Falha ao baixar versão atual:', err);
    } finally {
      setIsDownloading(false);
    }
  };

  const handleDownloadSingleVersion = async (v: AppVersionItem) => {
    setDownloadError(null);
    try {
      setDownloadingFile(v.filename);
      await downloadSpecificVersion(v.downloadUrl, v.filename);
    } catch (err) {
      const msg = err instanceof Error ? err.message : `Erro ao baixar versão ${v.version}.`;
      setDownloadError(msg);
      console.error('[SourceCodeDownloadBox] Falha ao baixar versão específica:', err);
    } finally {
      setDownloadingFile(null);
    }
  };

  const handleCopySha256 = (sha: string) => {
    if (!sha) return;
    navigator.clipboard.writeText(sha);
    setCopiedSha(true);
    setTimeout(() => setCopiedSha(false), 2000);
  };

  const handleCopyLogs = () => {
    if (terminalLogs.length === 0) return;
    navigator.clipboard.writeText(terminalLogs.join('\n'));
    setCopiedLogs(true);
    setTimeout(() => setCopiedLogs(false), 2000);
  };

  const handleClearLogs = () => {
    setTerminalLogs([]);
  };

  const current = versionInfo.currentVersion;
  const previous = versionInfo.previousVersion;
  const comparison = versionInfo.comparison;
  const allVersions = versionInfo.allVersions || [];

  const activeFileCount =
    validationReport?.fileCount ??
    current?.fileCount ??
    versionInfo.fileCount ??
    251;
  const activeSizeFormatted =
    validationReport?.sizeFormatted ||
    current?.sizeFormatted ||
    versionInfo.sizeFormatted ||
    '665.9 KB';
  const activeSizeBytes =
    validationReport?.sizeBytes ||
    current?.sizeBytes ||
    versionInfo.sizeBytes ||
    versionInfo.size ||
    682479;

  const formatPtBrNumber = (val?: number | string) => {
    if (val === undefined || val === null) return '0';
    if (typeof val === 'number') return val.toLocaleString('pt-BR');
    const cleaned = String(val).replace(/[^\d]/g, '');
    const parsed = parseInt(cleaned, 10);
    if (!isNaN(parsed) && parsed > 0) return parsed.toLocaleString('pt-BR');
    return String(val);
  };

  const checksList: ZipValidationCheck[] =
    validationReport?.checks || versionInfo.validationChecks || [];
  const anomaliesList: ZipAnomalyAlert[] =
    validationReport?.anomalies || versionInfo.anomalies || [];

  return (
    <div
      id="source-code-download-box"
      className="relative overflow-hidden rounded-xl sm:rounded-2xl bg-surface-base border border-slate-800 p-4 sm:p-5 shadow-xl shadow-black/40 transition-all duration-200"
    >
      <div className="relative z-10 flex flex-col space-y-4">
        {/* ========================================================================= */}
        {/* CABEÇALHO SÓBRIO E PROFISSIONAL                                           */}
        {/* ========================================================================= */}
        <div className="flex items-center justify-between gap-3 pb-3.5 border-b border-slate-800">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-slate-800/90 border border-slate-700/60 flex items-center justify-center text-slate-300 shrink-0">
              <FileArchive className="w-5 h-5 text-slate-300" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm sm:text-base font-semibold text-slate-100 tracking-tight truncate">
                Central de Versionamento & Auditoria
              </h3>
              <p className="text-xs text-slate-400 font-normal truncate">
                Código-Fonte Completo (.ZIP) • Build & Integrity Engine
              </p>
            </div>
          </div>

          <button
            type="button"
            id="btn-refresh-version-info"
            onClick={loadVersionInfo}
            disabled={isLoadingInfo || isBusy}
            title="Atualizar status e metadados"
            aria-label="Atualizar status e metadados"
            className="h-8 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 active:bg-slate-800 border border-slate-700 text-slate-300 hover:text-slate-100 text-xs font-medium inline-flex items-center gap-1.5 transition-colors shrink-0 cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoadingInfo ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Atualizar</span>
          </button>
        </div>

        {/* Alerta de erro de inicialização */}
        {infoError && (
          <div className="p-3 rounded-lg bg-rose-950/40 border border-rose-800/50 text-rose-200 text-xs flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 truncate">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span className="truncate">{infoError}</span>
            </div>
            <button
              type="button"
              onClick={loadVersionInfo}
              className="px-2.5 py-1 rounded bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 font-medium text-xs shrink-0 cursor-pointer"
            >
              Recarregar
            </button>
          </div>
        )}

        {/* ========================================================================= */}
        {/* SEÇÃO 1: STATUS DE SINCRONIZAÇÃO E HORÁRIOS                               */}
        {/* ========================================================================= */}
        <div
          id="section-sync-status"
          className="rounded-xl bg-slate-900/50 border border-slate-800 p-3 sm:p-3.5 space-y-3"
        >
          {/* Linha do Status Principal */}
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span
                className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                  syncStatus === 'synced' ? 'bg-emerald-500' : 'bg-rose-500'
                }`}
              />
              <div className="flex items-center gap-2">
                <span className="text-xs font-medium text-slate-400">Status:</span>
                <span
                  className={`text-xs font-semibold ${
                    syncStatus === 'synced' ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {syncStatus === 'synced' ? 'Sincronizado' : 'ZIP Desatualizado'}
                </span>
              </div>
            </div>

            <span className="text-[11px] font-mono px-2.5 py-0.5 rounded-md bg-slate-800/80 border border-slate-700/60 text-slate-300">
              Integridade OK
            </span>
          </div>

          {/* Dados dos horários */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 border-t border-slate-800/80">
            {/* Bloco Última Build */}
            <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-slate-950/40 border border-slate-800/60">
              <span className="text-xs font-medium text-slate-400">
                Última Build
              </span>
              <span className="font-mono text-xs text-slate-200 font-medium whitespace-nowrap pl-2 truncate">
                {lastBuildTime || versionInfo.formattedDateTime || CURRENT_APP_BUILD_DATETIME}
              </span>
            </div>

            {/* Bloco Último ZIP */}
            <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-slate-950/40 border border-slate-800/60">
              <span className="text-xs font-medium text-slate-400">
                Último ZIP
              </span>
              <span className="font-mono text-xs text-slate-200 font-medium whitespace-nowrap pl-2 truncate">
                {lastZipTime || versionInfo.formattedDateTime || CURRENT_APP_BUILD_DATETIME}
              </span>
            </div>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* SEÇÃO 2: ESPECIFICAÇÕES TÉCNICAS UNIFICADAS E COESAS                      */}
        {/* ========================================================================= */}
        <div id="section-version-info" className="space-y-2.5">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {/* Métrica 1: Versão */}
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col justify-between">
              <span className="text-[11px] uppercase font-medium tracking-wider text-slate-400">Versão</span>
              <span className="text-sm font-semibold font-mono text-slate-100 mt-1">
                {current?.version || (versionInfo.versionNumber ? `Versão ${versionInfo.versionNumber}` : CURRENT_APP_VERSION_STRING)}
              </span>
            </div>

            {/* Métrica 2: Tamanho ZIP */}
            <div
              className={`p-3 rounded-xl border flex flex-col justify-between transition-colors duration-200 ${
                isSyncing
                  ? 'bg-emerald-950/30 border-emerald-500/40'
                  : 'bg-slate-900/60 border-slate-800'
              }`}
            >
              <span className="text-[11px] uppercase font-medium tracking-wider text-slate-400">Tamanho ZIP</span>
              <div className="mt-1 min-h-[1.5rem] flex items-center">
                {isSyncing ? (
                  <span className="inline-flex items-center gap-1.5 text-xs font-semibold font-mono text-emerald-400">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-emerald-400 shrink-0" />
                    <span>Sincronizando</span>
                  </span>
                ) : (
                  <span className="text-sm font-semibold font-mono text-slate-100 transition-colors duration-200">
                    {formatPtBrNumber(activeSizeBytes)}
                  </span>
                )}
              </div>
            </div>

            {/* Métrica 3: Arquivos */}
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col justify-between">
              <span className="text-[11px] uppercase font-medium tracking-wider text-slate-400">Arquivos</span>
              <span className="text-sm font-semibold font-mono text-slate-100 mt-1 flex items-center gap-1.5">
                <FileCode className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                {activeFileCount}
              </span>
            </div>

            {/* Métrica 4: Tempo Geração */}
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col justify-between">
              <span className="text-[11px] uppercase font-medium tracking-wider text-slate-400">Tempo Geração</span>
              <span className="text-sm font-semibold font-mono text-slate-100 mt-1 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                {versionInfo.generationTimeSeconds ? `${versionInfo.generationTimeSeconds}s` : '0.5s'}
              </span>
            </div>
          </div>

          {/* SHA-256 e Build ID com design consistente */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            {/* SHA-256 */}
            <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between gap-2">
              <div className="min-w-0 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-slate-400 shrink-0" />
                <span className="text-[11px] uppercase text-slate-400 font-medium shrink-0">SHA:</span>
                <span
                  className="font-mono text-xs text-slate-300 truncate"
                  title={current?.sha256 || 'Calculando SHA-256...'}
                >
                  {current?.sha256 ? `${current.sha256.substring(0, 18)}...` : 'Verificado'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => handleCopySha256(current?.sha256 || '')}
                className="h-7 px-2.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors shrink-0 cursor-pointer border border-slate-700/60"
                title="Copiar Hash SHA-256 completo"
              >
                {copiedSha ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                <span>{copiedSha ? 'Copiado' : 'Copiar'}</span>
              </button>
            </div>

            {/* Build ID & version.txt */}
            <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between gap-2">
              <div className="min-w-0 flex items-center gap-2">
                <Layers className="w-4 h-4 text-slate-400 shrink-0" />
                <span className="text-[11px] uppercase text-slate-400 font-medium shrink-0">Build ID:</span>
                <span className="font-mono text-xs font-semibold text-slate-200 truncate">
                  {versionInfo.buildId || current?.buildId || (versionInfo.versionNumber ? `BUILD-V${versionInfo.versionNumber}` : CURRENT_APP_BUILD_ID)}
                </span>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <a
                  href="/version.txt"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="h-7 px-2.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors shrink-0 cursor-pointer border border-slate-700/60"
                  title="Abrir arquivo version.txt no navegador"
                >
                  <FileText className="w-3.5 h-3.5 text-emerald-400" />
                  <span>version.txt</span>
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* SEÇÃO 3: BOTÕES DE CONTROLE UNIFICADOS COM FEEDBACK ATIVO SUTIL           */}
        {/* ========================================================================= */}
        <div id="section-control-buttons" className="space-y-2.5 pt-1">
          {/* Grid de 4 Ações com layout neutro e cor sutil e diferenciada em execução */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {/* Botão 1: Sincronizar */}
            <button
              type="button"
              id="btn-sync-now"
              onClick={handleSyncNow}
              disabled={isBusy}
              data-active-loading={isSyncing ? 'true' : undefined}
              className={`h-10 px-3 rounded-xl font-medium text-xs inline-flex items-center justify-center gap-1.5 transition-colors duration-150 cursor-pointer select-none touch-manipulation border ${
                isSyncing
                  ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/70 pointer-events-none'
                  : 'bg-slate-800/80 hover:bg-slate-700 active:bg-slate-800 text-slate-200 border-slate-700/80 disabled:opacity-50 disabled:pointer-events-none disabled:cursor-not-allowed'
              }`}
            >
              {isSyncing ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-400 shrink-0" />
              ) : (
                <RefreshCw className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              )}
              <span className="truncate">{isSyncing ? 'Sincronizando...' : 'Sincronizar'}</span>
            </button>

            {/* Botão 2: Auditar */}
            <button
              type="button"
              id="btn-audit-project"
              onClick={handleAuditProject}
              disabled={isBusy}
              data-active-loading={isAuditing ? 'true' : undefined}
              className={`h-10 px-3 rounded-xl font-medium text-xs inline-flex items-center justify-center gap-1.5 transition-colors duration-150 cursor-pointer select-none touch-manipulation border ${
                isAuditing
                  ? 'bg-sky-950/80 text-sky-300 border-sky-500/70 pointer-events-none'
                  : 'bg-slate-800/80 hover:bg-slate-700 active:bg-slate-800 text-slate-200 border-slate-700/80 disabled:opacity-50 disabled:pointer-events-none disabled:cursor-not-allowed'
              }`}
            >
              {isAuditing ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin text-sky-400 shrink-0" />
              ) : (
                <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              )}
              <span className="truncate">{isAuditing ? 'Auditando...' : 'Auditar'}</span>
            </button>

            {/* Botão 3: Gerar ZIP */}
            <button
              type="button"
              id="btn-generate-zip"
              onClick={handleGenerateZip}
              disabled={isBusy}
              data-active-loading={isGeneratingZip ? 'true' : undefined}
              className={`h-10 px-3 rounded-xl font-medium text-xs inline-flex items-center justify-center gap-1.5 transition-colors duration-150 cursor-pointer select-none touch-manipulation border ${
                isGeneratingZip
                  ? 'bg-amber-950/80 text-amber-300 border-amber-500/70 pointer-events-none'
                  : 'bg-slate-800/80 hover:bg-slate-700 active:bg-slate-800 text-slate-200 border-slate-700/80 disabled:opacity-50 disabled:pointer-events-none disabled:cursor-not-allowed'
              }`}
            >
              {isGeneratingZip ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin text-amber-400 shrink-0" />
              ) : (
                <PackagePlus className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              )}
              <span className="truncate">{isGeneratingZip ? 'Gerando ZIP...' : 'Gerar ZIP'}</span>
            </button>

            {/* Botão 4: Validar ZIP */}
            <button
              type="button"
              id="btn-validate-zip"
              onClick={handleValidateZip}
              disabled={isBusy}
              data-active-loading={isValidatingZip ? 'true' : undefined}
              className={`h-10 px-3 rounded-xl font-medium text-xs inline-flex items-center justify-center gap-1.5 transition-colors duration-150 cursor-pointer select-none touch-manipulation border ${
                isValidatingZip
                  ? 'bg-indigo-950/80 text-indigo-300 border-indigo-500/70 pointer-events-none'
                  : 'bg-slate-800/80 hover:bg-slate-700 active:bg-slate-800 text-slate-200 border-slate-700/80 disabled:opacity-50 disabled:pointer-events-none disabled:cursor-not-allowed'
              }`}
            >
              {isValidatingZip ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-400 shrink-0" />
              ) : (
                <ShieldCheck className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              )}
              <span className="truncate">{isValidatingZip ? 'Validando...' : 'Validar'}</span>
            </button>
          </div>

          {/* Botão Principal de Download */}
          <div className="pt-1">
            <button
              type="button"
              id="btn-download-latest-source"
              onClick={handleDownloadLatest}
              disabled={isDownloading || isLoadingInfo}
              className={`w-full h-11 px-4 rounded-xl font-semibold text-xs sm:text-sm inline-flex items-center justify-center gap-2.5 transition-colors duration-150 cursor-pointer select-none touch-manipulation shadow-md shadow-black/20 disabled:opacity-50 disabled:cursor-not-allowed disabled:pointer-events-none ${
                isDownloading
                  ? 'bg-slate-200 text-slate-900 border border-slate-300'
                  : downloadSuccess
                  ? 'bg-emerald-950/70 text-emerald-200 border border-emerald-500/50'
                  : 'bg-slate-100 hover:bg-white active:bg-slate-200 text-slate-950'
              }`}
            >
              {isDownloading ? (
                <>
                  <Loader2 className="w-4 h-4 text-slate-900 animate-spin shrink-0" />
                  <span className="truncate">Baixando arquivo ZIP...</span>
                </>
              ) : downloadSuccess ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="truncate font-semibold text-emerald-200">Download Concluído com Sucesso</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 text-slate-800 shrink-0" />
                  <span className="truncate font-semibold">
                    Baixar Código-Fonte Completo (.ZIP)
                  </span>
                  <span className="text-xs font-mono font-medium text-slate-600 pl-1.5 border-l border-slate-300 hidden sm:inline">
                    {current?.version || (versionInfo.versionNumber ? `Versão ${versionInfo.versionNumber}` : CURRENT_APP_VERSION_STRING)} •{' '}
                    {formatPtBrNumber(activeSizeBytes)}
                  </span>
                </>
              )}
            </button>
          </div>

          {downloadError && (
            <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-800/50 text-rose-200 text-xs flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 truncate">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                <span className="truncate">{downloadError}</span>
              </div>
              <button
                type="button"
                onClick={() => setDownloadError(null)}
                className="text-rose-400 hover:text-rose-100 font-bold px-1.5 cursor-pointer"
              >
                ✕
              </button>
            </div>
          )}
        </div>

        {/* ========================================================================= */}
        {/* SEÇÃO 4: TERMINAL CMD COM LAYOUT MOBILE BLINDADO (Sem Sobreposições)      */}
        {/* ========================================================================= */}
        <div
          id="section-execution-terminal"
          className="rounded-lg bg-black border border-neutral-800 overflow-hidden shadow-2xl transition-all"
        >
          {/* Barra Superior estilo Janela CMD com layout responsivo protegido */}
          <div className="flex items-center justify-between px-2.5 sm:px-3 py-2 bg-surface-base border-b border-neutral-800 text-xs select-none gap-2">
            {/* Esquerda: 3 bolinhas e título sem quebrar */}
            <div className="flex items-center gap-2 min-w-0">
              <div className="flex items-center gap-1 shrink-0">
                <span className="w-2.5 h-2.5 rounded-full bg-money-negative inline-block" />
                <span className="w-2.5 h-2.5 rounded-full bg-money-warning-light inline-block" />
                <span className="w-2.5 h-2.5 rounded-full bg-money-positive-hover inline-block" />
              </div>

              <div className="flex items-center gap-1.5 text-neutral-300 font-mono text-[11px] min-w-0">
                <TerminalIcon className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="font-semibold truncate">
                  <span className="hidden sm:inline">Prompt de Comando [CMD]</span>
                  <span className="sm:hidden">CMD</span>
                </span>
              </div>

              {isBusy && (
                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-mono animate-pulse shrink-0">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  <span>ativo</span>
                </span>
              )}
            </div>

            {/* Direita: Botões compactos de controle com largura fixa (sem colisão) */}
            <div className="flex items-center gap-1 shrink-0">
              {terminalLogs.length > 0 && (
                <>
                  <button
                    type="button"
                    onClick={handleCopyLogs}
                    className="w-7 h-7 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-emerald-300 flex items-center justify-center transition-colors cursor-pointer"
                    title="Copiar saída do terminal"
                    aria-label="Copiar saída do terminal"
                  >
                    {copiedLogs ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                  <button
                    type="button"
                    onClick={handleClearLogs}
                    className="w-7 h-7 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-rose-400 flex items-center justify-center transition-colors cursor-pointer"
                    title="Limpar tela (cls)"
                    aria-label="Limpar tela"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </>
              )}

              <button
                type="button"
                id="btn-toggle-terminal-logs"
                onClick={() => setShowTerminal((prev) => !prev)}
                className="h-7 px-2 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-mono text-[11px] inline-flex items-center gap-1 cursor-pointer transition-colors"
              >
                {showTerminal ? (
                  <>
                    <ChevronUp className="w-3 h-3" />
                    <span>Minimizar</span>
                  </>
                ) : (
                  <>
                    <ChevronDown className="w-3 h-3" />
                    <span>Abrir ({terminalLogs.length})</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Corpo do CMD (Fundo Preto com Saída em Tempo Real) */}
          {showTerminal ? (
            <div
              ref={terminalContainerRef}
              className="p-3 bg-black text-neutral-200 font-mono text-[11px] sm:text-xs leading-5 h-52 sm:h-64 overflow-y-auto select-text scroll-smooth"
              style={{ fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace' }}
            >
              {/* Banner Clássico do CMD */}
              <div className="text-neutral-500 pb-2 border-b border-neutral-900 mb-2">
                <div>Microsoft Windows [Versão 10.0.22631.3593] / Node.js Engine</div>
                <div>(c) Kitnet Architecture. Todos os direitos reservados.</div>
                <div className="text-emerald-400/80 mt-1">C:\Kitnet\build-system&gt; ready</div>
              </div>

              {terminalLogs.length === 0 ? (
                <div className="text-neutral-600 italic py-2">
                  Console pronto. Clique em Sincronizar, Auditar, Gerar ZIP ou Validar para acompanhar o processamento em tempo real.
                </div>
              ) : (
                terminalLogs.map((line, idx) => {
                  let lineStyle = 'text-neutral-300';
                  if (line.includes('✓') || line.includes('✅') || line.includes('sucesso') || line.includes('PASS')) {
                    lineStyle = 'text-emerald-400 font-medium';
                  } else if (line.includes('❌') || line.includes('🚨') || line.includes('ERRO') || line.includes('FAIL')) {
                    lineStyle = 'text-rose-400 font-bold';
                  } else if (line.includes('⚠️') || line.includes('Alerta')) {
                    lineStyle = 'text-amber-400';
                  } else if (line.includes('▶️') || line.includes('PASSO') || line.includes('🚀') || line.startsWith('C:\\Kitnet>')) {
                    lineStyle = 'text-sky-300 font-semibold';
                  }

                  return (
                    <div key={idx} className={`${lineStyle} break-all whitespace-pre-wrap`}>
                      {line}
                    </div>
                  );
                })
              )}

              {/* Cursor piscante clássico de terminal */}
              <div className="pt-1 flex items-center text-emerald-400">
                <span>C:\Kitnet&gt;</span>
                <span className="inline-block w-2 h-3.5 bg-emerald-400 animate-pulse ml-1 align-middle" />
              </div>

              <div ref={terminalEndRef} />
            </div>
          ) : (
            <div
              onClick={() => setShowTerminal(true)}
              className="px-3 py-2 bg-black text-neutral-400 font-mono text-[11px] flex items-center justify-between gap-2 cursor-pointer hover:text-neutral-200 transition-colors"
            >
              <div className="flex items-center gap-2 min-w-0 flex-1 overflow-hidden">
                <span className="text-emerald-400 font-bold shrink-0">C:\Kitnet&gt;</span>
                <span className="truncate block min-w-0 flex-1 text-neutral-300">
                  {terminalLogs.length > 0
                    ? terminalLogs[terminalLogs.length - 1]
                    : 'Terminal pronto. Toque para abrir o console.'}
                </span>
              </div>
              <span className="text-[10px] text-emerald-400 font-semibold uppercase shrink-0 bg-neutral-900 border border-neutral-700 px-2 py-0.5 rounded">
                Abrir CMD
              </span>
            </div>
          )}
        </div>

        {/* ========================================================================= */}
        {/* SEÇÃO 8 & 9: VALIDAÇÃO DO ZIP & ANOMALIAS                                 */}
        {/* ========================================================================= */}
        {(showValidationChecks || checksList.length > 0 || anomaliesList.length > 0) && (
          <div
            id="section-zip-validation"
            className="rounded-xl bg-slate-900/50 border border-slate-800 p-3 space-y-2.5"
          >
            <div className="flex items-center justify-between text-xs pb-1.5 border-b border-slate-800">
              <span className="font-semibold text-slate-200 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-slate-400" />
                Auditoria de Integridade do Arquivo ZIP
              </span>
              <span className="text-[11px] text-slate-400 font-mono">
                {checksList.filter((c) => c.passed).length}/{checksList.length || 9} checagens aprovadas
              </span>
            </div>

            {/* Banner de anomalias */}
            {anomaliesList.length > 0 && (
              <div className="space-y-1.5">
                {anomaliesList.map((a) => (
                  <div
                    key={a.id}
                    className={`p-2.5 rounded-lg border text-xs flex items-start gap-2.5 ${
                      a.severity === 'error'
                        ? 'bg-rose-950/40 border-rose-800/60 text-rose-200'
                        : 'bg-amber-950/40 border-amber-800/60 text-amber-200'
                    }`}
                  >
                    <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
                    <div className="min-w-0">
                      <strong className="font-semibold block">Possível inconsistência: {a.title}</strong>
                      <p className="text-[11px] opacity-90">{a.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Checklist items em grid compacto */}
            {checksList.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-1.5 text-[11px]">
                {checksList.map((chk) => (
                  <div
                    key={chk.id}
                    className={`p-2 rounded-lg border flex items-center gap-2 ${
                      chk.passed
                        ? 'bg-slate-950/50 border-slate-800 text-slate-300'
                        : 'bg-rose-950/30 border-rose-800/50 text-rose-300'
                    }`}
                  >
                    <span className={`text-xs shrink-0 font-bold ${chk.passed ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {chk.passed ? '✓' : '✕'}
                    </span>
                    <div className="truncate">
                      <span className="font-medium block truncate text-slate-200">{chk.label}</span>
                      {chk.details && (
                        <span className="text-[10px] text-slate-400 block truncate">{chk.details}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* SEÇÃO 7: COMPARATIVO DE VERSÕES                                           */}
        {/* ========================================================================= */}
        <div
          id="section-version-comparison"
          className="rounded-xl bg-slate-900/50 border border-slate-800 p-3 space-y-2.5"
        >
          <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <HardDrive className="w-3.5 h-3.5 text-slate-400" />
            <span>Comparativo de Versões</span>
          </div>

          <div className="grid grid-cols-3 items-center justify-center gap-2 text-xs text-center">
            {/* Versão Anterior */}
            <div className="p-2.5 rounded-lg bg-slate-950/40 border border-slate-800 flex flex-col justify-center">
              <span className="text-[10px] uppercase font-medium text-slate-400 truncate">
                {comparison?.isFirstVersion || !previous
                  ? 'Primeira Versão'
                  : previous.version || comparison?.oldVersion || 'Anterior'}
              </span>
              <span className="text-xs font-mono font-medium text-slate-300 mt-0.5 truncate">
                {comparison?.isFirstVersion || !previous
                  ? 'Primeiro Registro'
                  : formatPtBrNumber(previous?.sizeBytes ?? comparison?.oldSizeBytes ?? comparison?.oldSizeFormatted)}
              </span>
            </div>

            {/* Variação */}
            <div className="flex flex-col items-center justify-center">
              <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-200">
                {comparison?.diffBytes !== undefined
                  ? (comparison.diffBytes > 0
                      ? `+${formatPtBrNumber(comparison.diffBytes)}`
                      : formatPtBrNumber(comparison.diffBytes))
                  : (comparison?.diffFormatted ? comparison.diffFormatted.replace(/ KB| MB| bytes/g, '') : '0')}
              </span>
              <span className="text-[10px] text-slate-400 mt-0.5 font-mono">
                {comparison?.diffPercent || '0%'}
              </span>
            </div>

            {/* Versão Atual */}
            <div className="p-2.5 rounded-lg bg-slate-800/60 border border-slate-700/80 flex flex-col justify-center">
              <span className="text-[10px] uppercase font-semibold text-slate-200 truncate">
                {current?.version || (versionInfo.versionNumber ? `Versão ${versionInfo.versionNumber}` : CURRENT_APP_VERSION_STRING)}
              </span>
              <span className="text-xs font-mono font-semibold text-slate-100 mt-0.5 truncate">
                {formatPtBrNumber(current?.sizeBytes ?? versionInfo.sizeBytes ?? activeSizeBytes)}
              </span>
            </div>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* SEÇÃO 6: HISTÓRICO DE VERSÕES                                             */}
        {/* ========================================================================= */}
        <div id="section-versions-history" className="pt-0.5">
          <button
            type="button"
            id="btn-toggle-versions-history"
            onClick={() => setShowHistory((prev) => !prev)}
            className="w-full h-9 px-3 rounded-xl bg-slate-900/60 hover:bg-slate-800 active:bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs font-medium text-slate-300 hover:text-slate-100 flex items-center justify-between transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <History className="w-3.5 h-3.5 text-slate-400" />
              <span>Histórico de Versões ({allVersions.length || 1})</span>
            </div>
            {showHistory ? <ChevronUp className="w-3.5 h-3.5 text-slate-400" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-400" />}
          </button>

          {showHistory && (
            <div className="mt-2 space-y-2 bg-slate-900/50 border border-slate-800 rounded-xl p-3 animate-in fade-in duration-200">
              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {allVersions.length === 0 ? (
                  <div className="text-xs text-slate-400 text-center py-2">
                    Primeira versão registrada
                  </div>
                ) : (
                  allVersions.map((v) => {
                    const isCurrent = v.isLatest;
                    const isSingleDownloading = downloadingFile === v.filename;

                    return (
                      <div
                        key={v.filename}
                        className={`flex items-center justify-between gap-2 p-2.5 rounded-lg border transition-all ${
                          isCurrent
                            ? 'bg-slate-800/80 border-slate-700'
                            : 'bg-slate-950/40 border-slate-800/70 hover:border-slate-700'
                        }`}
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span
                              className={`text-xs font-semibold font-mono px-2 py-0.5 rounded ${
                                isCurrent
                                  ? 'bg-slate-700 text-slate-100'
                                  : 'bg-slate-900 text-slate-300'
                              }`}
                            >
                              {v.version}
                            </span>
                            {isCurrent && (
                              <span className="text-[10px] font-semibold text-emerald-400 uppercase bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.5 rounded">
                                Atual
                              </span>
                            )}
                            <span className="text-xs font-mono text-slate-300">
                              {formatPtBrNumber(v.sizeBytes || v.sizeFormatted)} • {v.fileCount || activeFileCount} arquivos
                            </span>
                          </div>

                          <div className="text-[10px] text-slate-400 mt-1 flex items-center gap-1.5">
                            <Clock className="w-3 h-3 text-slate-500 shrink-0" />
                            <span className="truncate">{v.formattedDateTime}</span>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleDownloadSingleVersion(v)}
                          disabled={isSingleDownloading}
                          className="shrink-0 h-7 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium inline-flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
                          title={`Baixar ${v.version} (${v.filename})`}
                        >
                          {isSingleDownloading ? (
                            <Loader2 className="w-3 h-3 animate-spin text-slate-300" />
                          ) : (
                            <Download className="w-3 h-3 text-slate-300" />
                          )}
                          <span className="hidden sm:inline">Baixar</span>
                        </button>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
