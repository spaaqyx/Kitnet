import os
import zipfile
import sys
import datetime
import json
import shutil
import re

try:
    import zoneinfo
    BRAZIL_TZ = zoneinfo.ZoneInfo("America/Sao_Paulo")
except Exception:
    BRAZIL_TZ = datetime.timezone(datetime.timedelta(hours=-3))

CURRENT_PROMPT_VERSION = 4

# Known historical timestamps for past milestones (in America/Sao_Paulo)
MILESTONE_TIMESTAMPS = {
    1: datetime.datetime(2026, 9, 5, 11, 29, 37, tzinfo=BRAZIL_TZ),
    2: datetime.datetime(2026, 9, 5, 11, 46, 31, tzinfo=BRAZIL_TZ),
    3: datetime.datetime(2026, 9, 5, 11, 58, 37, tzinfo=BRAZIL_TZ),
}

def get_brazil_now():
    return datetime.datetime.now(BRAZIL_TZ)

def format_size(bytes_size):
    if bytes_size >= 1024 * 1024:
        return f"{round(bytes_size / (1024 * 1024), 2)} MB"
    return f"{round(bytes_size / 1024, 1)} KB"

def make_zip():
    # Allow command-line override of target version: python3 scripts/generate-zip.py --version 5
    target_version = CURRENT_PROMPT_VERSION
    for i, arg in enumerate(sys.argv):
        if arg in ('--version', '-v') and i + 1 < len(sys.argv):
            try:
                target_version = int(sys.argv[i + 1])
            except ValueError:
                pass
        elif arg.isdigit():
            target_version = int(arg)

    root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    public_dir = os.path.join(root_dir, 'public')
    versions_dir = os.path.join(public_dir, 'versions')
    dist_dir = os.path.join(root_dir, 'dist')
    dist_versions_dir = os.path.join(dist_dir, 'versions')
    
    os.makedirs(versions_dir, exist_ok=True)
    if os.path.exists(dist_dir):
        os.makedirs(dist_versions_dir, exist_ok=True)

    exclude_dirs = {'.git', 'node_modules', 'dist', '.cache', '__pycache__', 'versions', 'tmp'}
    exclude_files = {'projeto-completo.zip'}

    now = get_brazil_now()
    time_str = now.strftime('%H:%M:%S')
    date_str = now.strftime('%d/%m/%Y')
    datetime_str = f"{date_str} às {time_str}"

    current_zip_filename = f"projeto-versao-{target_version}.zip"
    current_zip_path = os.path.join(versions_dir, current_zip_filename)
    latest_zip_path = os.path.join(public_dir, 'projeto-completo.zip')

    print(f"Gerando/Atualizando Versão {target_version} ({current_zip_filename})...")
    with zipfile.ZipFile(current_zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(root_dir):
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.')]
            rel_root = os.path.relpath(root, root_dir)
            if rel_root.startswith('public/versions') or rel_root == 'public/versions':
                continue
            for f in files:
                if f in exclude_files or f.endswith('.pyc') or f.endswith('.zip') or f.startswith('.'):
                    continue
                full_path = os.path.join(root, f)
                arcname = os.path.relpath(full_path, root_dir)
                z.write(full_path, arcname)

    # Copy current version to public/projeto-completo.zip
    shutil.copy2(current_zip_path, latest_zip_path)

    # Collect all existing numbered versions (projeto-versao-N.zip)
    version_items = []
    for f in os.listdir(versions_dir):
        match = re.match(r'^projeto-versao-(\d+)\.zip$', f)
        if match:
            v_num = int(match.group(1))
            f_path = os.path.join(versions_dir, f)
            f_size = os.path.getsize(f_path)

            if v_num == target_version:
                v_dt = now
            elif v_num in MILESTONE_TIMESTAMPS:
                v_dt = MILESTONE_TIMESTAMPS[v_num]
            else:
                mtime = os.path.getmtime(f_path)
                utc_dt = datetime.datetime.fromtimestamp(mtime, tz=datetime.timezone.utc)
                v_dt = utc_dt.astimezone(BRAZIL_TZ)

            # User naming requirement:
            # "o nome de cada versão deverá ser Projeto Versão 1, versão 2, versão 3, assim por diante, a cada atualização tem 1 número"
            if v_num == 1:
                v_name = "Projeto Versão 1"
            else:
                v_name = f"Versão {v_num}"

            version_items.append({
                'num': v_num,
                'version': v_name,
                'displayName': f"Projeto Versão {v_num}" if v_num > 1 else "Projeto Versão 1",
                'filename': f,
                'downloadUrl': f"/versions/{f}",
                'sizeBytes': f_size,
                'sizeFormatted': format_size(f_size),
                'updatedAt': v_dt.isoformat(),
                'formattedDateTime': v_dt.strftime('%d/%m/%Y às %H:%M:%S'),
                'formattedTime': v_dt.strftime('%H:%M:%S'),
                'formattedDate': v_dt.strftime('%d/%m/%Y'),
                'isLatest': False
            })

    # Sort descending by version number (highest / newest first)
    version_items.sort(key=lambda x: x['num'], reverse=True)

    if version_items:
        version_items[0]['isLatest'] = True

    current_v = version_items[0] if version_items else {
        'num': target_version,
        'version': f"Versão {target_version}",
        'displayName': f"Projeto Versão {target_version}",
        'filename': current_zip_filename,
        'downloadUrl': f"/versions/{current_zip_filename}",
        'sizeBytes': os.path.getsize(current_zip_path),
        'sizeFormatted': format_size(os.path.getsize(current_zip_path)),
        'updatedAt': now.isoformat(),
        'formattedDateTime': datetime_str,
        'formattedTime': time_str,
        'formattedDate': date_str,
        'isLatest': True
    }

    previous_v = version_items[1] if len(version_items) > 1 else None

    comparison = {
        'hasPrevious': previous_v is not None,
        'oldSizeFormatted': previous_v['sizeFormatted'] if previous_v else '-',
        'oldSizeBytes': previous_v['sizeBytes'] if previous_v else 0,
        'newSizeFormatted': current_v['sizeFormatted'],
        'newSizeBytes': current_v['sizeBytes'],
        'diffBytes': 0,
        'diffFormatted': '0 KB',
        'diffPercent': '0%',
        'isIncrease': False
    }

    if previous_v:
        diff_bytes = current_v['sizeBytes'] - previous_v['sizeBytes']
        comparison['diffBytes'] = diff_bytes
        sign = '+' if diff_bytes > 0 else ('' if diff_bytes == 0 else '-')
        diff_kb = abs(round(diff_bytes / 1024, 1))
        comparison['diffFormatted'] = f"{sign}{diff_kb} KB" if diff_bytes != 0 else "0 KB"
        pct = abs(round((diff_bytes / previous_v['sizeBytes']) * 100, 1)) if previous_v['sizeBytes'] > 0 else 0
        comparison['diffPercent'] = f"{sign}{pct}%" if diff_bytes != 0 else "0%"
        comparison['isIncrease'] = diff_bytes > 0

    version_metadata = {
        'lastGenerated': now.isoformat(),
        'updatedAt': now.isoformat(),
        'formattedTime': time_str,
        'formattedDate': date_str,
        'formattedDateTime': datetime_str,
        'currentVersion': current_v,
        'previousVersion': previous_v,
        'comparison': comparison,
        'allVersions': version_items
    }

    info_json_path = os.path.join(public_dir, 'version-info.json')
    with open(info_json_path, 'w', encoding='utf-8') as f:
        json.dump(version_metadata, f, indent=2, ensure_ascii=False)

    print(f"[{time_str}] Versão atual: {current_v['version']} ({current_v['sizeFormatted']})")
    if previous_v:
        print(f"Comparativo: Anterior {previous_v['version']} ({previous_v['sizeFormatted']}) -> Nova {current_v['version']} ({current_v['sizeFormatted']}) ({comparison['diffFormatted']} / {comparison['diffPercent']})")
    print(f"Total de versões registradas para download: {len(version_items)}")

    # Sync to dist if exists
    if os.path.exists(dist_dir):
        shutil.copy2(latest_zip_path, os.path.join(dist_dir, 'projeto-completo.zip'))
        shutil.copy2(info_json_path, os.path.join(dist_dir, 'version-info.json'))
        for v in version_items:
            v_src = os.path.join(versions_dir, v['filename'])
            if os.path.exists(v_src):
                shutil.copy2(v_src, os.path.join(dist_versions_dir, v['filename']))
        print(f"[{time_str}] Todos os arquivos sincronizados para dist/")

if __name__ == '__main__':
    make_zip()
