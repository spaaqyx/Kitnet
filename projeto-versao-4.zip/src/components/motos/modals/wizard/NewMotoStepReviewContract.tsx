import React, { useState } from 'react';
import {
  FileText,
  Copy,
  Printer,
  Download,
  Check,
  FileCheck,
  ShieldCheck,
} from 'lucide-react';
import { formatCPF } from '../../../../utils/formatters';
import {
  generateMotoRentalContractPdfFile,
  MotoRentalContractPdfOptions,
} from '../../../../utils/pdf/motoPdfGenerator';
import {
  extractOfficialMotoContractData,
  getOfficialMotoContractSections,
  getOfficialMotoContractRawText,
} from '../../../../utils/pdf/officialMotoContract';
import { copyTextToClipboard, printContractDocument } from '../../../../utils/printHelper';

interface NewMotoStepReviewContractProps {
  form: any;
  settings: any;
}

export const NewMotoStepReviewContract: React.FC<NewMotoStepReviewContractProps> = ({
  form,
  settings,
}) => {
  const [contractTab, setContractTab] = useState<'preview' | 'text'>('preview');
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Fonte canônica única de dados do contrato oficial
  const contractData = extractOfficialMotoContractData(form, settings);
  const sections = getOfficialMotoContractSections(contractData);
  const rawContractText = getOfficialMotoContractRawText(contractData);

  const getPdfOptions = (autoDownload = true): MotoRentalContractPdfOptions => ({
    moto: {
      id: 'preview',
      brand: contractData.moto.brand,
      model: contractData.moto.model,
      plate: contractData.moto.plate,
      year: Number(contractData.moto.year),
      color: contractData.moto.color,
      renavam: contractData.moto.renavam,
      chassi: contractData.moto.chassi,
      currentKm: Number(contractData.moto.initialKm),
      purchasePrice: Number(form.purchasePrice) || 0,
      purchaseDate: form.purchaseDate || contractData.terms.startDate,
      status: 'alugada' as const,
      insuranceDeductible: contractData.terms.depositFormatted,
      documents: [],
      photos: [],
      kmLogs: [],
    } as any,
    tenant: {
      id: 'preview',
      fullName: contractData.locatario.name,
      cpf: contractData.locatario.cpf.replace(/\D/g, ''),
      rg: contractData.locatario.rg || '',
      phone: contractData.locatario.phone.replace(/\D/g, ''),
      whatsapp: contractData.locatario.whatsapp.replace(/\D/g, ''),
      email: contractData.locatario.email,
      address: contractData.locatario.address,
      profession: contractData.locatario.profession,
      company: form.tenantCompany || 'Autônomo',
      income: Number(form.monthlyIncome) || contractData.terms.weeklyValue * 4,
      cnh: {
        number: contractData.locatario.cnh,
        category: contractData.locatario.cnhCategory,
        expirationDate: form.cnhExpiration || '',
      },
      birthDate: form.tenantBirthDate || '',
      documents: form.documents || {},
      approvalChecklist: {
        cnhValid: true,
        docsChecked: true,
        addressValidated: true,
        incomeAnalyzed: true,
        depositReceived: true,
        contractSigned: true,
        result: 'aprovado' as const,
      },
    } as any,
    contract: {
      id: 'preview',
      motoId: 'preview',
      tenantId: 'preview',
      durationMonths: contractData.terms.minimumMonths,
      paymentFrequency: contractData.terms.isWeekly ? 'semanal' : 'mensal',
      startDate: contractData.terms.startDate,
      dueDay: form.dueDay || 10,
      dueDayOfWeek: form.dueDayOfWeek ?? 1,
      monthlyValue: contractData.terms.monthlyValue,
      weeklyValue: contractData.terms.weeklyValue,
      deposit: contractData.terms.deposit,
      depositStatus: form.depositStatus || 'retida',
      totalAgreedValue: contractData.terms.isWeekly
        ? Math.round(contractData.terms.minimumMonths * (52 / 12) * contractData.terms.weeklyValue)
        : contractData.terms.monthlyValue * contractData.terms.minimumMonths,
      insuranceDeductible: contractData.terms.depositFormatted,
      status: 'ativo' as const,
      installments: [],
    } as any,
    settings,
    autoDownload,
  });

  const handleCopy = async () => {
    const success = await copyTextToClipboard(rawContractText);
    if (success) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handlePrint = () => {
    printContractDocument('Contrato Oficial de Locação de Motocicleta', rawContractText);
  };

  const handleDownloadPdf = () => {
    try {
      setDownloading(true);
      generateMotoRentalContractPdfFile(getPdfOptions(true));
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3000);
    } catch (err) {
      console.error('Erro ao gerar PDF da moto:', err);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="space-y-4 sm:space-y-5 animate-fadeIn font-sans" id="moto-contract-review-container">
      {/* CABEÇALHO DA ETAPA */}
      <div className="flex items-center justify-between border-b border-white/[0.08] pb-3.5">
        <div className="flex items-center gap-2.5 text-white font-bold text-sm sm:text-base">
          <span className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center text-xs font-black shrink-0">
            7
          </span>
          <span>Contrato Oficial de Locação & Emissão</span>
        </div>
        <span className="text-xs text-emerald-400 font-semibold bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20">
          12 Cláusulas Oficiais + Anexo I
        </span>
      </div>

      {/* RESUMO RÁPIDO DO CONTRATO */}
      <div className="p-4 sm:p-5 rounded-2xl bg-[#090B10] border border-white/[0.08] text-xs">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="space-y-1">
            <span className="text-slate-400 text-[11px] font-medium block">Locador & Veículo:</span>
            <strong className="text-white text-sm block truncate font-bold">
              {contractData.locador.name}
            </strong>
            <span className="text-slate-300 truncate block text-[11px]">
              {contractData.moto.brand} {contractData.moto.model} ({contractData.moto.year}) •{' '}
              <span className="font-mono font-semibold text-emerald-400">{contractData.moto.plate}</span>
            </span>
          </div>

          <div className="space-y-1">
            <span className="text-slate-400 text-[11px] font-medium block">Locatário / Condutor:</span>
            <strong className="text-white text-sm block truncate font-bold">
              {contractData.locatario.name}
            </strong>
            <span className="text-slate-300 block text-[11px] font-mono">
              CPF: {formatCPF(contractData.locatario.cpf)} • CNH: {contractData.locatario.cnh} ({contractData.locatario.cnhCategory})
            </span>
          </div>

          <div className="space-y-1">
            <span className="text-slate-400 text-[11px] font-medium block">Valores & Pagamento:</span>
            <strong className="text-emerald-400 text-sm block font-mono font-bold">
              {contractData.terms.isWeekly
                ? `${contractData.terms.weeklyValueFormatted} / semana`
                : `${contractData.terms.monthlyValueFormatted} / mês`}
            </strong>
            <span className="text-slate-300 block text-[11px]">
              {contractData.terms.minimumMonths} meses de prazo mínimo • Vencimento: {contractData.terms.dueDayName} até às {contractData.terms.dueLimitTime}
            </span>
          </div>
        </div>
      </div>

      {/* TOOLBAR UNIFICADA */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 sm:p-3.5 rounded-2xl bg-[#090B10] border border-white/[0.08]">
        {/* Toggle de Modo: Minuta Formatada vs Texto Puro */}
        <div className="flex items-center gap-1 p-1 bg-[#0E111A] border border-white/[0.08] rounded-xl">
          <button
            type="button"
            id="btn-tab-preview"
            onClick={() => setContractTab('preview')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              contractTab === 'preview'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileCheck className="w-3.5 h-3.5" />
            <span>Contrato Formatado</span>
          </button>

          <button
            type="button"
            id="btn-tab-text"
            onClick={() => setContractTab('text')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              contractTab === 'text'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Texto Puro</span>
          </button>
        </div>

        {/* Botões de Ação Direta */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            id="btn-copy-contract"
            onClick={handleCopy}
            className="px-3.5 py-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.10] border border-white/[0.10] text-slate-200 hover:text-white font-semibold text-xs flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
            title="Copiar texto integral do contrato oficial"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400 font-bold">Texto Copiado!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-slate-400" />
                <span>Copiar Texto</span>
              </>
            )}
          </button>

          <button
            type="button"
            id="btn-print-contract"
            onClick={handlePrint}
            className="px-3.5 py-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.10] border border-white/[0.10] text-slate-200 hover:text-white font-semibold text-xs flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
            title="Imprimir contrato oficial completo"
          >
            <Printer className="w-3.5 h-3.5 text-slate-400" />
            <span>Imprimir</span>
          </button>

          <button
            type="button"
            id="btn-download-pdf"
            onClick={handleDownloadPdf}
            disabled={downloading}
            className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-500/30 hover:shadow-emerald-500/50 hover:brightness-110 active:scale-95 transition-all cursor-pointer ring-1 ring-emerald-400/40"
            title="Baixar Contrato Oficial em PDF"
          >
            {downloadSuccess ? (
              <>
                <Check className="w-4 h-4 stroke-[3]" />
                <span>PDF Baixado!</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Baixar PDF Oficial</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* VISUALIZAÇÃO INTEGRAL DO CONTRATO OFICIAL */}
      {contractTab === 'preview' ? (
        <div
          id="official-contract-preview-scroll"
          className="p-5 sm:p-8 bg-[#07090E] border border-white/[0.12] rounded-2xl space-y-6 max-h-[62vh] overflow-y-auto font-sans shadow-2xl custom-scrollbar text-slate-200"
        >
          {/* CABEÇALHO FORMAL DO CONTRATO */}
          <div className="text-center pb-5 border-b border-white/[0.12] space-y-2">
            <div className="inline-flex items-center gap-1.5 bg-emerald-500/10 text-emerald-400 px-3 py-1 rounded-full border border-emerald-500/20 text-[10px] font-bold tracking-wider uppercase">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Contrato Oficial de Locação de Motocicleta</span>
            </div>
            <h2 className="text-base sm:text-lg font-black text-white uppercase tracking-wide">
              CONTRATO DE LOCAÇÃO DE MOTOCICLETA COM PRAZO MÍNIMO E RENOVAÇÃO AUTOMÁTICA
            </h2>
            <p className="text-xs text-slate-400 max-w-xl mx-auto">
              Instrumento Jurídico de Locação com Todas as Cláusulas Oficiais, Direitos, Deveres e Anexo I de Vistoria
            </p>
          </div>

          {/* TODAS AS CLÁUSULAS OFICIAIS RENDERIZADAS EM 100% PARIDADE */}
          <div className="space-y-5 text-xs leading-relaxed text-slate-300 divide-y divide-white/[0.06]">
            {sections.map((section, idx) => (
              <div key={idx} className={idx === 0 ? '' : 'pt-4'}>
                <h3 className="font-bold text-emerald-400 uppercase text-xs mb-2">
                  {section.title}
                </h3>
                <div className="space-y-2">
                  {section.paragraphs.map((p, pIdx) => {
                    // Detecção de marcadores ou alíneas
                    const isBullet =
                      p.startsWith('•') ||
                      p.startsWith('-') ||
                      /^[a-z]\)/i.test(p);
                    const isSubheading =
                      p.startsWith('1.1.') ||
                      p.startsWith('1.2.') ||
                      p.startsWith('Dados do Veículo:');

                    return (
                      <p
                        key={pIdx}
                        className={`${
                          isBullet
                            ? 'pl-4 text-slate-200 border-l border-emerald-500/30 ml-1 py-0.5'
                            : isSubheading
                            ? 'font-medium text-white'
                            : 'text-slate-300'
                        }`}
                      >
                        {p}
                      </p>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          {/* LOCAL, DATA E ASSINATURAS DO CONTRATO PRINCIPAL */}
          <div className="pt-6 border-t border-white/[0.12] space-y-6">
            <p className="text-center font-bold text-xs text-slate-200">
              {contractData.terms.contractCity}, {contractData.terms.contractDateFormatted}.
            </p>

            {/* LINHAS DE ASSINATURA PRINCIPAIS */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-4">
              <div className="text-center border-t border-white/40 pt-2 space-y-0.5">
                <strong className="text-white text-xs block font-bold">
                  {contractData.locador.name}
                </strong>
                <span className="text-[11px] text-slate-400 block uppercase tracking-wider">
                  LOCADOR (Proprietário)
                </span>
                <span className="text-[10px] text-slate-400 block font-mono">
                  CPF: {formatCPF(contractData.locador.cpf)}
                </span>
              </div>

              <div className="text-center border-t border-white/40 pt-2 space-y-0.5">
                <strong className="text-white text-xs block font-bold">
                  {contractData.locatario.name}
                </strong>
                <span className="text-[11px] text-slate-400 block uppercase tracking-wider">
                  LOCATÁRIO (Condutor)
                </span>
                <span className="text-[10px] text-slate-400 block font-mono">
                  CPF: {formatCPF(contractData.locatario.cpf)}
                </span>
              </div>
            </div>

            {/* TESTEMUNHAS */}
            <div className="pt-4 border-t border-white/[0.06]">
              <span className="text-[10px] text-slate-400 block uppercase tracking-wider font-bold mb-3 text-center">
                TESTEMUNHAS INSTRUMENTÁRIAS:
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-[11px] text-slate-300">
                <div className="border-t border-white/20 pt-2">
                  <p>1. Nome: _____________________________________</p>
                  <p className="mt-1">CPF: ________________________________________</p>
                </div>
                <div className="border-t border-white/20 pt-2">
                  <p>2. Nome: _____________________________________</p>
                  <p className="mt-1">CPF: ________________________________________</p>
                </div>
              </div>
            </div>
          </div>

          {/* ANEXO I – TERMO DE VISTORIA E ENTREGA DO VEÍCULO */}
          <div className="pt-6 border-t-2 border-emerald-500/20 space-y-4">
            <div className="p-4 rounded-xl bg-[#0D1019] border border-white/[0.08] space-y-3">
              <div className="text-center space-y-1">
                <h4 className="text-xs sm:text-sm font-black text-emerald-400 uppercase tracking-wide">
                  ANEXO I – TERMO DE VISTORIA E ENTREGA DO VEÍCULO
                </h4>
                <p className="text-[11px] text-slate-400">
                  Declaração de recebimento, estado de conservação e itens de checagem inicial
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 p-3 bg-white/[0.02] border border-white/[0.06] rounded-lg font-mono text-[11px]">
                <div>
                  <span className="text-slate-400 block text-[10px]">Marca/Modelo:</span>
                  <strong className="text-white">{contractData.moto.brand} {contractData.moto.model}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Ano:</span>
                  <strong className="text-white">{contractData.moto.year}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Cor:</span>
                  <strong className="text-white">{contractData.moto.color}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Placa:</span>
                  <strong className="text-emerald-400">{contractData.moto.plate}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Chassi:</span>
                  <strong className="text-white">{contractData.moto.chassi}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">KM de Entrega:</span>
                  <strong className="text-white">{Number(contractData.moto.initialKm).toLocaleString('pt-BR')} km</strong>
                </div>
              </div>

              <p className="text-[11.5px] text-slate-300 leading-relaxed">
                Pelo presente termo, o <strong>LOCATÁRIO</strong> declara haver recebido a motocicleta acima identificada em perfeito estado de conservação, com pneus em condições seguras de rodagem, freios, luzes, espelhos e motorização testados e aprovados, comprometendo-se a zelar pelo bem e devolvê-lo nas mesmas condições.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-4">
                <div className="text-center border-t border-white/40 pt-2">
                  <strong className="text-white text-xs block font-bold">
                    {contractData.locador.name}
                  </strong>
                  <span className="text-[10px] text-slate-400 block uppercase">LOCADOR</span>
                </div>

                <div className="text-center border-t border-white/40 pt-2">
                  <strong className="text-white text-xs block font-bold">
                    {contractData.locatario.name}
                  </strong>
                  <span className="text-[10px] text-slate-400 block uppercase">LOCATÁRIO</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* ABA DE TEXTO PURO DO CONTRATO OFICIAL */
        <div className="p-4 sm:p-5 bg-[#07090E] border border-white/[0.12] rounded-2xl max-h-[62vh] overflow-y-auto font-mono text-xs text-slate-300 shadow-2xl">
          <div className="flex items-center justify-between text-xs text-slate-400 pb-2 mb-3 border-b border-white/[0.08]">
            <span>Texto oficial e integral do contrato para envio por WhatsApp ou e-mail:</span>
            <span className="text-[11px] font-mono text-emerald-400">12 Cláusulas + Anexo I • UTF-8</span>
          </div>
          <pre className="whitespace-pre-wrap leading-relaxed font-mono select-all text-[11px] sm:text-xs">
            {rawContractText}
          </pre>
        </div>
      )}
    </div>
  );
};
