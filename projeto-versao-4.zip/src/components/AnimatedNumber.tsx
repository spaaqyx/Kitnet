import React, { useEffect, useState, useRef, memo } from 'react';
import { formatCurrency } from '../utils/formatters';

interface AnimatedNumberProps {
  value: number;
  format?: 'currency' | 'number' | 'percent';
  duration?: number;
  className?: string;
  prefix?: string;
  suffix?: string;
  animateOnMount?: boolean;
  cacheKey?: string;
}

// Global cache of previous values to prevent jarring restarts from 0 when returning to tabs
const previousValuesMap = new Map<string, number>();

export const AnimatedNumberComponent: React.FC<AnimatedNumberProps> = ({
  value,
  format = 'number',
  duration = 600,
  className = '',
  prefix = '',
  suffix = '',
  animateOnMount = true,
  cacheKey,
}) => {
  const resolvedKey = cacheKey || `${format}_${prefix}_${suffix}_${className.slice(0, 24)}`;
  const cachedValue = previousValuesMap.get(resolvedKey);

  // If already displayed in this session, start from previous value rather than 0!
  const [displayValue, setDisplayValue] = useState<number>(() => {
    if (cachedValue !== undefined) {
      return cachedValue;
    }
    return animateOnMount && value !== 0 ? 0 : value;
  });

  const prevValueRef = useRef<number>(
    cachedValue !== undefined ? cachedValue : (animateOnMount && value !== 0 ? 0 : value)
  );
  const isFirstMount = useRef<boolean>(true);

  useEffect(() => {
    const startValue = isFirstMount.current
      ? (cachedValue !== undefined ? cachedValue : (animateOnMount ? 0 : value))
      : prevValueRef.current;
    
    isFirstMount.current = false;
    const endValue = value;

    // Cache the latest value for next time
    previousValuesMap.set(resolvedKey, endValue);

    if (startValue === endValue) {
      setDisplayValue(endValue);
      prevValueRef.current = endValue;
      return;
    }

    let startTimestamp: number | null = null;
    let animId: number;
    const animDuration = Math.min(duration, 600);

    const step = (timestamp: number) => {
      if (!startTimestamp) startTimestamp = timestamp;
      const progress = Math.min((timestamp - startTimestamp) / animDuration, 1);
      
      // Silky smooth Ease-out Quart curve
      const easeOut = 1 - Math.pow(1 - progress, 4);
      const current = startValue + (endValue - startValue) * easeOut;

      setDisplayValue(current);

      if (progress < 1) {
        animId = requestAnimationFrame(step);
      } else {
        setDisplayValue(endValue);
        prevValueRef.current = endValue;
      }
    };

    animId = requestAnimationFrame(step);
    return () => {
      cancelAnimationFrame(animId);
      prevValueRef.current = displayValue;
    };
  }, [value, duration, animateOnMount, resolvedKey, cachedValue]);

  let formattedText = '';
  if (format === 'currency') {
    formattedText = formatCurrency(displayValue);
  } else if (format === 'percent') {
    formattedText = `${Math.round(displayValue)}%`;
  } else {
    formattedText = Math.round(displayValue).toLocaleString('pt-BR');
  }

  return (
    <span className={className}>
      {prefix}
      {formattedText}
      {suffix}
    </span>
  );
};

export const AnimatedNumber = memo(AnimatedNumberComponent);


