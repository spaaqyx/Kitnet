import React, { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';
import { getBrazilParts, BRAZIL_TIMEZONE } from '../utils/dateUtils';

interface BrazilTimeBadgeProps {
  className?: string;
  showSeconds?: boolean;
  showDate?: boolean;
  variant?: 'compact' | 'pill' | 'header';
}

/**
 * Componente que exibe a Data e Hora Oficial do Brasil (Brasília / America/Sao_Paulo)
 * Sincronizado dinamicamente em tempo real.
 */
export const BrazilTimeBadge: React.FC<BrazilTimeBadgeProps> = ({
  className = '',
  showSeconds = false,
  showDate = false,
  variant = 'pill',
}) => {
  const [timeStr, setTimeStr] = useState<string>('');
  const [dateStr, setDateStr] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const parts = getBrazilParts();
      const hh = String(parts.hour).padStart(2, '0');
      const mm = String(parts.minute).padStart(2, '0');
      const ss = String(parts.second).padStart(2, '0');
      const dd = String(parts.day).padStart(2, '0');
      const mo = String(parts.month).padStart(2, '0');

      setTimeStr(showSeconds ? `${hh}:${mm}:${ss}` : `${hh}:${mm}`);
      setDateStr(`${dd}/${mo}`);
    };

    updateTime();
    const interval = setInterval(updateTime, showSeconds ? 1000 : 10000);
    return () => clearInterval(interval);
  }, [showSeconds]);

  if (!timeStr) return null;

  if (variant === 'compact') {
    return (
      <div
        className={`inline-flex items-center gap-1.5 text-xs text-slate-400 font-mono ${className}`}
        title={`Horário de Brasília (${BRAZIL_TIMEZONE} • UTC-3)`}
      >
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
        <span>{timeStr}</span>
      </div>
    );
  }

  if (variant === 'header') {
    return (
      <div
        className={`inline-flex items-center gap-2 px-2.5 py-1 rounded-xl bg-white/[0.04] border border-white/[0.08] text-xs text-slate-300 backdrop-blur-md shadow-xs ${className}`}
        title="Operação sincronizada com o Horário Oficial de Brasília (America/Sao_Paulo • UTC-3)"
      >
        <div className="flex items-center gap-1.5">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-60" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
          </span>
          <Clock className="w-3.5 h-3.5 text-emerald-400" />
        </div>
        <div className="flex items-center gap-1 font-mono text-[11px] sm:text-xs">
          <span className="text-slate-400 font-sans font-medium text-[10px] sm:text-[11px] hidden xs:inline">
            Brasília
          </span>
          {showDate && dateStr && (
            <span className="text-slate-400 hidden sm:inline">{dateStr} •</span>
          )}
          <strong className="text-white font-bold tracking-tight">{timeStr}</strong>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs font-medium tracking-wide shadow-xs ${className}`}
      title="Sincronizado com o Horário Oficial de Brasília (America/Sao_Paulo • UTC-3)"
    >
      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
      <Clock className="w-3 h-3 text-emerald-400" />
      <span className="font-mono text-[11px] font-bold text-emerald-200">
        Brasília {timeStr}
      </span>
    </div>
  );
};
