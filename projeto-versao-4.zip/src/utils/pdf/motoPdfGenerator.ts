import { jsPDF } from 'jspdf';
import { MotoRentalContractPdfOptions } from './types';
import {
  formatCurrency,
  formatDate,
  formatCPF,
  formatPhone,
  formatCurrencyExtenso,
  formatDateFullPT,
  addMonthsToDate,
  getTodayLocalDateString,
} from '../formatters';
import { getWeekdayName } from '../contractCalculations';
import { weeklyToMonthly, monthlyToWeekly } from '../../domain';
import { printContractDocument } from '../printHelper';
import {
  extractOfficialMotoContractData,
  getOfficialMotoContractSections,
  getOfficialMotoContractRawText,
  OfficialMotoContractData,
  ContractSection,
} from './officialMotoContract';

export {
  extractOfficialMotoContractData,
  getOfficialMotoContractSections,
  getOfficialMotoContractRawText,
};
export type { OfficialMotoContractData, ContractSection, MotoRentalContractPdfOptions };

export function generateMotoRentalContractPdfFile(options: MotoRentalContractPdfOptions) {
  const contractData = extractOfficialMotoContractData(options, options.settings);
  const { locador, locatario, moto, terms } = contractData;

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const locadorName = locador.name;
  const locadorCpf = locador.cpf;
  const locadorAddress = locador.address;

  const startDateFormatted = terms.startDateFormatted;
  const endDateMinFormatted = terms.endDateMinFormatted;
  const isWeekly = terms.isWeekly;
  const weeklyVal = terms.weeklyValue;
  const weeklyValExtenso = terms.weeklyValueExtenso;
  const monthlyVal = terms.monthlyValue;
  const monthlyValExtenso = terms.monthlyValueExtenso;
  const dueDay = terms.dueDay;
  const dueDayName = terms.dueDayName;
  const dueLimitTime = terms.dueLimitTime;
  const depositVal = terms.deposit;
  const depositValExtenso = terms.depositExtenso;
  const insuranceDeductible = terms.insuranceDeductible;
  const contractCity = terms.contractCity;
  const contractDateFormatted = terms.contractDateFormatted;
  const initialKm = moto.initialKm;

  const inspectionDate = options.inspectionDate || terms.startDate;
  const inspectionDateFormatted = formatDate(inspectionDate);
  const inspectionTime = options.inspectionTime || '10:00';

  const marginX = 16;
  const pageWidth = 210;
  const contentWidth = 178;
  const maxY = 276;
  let cursorY = 16;

  function drawHeader(isFirstPage: boolean) {
    if (isFirstPage) {
      doc.setFillColor(15, 23, 42); // slate-900
      doc.rect(marginX, cursorY, contentWidth, 14, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9.5);
      doc.text('CONTRATO DE LOCAÇÃO DE MOTOCICLETA', 105, cursorY + 5.5, { align: 'center' });
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.text('COM PRAZO MÍNIMO E RENOVAÇÃO AUTOMÁTICA', 105, cursorY + 10.5, { align: 'center' });
      cursorY += 18;
    } else {
      doc.setTextColor(100, 116, 139);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7);
      doc.text('CONTRATO DE LOCAÇÃO DE MOTOCICLETA COM PRAZO MÍNIMO', marginX, 11);
      doc.text(`${moto.brand} ${moto.model} (${moto.plate}) • ${locatario.name}`, pageWidth - marginX, 11, { align: 'right' });
      doc.setDrawColor(226, 232, 240);
      doc.line(marginX, 13, pageWidth - marginX, 13);
      cursorY = 18;
    }
  }

  function checkPageBreak(neededHeight: number) {
    if (cursorY + neededHeight > maxY) {
      doc.addPage();
      drawHeader(false);
    }
  }

  // Draw Page 1 header
  drawHeader(true);

  // Use the canonical 12 clauses from the official contract source of truth
  const sections: ContractSection[] = getOfficialMotoContractSections(contractData);

  sections.forEach((sec) => {
    checkPageBreak(12);

    doc.setTextColor(15, 23, 42);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.2);
    doc.text(sec.title, marginX, cursorY);
    cursorY += 4.2;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.6);
    doc.setTextColor(51, 65, 85);

    sec.paragraphs.forEach((p) => {
      const lines = doc.splitTextToSize(p, contentWidth);
      checkPageBreak(lines.length * 3.6 + 2);
      doc.text(lines, marginX, cursorY);
      cursorY += lines.length * 3.6 + 1.2;
    });

    if (sec.bullets && sec.bullets.length > 0) {
      sec.bullets.forEach((b) => {
        const bulletLines = doc.splitTextToSize(`• ${b}`, contentWidth - 4);
        checkPageBreak(bulletLines.length * 3.6 + 1.2);
        doc.text(bulletLines, marginX + 3, cursorY);
        cursorY += bulletLines.length * 3.6 + 0.8;
      });
    }

    cursorY += 1.8;
  });

  // Closing paragraph and signatures
  const witnessesCount = options.witnessesCount !== undefined ? options.witnessesCount : 2;
  const neededHeightSignatures = witnessesCount > 0 ? 54 : 38;
  checkPageBreak(neededHeightSignatures);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.6);
  doc.setTextColor(51, 65, 85);
  const closingText =
    witnessesCount === 0
      ? 'E, por estarem assim justas e contratadas, as partes firmam o presente instrumento em 2 (duas) vias de igual teor e forma, para que produza seus regulares efeitos legais.'
      : witnessesCount === 1
      ? 'E, por estarem assim justas e contratadas, as partes firmam o presente instrumento em 2 (duas) vias de igual teor e forma, na presença de 1 (uma) testemunha abaixo qualificada, para que produza seus regulares efeitos legais.'
      : 'E, por estarem assim justas e contratadas, as partes firmam o presente instrumento em 2 (duas) vias de igual teor e forma, na presença das testemunhas abaixo qualificadas, para que produza seus efeitos legais.';
  const closingLines = doc.splitTextToSize(closingText, contentWidth);
  doc.text(closingLines, marginX, cursorY);
  cursorY += closingLines.length * 3.6 + 4;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(15, 23, 42);
  doc.text(`Local: ${contractCity} , Data: ${contractDateFormatted}`, marginX, cursorY);
  cursorY += 14;

  // Signatures Grid
  doc.setDrawColor(15, 23, 42);
  doc.line(marginX + 8, cursorY, marginX + 78, cursorY);
  doc.line(marginX + 98, cursorY, marginX + 168, cursorY);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.8);
  doc.setTextColor(15, 23, 42);
  doc.text(locadorName, marginX + 43, cursorY + 3.8, { align: 'center' });
  doc.text(locatario.name, marginX + 133, cursorY + 3.8, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.8);
  doc.setTextColor(100, 116, 139);
  doc.text(`CPF: ${formatCPF(locadorCpf)} • LOCADOR`, marginX + 43, cursorY + 7.2, { align: 'center' });
  doc.text(`CPF: ${formatCPF(locatario.cpf)} • LOCATÁRIO`, marginX + 133, cursorY + 7.2, { align: 'center' });

  if (witnessesCount > 0) {
    cursorY += 16;
    checkPageBreak(22);

    doc.setDrawColor(148, 163, 184);

    if (witnessesCount === 1) {
      // Single centered witness line
      doc.line(marginX + 49, cursorY, marginX + 129, cursorY);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(6.8);
      doc.setTextColor(71, 85, 105);
      const w1NameText = options.witness1Name
        ? `Testemunha: ${options.witness1Name}`
        : 'Testemunha: ____________________________';
      const w1CpfText = options.witness1Cpf
        ? `CPF: ${formatCPF(options.witness1Cpf)}`
        : 'CPF: __________________';
      doc.text(w1NameText, marginX + 89, cursorY + 3.8, { align: 'center' });
      doc.text(w1CpfText, marginX + 89, cursorY + 7.2, { align: 'center' });
    } else {
      // 2 Witnesses side by side
      doc.line(marginX + 8, cursorY, marginX + 78, cursorY);
      doc.line(marginX + 98, cursorY, marginX + 168, cursorY);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(6.8);
      doc.setTextColor(71, 85, 105);

      const w1NameText = options.witness1Name
        ? `Testemunha 1: ${options.witness1Name}`
        : 'Testemunha 1: ____________________________';
      const w1CpfText = options.witness1Cpf
        ? `CPF: ${formatCPF(options.witness1Cpf)}`
        : 'CPF: __________________';

      const w2NameText = options.witness2Name
        ? `Testemunha 2: ${options.witness2Name}`
        : 'Testemunha 2: ____________________________';
      const w2CpfText = options.witness2Cpf
        ? `CPF: ${formatCPF(options.witness2Cpf)}`
        : 'CPF: __________________';

      doc.text(w1NameText, marginX + 43, cursorY + 3.8, { align: 'center' });
      doc.text(w2NameText, marginX + 133, cursorY + 3.8, { align: 'center' });
      doc.text(w1CpfText, marginX + 43, cursorY + 7.2, { align: 'center' });
      doc.text(w2CpfText, marginX + 133, cursorY + 7.2, { align: 'center' });
    }
  }

  // -------------------------------------------------------------
  // ANEXO I - TERMO DE VISTORIA E RETIRADA (Always start on new page)
  // -------------------------------------------------------------
  doc.addPage();
  cursorY = 16;

  doc.setFillColor(15, 23, 42);
  doc.rect(marginX, cursorY, contentWidth, 14, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text('ANEXO I - TERMO DE VISTORIA E RETIRADA', 105, cursorY + 5.5, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.text('PARTE INTEGRANTE E INDISSOCIÁVEL DO CONTRATO DE LOCAÇÃO', 105, cursorY + 10.5, { align: 'center' });
  cursorY += 18;

  // Metadata Card
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(marginX, cursorY, contentWidth, 18, 2, 2, 'FD');

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.6);
  doc.text(`Data da Vistoria: ${inspectionDateFormatted}`, marginX + 4, cursorY + 5.5);
  doc.text(`Hora da Retirada: ${inspectionTime}`, marginX + 64, cursorY + 5.5);
  doc.text(`Quilometragem Inicial: ${initialKm.toLocaleString('pt-BR')} km`, marginX + 114, cursorY + 5.5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.2);
  doc.setTextColor(71, 85, 105);
  doc.text(`Veículo: ${moto.brand} ${moto.model} (${moto.year}) • Placa: ${moto.plate} • Renavam: ${moto.renavam || 'N/A'}`, marginX + 4, cursorY + 11);
  doc.text(`Locatário: ${locatario.name} • CPF: ${formatCPF(locatario.cpf)}`, marginX + 4, cursorY + 15);

  cursorY += 23;

  // Table: CONDIÇÕES GERAIS DA MOTOCICLETA
  doc.setFillColor(241, 245, 249);
  doc.rect(marginX, cursorY, contentWidth, 6, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.6);
  doc.setTextColor(15, 23, 42);
  doc.text('ITEM VISTORIADO', marginX + 3, cursorY + 4.2);
  doc.text('ESTADO / CONDIÇÃO', marginX + 58, cursorY + 4.2);
  doc.text('OBSERVAÇÕES', marginX + 116, cursorY + 4.2);
  cursorY += 7;

  const inspectionItems = [
    'Pneu Dianteiro',
    'Pneu Traseiro',
    'Freio Dianteiro (Pastilha/Disco)',
    'Freio Traseiro (Lona/Disco)',
    'Farol Principal e Lanternas',
    'Setas / Piscas (Diant./Tras.)',
    'Buzina e Painel de Instrumentos',
    'Espelhos Retrovisores (D / E)',
    'Assento / Banco e Capa',
    'Pintura, Carenagens e Lataria',
  ];

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(51, 65, 85);

  inspectionItems.forEach((item, idx) => {
    const rowY = cursorY;
    if (idx % 2 === 1) {
      doc.setFillColor(248, 250, 252);
      doc.rect(marginX, rowY - 1, contentWidth, 5.5, 'F');
    }
    doc.text(item, marginX + 3, rowY + 3);
    doc.text('[ X ] Bom   [  ] Regular   [  ] Ruim', marginX + 58, rowY + 3);
    doc.text('_____________________________', marginX + 116, rowY + 3);
    cursorY += 5.5;
  });

  cursorY += 4;

  // Checklist: NÍVEL DE COMBUSTÍVEL NA RETIRADA
  doc.setFillColor(241, 245, 249);
  doc.rect(marginX, cursorY, contentWidth, 5.5, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.6);
  doc.setTextColor(15, 23, 42);
  doc.text('NÍVEL DE COMBUSTÍVEL NA RETIRADA:', marginX + 3, cursorY + 4);
  cursorY += 8;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.4);
  doc.setTextColor(30, 41, 59);
  doc.text('[  ] Cheio        [  ] 3/4        [  ] 1/2        [  ] 1/4        [  ] Reserva', marginX + 6, cursorY);
  cursorY += 6;

  // Checklist: ACESSÓRIOS ENTREGUES
  doc.setFillColor(241, 245, 249);
  doc.rect(marginX, cursorY, contentWidth, 5.5, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.6);
  doc.setTextColor(15, 23, 42);
  doc.text('ACESSÓRIOS ENTREGUES JUNTO COM O VEÍCULO:', marginX + 3, cursorY + 4);
  cursorY += 8;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.4);
  doc.setTextColor(30, 41, 59);
  doc.text('[  ] Capacete             [  ] Capa de Chuva             [  ] Suporte de Celular', marginX + 6, cursorY);
  cursorY += 5;
  doc.text('[  ] Baú / Bauleto        [  ] Chave Reserva             [  ] Outros: _________________________________', marginX + 6, cursorY);
  cursorY += 7;

  // Box: DESCRIÇÃO DE AVARIAS
  doc.setFillColor(241, 245, 249);
  doc.rect(marginX, cursorY, contentWidth, 5.5, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.6);
  doc.setTextColor(15, 23, 42);
  doc.text('DESCRIÇÃO DETALHADA DE AVARIAS EXISTENTES (Riscos, amassados, peças desgastadas):', marginX + 3, cursorY + 4);
  cursorY += 8;

  doc.setDrawColor(203, 213, 225);
  doc.setFillColor(255, 255, 255);
  doc.roundedRect(marginX, cursorY, contentWidth, 16, 1.5, 1.5, 'FD');
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(6.8);
  doc.setTextColor(148, 163, 184);
  doc.text('Nenhuma avaria estrutural identificada na vistoria inicial. Veículo entregue revisado, lavado e em perfeitas condições operacionais.', marginX + 3, cursorY + 5);
  cursorY += 19;

  // Video Inspection Note Box
  doc.setFillColor(238, 242, 255);
  doc.setDrawColor(199, 210, 254);
  doc.roundedRect(marginX, cursorY, contentWidth, 12, 1.5, 1.5, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(67, 56, 202);
  doc.text('REGISTRO EM VÍDEO 360°:', marginX + 3, cursorY + 4.5);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.8);
  doc.setTextColor(79, 70, 229);
  doc.text('Além deste termo impresso, foi realizado e armazenado um vídeo de vistoria em 360 graus do veículo no ato da entrega, servindo ambos como prova das condições iniciais da motocicleta.', marginX + 3, cursorY + 8.5);
  cursorY += 15;

  // Declaration
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(51, 65, 85);
  const declarationText = 'O LOCATÁRIO declara que vistoriou a motocicleta, recebeu os acessórios marcados e concorda que o veículo está em perfeitas condições de uso, segurança e funcionamento, obrigando-se a devolvê-lo nas mesmas condições.';
  const declLines = doc.splitTextToSize(declarationText, contentWidth);
  doc.text(declLines, marginX, cursorY);
  cursorY += declLines.length * 3.4 + 9;

  // Signatures on Annex
  doc.setDrawColor(15, 23, 42);
  doc.line(marginX + 8, cursorY, marginX + 78, cursorY);
  doc.line(marginX + 98, cursorY, marginX + 168, cursorY);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.6);
  doc.setTextColor(15, 23, 42);
  doc.text(locadorName, marginX + 43, cursorY + 3.6, { align: 'center' });
  doc.text(locatario.name, marginX + 133, cursorY + 3.6, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.8);
  doc.setTextColor(100, 116, 139);
  doc.text(`CPF: ${formatCPF(locadorCpf)} • LOCADOR`, marginX + 43, cursorY + 7, { align: 'center' });
  doc.text(`CPF: ${formatCPF(locatario.cpf)} • LOCATÁRIO`, marginX + 133, cursorY + 7, { align: 'center' });

  // Add Page Numbers to all pages
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.setTextColor(148, 163, 184);
    doc.text(`Página ${i} de ${totalPages}`, pageWidth - marginX, 291, { align: 'right' });
    doc.text(`Contrato de Locação de Motocicleta — ${moto.brand} ${moto.model} (${moto.plate})`, marginX, 291);
  }

  const safeTenantName = (locatario?.name || 'Locatario').replace(/\s+/g, '_');
  const safePlate = (moto?.plate || 'SEM_PLACA').replace(/[^A-Za-z0-9]/g, '');
  const fileName = `Contrato_Locacao_Moto_${safeTenantName}_${safePlate}.pdf`;
  const dataUri = doc.output('datauristring');

  if (options.autoDownload !== false) {
    doc.save(fileName);
  }

  return { dataUri, fileName };
}

export function getMotoContractRawText(options: MotoRentalContractPdfOptions): string {
  const contractData = extractOfficialMotoContractData(options, options.settings);
  return getOfficialMotoContractRawText(contractData);
}

export function openMotoContractPrintWindow(options: MotoRentalContractPdfOptions) {
  const text = getMotoContractRawText(options);
  printContractDocument('Contrato de Locação de Motocicleta', text);
}
