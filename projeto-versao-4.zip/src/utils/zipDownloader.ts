import JSZip from 'jszip';
import type { ProjectVersionInfo, AppVersionItem } from '../types';
import { today, nowDateTime, getBrazilParts } from './dateUtils';

export const DEFAULT_VERSION_INFO: ProjectVersionInfo = {
  lastGenerated: '2026-09-05T12:09:20-03:00',
  updatedAt: '2026-09-05T12:09:20-03:00',
  formattedTime: '12:09:20',
  formattedDate: '05/09/2026',
  formattedDateTime: '05/09/2026 às 12:09:20',
  currentVersion: {
    num: 4,
    version: 'Versão 4',
    displayName: 'Projeto Versão 4',
    filename: 'projeto-versao-4.zip',
    downloadUrl: '/versions/projeto-versao-4.zip',
    sizeBytes: 647111,
    sizeFormatted: '631.9 KB',
    updatedAt: '2026-09-05T12:09:20-03:00',
    formattedDateTime: '05/09/2026 às 12:09:20',
    formattedTime: '12:09:20',
    formattedDate: '05/09/2026',
    isLatest: true,
  },
  previousVersion: {
    num: 3,
    version: 'Versão 3',
    displayName: 'Projeto Versão 3',
    filename: 'projeto-versao-3.zip',
    downloadUrl: '/versions/projeto-versao-3.zip',
    sizeBytes: 644272,
    sizeFormatted: '629.2 KB',
    updatedAt: '2026-09-05T11:58:37-03:00',
    formattedDateTime: '05/09/2026 às 11:58:37',
    formattedTime: '11:58:37',
    formattedDate: '05/09/2026',
    isLatest: false,
  },
  comparison: {
    hasPrevious: true,
    oldSizeFormatted: '629.2 KB',
    oldSizeBytes: 644272,
    newSizeFormatted: '631.9 KB',
    newSizeBytes: 647111,
    diffBytes: 2839,
    diffFormatted: '+2.8 KB',
    diffPercent: '+0.4%',
    isIncrease: true,
  },
  allVersions: [
    {
      num: 4,
      version: 'Versão 4',
      displayName: 'Projeto Versão 4',
      filename: 'projeto-versao-4.zip',
      downloadUrl: '/versions/projeto-versao-4.zip',
      sizeBytes: 647111,
      sizeFormatted: '631.9 KB',
      updatedAt: '2026-09-05T12:09:20-03:00',
      formattedDateTime: '05/09/2026 às 12:09:20',
      formattedTime: '12:09:20',
      formattedDate: '05/09/2026',
      isLatest: true,
    },
    {
      num: 3,
      version: 'Versão 3',
      displayName: 'Projeto Versão 3',
      filename: 'projeto-versao-3.zip',
      downloadUrl: '/versions/projeto-versao-3.zip',
      sizeBytes: 644272,
      sizeFormatted: '629.2 KB',
      updatedAt: '2026-09-05T11:58:37-03:00',
      formattedDateTime: '05/09/2026 às 11:58:37',
      formattedTime: '11:58:37',
      formattedDate: '05/09/2026',
      isLatest: false,
    },
    {
      num: 2,
      version: 'Versão 2',
      displayName: 'Projeto Versão 2',
      filename: 'projeto-versao-2.zip',
      downloadUrl: '/versions/projeto-versao-2.zip',
      sizeBytes: 646913,
      sizeFormatted: '631.8 KB',
      updatedAt: '2026-09-05T11:46:31-03:00',
      formattedDateTime: '05/09/2026 às 11:46:31',
      formattedTime: '11:46:31',
      formattedDate: '05/09/2026',
      isLatest: false,
    },
    {
      num: 1,
      version: 'Projeto Versão 1',
      displayName: 'Projeto Versão 1',
      filename: 'projeto-versao-1.zip',
      downloadUrl: '/versions/projeto-versao-1.zip',
      sizeBytes: 640788,
      sizeFormatted: '625.8 KB',
      updatedAt: '2026-09-05T11:29:37-03:00',
      formattedDateTime: '05/09/2026 às 11:29:37',
      formattedTime: '11:29:37',
      formattedDate: '05/09/2026',
      isLatest: false,
    },
  ],
};

/**
 * Loads the latest version-info.json generated during build or update
 */
export async function fetchProjectVersionInfo(): Promise<ProjectVersionInfo> {
  try {
    const res = await fetch(`/version-info.json?t=${Date.now()}`);
    if (res.ok) {
      const data = (await res.json()) as ProjectVersionInfo;
      return data;
    }
  } catch (err) {
    console.warn('Erro ao carregar version-info.json, usando fallback padrão:', err);
  }
  return DEFAULT_VERSION_INFO;
}

/**
 * Downloads a specific version archive by URL and filename
 */
export async function downloadSpecificVersion(downloadUrl: string, filename: string): Promise<void> {
  try {
    const cleanUrl = `${downloadUrl}?t=${Date.now()}`;
    const res = await fetch(cleanUrl);
    if (res.ok) {
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      return;
    }
  } catch (err) {
    console.warn('Download de versão específica falhou:', err);
  }

  // Fallback: direct anchor link
  const a = document.createElement('a');
  a.href = downloadUrl;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

/**
 * Downloads the latest complete project ZIP file
 */
export async function downloadLatestProjectZip(): Promise<void> {
  const zipName = 'projeto-versao-4.zip';

  // Try downloading the pre-packaged zip first (with cache-busting)
  try {
    const res = await fetch(`/projeto-completo.zip?t=${Date.now()}`);
    if (res.ok) {
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = zipName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      return;
    }
  } catch (err) {
    console.warn('Pre-bundled zip fetch failed, falling back to dynamic generator', err);
  }

  // Fallback: create zip dynamically using JSZip
  const zip = new JSZip();
  zip.file('README.txt', 'Projeto Versão 4 - Gestão Patrimonial gerado em ' + nowDateTime(true));
  const content = await zip.generateAsync({ type: 'blob' });
  const url = window.URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = url;
  a.download = zipName;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(url);
  document.body.removeChild(a);
}
