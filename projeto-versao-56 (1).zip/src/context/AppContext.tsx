import React, { createContext, useContext, useEffect, useState, useMemo, useCallback, useRef } from 'react';
import { AppContextType } from './types';
import { useAuthManager } from './useAuthManager';
import { useSettingsManager } from './useSettingsManager';
import { useMotosManager } from './useMotosManager';
import { useKitnetsManager } from './useKitnetsManager';
import { useFinanceTimelineManager } from './useFinanceTimelineManager';
import { checkAndSendDueNotifications, isNotificationSupported } from '../utils/notificationService';
import { initialMotos, initialMotoTenants, initialMotoContracts, initialKitnets, initialKitnetTenants, initialKitnetContracts, initialSettings, initialExpenses } from '../utils/initialData';
import {
  subscribeStorageHealthWarning,
  setStorageHealthWarningState,
  getStorageHealthWarningState,
} from './storageHelpers';
import {
  hasRealDataStored,
  setRealDataActive,
  isDemoEntity,
  filterOutDemoEntities,
  sanitizeStorageFromDemo,
  isDemoModeActive,
  setDemoModeActive,
} from '../utils/demoDataSecurity';

export * from './types';

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Clientes Demo SEMPRE inicia desligado (false) por especificação do usuário
  const [isDemoMode, setIsDemoMode] = useState<boolean>(() => isDemoModeActive());
  const [hasRealDataState, setHasRealDataState] = useState<boolean>(() => !isDemoModeActive());

  // Stable references for backup restoration & cross-hook callbacks
  const motosManagerRef = useRef<any>(null);
  const kitnetsManagerRef = useRef<any>(null);
  const settingsManagerRef = useRef<any>(null);

  const handleTransitionToRealData = useCallback(() => {
    if (isDemoModeActive()) {
      setDemoModeActive(false);
      setIsDemoMode(false);
      setRealDataActive(true);
      setHasRealDataState(true);
      if (motosManagerRef.current) {
        motosManagerRef.current.setMotos((prev: any) => filterOutDemoEntities(prev));
        motosManagerRef.current.setMotoTenants((prev: any) => filterOutDemoEntities(prev));
        motosManagerRef.current.setMotoContracts((prev: any) => filterOutDemoEntities(prev));
      }
      if (kitnetsManagerRef.current) {
        kitnetsManagerRef.current.setKitnets((prev: any) => filterOutDemoEntities(prev));
        kitnetsManagerRef.current.setKitnetTenants((prev: any) => filterOutDemoEntities(prev));
        kitnetsManagerRef.current.setKitnetContracts((prev: any) => filterOutDemoEntities(prev));
      }
      financeManager.purgeDemoEntities();
      sanitizeStorageFromDemo();
    }
  }, []);

  const financeManager = useFinanceTimelineManager({
    onRestoreBackup: (data) => {
      setDemoModeActive(false);
      setIsDemoMode(false);
      setRealDataActive(true);
      setHasRealDataState(true);
      if (settingsManagerRef.current) settingsManagerRef.current.setSettings(data.settings);
      if (motosManagerRef.current) {
        motosManagerRef.current.setMotos(data.motos);
        motosManagerRef.current.setMotoTenants(data.motoTenants || []);
        motosManagerRef.current.setMotoContracts(data.motoContracts || []);
      }
      if (kitnetsManagerRef.current) {
        kitnetsManagerRef.current.setKitnets(data.kitnets);
        kitnetsManagerRef.current.setKitnetTenants(data.kitnetTenants || []);
        kitnetsManagerRef.current.setKitnetContracts(data.kitnetContracts || []);
      }
    },
    getBackupPayload: () => ({
      settings: settingsManager.settings,
      motos: motosManager.motos,
      motoTenants: motosManager.motoTenants,
      motoContracts: motosManager.motoContracts,
      kitnets: kitnetsManager.kitnets,
      kitnetTenants: kitnetsManager.kitnetTenants,
      kitnetContracts: kitnetsManager.kitnetContracts,
    }),
    onResetAllState: () => {
      setDemoModeActive(false);
      setIsDemoMode(false);
      setRealDataActive(true);
      setHasRealDataState(true);
      if (settingsManagerRef.current) settingsManagerRef.current.setSettings(initialSettings);
      if (motosManagerRef.current) {
        motosManagerRef.current.setMotos([]);
        motosManagerRef.current.setMotoTenants([]);
        motosManagerRef.current.setMotoContracts([]);
      }
      if (kitnetsManagerRef.current) {
        kitnetsManagerRef.current.setKitnets([]);
        kitnetsManagerRef.current.setKitnetTenants([]);
        kitnetsManagerRef.current.setKitnetContracts([]);
      }
    },
    onTransitionToRealData: handleTransitionToRealData,
  });

  const motosManager = useMotosManager({
    addTimelineEvent: financeManager.addTimelineEvent,
    addExpense: financeManager.addExpense,
    deleteExpensesByTarget: financeManager.deleteExpensesByTarget,
    onTransitionToRealData: handleTransitionToRealData,
  });

  const kitnetsManager = useKitnetsManager({
    addTimelineEvent: financeManager.addTimelineEvent,
    deleteExpensesByTarget: financeManager.deleteExpensesByTarget,
    onTransitionToRealData: handleTransitionToRealData,
  });

  const settingsManager = useSettingsManager({
    addTimelineEvent: financeManager.addTimelineEvent,
    getNotificationContext: () => ({
      motos: motosManager.motos,
      motoContracts: motosManager.motoContracts,
      motoTenants: motosManager.motoTenants,
      kitnets: kitnetsManager.kitnets,
      kitnetContracts: kitnetsManager.kitnetContracts,
      kitnetTenants: kitnetsManager.kitnetTenants,
      expenses: financeManager.expenses,
    }),
  });

  // Keep refs synchronized
  motosManagerRef.current = motosManager;
  kitnetsManagerRef.current = kitnetsManager;
  settingsManagerRef.current = settingsManager;

  const authManager = useAuthManager({
    settings: settingsManager.settings,
    addTimelineEvent: financeManager.addTimelineEvent,
  });

  const [storageHealthWarning, setStorageHealthWarning] = useState<boolean>(getStorageHealthWarningState);

  useEffect(() => {
    return subscribeStorageHealthWarning((warning) => {
      setStorageHealthWarning(warning);
    });
  }, []);

  // Background notifications check - debounced on mount or contract changes
  useEffect(() => {
    if (
      settingsManager.settings.browserNotificationsEnabled &&
      isNotificationSupported() &&
      Notification.permission === 'granted'
    ) {
      const timer = setTimeout(() => {
        checkAndSendDueNotifications({
          motos: motosManager.motos,
          motoContracts: motosManager.motoContracts,
          motoTenants: motosManager.motoTenants,
          kitnets: kitnetsManager.kitnets,
          kitnetContracts: kitnetsManager.kitnetContracts,
          kitnetTenants: kitnetsManager.kitnetTenants,
          expenses: financeManager.expenses,
          contractEndAlertDays: settingsManager.settings.contractEndAlertDays || 60,
        });
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [
    settingsManager.settings.browserNotificationsEnabled,
    settingsManager.settings.contractEndAlertDays,
    motosManager.motoContracts,
    kitnetsManager.kitnetContracts,
  ]);

  const clearDemoDataAndStartFresh = useCallback(() => {
    setDemoModeActive(false);
    setIsDemoMode(false);
    setRealDataActive(true);
    setHasRealDataState(true);
    if (motosManagerRef.current) {
      motosManagerRef.current.setMotos([]);
      motosManagerRef.current.setMotoTenants([]);
      motosManagerRef.current.setMotoContracts([]);
    }
    if (kitnetsManagerRef.current) {
      kitnetsManagerRef.current.setKitnets([]);
      kitnetsManagerRef.current.setKitnetTenants([]);
      kitnetsManagerRef.current.setKitnetContracts([]);
    }
    financeManager.clearAll();
    sanitizeStorageFromDemo();
    financeManager.addTimelineEvent({
      type: 'documento_atualizado',
      title: 'Ambiente Real Inicializado',
      description: 'Dados de demonstração foram isolados e removidos. Sistema pronto para dados reais.',
      entityType: 'sistema',
    });
  }, [financeManager]);

  const loadDemoData = useCallback(() => {
    setDemoModeActive(true);
    setIsDemoMode(true);
    setRealDataActive(false);
    setHasRealDataState(false);
    if (settingsManagerRef.current) settingsManagerRef.current.setSettings(initialSettings);
    if (motosManagerRef.current) {
      motosManagerRef.current.setMotos(initialMotos);
      motosManagerRef.current.setMotoTenants(initialMotoTenants);
      motosManagerRef.current.setMotoContracts(initialMotoContracts);
    }
    if (kitnetsManagerRef.current) {
      kitnetsManagerRef.current.setKitnets(initialKitnets);
      kitnetsManagerRef.current.setKitnetTenants(initialKitnetTenants);
      kitnetsManagerRef.current.setKitnetContracts(initialKitnetContracts);
    }
    financeManager.resetToDefaults();
  }, [financeManager]);

  const toggleDemoMode = useCallback(
    (enable?: boolean): boolean => {
      // Se enable for explicitamente fornecido, usa-o; caso contrário alterna o estado atual
      const targetDemoState = enable !== undefined ? enable : !isDemoMode;

      if (targetDemoState) {
        // Ligar Clientes Demo: injeta clientes, contratos e bens demonstrativos
        setDemoModeActive(true);
        setIsDemoMode(true);
        setRealDataActive(false);
        setHasRealDataState(false);

        if (motosManagerRef.current) {
          motosManagerRef.current.setMotoTenants((prev: any[]) => {
            const nonDemo = Array.isArray(prev) ? prev.filter((t) => !isDemoEntity(t)) : [];
            return [...nonDemo, ...initialMotoTenants];
          });
          motosManagerRef.current.setMotoContracts((prev: any[]) => {
            const nonDemo = Array.isArray(prev) ? prev.filter((c) => !isDemoEntity(c)) : [];
            return [...nonDemo, ...initialMotoContracts];
          });
          motosManagerRef.current.setMotos((prev: any[]) => {
            const nonDemo = Array.isArray(prev) ? prev.filter((m) => !isDemoEntity(m)) : [];
            return [...nonDemo, ...initialMotos];
          });
        }

        if (kitnetsManagerRef.current) {
          kitnetsManagerRef.current.setKitnetTenants((prev: any[]) => {
            const nonDemo = Array.isArray(prev) ? prev.filter((t) => !isDemoEntity(t)) : [];
            return [...nonDemo, ...initialKitnetTenants];
          });
          kitnetsManagerRef.current.setKitnetContracts((prev: any[]) => {
            const nonDemo = Array.isArray(prev) ? prev.filter((c) => !isDemoEntity(c)) : [];
            return [...nonDemo, ...initialKitnetContracts];
          });
          kitnetsManagerRef.current.setKitnets((prev: any[]) => {
            const nonDemo = Array.isArray(prev) ? prev.filter((k) => !isDemoEntity(k)) : [];
            return [...nonDemo, ...initialKitnets];
          });
        }

        if (financeManager.setExpenses) {
          financeManager.setExpenses((prev: any[]) => {
            const nonDemo = Array.isArray(prev) ? prev.filter((e) => !isDemoEntity(e)) : [];
            return [...nonDemo, ...initialExpenses];
          });
        }

        financeManager.addTimelineEvent({
          type: 'documento_atualizado',
          title: 'Clientes Demo Ativados',
          description: 'Clientes e contratos demonstrativos carregados para teste completo do sistema.',
          entityType: 'sistema',
        });
        return true;
      } else {
        // Desligar Clientes Demo: remove qualquer dado demonstrativo mantendo dados reais
        setDemoModeActive(false);
        setIsDemoMode(false);
        setRealDataActive(true);
        setHasRealDataState(true);

        if (motosManagerRef.current) {
          motosManagerRef.current.setMotoTenants((prev: any[]) =>
            Array.isArray(prev) ? prev.filter((t) => !isDemoEntity(t)) : []
          );
          motosManagerRef.current.setMotoContracts((prev: any[]) =>
            Array.isArray(prev) ? prev.filter((c) => !isDemoEntity(c)) : []
          );
          motosManagerRef.current.setMotos((prev: any[]) =>
            Array.isArray(prev) ? prev.filter((m) => !isDemoEntity(m)) : []
          );
        }

        if (kitnetsManagerRef.current) {
          kitnetsManagerRef.current.setKitnetTenants((prev: any[]) =>
            Array.isArray(prev) ? prev.filter((t) => !isDemoEntity(t)) : []
          );
          kitnetsManagerRef.current.setKitnetContracts((prev: any[]) =>
            Array.isArray(prev) ? prev.filter((c) => !isDemoEntity(c)) : []
          );
          kitnetsManagerRef.current.setKitnets((prev: any[]) =>
            Array.isArray(prev) ? prev.filter((k) => !isDemoEntity(k)) : []
          );
        }

        if (financeManager.setExpenses) {
          financeManager.setExpenses((prev: any[]) =>
            Array.isArray(prev) ? prev.filter((e) => !isDemoEntity(e)) : []
          );
        }

        sanitizeStorageFromDemo();

        financeManager.addTimelineEvent({
          type: 'documento_atualizado',
          title: 'Clientes Demo Desativados',
          description: 'Dados demonstrativos removidos. Ambiente limpo e seguro para dados reais.',
          entityType: 'sistema',
        });
        return false;
      }
    },
    [isDemoMode, financeManager]
  );

  const handleSetStorageHealthWarning = useCallback((warning: boolean) => {
    setStorageHealthWarningState(warning);
    setStorageHealthWarning(warning);
  }, []);

  const guardMutation = useCallback(
    <Args extends unknown[], R>(fn: (...args: Args) => R, fallback: R): ((...args: Args) => R) => {
      return (...args: Args) => {
        if (authManager.isReadOnlyMode) {
          console.warn('[Modo Somente Leitura] Ação bloqueada: o sistema está em modo de leitura.');
          return fallback;
        }
        return fn(...args);
      };
    },
    [authManager.isReadOnlyMode]
  );

  const contextValue: AppContextType = useMemo(
    () => ({
      // Auth
      isAuthenticated: authManager.isAuthenticated,
      isLocked: authManager.isLocked,
      isDisconnecting: authManager.isDisconnecting,
      isLogoutDisconnect: authManager.isLogoutDisconnect,
      completeDisconnect: authManager.completeDisconnect,
      isReadOnlyMode: authManager.isReadOnlyMode,
      toggleReadOnlyMode: authManager.toggleReadOnlyMode,
      googleSession: authManager.googleSession,
      hasValidGoogleSession: authManager.hasValidGoogleSession,
      loginWithGoogle: authManager.loginWithGoogle,
      loginWithPin: authManager.loginWithPin,
      loginWithBiometrics: authManager.loginWithBiometrics,
      lockApp: authManager.lockApp,
      logout: authManager.logout,
      clearGoogleSession: authManager.clearGoogleSession,

      // Settings
      settings: settingsManager.settings,
      updateSettings: guardMutation(settingsManager.updateSettings, undefined),
      requestBrowserNotifications: settingsManager.requestBrowserNotifications,

      // Motos
      motos: motosManager.motos,
      motoTenants: motosManager.motoTenants,
      motoContracts: motosManager.motoContracts,
      addMoto: guardMutation(motosManager.addMoto, ''),
      duplicateMoto: guardMutation(motosManager.duplicateMoto, ''),
      updateMoto: guardMutation(motosManager.updateMoto, undefined),
      deleteMoto: guardMutation(motosManager.deleteMoto, undefined),
      addKmLog: guardMutation(motosManager.addKmLog, undefined),
      recordMotoDelivery: guardMutation(motosManager.recordMotoDelivery, undefined),
      addMotoMaintenance: guardMutation(motosManager.addMotoMaintenance, undefined),
      deleteMotoMaintenance: guardMutation(motosManager.deleteMotoMaintenance, undefined),
      addMotoTenant: guardMutation(motosManager.addMotoTenant, ''),
      updateMotoTenant: guardMutation(motosManager.updateMotoTenant, undefined),
      createMotoContract: guardMutation(motosManager.createMotoContract, ''),
      updateMotoContract: guardMutation(motosManager.updateMotoContract, undefined),
      adjustMotoContractRent: guardMutation(motosManager.adjustMotoContractRent, undefined),
      renewMotoContract: guardMutation(motosManager.renewMotoContract, undefined),
      payMotoInstallment: guardMutation(motosManager.payMotoInstallment, undefined),
      terminateMotoContract: guardMutation(motosManager.terminateMotoContract, undefined),

      // Kitnets
      kitnets: kitnetsManager.kitnets,
      kitnetTenants: kitnetsManager.kitnetTenants,
      kitnetContracts: kitnetsManager.kitnetContracts,
      addKitnet: guardMutation(kitnetsManager.addKitnet, ''),
      duplicateKitnet: guardMutation(kitnetsManager.duplicateKitnet, ''),
      updateKitnet: guardMutation(kitnetsManager.updateKitnet, undefined),
      deleteKitnet: guardMutation(kitnetsManager.deleteKitnet, undefined),
      recordKitnetInspection: guardMutation(kitnetsManager.recordKitnetInspection, undefined),
      addKitnetTenant: guardMutation(kitnetsManager.addKitnetTenant, ''),
      updateKitnetTenant: guardMutation(kitnetsManager.updateKitnetTenant, undefined),
      createKitnetContract: guardMutation(kitnetsManager.createKitnetContract, ''),
      adjustKitnetContractRent: guardMutation(kitnetsManager.adjustKitnetContractRent, undefined),
      renewKitnetContract: guardMutation(kitnetsManager.renewKitnetContract, undefined),
      payKitnetInstallment: guardMutation(kitnetsManager.payKitnetInstallment, undefined),
      terminateKitnetContract: guardMutation(kitnetsManager.terminateKitnetContract, undefined),

      // Expenses
      expenses: financeManager.expenses,
      addExpense: guardMutation(financeManager.addExpense, undefined),
      updateExpense: guardMutation(financeManager.updateExpense, undefined),
      payExpense: guardMutation(financeManager.payExpense, undefined),
      deleteExpense: guardMutation(financeManager.deleteExpense, undefined),

      // Timeline & Docs
      timeline: financeManager.timeline,
      documents: financeManager.documents,
      addTimelineEvent: guardMutation(financeManager.addTimelineEvent, undefined),
      clearTimeline: guardMutation(financeManager.clearTimeline, undefined),
      addDocument: guardMutation(financeManager.addDocument, undefined),
      deleteDocument: guardMutation(financeManager.deleteDocument, undefined),
      saveSignature: guardMutation(financeManager.saveSignature, undefined),

      // Backup & Restore
      exportBackup: financeManager.exportBackup,
      importBackup: guardMutation(financeManager.importBackup, false),
      resetToDefaults: guardMutation(financeManager.resetToDefaults, undefined),

      // Demo Data Isolation
      hasRealData: hasRealDataState,
      isDemoMode,
      toggleDemoMode,
      clearDemoDataAndStartFresh: guardMutation(clearDemoDataAndStartFresh, undefined),
      loadDemoData: guardMutation(loadDemoData, undefined),

      // Storage Health & Quota
      storageHealthWarning,
      setStorageHealthWarning: handleSetStorageHealthWarning,
    }),
    [
      authManager,
      guardMutation,
      settingsManager,
      motosManager,
      kitnetsManager,
      financeManager,
      hasRealDataState,
      isDemoMode,
      toggleDemoMode,
      clearDemoDataAndStartFresh,
      loadDemoData,
      storageHealthWarning,
      handleSetStorageHealthWarning,
    ]
  );

  return <AppContext.Provider value={contextValue}>{children}</AppContext.Provider>;
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

